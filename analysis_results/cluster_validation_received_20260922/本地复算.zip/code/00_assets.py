import core as c
from pathlib import Path
import re,json,base64,io
from PIL import Image,ImageDraw,ImageFont
import numpy as np

def main():
    s=(c.SOURCE/'analysis_results/cluster_screen_20260921/data.js').read_text()
    payload,end=json.JSONDecoder().raw_decode(s[s.index('=')+1:])
    images=re.findall(r'\{const image="(data:image/[^;]+;base64,[^"]+)";window.STUDIO_IMAGES\[(\d+)\]=\{original:image,texture:image\};\}',s)
    assert len(images)==24
    dest=c.ROOT/'evidence/original24';dest.mkdir(parents=True,exist_ok=True)
    for data,k in images:
        (dest/f'{int(k)+1:02d}.png').write_bytes(base64.b64decode(data.split(',',1)[1]))
    reviews=c.read(c.SOURCE/'analysis_results/cluster_screen_reviewed_20260922/逐项接收.json')
    rows,recs,views,reg,_=c.load()
    panels=[];assets=[]
    font=c.annotation_font(16)
    small=c.annotation_font(12)
    for idx,(case,review) in enumerate(zip(payload['cases'],reviews),1):
        im=Image.open(dest/f'{idx:02d}.png').convert('RGB');assets.append(dict(case=idx,image_id=case['image_id'],size=list(im.size),sha256=c.sha(dest/f'{idx:02d}.png')))
        panel=Image.new('RGB',(1024,552),'white');panel.paste(im.resize((1024,512)),(0,40));dr=ImageDraw.Draw(panel)
        dr.text((6,5),f"{idx:02d} {review['code']} | A={review['workers'][0]} B={review['workers'][1]} | max {review['fixed_max_px']:.3f} px",font=font,fill='black')
        for k,cid in enumerate(review['ids']):
            p=recs[cid]['p'];links=recs[cid]['links'];col=['#0072B2','#D55E00'][k]
            for a,b in links:
                aa=(float(p[a,0]),float(p[a,1])+40);bb=(float(p[b,0]),float(p[b,1])+40)
                if abs(aa[0]-bb[0])<512:dr.line([aa,bb],fill=col,width=2)
            for j,(x,y) in enumerate(p):
                y+=40
                if k==0:dr.ellipse((x-3,y-3,x+3,y+3),outline=col,width=2)
                else:dr.line((x-4,y-4,x+4,y+4),fill=col,width=2);dr.line((x+4,y-4,x-4,y+4),fill=col,width=2)
                dr.text((x+4,y+(3 if k else -14)),f'{"A" if k==0 else "B"}{j+1}',fill=col,font=small,stroke_width=1,stroke_fill='white')
        panel.save(c.ROOT/'evidence'/f'case_{idx:02d}_overlay.png');panels.append(panel)
    for start in range(0,24,4):
        sheet=Image.new('RGB',(1024,552*4),'white')
        for j,im in enumerate(panels[start:start+4]):sheet.paste(im,(0,j*552))
        sheet.save(c.ROOT/'evidence'/f'contact_{start+1:02d}_{start+4:02d}.jpg',quality=92)
    c.save('asset_manifest.json',assets)
    c.save('review24_original_decisions.json',reviews)
    print('Extracted and hashed 24 original images; overlays are derived, coordinates unmodified.')
if __name__=='__main__':main()
