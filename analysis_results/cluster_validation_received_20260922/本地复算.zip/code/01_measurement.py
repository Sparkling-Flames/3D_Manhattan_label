"""Raw/shared-x, correspondence, finite partitions, and membership influence.
All human cases are development evidence; no threshold is selected as validated.
"""
import core as c
import numpy as np,pandas as pd,itertools,json,time,gzip
from scipy.optimize import linear_sum_assignment

def main():
    rows,recs,views,reg,elig=c.load()
    pred_ids={cid for v in views.values() for cid in v['ids']}
    variants=['raw','snap01','snap02','snap05','snap1','snap_all','cyclic_raw','cyclic_snap02']
    reviews=c.read(c.SOURCE/'analysis_results/cluster_screen_reviewed_20260922/逐项接收.json')
    rev_i={r['image_id']:r for r in reviews}
    coord=[];responses=[];mats={};pts={};ps=[];parts={};cases=[];loo=[];cycles=[];flips=[]
    for cid in sorted(pred_ids):
        rec=recs[cid];r=rec['row'];p=rec['p'][rec['links']];dx=c.signed_x(p[:,1,0],p[:,0,0]);v=views[r['image_id']]
        for k,((top,bot),link) in enumerate(zip(p,rec['links'])):
            coord.append(dict(id=cid,image_id=r['image_id'],code=v['code'],building=v['building'],worker=r['worker_id'],pair_index=k+1,
                top_point=int(link[0])+1,bottom_point=int(link[1])+1,top_x=top[0],top_y=top[1],bottom_x=bot[0],bottom_y=bot[1],signed_gap_px=dx[k],gap_pp=abs(dx[k])*100/1024))
        responses.append(dict(id=cid,image_id=r['image_id'],code=v['code'],building=v['building'],worker=r['worker_id'],N=v['N'],pairs=len(p),max_gap_pp=max(abs(dx))*100/1024,
            median_gap_pp=np.median(abs(dx))*100/1024,signed_median_gap_pp=np.median(dx)*100/1024,new=cid.startswith('new_')))
    cp=pd.DataFrame(coord);rp=pd.DataFrame(responses)
    c.save('within_response_x_pairs.csv.gz',cp);c.save('within_response_x_responses.csv',rp)
    for variant in variants:
        mats[variant],pts[variant]=c.matrices(recs,views,variant)
        if variant=='raw':assert all(np.allclose(mats[variant][i],v['d'],rtol=0,atol=1e-9) for i,v in views.items())
        for iid,v in views.items():
            d=mats[variant][iid];a,b=np.triu_indices(v['N'],1)
            for cut in c.CUTS:
                for method in ['complete','representative']:
                    lab,centres=c.part(d,v['ids'],method,cut);parts[(variant,iid,method,cut)]=lab
                    ps.append(dict(variant=variant,image_id=iid,code=v['code'],building=v['building'],method=method,cut=cut,**c.stats(lab,d,cut)))
                    if iid in rev_i:
                        r=rev_i[iid];ia,ib=[v['ids'].index(z) for z in r['ids']];tar=r['target_same']
                        aa,bb=pts[variant][iid][ia],pts[variant][iid][ib]
                        dist,roll=c.distance(aa,bb,variant.startswith('cyclic'));bd=np.roll(bb,roll,0)
                        residual=c.endpoint_dist(aa,bd);ki,role=np.unravel_index(residual.argmax(),residual.shape)
                        cases.append(dict(case=r['case'],image_id=iid,code=v['code'],variant=variant,method=method,cut=cut,target_same=tar,
                            same_cluster=lab[ia]==lab[ib],direct_near=d[ia,ib]<=cut,match=None if tar is None else (lab[ia]==lab[ib])==tar,
                            max_px=d[ia,ib],top_max_px=residual[:,0].max(),bottom_max_px=residual[:,1].max(),
                            dx_max_px=abs(c.signed_x(aa[...,0],bd[...,0])).max(),dy_max_px=abs(aa[...,1]-bd[...,1]).max(),rms_px=np.sqrt(np.mean(residual**2)),
                            median_px=np.median(residual),limiting_pair=ki+1,limiting_role=['top','bottom'][role],roll=roll,
                            a_point=int(recs[r['ids'][0]]['links'][ki,role])+1,b_point=int(np.roll(recs[r['ids'][1]]['links'],roll,axis=0)[ki,role])+1))
        print('variant',variant,flush=True)
    for iid,v in views.items():
        raw=mats['raw'][iid];a,b=np.triu_indices(v['N'],1)
        for variant in variants[1:]:
            new=mats[variant][iid]
            for cut in c.CUTS:
                oldnear=raw[a,b]<=cut;newnear=new[a,b]<=cut
                for method in ['complete','representative']:
                    l0=parts[('raw',iid,method,cut)];l1=parts[(variant,iid,method,cut)]
                    change=(l0[a]==l0[b])!=(l1[a]==l1[b])
                    flips.append(dict(image_id=iid,code=v['code'],building=v['building'],N=v['N'],variant=variant,method=method,cut=cut,
                         pair_edge_changes=int(sum(oldnear!=newnear)),near_to_far=int(sum(oldnear&~newnear)),far_to_near=int(sum(~oldnear&newnear)),
                         coclustering_changes=int(change.sum()),members_relation_changed=int(len(set(a[change])|set(b[change]))),
                         K_raw=len(set(l0)),K_new=len(set(l1)),raw_singletons=c.stats(l0)['singletons'],new_singletons=c.stats(l1)['singletons']))
        for i,j in zip(a,b):
            if raw[i,j]>=c.SENTINEL:continue
            aa,bb=pts['raw'][iid][i],pts['raw'][iid][j];cy,shift=c.distance(aa,bb,True)
            if shift:
                cycles.append(dict(image_id=iid,code=v['code'],building=v['building'],a_id=v['ids'][i],b_id=v['ids'][j],a_worker=v['workers'][i],b_worker=v['workers'][j],N=v['N'],
                    raw=raw[i,j],cyclic=cy,shift=shift,crosses_25_6=raw[i,j]>25.6 and cy<=25.6,
                    raw_top_x=aa[:,0,0].tolist(),raw_bottom_x=aa[:,1,0].tolist(),b_top_x=bb[:,0,0].tolist(),b_bottom_x=bb[:,1,0].tolist()))
        if v['N']>=4:
            for variant in ['raw','snap02']:
                d=mats[variant][iid]
                for method in ['complete','representative']:
                    for cut in [25.6,1024/30]:
                        full=parts[(variant,iid,method,cut)]
                        for drop in range(v['N']):
                            ix=[k for k in range(v['N']) if k!=drop];lab,_=c.part(d[np.ix_(ix,ix)],[v['ids'][k] for k in ix],method,cut)
                            aa,bb=np.triu_indices(len(ix),1);f=full[ix];changed=(lab[aa]==lab[bb])!=(f[aa]==f[bb])
                            loo.append(dict(image_id=iid,code=v['code'],building=v['building'],N=v['N'],variant=variant,method=method,cut=cut,removed=v['workers'][drop],
                                surviving_pair_changes=int(sum(changed)),surviving_pairs=len(aa),fraction=changed.mean()))
    ps=pd.DataFrame(ps);flips=pd.DataFrame(flips);cases=pd.DataFrame(cases);loo=pd.DataFrame(loo)
    c.save('image_partition_sensitivity.csv.gz',ps);c.save('x_effect_on_memberships.csv.gz',flips)
    c.save('review24_comparisons.csv',cases);c.save('cyclic_candidates.csv',pd.DataFrame(cycles));c.save('leave_one_member_repartition.csv.gz',loo)
    c.save('partition_memberships.json.gz',{}) if False else None
    with gzip.open(c.OUT/'partition_memberships.json.gz','wt',encoding='utf8') as f:
        json.dump([dict(variant=v,image_id=i,method=m,cut=t,ids=views[i]['ids'],labels=lab.tolist()) for (v,i,m,t),lab in parts.items()],f,ensure_ascii=False)
    with gzip.open(c.OUT/'distance_variants.json.gz','wt',encoding='utf8') as f:
        json.dump({v:{i:d.tolist() for i,d in dm.items()} for v,dm in mats.items()},f)
    ag=[]
    for (v,m,t),z in ps[ps.N>=8].groupby(['variant','method','cut']):
        ag.append(dict(variant=v,method=m,cut=t,images=len(z),buildings=z.building.nunique(),mean_K=z.K.mean(),median_K=z.K.median(),
            mean_singleton_share=z.singleton_share.mean(),total_singletons=z.singletons.sum(),mean_largest_share=z.largest_share.mean(),
            few_J3_m2_s10=int(z.few_J3_m2_s10.sum()),few_J3_m2_s20=int(z.few_J3_m2_s20.sum()),near_split=int(z.near_split.sum()),far_joined=int(z.far_joined.sum())))
    c.save('partition_sensitivity_summary.csv',pd.DataFrame(ag))
    summs=[]
    for (v,m,t),z in cases[cases.target_same.notna()].groupby(['variant','method','cut']):
        summs.append(dict(variant=v,method=m,cut=t,decided=len(z),agree=int(z.match.astype(bool).astype(int).sum()),false_split=int((z.target_same&~z.same_cluster).sum()),false_merge=int((~z.target_same.astype(bool)&z.same_cluster).sum())))
    c.save('review24_development_agreement.csv',pd.DataFrame(summs))
    summ=dict(images=len(views),responses=len(pred_ids),workers=len(rp.worker.unique()),buildings=len(rp.building.unique()),x_pairs=len(cp),
        x_quantiles_pp=cp.gap_pp.quantile([.5,.9,.95,.99,1]).to_dict(),
        grids=[dict(gate_pp=g,pairs_nonzero_small=int(((cp.gap_pp>0)&(cp.gap_pp<=g)).sum()),pairs_large=int((cp.gap_pp>g).sum()),responses_any_large=int((rp.max_gap_pp>g).sum())) for g in [.1,.2,.5,1]],
        human_cases_development_only=True,no_raw_changes=True,baseline_matrix_max_difference=max(np.max(abs(mats['raw'][i]-v['d'])) for i,v in views.items()))
    c.save('measurement_summary.json',summ)
    c.save('worker_x_summary.csv',rp.groupby('worker').agg(responses=('id','size'),images=('image_id','nunique'),median_max_gap_pp=('max_gap_pp','median'),mean_median_gap_pp=('median_gap_pp','mean')).reset_index())
    print(json.dumps(c.clean(summ),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
