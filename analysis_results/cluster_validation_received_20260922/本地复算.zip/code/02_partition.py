"""Diameter-bounded affinity partition candidate; nontransitivity is measured explicitly.
Not a semantic validation and not chosen to optimise convergence.
"""
import core as c
import itertools,time,json
import numpy as np,pandas as pd
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

def affinity_partition(d,ids,cut=25.6,weight='quadratic',force=None,time_limit=6):
    """Maximise preserved close-pair affinity subject to equivalence and diameter.
    Each pair weight is 1 or (1-d/cut)^2. Triangle constraints enforce transitivity.
    Force is only a retrospective diagnostic, never a production use of human labels.
    """
    order=np.argsort(ids);d=np.round(d[np.ix_(order,order)],8);N=len(ids)
    ix={int(old):j for j,old in enumerate(order)}
    edges=list(itertools.combinations(range(N),2));ei={e:k for k,e in enumerate(edges)};E=len(edges)
    near=np.array([d[i,j]<=cut for i,j in edges],float)
    if not E:return np.ones(N,int),dict(status=0,objective=0,gap=0,certified=True)
    wt=np.ones(E) if weight=='uniform' else np.maximum(0,1-np.array([d[i,j] for i,j in edges])/cut)**2
    rr=[];cc=[];vv=[];r=0
    for i,j,k in itertools.combinations(range(N),3):
        es=[ei[(i,j)],ei[(i,k)],ei[(j,k)]]
        if sum(near[es])<2:continue
        for neg in es:
            rr.extend([r]*3);cc.extend(es);vv.extend([-1 if e==neg else 1 for e in es]);r+=1
    lb=np.zeros(E)
    if force is not None:
        a,b=sorted([ix[force[0]],ix[force[1]]]);lb[ei[(a,b)]]=1
        if near[ei[(a,b)]]==0:raise ValueError('Cannot force a far pair together')
    A=coo_matrix((vv,(rr,cc)),shape=(r,E)).tocsc()
    res=milp(-wt,integrality=np.ones(E),bounds=Bounds(lb,near),constraints=LinearConstraint(A,np.full(r,-np.inf),np.ones(r)),
             options={'time_limit':time_limit,'mip_rel_gap':0.0})
    if res.x is None:return None,dict(status=int(res.status),message=res.message,certified=False)
    xx=res.x>.5;adj=np.eye(N,dtype=int)
    for (i,j),same in zip(edges,xx):adj[i,j]=adj[j,i]=same
    n,lab=connected_components(adj,directed=False)
    assert all(adj[i,j] for i in range(N) for j in range(N) if lab[i]==lab[j])
    assert all(d[i,j]<=cut for i in range(N) for j in range(N) if lab[i]==lab[j])
    ans=np.empty(N,int);ans[order]=lab+1
    return ans,dict(status=int(res.status),objective=float(wt@xx),gap=float(res.mip_gap),certified=res.status==0)

def main():
    _,recs,views,reg,_=c.load();mats,_=c.matrices(recs,views,'raw')
    reviews=c.read(c.SOURCE/'analysis_results/cluster_screen_reviewed_20260922/逐项接收.json')
    manifest=c.read(c.SOURCE/'analysis_results/cluster_screen_20260921/REVIEW_MANIFEST.json')
    evidence=[];graph=[];revm=[];membership=[]
    for iid,v in views.items():
        d=mats[iid];N=v['N']
        for cut in [1024/60,25.6,1024/30]:
            triples=0;affected=set();examples=[]
            for i,j,k in itertools.combinations(range(N),3):
                es=[d[i,j]<=cut,d[i,k]<=cut,d[j,k]<=cut]
                if sum(es)==2:
                    triples+=1;affected.update([i,j,k])
                    if len(examples)<3:examples.append(dict(ids=[v['ids'][x] for x in [i,j,k]],workers=[v['workers'][x] for x in [i,j,k]],distances=[d[i,j],d[i,k],d[j,k]]))
            graph.append(dict(image_id=iid,code=v['code'],building=v['building'],N=N,cut=cut,nontransitive_triples=triples,affected_members=len(affected),examples=examples))
    for r,mc in zip(reviews,manifest['cases']):
        iid=r['image_id'];v=views[iid];d=mats[iid];ia,ib=[v['ids'].index(z) for z in r['ids']]
        for cut in [25.6,1024/30]:
            for weight in ['uniform','quadratic']:
                lab,info=affinity_partition(d,v['ids'],cut,weight)
                if lab is None:
                    revm.append(dict(case=r['case'],code=v['code'],weight=weight,cut=cut,**info));continue
                for method in ['complete','representative']:
                    old,_=c.part(d,v['ids'],method,cut)
                    aa,bb=np.triu_indices(v['N'],1);wt=np.ones(len(aa)) if weight=='uniform' else np.maximum(0,1-d[aa,bb]/cut)**2
                    objective=(wt*(old[aa]==old[bb])*(d[aa,bb]<=cut)).sum()
                    evidence.append(dict(case=r['case'],code=v['code'],cut=cut,weight=weight,baseline_method=method,baseline_preserved_affinity=objective,candidate_preserved_affinity=info['objective'],**c.stats(lab,d,cut)))
                revm.append(dict(case=r['case'],code=v['code'],weight=weight,cut=cut,target_same=r['target_same'],same_cluster=lab[ia]==lab[ib],
                    match=None if r['target_same'] is None else (lab[ia]==lab[ib])==r['target_same'],**info,**c.stats(lab,d,cut)))
                membership.append(dict(case=r['case'],code=v['code'],cut=cut,weight=weight,ids=v['ids'],workers=v['workers'],labels=lab.tolist(),**info))
                if r['case']<=4 and cut==25.6 and weight=='quadratic':
                    forced,fi=affinity_partition(d,v['ids'],cut,weight,force=(ia,ib))
                    evidence.append(dict(case=r['case'],code=v['code'],cut=cut,weight=weight,baseline_method='forced_reviewed_near_pair_diagnostic',
                        baseline_preserved_affinity=info['objective'],candidate_preserved_affinity=fi.get('objective'),**({} if forced is None else c.stats(forced,d,cut))))
        print('MILP case',r['case'],flush=True)
    c.save('nontransitivity_per_image.json',graph)
    c.save('affinity_partition_development.csv',pd.DataFrame(revm));c.save('affinity_partition_objectives.csv',pd.DataFrame(evidence));c.save('affinity_partition_memberships.json',membership)
    print('Done',flush=True)
if __name__=='__main__':main()
