"""Execute extracted, pinned JavaScript preview routines on effective point sets.
This audits code mechanics, NOT which deployed UI/version a worker used.
"""
import core as c
import numpy as np,pandas as pd,json,subprocess

def main():
    _,recs,views,_,_=c.load()
    userscript=c.SOURCE/'tools/label_studio/official/ls_userscript_annotator.js'
    viewer=c.SOURCE/'tools/label_studio/vis_3d.html'
    s=userscript.read_text();v=viewer.read_text()
    a=s.index('          points.sort((a, b) => a.x - b.x);',s.index('HoHoNet: 原始点:'))
    b=s.index('          const previewTaskKey',a)
    pairing=s[a:b]
    a=v.index('      function projectCornersForViewer(corners)');b=v.index('      function renderGeometry',a)
    projection=v[a:b]
    runner="""const fs=require('fs');const W=1024,H=512;
const THREE={Vector3:class{constructor(x,y,z){this.x=x;this.y=y;this.z=z;}}};
"""+projection+"\nfunction pair(points){\n"+pairing+"\nreturn {pairs:pairedDefault,unused:points.filter((p,i)=>!used[i])};}\n"+"""
const data=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const out=data.map(r=>{let z=pair(r.points);return {id:r.id,...z,projection:projectCornersForViewer(z.pairs)};});
fs.writeFileSync(process.argv[3],JSON.stringify(out));
"""
    tmp=c.ROOT/'evidence/preview_execution';tmp.mkdir(parents=True,exist_ok=True)
    (tmp/'pinned_routines.js').write_text(runner)
    ids=[cid for v in views.values() for cid in v['ids']]
    inputs=[dict(id=cid,points=[dict(x=p[0],y=p[1],original_point=i+1) for i,p in enumerate(recs[cid]['p'])]) for cid in ids]
    (tmp/'inputs.json').write_text(json.dumps(c.clean(inputs)))
    run=subprocess.run(['node',str(tmp/'pinned_routines.js'),str(tmp/'inputs.json'),str(tmp/'outputs.json')],capture_output=True,text=True,check=True)
    out=c.read(tmp/'outputs.json');rows=[];bad=[];dx=[];maxerr=0
    for r in out:
        cid=r['id'];rec=recs[cid];row=rec['row'];view=views[row['image_id']]
        expected={tuple(sorted((link+1).tolist())) for link in rec['links']}
        actual={tuple(sorted(p['original_point'] for p in q['originalPoints'])) for q in r['pairs']}
        for j,(q,ceil,floor) in enumerate(zip(r['pairs'],r['projection']['ceilPoints'],r['projection']['floorPoints'])):
            u=q['x']/1024*2*np.pi-np.pi
            vf=(q['y_floor']/512-.5)*np.pi;vc=(q['y_ceiling']/512-.5)*np.pi
            dist=1.6/np.tan(np.clip(vf,.01,1.5));xx=dist*np.sin(u);zz=-dist*np.cos(u);yy=-dist*np.tan(np.clip(vc,-1.5,-.01))
            maxerr=max(maxerr,abs(xx-floor['x']),abs(zz-floor['z']),abs(yy-ceil['y']))
            dx.append(dict(id=cid,code=view['code'],pair=j+1,points=[p['original_point'] for p in q['originalPoints']],same_hemisphere=(q['y_ceiling']>=256 or q['y_floor']<=256),floor_clipped=not(.01<=vf<=1.5),ceiling_clipped=not(-1.5<=vc<=-.01),mean_x=q['x'],y_ceiling=q['y_ceiling'],y_floor=q['y_floor']))
        rr=dict(id=cid,code=view['code'],image_id=view['image_id'],building=view['building'],worker=row['worker_id'],expected_pairs=len(expected),actual_pairs=len(actual),unmatched_points=len(r['unused']),pair_sets_equal=expected==actual,wrong_pairs=len(actual-expected))
        rows.append(rr)
        if expected!=actual:
            bad.append(dict(**rr,expected_pairs_1based=sorted(expected),actual_pairs_1based=sorted(actual),wrong_pairs_1based=sorted(actual-expected),points=rec['p'].tolist(),unused_points=r['unused']))
    df=pd.DataFrame(rows);details=pd.DataFrame(dx)
    c.save('preview_pairing_comparison.csv',df);c.save('preview_pairing_discrepancies.json',bad);c.save('preview_projection_pairs.csv.gz',details)
    summ=dict(responses=len(df),different_pair_sets=int((~df.pair_sets_equal).sum()),affected_images=int(df.loc[~df.pair_sets_equal,'image_id'].nunique()),unmatched_response_count=int((df.unmatched_points>0).sum()),default_pairs=len(details),same_hemisphere_pairs=int(details.same_hemisphere.sum()),floor_clipped_pairs=int(details.floor_clipped.sum()),ceiling_clipped_pairs=int(details.ceiling_clipped.sum()),python_javascript_max_numeric_difference=maxerr,userscript_sha256=c.sha(userscript),viewer_sha256=c.sha(viewer),node_version=subprocess.check_output(['node','--version'],text=True).strip(),scope='Pinned preview default pairing on effective points; not evidence of actual deployment or historical user behaviour')
    c.save('preview_mechanism_summary.json',summ);print(json.dumps(c.clean(summ),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
