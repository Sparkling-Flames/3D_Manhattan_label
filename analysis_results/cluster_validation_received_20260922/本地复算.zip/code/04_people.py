"""Outer-building held-out PERSON tendencies and finite real-team variation.
Centred outcomes are conditional person contrasts, not pre-annotation image prediction.
No GT/model outputs are newly used as explanatory variables; historical named rosters
are evaluated as supplied (and retain their original source semantics).
"""
import core as c
import pandas as pd,numpy as np,gzip,json,itertools,math,collections

SPEC=[('raw',25.6),('snap02',25.6),('raw',1024/30)]
CONFIG=['Q_2','QTSB_3','TRI_3']
def main():
 _,recs,views,_,_=c.load()
 with gzip.open(c.OUT/'distance_variants.json.gz','rt') as f: allm=json.load(f)
 ro=pd.read_csv(c.SOURCE/'analysis_results/clustering_numeric_received_20260920/results/personnel/refitted_lobo_rosters.csv')
 pred=[];profiles=[];teamsout=[];ranges=[]
 rng=np.random.default_rng(c.SEED)
 teams={}
 for iid,v in views.items():
  if v['N']<=8:continue
  N=v['N'];total=math.comb(N,8)
  if total<=2000:teams[iid]=np.array(list(itertools.combinations(range(N),8)),int)
  else:
   z=set()
   while len(z)<2000:z.add(tuple(sorted(rng.choice(N,8,replace=False))))
   teams[iid]=np.array(sorted(z),int)
 for variant,cut in SPEC:
  rr=[]
  for iid,v in views.items():
   if v['N']<4:continue
   d=np.asarray(allm[variant][iid]);K=np.array([len(recs[cid]['links']) for cid in v['ids']]);N=v['N']
   y=(d>cut).sum(1)/(N-1);yk=(K[:,None]!=K[None,:]).sum(1)/(N-1)
   for j,w in enumerate(v['workers']):rr.append(dict(image_id=iid,code=v['code'],building=v['building'],worker=w,N=N,y=y[j]-y.mean(),yc=yk[j]-yk.mean(),raw_y=y[j],raw_yc=yk[j]))
  wr=pd.DataFrame(rr)
  for building in sorted(wr.building.unique()):
   tr=wr[wr.building!=building];te=wr[wr.building==building]
   assert building not in set(tr.building)
   for col in ['y','yc']:
    if col=='yc' and (variant,cut)!=SPEC[0]:continue
    bt=tr.groupby(['worker','building'])[col].mean();nb=bt.groupby('worker').size();nt=tr.groupby('worker').size()
    eff=bt.groupby('worker').mean()*nt/(nt+20);qual=(nt>=4)&(nb>=2);eff=eff.where(qual,0)
    p0=te.worker.map(eff).fillna(0);q0=te.worker.map(qual).fillna(False)
    outmodels=[('continuous_shrink20',p0,q0)]
    sign={w:('positive' if eff[w]>0 else 'negative') if qual.get(w,False) else 'U' for w in eff.index}
    cl=tr.worker.map(sign).fillna('U');est=tr.assign(cls=cl).groupby(['building','cls'])[col].mean().groupby('cls').mean().to_dict();est['U']=0
    outmodels.append(('fixed_sign_discrete',te.worker.map(sign).fillna('U').map(est).fillna(0),q0))
    for conf in CONFIG:
     r=ro[(ro.heldout_building==building)&(ro.config==conf)].drop_duplicates('worker').set_index('worker')
     cls=r.subtype.astype(str).to_dict()
     zz=tr.assign(cls=tr.worker.map(cls).fillna('U'))
     est=zz.groupby(['building','cls'])[col].mean().groupby('cls').mean().to_dict();est['U']=0
     ll=te.worker.map(cls).fillna('U')
     outmodels.append(('historical_'+conf,ll.map(est).fillna(0),ll!='U'))
    for model,pp,qq in outmodels:
     for (_,r),p,q in zip(te.iterrows(),pp,qq):pred.append(dict(variant=variant,cut=cut,outcome=col,model=model,image_id=r.image_id,code=r.code,building=building,worker=r.worker,N=r.N,y=r[col],prediction=p,qualified=bool(q)))
    for w in sorted(wr.worker.unique()):profiles.append(dict(variant=variant,cut=cut,outcome=col,heldout_building=building,worker=w,effect=eff.get(w,0),images=nt.get(w,0),buildings=nb.get(w,0),qualified=bool(qual.get(w,False)),training_buildings=';'.join(sorted(tr.loc[tr.worker==w,'building'].unique()))))
  aa,bb=np.triu_indices(8,1)
  for iid,tt in teams.items():
   v=views[iid];d=np.asarray(allm[variant][iid]);yy=(d[tt[:,aa],tt[:,bb]]>cut).mean(1);var=yy.var();N=v['N']
   for config in CONFIG:
    r=ro[(ro.heldout_building==v['building'])&(ro.config==config)].drop_duplicates('worker').set_index('worker')
    labels=np.array([str(r.loc[w,'subtype']) if w in r.index else 'U' for w in v['workers']]);kinds=sorted(set(labels));X=np.stack([(labels[tt]==k).sum(1) for k in kinds],1)
    buckets=collections.defaultdict(list)
    for j,x in enumerate(X):buckets[tuple(x)].append(j)
    within=sum(len(ix)*yy[ix].var()/len(tt) for ix in buckets.values());between=sum(len(ix)*(yy[ix].mean()-yy.mean())**2/len(tt) for ix in buckets.values())
    assert np.isclose(var,within+between)
    spreads=[np.quantile(yy[ix],.9)-np.quantile(yy[ix],.1) for ix in buckets.values() if len(ix)>=20]
    teamsout.append(dict(variant=variant,cut=cut,image_id=iid,code=v['code'],building=v['building'],N=N,n=8,config=config,teams=len(tt),feasible=math.comb(N,8),compositions=len(buckets),total_variance=var,within_variance=within,within_fraction=within/var if var>1e-14 else np.nan,within_q90q10=np.median(spreads) if spreads else np.nan))
   ranges.append(dict(variant=variant,cut=cut,image_id=iid,code=v['code'],building=v['building'],N=N,n=8,teams=len(tt),q10=np.quantile(yy,.1),q50=np.median(yy),q90=np.quantile(yy,.9)))
  print('people',variant,cut,flush=True)
 pr=pd.DataFrame(pred);pr['mse']=(pr.y-pr.prediction)**2;pr['base_mse']=pr.y**2
 summaries=[]
 for key,z in pr.groupby(['variant','cut','outcome','model']):
  gg=z.groupby(['building','image_id'])[['mse','base_mse']].mean().groupby('building').mean();gain=gg.base_mse-gg.mse
  rr=np.random.default_rng(c.SEED);ci=np.quantile(rr.choice(gain.to_numpy(),(3000,len(gain)),replace=True).mean(1),[.025,.975])
  summaries.append(dict(variant=key[0],cut=key[1],outcome=key[2],model=key[3],responses=len(z),images=z.image_id.nunique(),buildings=len(gg),mse=gg.mse.mean(),base_mse=gg.base_mse.mean(),relative_gain=1-gg.mse.mean()/gg.base_mse.mean(),absolute_gain= gain.mean(),conditional_gain_interval95=ci,unclassified=int((~z.qualified).sum())))
 ts=pd.DataFrame(teamsout);sums=[]
 for key,z in ts.groupby(['variant','cut','config']):
  zz=z[z.total_variance>1e-14];sums.append(dict(variant=key[0],cut=key[1],config=key[2],images=len(z),variable_images=len(zz),buildings=zz.building.nunique(),mean_within_fraction=zz.within_fraction.mean(),building_equal_within_fraction=zz.groupby('building').within_fraction.mean().mean(),median_within_q90q10=zz.within_q90q10.median()))
 c.save('worker_predictions_new.csv.gz',pr);c.save('worker_profiles_new.csv.gz',pd.DataFrame(profiles));c.save('worker_prediction_summary_new.json',summaries)
 c.save('teams_n8_variance.csv',ts);c.save('teams_n8_ranges.csv',pd.DataFrame(ranges));c.save('teams_n8_summary.json',sums)
 print('done',flush=True)
if __name__=='__main__':main()
