"""Exploratory full-corpus application of a diameter-bounded candidate. No validation labels fitted."""
import core as c
import importlib.util,numpy as np,pandas as pd,gzip,json,time
spec=importlib.util.spec_from_file_location('ap',c.ROOT/'code/02_partition.py');ap=importlib.util.module_from_spec(spec);spec.loader.exec_module(ap)
def main():
 _,_,views,_,_=c.load();rows=[];members=[]
 for j,(iid,v) in enumerate(sorted(views.items())):
  lab,info=ap.affinity_partition(v['d'],v['ids'],25.6,'quadratic',time_limit=10)
  if lab is not None:
   rows.append(dict(image_id=iid,code=v['code'],building=v['building'],**info,**c.stats(lab,v['d'])))
   members.append(dict(image_id=iid,ids=v['ids'],workers=v['workers'],labels=lab.tolist(),**info))
  else:rows.append(dict(image_id=iid,code=v['code'],building=v['building'],N=v['N'],**info))
  if j%30==0:print(j,len(views),flush=True)
 c.save('affinity_corpus.csv',pd.DataFrame(rows));c.save('affinity_corpus_memberships.json',members)
 print('Done',flush=True)
if __name__=='__main__':main()
