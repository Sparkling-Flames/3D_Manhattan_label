"""Finite real-person consensus/repeated-expression persistence, NOT a replacement by coverage.
Provisional rules: up to J repeatedly supported clusters cover 80/90%; m=2/3.
Persistence checks all later observed prefixes against the candidate prefix, with
aligned cluster-share TV<=.1 and old-member coassignment change<=.05.
At least h=3/5 remaining observed people. No inference beyond the finite pool.
"""
import core as c
import numpy as np,pandas as pd,gzip,json,itertools
from scipy.optimize import linear_sum_assignment
SPECS=[('raw','complete',25.6),('snap02','complete',25.6),('raw','complete',1024/30),('raw','representative',25.6)]
RULES=[(3,2,.1),(3,2,.2),(3,3,.1),(2,2,.1)]
ORDERS=80

def compare_prefix(a,b):
 # b's first len(a) members are exactly the same real people as a, in the same order.
 _,a=np.unique(a,return_inverse=True);_,b=np.unique(b,return_inverse=True);k=len(a);N=len(b)
 ka=max(a)+1;kb=max(b)+1;over=np.zeros((ka,kb),int)
 np.add.at(over,(a,b[:k]),1)
 ii,jj=linear_sum_assignment(-over)
 pa=np.bincount(a,minlength=ka)/k;pb=np.bincount(b,minlength=kb)/N
 tv=.5*(sum(abs(pa[i]-pb[j]) for i,j in zip(ii,jj))+sum(pa[i] for i in set(range(ka))-set(ii))+sum(pb[j] for j in set(range(kb))-set(jj)))
 x,y=np.triu_indices(k,1);flip=np.mean((a[x]==a[y])!=(b[x]==b[y])) if len(x) else 0.
 return float(tv),float(flip)

def main():
 _,_,views,_,_=c.load()
 with gzip.open(c.OUT/'distance_variants.json.gz','rt') as f:mats=json.load(f)
 workers=sorted({w for v in views.values() for w in v['workers']});rng=np.random.default_rng(c.SEED)
 globalorders=[rng.permutation(workers).tolist() for _ in range(ORDERS)];out=[];prefix=[]
 for variant,method,cut in SPECS:
  for ni,(iid,v) in enumerate(sorted(views.items())):
   N=v['N']
   if N<8:continue
   d=np.asarray(mats[variant][iid]);wix={w:j for j,w in enumerate(v['workers'])};cache={}
   for oi,order in enumerate(globalorders):
    perm=[wix[w] for w in order if w in wix];labs={};states={rule:{} for rule in RULES}
    for k in range(4,N+1):
     ss=tuple(sorted(perm[:k]))
     if ss not in cache:cache[ss]=c.part(d[np.ix_(ss,ss)],[v['ids'][j] for j in ss],method,cut)[0]
     lookup=dict(zip(ss,cache[ss]));lab=np.array([lookup[j] for j in perm[:k]]);labs[k]=lab
     counts=np.unique(lab,return_counts=True)[1]
     for J,m,s in RULES:states[(J,m,s)][k]=sum(sorted(counts[counts>=m],reverse=True)[:J])/k>=1-s-1e-10
     prefix.append(dict(variant=variant,method=method,cut=cut,image_id=iid,code=v['code'],building=v['building'],N=N,order=oi,k=k,K=len(counts),singleton_share=sum(counts==1)/k,counts=';'.join(map(str,sorted(counts,reverse=True)))))
    drift={}
    for k in range(4,N-2):
     # Exact short circuit: an anchor failing every support rule cannot be an onset.
     # No prefix labels or outcomes are changed; only unnecessary retrospective checks are skipped.
     if not any(all(st[n] for n in range(k,N+1)) for st in states.values()):
      drift[k]=False;continue
     drift[k]=True
     for n in range(k+1,N+1):
      tv,flip=compare_prefix(labs[k],labs[n])
      if tv>.1+1e-10 or flip>.05+1e-10:
       drift[k]=False;break
    for J,m,s in RULES:
     st=states[(J,m,s)]
     for h in [3,5]:
      starts=[k for k in range(4,N-h+1) if all(st[n] for n in range(k,N+1)) and drift.get(k,False)]
      out.append(dict(variant=variant,method=method,cut=cut,image_id=iid,code=v['code'],building=v['building'],N=N,order=oi,J=J,m=m,tail_fraction=s,h=h,endpoint_pass=st[N],observed_onset=min(starts) if starts else np.nan,eligible_anchor_positions=max(0,N-h-3)))
   if ni%40==0:print(variant,method,cut,ni,flush=True)
  print('finished spec',variant,method,cut,flush=True)
 df=pd.DataFrame(out);rows=[]
 for key,z in df.groupby(['variant','method','cut','J','m','tail_fraction','h','image_id'],sort=False):
  success=z.observed_onset.dropna();rows.append(dict(variant=key[0],method=key[1],cut=key[2],J=key[3],m=key[4],tail_fraction=key[5],h=key[6],image_id=key[7],code=z.code.iloc[0],building=z.building.iloc[0],N=z.N.iloc[0],orders=len(z),endpoint_pass=bool(z.endpoint_pass.iloc[0]),success_fraction=len(success)/len(z),observed_onset_median_success_only=success.median() if len(success) else np.nan,observed_onset_q10_success_only=success.quantile(.1) if len(success) else np.nan,observed_onset_q90_success_only=success.quantile(.9) if len(success) else np.nan,no_anchor_room=z.eligible_anchor_positions.iloc[0]==0))
 im=pd.DataFrame(rows);summ=[]
 for key,z in im.groupby(['variant','method','cut','J','m','tail_fraction','h']):
  summ.append(dict(variant=key[0],method=key[1],cut=key[2],J=key[3],m=key[4],tail_fraction=key[5],h=key[6],images=len(z),buildings=z.building.nunique(),endpoint_pass=int(z.endpoint_pass.sum()),no_observation_room=int(z.no_anchor_room.sum()),images_any_success=int((z.success_fraction>0).sum()),images_ge80pct_orders=int((z.success_fraction>=.8).sum()),mean_success_fraction=z.success_fraction.mean(),building_equal_success=z.groupby('building').success_fraction.mean().mean()))
 c.save('consensus_replay_orders.json',globalorders);c.save('consensus_replay_per_order.csv.gz',df);c.save('consensus_replay_prefixes.csv.gz',pd.DataFrame(prefix));c.save('consensus_replay_per_image.csv',im);c.save('consensus_replay_summary.csv',pd.DataFrame(summ))
 print('Done',flush=True)
if __name__=='__main__':main()
