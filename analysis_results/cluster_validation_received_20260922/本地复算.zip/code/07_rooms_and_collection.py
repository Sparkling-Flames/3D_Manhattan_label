"""Audited room relations, identical-human controls, and optional first-response costs.
No model features. Doorway working label is NOT a comprehensive occlusion/closed-room label.
"""
import core as c
import numpy as np,pandas as pd,collections,itertools,json,gzip,math
SPECS=[('raw',25.6),('snap02',25.6),('raw',1024/30)]
def main():
 rows,recs,views,reg,_=c.load()
 from tools.thesis_main.analysis.audit_collection_plan_20260921 import blocks
 candidates=[x for x in reg['candidates'] if x['physical_same_supported']];family=blocks(candidates)
 meta={x['image_id']:x for x in c.read(c.SOURCE/'analysis_results/spatial_dimensions_review_20260913_v2/空间描述与历轮人工记录.json')['images']}
 adj=collections.defaultdict(set);comp=collections.defaultdict(set);edges=collections.defaultdict(list);exp=collections.defaultdict(set)
 for ca in candidates:
  ids=[i for i in ca['image_ids'] if i in views]
  for a,b in itertools.combinations(ids,2):
   adj[a].add(b);adj[b].add(a);edges[tuple(sorted((a,b)))].append(ca['candidate_id'])
   if ca['comparable_for_prediction']:comp[a].add(b);comp[b].add(a)
   if ca.get('outcome_exposure'):exp[a].add(b);exp[b].add(a)
 with gzip.open(c.OUT/'distance_variants.json.gz','rt') as f:mats=json.load(f)
 predictions=[];paired=[];door=[];doorpairs=[];fixed=[]
 def mean_sources(ids,vals):
  z=pd.DataFrame([dict(building=views[i]['building'],family=family.get(i,i),value=vals[i]) for i in ids]);return z.groupby(['building','family']).value.mean().groupby('building').mean().mean()
 for variant,cut in SPECS:
  dd={i:np.asarray(d) for i,d in mats[variant].items()}
  for metric in ['pair_disagreement','singleton_mass','core3_mass']:
   vals={}
   for iid,v in views.items():
    if v['N']<8:continue
    d=dd[iid];n=len(d)
    if metric=='pair_disagreement':y=np.mean(d[np.triu_indices(n,1)]>cut)
    else:
     lab,_=c.part(d,v['ids'],'complete',cut);co=np.unique(lab,return_counts=True)[1]
     y=np.sum(co==1)/n if metric=='singleton_mass' else sum(sorted(co[co>=2],reverse=True)[:3])/n
    vals[iid]=y
    if metric=='pair_disagreement':
     dr=meta[iid].get('doorway_reconciliation',{});label=dr.get('current_working_label','unknown')
     door.append(dict(variant=variant,cut=cut,image_id=iid,code=v['code'],building=v['building'],family=family.get(iid,iid),N=n,doorway_label=label,source=dr.get('source'),coarse=meta[iid].get('current_coarse_review',{}).get('value'),pair_disagreement=y))
   for i,y in vals.items():
    outside=[j for j in vals if views[j]['building']!=views[i]['building']]
    otherroom=[j for j in vals if views[j]['building']==views[i]['building'] and family.get(j,j)!=family.get(i,i)]
    for kind,srcs in [('physical_same',adj[i]),('comparable_same',comp[i])]:
     src=sorted(j for j in srcs if j in vals)
     if not src or not outside:continue
     predictions.append(dict(variant=variant,cut=cut,metric=metric,kind=kind,image_id=i,code=views[i]['code'],building=views[i]['building'],family=family.get(i,i),N=views[i]['N'],value=y,prediction=np.mean([vals[j] for j in src]),outside_baseline=mean_sources(outside,vals),otherroom_baseline=mean_sources(otherroom,vals) if otherroom else np.nan,source_codes=';'.join(views[j]['code'] for j in src),source_N=';'.join(str(views[j]['N']) for j in src),outcome_exposed=any(j in exp[i] for j in src)))
  for a,b in edges:
   va,vb=views[a],views[b];wa={w:j for j,w in enumerate(va['workers'])};wb={w:j for j,w in enumerate(vb['workers'])};ww=sorted(set(wa)&set(wb));N=len(ww)
   if N<8:continue
   ia=[wa[w] for w in ww];ib=[wb[w] for w in ww];da=dd[a][np.ix_(ia,ia)];db=dd[b][np.ix_(ib,ib)];tri=np.triu_indices(N,1)
   qa=np.mean(da[tri]>cut);qb=np.mean(db[tri]>cut)
   allqa=np.mean(dd[a][np.triu_indices(va['N'],1)]>cut);allqb=np.mean(dd[b][np.triu_indices(vb['N'],1)]>cut)
   lab_a=meta[a].get('doorway_reconciliation',{}).get('current_working_label');lab_b=meta[b].get('doorway_reconciliation',{}).get('current_working_label')
   pp=dict(variant=variant,cut=cut,a_id=a,b_id=b,a_code=va['code'],b_code=vb['code'],building=va['building'],family=family.get(a,a),common_N=N,a_N=va['N'],b_N=vb['N'],workers=';'.join(ww),comparable=b in comp[a],candidates=';'.join(edges[a,b]),common_a=qa,common_b=qb,common_gap=abs(qa-qb),all_gap=abs(allqa-allqb),a_doorway=lab_a,b_doorway=lab_b)
   paired.append(pp)
   if {lab_a,lab_b}=={'确认','否'}:doorpairs.append(dict(**pp,confirmed_minus_no=qa-qb if lab_a=='确认' else qb-qa))
   # Same 8 real people in both views; descriptive rarefaction, not more independent data.
   rng=np.random.default_rng(c.SEED+sum(ord(z) for z in a+b));total=math.comb(N,8)
   if total<=100:ts=list(itertools.combinations(range(N),8))
   else:
    ts=set()
    while len(ts)<100:ts.add(tuple(sorted(rng.choice(N,8,replace=False))))
    ts=sorted(ts)
   scores=[]
   for ix in ts:
    vals=[]
    for d,iids,idx in [(da,va['ids'],ia),(db,vb['ids'],ib)]:
     lab,_=c.part(d[np.ix_(ix,ix)],[iids[idx[j]] for j in ix],'complete',cut);co=np.unique(lab,return_counts=True)[1]
     vals.append(sum(sorted(co[co>=2],reverse=True)[:3])/8>=.9-1e-10)
    scores.append(vals)
   ss=np.array(scores,dtype=int)
   fixed.append(dict(**pp,n=8,evaluated_common_teams=len(ts),feasible_common_teams=total,p_current_few_a=ss[:,0].mean(),p_current_few_b=ss[:,1].mean(),same_team_discordance=(ss[:,0]!=ss[:,1]).mean()))
  print('rooms',variant,cut,flush=True)
 pr=pd.DataFrame(predictions)
 for name in ['prediction','outside_baseline','otherroom_baseline']:pr['error_'+name]=abs(pr.value-pr[name])
 sums=[]
 for key,z in pr.groupby(['variant','cut','metric','kind']):
  for shared in [False,True]:
   zz=z[z.otherroom_baseline.notna()] if shared else z
   if not len(zz):continue
   gg=zz.groupby(['building','family'])[['error_prediction','error_outside_baseline','error_otherroom_baseline']].mean().groupby('building').mean()
   gain=gg.error_outside_baseline-gg.error_prediction;rng=np.random.default_rng(c.SEED);ci=np.quantile(rng.choice(gain.to_numpy(),(3000,len(gain)),replace=True).mean(1),[.025,.975])
   sums.append(dict(variant=key[0],cut=key[1],metric=key[2],kind=key[3],same_panel_otherroom=shared,images=len(zz),families=zz.family.nunique(),buildings=len(gg),MAE=gg.error_prediction.mean(),outside_MAE=gg.error_outside_baseline.mean(),samebuilding_otherroom_MAE=gg.error_otherroom_baseline.mean(),conditional_gain_interval95=ci,outcome_exposed=int(zz.outcome_exposed.sum())))
 c.save('room_predictions_new.csv',pr);c.save('room_summary_new.json',sums);c.save('room_identical_workers_new.csv',pd.DataFrame(paired));c.save('room_matched_n8_current_consensus.csv',pd.DataFrame(fixed));c.save('doorway_descriptive_images.csv',pd.DataFrame(door));c.save('doorway_identical_workers_pairs.csv',pd.DataFrame(doorpairs))
 # Optional minimal coverage plans, excluding future W011 while retaining historical observations.
 workers={w for v in views.values() for w in v['workers']};exposure=collections.defaultdict(set)
 for r in rows:exposure[r['image_id']].add(r['worker_id'])
 for r in c.read(c.SOURCE/'import_json/scene_stability_stage1_20260913_v2/historical_exposure.json'):exposure[r['image_id']].add(f"W{int(r['worker_id']):03d}")
 costs=[];plans=[]
 for ca in candidates:
  if not ca['comparable_for_prediction']:continue
  for a,b in itertools.combinations([i for i in ca['image_ids'] if i in views and views[i]['N']>=8],2):
   va,vb=views[a],views[b];A=set(va['workers']);B=set(vb['workers']);common=A&B
   candidates_w={w:2-int(w in A)-int(w in B) for w in workers if (w in common or w!='W011') and (w in A or w not in exposure[a]) and (w in B or w not in exposure[b])}
   order=sorted(candidates_w,key=lambda w:(candidates_w[w],w))
   r=dict(candidate=ca['candidate_id'],building=va['building'],a_code=va['code'],b_code=vb['code'],a_id=a,b_id=b,a_N=len(A),b_N=len(B),common_N=len(common),feasible_workers=len(order),future_W011_excluded=True)
   for H in [12,16,20]:r['additional_for_common_'+str(H)]=sum(candidates_w[w] for w in order[:H]) if len(order)>=H else None
   costs.append(r)
   for H in [12,16]:
    if len(order)<H:continue
    for w in order[:H]:
     for iid,seen in [(a,A),(b,B)]:
      if w not in seen:plans.append(dict(candidate=ca['candidate_id'],building=va['building'],a_code=va['code'],b_code=vb['code'],target_common_N=H,worker=w,image_id=iid,code=views[iid]['code'],selection='minimal number first responses; lexicographic tie; NOT performance selection; availability unverified',known_exposure=False))
 c.save('optional_collection_costs_new.csv',pd.DataFrame(costs).sort_values(['additional_for_common_12','building','a_code','b_code']).drop_duplicates(['a_id','b_id']));c.save('optional_collection_assignments_new.csv',pd.DataFrame(plans).drop_duplicates(['a_code','b_code','target_common_N','worker','image_id']))
 print('Done',flush=True)
if __name__=='__main__':main()
