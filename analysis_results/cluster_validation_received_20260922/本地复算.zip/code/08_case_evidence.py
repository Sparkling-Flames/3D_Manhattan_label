"""Precisely annotated source-image crops and complete-member numerical context.
No visual judgement is written into the original review or numerical metric.
"""
import core as c
import pandas as pd,numpy as np,json,html
from PIL import Image,ImageDraw,ImageFont

def main():
 _,recs,views,_,_=c.load();reviews=c.read(c.SOURCE/'analysis_results/cluster_screen_reviewed_20260922/逐项接收.json')
 font=c.annotation_font(16)
 out=c.ROOT/'evidence';raw=out/'original24';contexts=[];queue=[]
 for r in reviews:
  case=r['case'];v=views[r['image_id']];d=v['d'];lab,_=c.part(d,v['ids']);a,b=[v['ids'].index(cid) for cid in r['ids']]
  for j,cid in enumerate(v['ids']):
   contexts.append(dict(case=case,code=v['code'],image_id=r['image_id'],id=cid,worker=v['workers'][j],pairs=len(recs[cid]['links']),complete25_6_cluster=int(lab[j]),distance_to_A=d[a,j] if d[a,j]<c.SENTINEL else None,distance_to_B=d[b,j] if d[b,j]<c.SENTINEL else None,point_count_differs_from_A=d[a,j]>=c.SENTINEL,point_count_differs_from_B=d[b,j]>=c.SENTINEL))
  if case in [1,2,3,4]:
   # Small multiples are source-photo overlays, not statistical charts.
   thumbs=[]
   for j,cid in enumerate(v['ids']):
    im=Image.open(raw/f'{case:02d}.png').convert('RGB').resize((512,256));dr=ImageDraw.Draw(im);rec=recs[cid]
    for t,bt in rec['links']:
     pp=[tuple(p*.5) for p in rec['p'][[t,bt]]]
     if abs(pp[0][0]-pp[1][0])<256:dr.line(pp,fill=(255,230,30),width=2)
    for k,p in enumerate(rec['p']):
     x,y=p*.5;dr.ellipse((x-2,y-2,x+2,y+2),fill=(255,230,30));dr.text((x+3,y),str(k+1),fill=(255,230,30))
    canvas=Image.new('RGB',(512,284),'white');canvas.paste(im,(0,28));ImageDraw.Draw(canvas).text((5,4),f"{v['workers'][j]} | CL group {lab[j]} | {len(rec['links'])} corner pairs",font=font,fill='black');thumbs.append(canvas)
   nr=(len(thumbs)+3)//4;page=Image.new('RGB',(2048,nr*284),'white')
   for j,im in enumerate(thumbs):page.paste(im,((j%4)*512,(j//4)*284))
   page.save(out/f'full_members_case_{case:02d}.jpg',quality=94)
  if case in [5,6,7,8,9,10,11,14,17]:
   # Native-resolution full annotation is retained only for these diagnostic crops.
   native=Image.open(raw/f'{case:02d}.png').convert('RGB');scale=native.width/1024
   p0=recs[r['ids'][0]]['p'][recs[r['ids'][0]]['links']];p1=recs[r['ids'][1]]['p'][recs[r['ids'][1]]['links']]
   dif=c.endpoint_dist(p0,p1);ki,role=np.unravel_index(dif.argmax(),dif.shape);mid=(p0[ki,role]+p1[ki,role])/2
   cx,cy=mid;bw,bh=180,170;x0=max(0,min(1024-bw,cx-bw/2));y0=max(0,min(512-bh,cy-bh/2))
   dr=ImageDraw.Draw(native)
   for n,cid in enumerate(r['ids']):
    rec=recs[cid];color=(0,135,230) if n==0 else (235,80,0)
    for k,p in enumerate(rec['p']):
     x,y=p*scale;dr.ellipse((x-5,y-5,x+5,y+5),outline=color,width=3);dr.text((x+6,y+4),f"{'A' if n==0 else 'B'}{k+1}",font=font,fill=color)
   box=tuple(int(round(q*scale)) for q in (x0,y0,x0+bw,y0+bh));crop=native.crop(box)
   page=Image.new('RGB',(crop.width,crop.height+48),'white');page.paste(crop,(0,48));dr=ImageDraw.Draw(page);dr.text((4,3),f"#{case} {v['code']}  A={v['workers'][a]} B={v['workers'][b]}",font=font,fill='black');dr.text((4,25),f"native crop; max={dif.max():.3f}px at {'top' if role==0 else 'bottom'}",font=font,fill='black');page.save(out/f'case_{case:02d}_native_crop.png')
 questions={11:'请先判断A/W008的p7、p8与B/W011的p2、p4是否对应同一组围护角；若是，分别标出直接可见的上端与被家具遮挡的下端。暂不把“都能接受”与“物理正确”合并。',14:'针对W037与W034的p3–p6，逐个说明选的是同一条墙面终止、不同深度平面，还是额外的小转折。两份都不正确不决定能否同簇；先核对表达与连接。',17:'在原尺寸和同一缩放下匿名重判W012/W010，说明18.216px极值所在顶部p5各自意图是哪条墙顶或下凸围边界线：是同一边界的定位波动，还是不同边缘选择？原图该处有冠线与下凸顶边，不预先指定哪条是真值；保留可接受/不可接受/不确定。',9:'与第10项一起随机左右、统一缩放复测，不要求改原结论。指出25.628px差异是不同终止边界还是同角定位差；不能只依据数字反转。',10:'与第9项统一显示复测26.007px，记录该偏移是否跨过门套、墙垛或围护面；原可同簇结论保留，复测作为新版本开发证据。'}
 for case,question in questions.items():
  r=reviews[case-1];v=views[r['image_id']]
  queue.append(dict(case=case,code=v['code'],image_id=r['image_id'],ids=r['ids'],original_target=r['target_same'],priority='pending_original' if case in [11,14,17] else 'optional_scale_repeat_not_overwrite',question=question,points=[dict(id=cid,worker=recs[cid]['row']['worker_id'],points_1024x512=recs[cid]['p'].tolist(),pairs_1based=(recs[cid]['links']+1).tolist()) for cid in r['ids']],native_crop=f'evidence/case_{case:02d}_native_crop.png'))
 c.save('full_member_context24.csv',pd.DataFrame(contexts));c.save('manual_review_queue_new.json',queue)
 # Additional x diagnostic is distinct from already settled inter-person same/different labels.
 xx=pd.read_csv(c.OUT/'within_response_x_pairs.csv.gz');known={r['image_id']:r['case'] for r in reviews};zz=xx[xx.image_id.isin(known)].sort_values(['gap_pp','id'],ascending=[False,True]).head(8).copy();zz['case']=zz.image_id.map(known);c.save('large_within_pair_x_review_candidates.csv',zz)
 print('Done')
if __name__=='__main__':main()
