"""Create report tables and targeted optional coverage, without changing source labels."""
import core as c
import pandas as pd,numpy as np

def main():
 rows,recs,views,reg,_=c.load();bycode={v['code']:v for v in views.values()}
 # Check ordered endpoint roles and the cyclic corner ring separately from pair-set equality.
 preview=c.read(c.ROOT/'evidence/preview_execution/outputs.json');role=[];ring=[]
 for r in preview:
  expected=[tuple((l+1).tolist()) for l in recs[r['id']]['links']]
  actual=[tuple(p['original_point'] for p in sorted(q['originalPoints'],key=lambda x:(x['y'],x['original_point']))) for q in r['pairs']]
  if set(actual)!=set(expected):role.append(r['id'])
  if not any(actual[s:]+actual[:s]==expected for s in range(len(actual))):ring.append(r['id'])
 c.save('preview_order_check.json',dict(responses=len(preview),endpoint_role_differences=len(role),cyclic_corner_order_differences=len(ring),role_ids=role,ring_ids=ring,scope='Effective-point default code path only, not historical deployment'))
 x=pd.read_csv(c.OUT/'room_matched_n8_current_consensus.csv');x=x[(x.variant=='raw')&(x.cut==25.6)&x.comparable&(x.common_N==8)&(x.same_team_discordance==1)]
 rr=[]
 for r in x.itertuples():
  for code in [r.a_code,r.b_code]:
   v=bycode[code];ix=[v['workers'].index(t) for t in r.workers.split(';')];d=v['d'][np.ix_(ix,ix)];lab,_=c.part(d,[v['ids'][j] for j in ix])
   rr.append(dict(a=r.a_code,b=r.b_code,code=code,workers=r.workers,candidates=r.candidates,**c.stats(lab,d)))
 c.save('same_room_n8_counterexamples.csv',pd.DataFrame(rr))
 plans=pd.read_csv(c.OUT/'optional_collection_assignments_new.csv')
 keep=[('S9hNv5qa7GM-06','S9hNv5qa7GM-15'),('yqstnuAEVhm-02','yqstnuAEVhm-26'),('wc2JMjhGNzB-22','wc2JMjhGNzB-29')]
 selected=plans[(plans.target_common_N==12)&plans.apply(lambda r:(r.a_code,r.b_code) in keep or (r.b_code,r.a_code) in keep,axis=1)].copy()
 assert len(selected)==15 and not selected.known_exposure.any()
 c.save('recommended_15_first_responses.csv',selected)
 exposure=c.read(c.SOURCE/'import_json/scene_stability_stage1_20260913_v2/historical_exposure.json');bridge=[]
 for code in ['yqstnuAEVhm-02','yqstnuAEVhm-26','wc2JMjhGNzB-22','wc2JMjhGNzB-29']:
  v=bycode[code];iid=v['image_id']
  seen=any(r['image_id']==iid and r['worker_id']=='W022' for r in rows) or any(r['image_id']==iid and int(r['worker_id'])==22 for r in exposure)
  assert not seen
  bridge.append(dict(worker='W022',image_id=iid,code=code,building=v['building'],known_exposure=seen,role='Optional extra cross-building profile bridge; availability unknown; not required for eligibility'))
 c.save('optional_W022_cross_building_bridge.csv',pd.DataFrame(bridge))
 ps=pd.read_csv(c.OUT/'partition_sensitivity_summary.csv');af=pd.read_csv(c.OUT/'affinity_corpus.csv');af=af[af.N>=8]
 ss=[]
 for method in ['complete','representative']:
  z=ps[(ps.variant=='raw')&(ps.cut==25.6)&(ps.method==method)].iloc[0]
  ss.append(dict(method=method,images=int(z.images),total_singletons=int(z.total_singletons),mean_singleton_share=z.mean_singleton_share,core3_90_count=int(z.few_J3_m2_s10),core3_80_count=int(z.few_J3_m2_s20),near_split=int(z.near_split),far_joined=int(z.far_joined)))
 ss.append(dict(method='diameter_affinity_candidate',images=len(af),total_singletons=int(af.singletons.sum()),mean_singleton_share=af.singleton_share.mean(),core3_90_count=int(af.few_J3_m2_s10.sum()),core3_80_count=int(af.few_J3_m2_s20.sum()),near_split=int(af.near_split.sum()),far_joined=int(af.far_joined.sum())))
 c.save('report_partition_comparison.csv',pd.DataFrame(ss))
 # Check terminal results are invariant to insertion order under deterministic re-partitioning.
 pf=pd.read_csv(c.OUT/'consensus_replay_prefixes.csv.gz');last=pf[pf.k==pf.N]
 assert last.groupby(['variant','method','cut','image_id'])['counts'].nunique().max()==1
 assert all(sum(map(int,s.split(';')))==int(k) for s,k in zip(pf.counts,pf.k))
 summary=dict(source_commit='1c26ef786195496806cb50a140cfffb6566fa1d6',descriptive_images=241,descriptive_responses=2481,prediction_images=240,prediction_responses=2444,people=25,buildings=22,high_support_images=110,high_support_responses=sum(v['N'] for v in views.values() if v['N']>=8),development_cases=24,decided=21,unknown=3,replay_orders=80,replay_terminal_order_invariant=True,no_synthetic_respondents=True,no_reference_or_model_prediction_extension=True,visual_scope='24 nominated pair overlays and native crops; complete-member panels for cases1–4 (83 responses); all338 members checked numerically; not a blind semantic audit',optional_first_responses=15,optional_profile_bridge=4)
 c.save('RESEARCH_SUMMARY.json',summary)
 print('Synthesis and invariant checks complete.')
if __name__=='__main__':main()
