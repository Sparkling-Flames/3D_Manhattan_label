"""Independent calculations on the pinned source. No source writes or raw-point edits."""
from pathlib import Path
import sys,json,gzip,hashlib,itertools,math
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'source'
OUT=ROOT/'results'
SEED=20260922
CUTS=[12.8,1024/60,25.6,1024/30,51.2]
SENTINEL=1e6

def clean(x):
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple,np.ndarray)):return [clean(v) for v in x]
    if isinstance(x,(np.bool_,)):return bool(x)
    if isinstance(x,(np.integer,)):return int(x)
    if isinstance(x,(np.floating,float)):return float(x) if np.isfinite(x) else None
    if isinstance(x,Path):return str(x)
    return x

def save(name,x):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    if isinstance(x,pd.DataFrame):x.to_csv(p,index=False)
    else:p.write_text(json.dumps(clean(x),ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load():
    sys.path.insert(0,str(SOURCE))
    old=SOURCE/'analysis_results/panorama_research_received_20260921/original_package/code'
    sys.path.insert(0,str(old))
    import common
    common.configure(SOURCE)
    rows,recs,views,reg,elig=common.load()
    return rows,recs,views,reg,elig

def part(d,ids,method='complete',cut=25.6):
    if str(SOURCE) not in sys.path: sys.path.insert(0,str(SOURCE))
    from tools.thesis_main.analysis.clustering_release.local_points import partition
    return partition(d,ids,cut,method)

def signed_x(a,b):return (np.asarray(a)-np.asarray(b)+512)%1024-512

def rectify(pairs,gap_pp=None):
    """Circular midpoint WITHIN each annotation pair. Retain y, identity and ordering.
    gap_pp=0 means raw. None means unconditional sensitivity, not approved correction.
    """
    p=np.array(pairs,float,copy=True)
    dx=signed_x(p[:,1,0],p[:,0,0])
    use=np.ones(len(p),bool) if gap_pp is None else abs(dx)<=gap_pp*1024/100+1e-10
    if gap_pp==0:use[:]=False
    mid=(p[:,0,0]+dx/2)%1024
    p[use,0,0]=mid[use];p[use,1,0]=mid[use]
    return p,use

def endpoint_dist(a,b):return np.hypot(signed_x(a[...,0],b[...,0]),a[...,1]-b[...,1])

def distance(a,b,cyclic=False):
    if len(a)!=len(b):return SENTINEL,0
    ds=[float(endpoint_dist(a,np.roll(b,s,axis=0)).max()) for s in range(len(a) if cyclic else 1)]
    k=int(np.argmin(ds));return ds[k],k

def matrices(recs,views,variant='raw'):
    pp={'raw':0,'snap01':.1,'snap02':.2,'snap05':.5,'snap1':1.,'snap_all':None,'cyclic_raw':0,'cyclic_snap02':.2}[variant]
    cyc=variant.startswith('cyclic')
    mats={};pairs={}
    for iid,v in views.items():
        pts=[rectify(recs[c]['p'][recs[c]['links']],pp)[0] for c in v['ids']]
        d=np.zeros((v['N'],v['N']))
        for i,j in itertools.combinations(range(v['N']),2):d[i,j]=d[j,i]=distance(pts[i],pts[j],cyc)[0]
        mats[iid]=d;pairs[iid]=pts
    return mats,pairs

def stats(labels,d=None,cut=25.6):
    _,counts=np.unique(labels,return_counts=True);n=len(labels)
    out=dict(N=n,K=len(counts),largest_share=counts.max()/n,singletons=int(sum(counts==1)),singleton_share=sum(counts==1)/n,
             supported_K2=int(sum(counts>=2)),supported_mass2=counts[counts>=2].sum()/n,
             counts=';'.join(map(str,sorted(counts,reverse=True))))
    for m in [2,3]:
        for J in [2,3,4]:
            cover=sum(sorted(counts[counts>=m],reverse=True)[:J])/n
            for s in [.1,.2]:out[f'few_J{J}_m{m}_s{int(100*s)}']=cover>=1-s-1e-10
    if d is not None and n>1:
        a,b=np.triu_indices(n,1);near=d[a,b]<=cut+1e-8;same=labels[a]==labels[b]
        out.update(pair_disagreement=1-near.mean(),near_split=int(sum(near&~same)),far_joined=int(sum(~near&same)))
    return out

def boot_building(df,col,B=3000):
    means=df.groupby('building')[col].mean();rng=np.random.default_rng(SEED)
    sims=rng.choice(means.to_numpy(),(B,len(means)),replace=True).mean(1)
    return dict(images=len(df),buildings=len(means),mean=float(means.mean()),interval95=np.quantile(sims,[.025,.975]),per_building=means.to_dict())

def annotation_font(size=16):
    """Use an installed font or Pillow fallback; do not bundle font files."""
    from PIL import ImageFont
    for name in ['DejaVuSans.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','Arial.ttf']:
        try:return ImageFont.truetype(name,size)
        except OSError:pass
    return ImageFont.load_default(size=size)
