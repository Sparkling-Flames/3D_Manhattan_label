"""One chart per figure; default matplotlib colours; source photographs are elsewhere."""
from pathlib import Path
import pandas as pd,numpy as np,json
import matplotlib.pyplot as plt

def make_figures(root):
 root=Path(root);r=root/'results';out=root/'figures';out.mkdir(exist_ok=True);paths=[]
 def finish(fig,name):
  fig.tight_layout();p=out/name;fig.savefig(p,dpi=170,bbox_inches='tight');plt.close(fig);paths.append(p)
 d=pd.read_csv(r/'review24_development_agreement.csv');a=pd.read_csv(r/'affinity_partition_development.csv')
 vals=[20,int(d[(d.variant=='raw')&(d.cut==25.6)&(d.method=='complete')].agree.iloc[0]),int(d[(d.variant=='raw')&(d.cut==25.6)&(d.method=='representative')].agree.iloc[0]),int(a[(a.cut==25.6)&(a.weight=='quadratic')].match.dropna().astype(bool).astype(int).sum())]
 fig,ax=plt.subplots(figsize=(8,4.8));labels=['Direct pair\ndistance','Complete\nlinkage','Representative\nradius','Diameter-bounded\naffinity candidate'];bars=ax.bar(labels,vals)
 ax.bar_label(bars,labels=[f'{v}/21' for v in vals],padding=3);ax.set(ylim=(0,24),ylabel='Agrees with the 21 decided development cases',title='Development evidence, not validation accuracy\nSame 25.6 px pair tolerance; 3 unknown cases not scored')
 finish(fig,'01_development_comparison.png')
 x=pd.read_csv(r/'x_effect_on_memberships.csv.gz');x=x[(x.cut==25.6)&(x.method=='complete')]
 variants=['snap01','snap02','snap05','snap1'];xx=[.1,.2,.5,1]
 fig,ax=plt.subplots(figsize=(7.5,4.8))
 for col,label,marker in [('pair_edge_changes','Pair-compatibility flips','o'),('coclustering_changes','Co-cluster relation flips','s')]:ax.plot(xx,[x[x.variant==v][col].sum() for v in variants],marker=marker,label=label)
 ax.set(xlabel='Within-response shared-x gate (percentage points)',ylabel='Changed response-pair relations across 240 images',title='A small coordinate change can propagate through a hierarchy')
 ax.legend();finish(fig,'02_shared_x_propagation.png')
 z=pd.read_csv(r/'report_partition_comparison.csv');fig,ax=plt.subplots(figsize=(8,4.8));labels=['Complete linkage','Representative radius','Diameter-affinity candidate']
 bars=ax.bar(labels,z.core3_90_count);ax.bar_label(bars,labels=[f'{n}/110\n{s} singleton responses' for n,s in zip(z.core3_90_count,z.total_singletons)],padding=4,fontsize=9)
 ax.set(ylim=(0,52),ylabel='Images: up to 3 repeated clusters cover at least 90%',title='Better agreement on selected cases does not imply easier consensus\n110 images with at least 8 people; 25.6 px')
 finish(fig,'03_full_corpus_consensus.png')
 z=pd.read_csv(r/'consensus_replay_summary.csv');z=z[(z.variant=='raw')&(z.method=='complete')&(z.cut==25.6)&(z.J==3)&(z.m==2)&(z.tail_fraction==.1)].set_index('h')
 fig,ax=plt.subplots(figsize=(8,4.8));vals=[27,int(z.loc[3,'images_any_success']),int(z.loc[3,'images_ge80pct_orders']),int(z.loc[5,'images_any_success']),int(z.loc[5,'images_ge80pct_orders'])]
 labels=['Final support\ncondition','h=3: any\nobserved order','h=3: at least\n80% of orders','h=5: any\nobserved order','h=5: at least\n80% of orders']
 bars=ax.bar(labels,vals);ax.bar_label(bars,padding=3);ax.set(ylim=(0,34),ylabel='Images out of the same 110-image panel',title='Few supported expressions and observed persistence are different\n80 real-person order replays; h=5 has 18 images with no eligible anchor')
 finish(fig,'04_observed_persistence.png')
 z=pd.DataFrame(json.loads((r/'room_summary_new.json').read_text()));z=z[(z.variant=='raw')&(z.cut==25.6)&(z.metric=='core3_mass')&(z.same_panel_otherroom==False)].set_index('kind')
 fig,ax=plt.subplots(figsize=(7.8,4.8));xx=np.arange(2);w=.24
 for off,col,lab in [(-w,'MAE','Same-room source'),(0,'outside_MAE','Other-building baseline'),(w,'samebuilding_otherroom_MAE','Same-building other-room baseline')]:
  vals=[z.loc[k,col] for k in ['physical_same','comparable_same']];bb=ax.bar(xx+off,vals,w,label=lab);ax.bar_label(bb,fmt='%.3f',padding=3,fontsize=9)
 ax.set_xticks(xx,['Physical same-room\n64 images / 9 buildings','Previously comparable same-room\n21 images / 5 buildings']);ax.set(ylim=(0,.44),ylabel='Building-equal mean absolute error',title='Same-room information about repeated-expression mass\nNot a prediction of required annotator count');ax.legend(fontsize=8)
 finish(fig,'05_same_room_support.png')
 return paths
