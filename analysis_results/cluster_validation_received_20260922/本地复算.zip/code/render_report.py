"""Embed local diagnostic PNGs into a standalone, offline HTML report."""
from pathlib import Path
import base64,re,html
import mistune

def render(root):
 root=Path(root);text=(root/'中文独立研究报告.md').read_text(encoding='utf8')
 body=mistune.create_markdown(escape=False,plugins=['table'])(text)
 def embed(m):
  p=root/m.group(1)
  if not p.exists():raise FileNotFoundError(p)
  typ='image/png' if p.suffix.lower()=='.png' else 'image/jpeg'
  return 'src="data:'+typ+';base64,'+base64.b64encode(p.read_bytes()).decode()+'"'
 body=re.sub(r'src="((?:figures|evidence)/[^\"]+)"',embed,body)
 css='''body{max-width:1060px;margin:40px auto;padding:0 30px 80px;font-family:system-ui,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#202329;line-height:1.85;background:white}h1{font-size:30px;line-height:1.45;margin-bottom:22px}h2{font-size:24px;margin-top:48px;border-top:1px solid #ddd;padding-top:22px}h3{font-size:19px;margin-top:28px}p{margin:15px 0}table{width:100%;border-collapse:collapse;margin:22px 0;font-size:14px;line-height:1.6}th,td{border-bottom:1px solid #ddd;padding:11px 10px;text-align:left;vertical-align:top}th{background:#f3f4f5}img{max-width:100%;height:auto;display:block;margin:18px auto}code{background:#f3f4f5;padding:2px 5px;overflow-wrap:anywhere;font-size:90%}pre{padding:16px;background:#f3f4f5;overflow:auto;line-height:1.55}pre code{padding:0}a{color:#234f72}strong{font-weight:650}footer{margin-top:50px;padding-top:20px;border-top:1px solid #bbb;font-size:13px} @media(max-width:650px){body{padding:0 14px}h1{font-size:25px}table{font-size:12px;display:block;overflow-x:auto}}'''
 out=root/'中文独立研究报告.html';out.write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>分簇核验与不确定性｜2026-09-22</title><style>'+css+'</style></head><body>'+body+'<footer>本HTML已嵌入全部报告图，可离线阅读。CSV、代码、原图审核页面、来源哈希及复算记录见完整交付包。没有将开发证据当作独立验证。</footer></body></html>',encoding='utf8')
 return out
if __name__=='__main__':print(render(Path(__file__).resolve().parents[1]))
