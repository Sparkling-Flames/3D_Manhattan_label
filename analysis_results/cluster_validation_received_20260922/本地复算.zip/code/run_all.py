"""Recompute new research only, offline, from the included trimmed frozen source.
--fresh never overwrites delivered results. Requires installed Python dependencies and Node.js.
"""
from pathlib import Path
import argparse,subprocess,sys,shutil,json,time,concurrent.futures,os,gzip

def compare_results(reference,actual):
 import pandas as pd,numpy as np
 rows=[]
 for p in sorted(actual.glob('*')):
  q=reference/p.name
  if not p.is_file() or not q.is_file():continue
  try:
   if '.csv' in p.name:
    a=pd.read_csv(q);b=pd.read_csv(p)
    pd.testing.assert_frame_equal(a,b,check_dtype=False,rtol=1e-9,atol=1e-10)
   elif '.json' in p.name:
    def read(x):
     if x.suffix=='.gz':
      with gzip.open(x,'rt',encoding='utf8') as f:return json.load(f)
     return json.loads(x.read_text(encoding='utf8'))
    # These JSONs have deterministic ordering and contain no timings or host paths.
    assert read(q)==read(p),'JSON values differ; inspect rather than overwrite reference'
   else:continue
   rows.append({'file':p.name,'pass':True})
  except Exception as e:rows.append({'file':p.name,'pass':False,'error':str(e)[:1500]})
 return rows

def main():
 a=argparse.ArgumentParser();a.add_argument('--fresh',action='store_true',required=True);a.add_argument('--output',type=Path);a.add_argument('--jobs',type=int,default=2);args=a.parse_args()
 root=Path(__file__).resolve().parents[1];out=(args.output or root/'recomputed').resolve()
 if out.exists():raise SystemExit(f'Output already exists, choose a new path: {out}')
 if shutil.which('node') is None:raise SystemExit('Node.js is required for actual JS preview verification.')
 out.mkdir(parents=True);shutil.copytree(root/'code',out/'code',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 shutil.copytree(root/'source',out/'source',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 for s in ['logs','results','figures','evidence']:(out/s).mkdir()
 status=[]
 def run(name):
  start=time.time();log=out/'logs'/(name+'.log');env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
  with log.open('w',encoding='utf8') as f:
   p=subprocess.run([sys.executable,'-B',str(out/'code'/(name+'.py'))],cwd=out,stdout=f,stderr=subprocess.STDOUT,env=env)
  r=dict(stage=name,returncode=p.returncode,seconds=round(time.time()-start,3),log=str(log.relative_to(out)))
  print(json.dumps(r),flush=True)
  if p.returncode:raise RuntimeError(f'{name} failed; see {log}')
  return r
 for stage in [['00_assets','01_measurement','03_preview'],['06_consensus_replay','04_people','02_partition','05_affinity_corpus','07_rooms_and_collection'],['08_case_evidence'],['09_synthesis']]:
  with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,args.jobs)) as ex:
   for r in ex.map(run,stage):status.append(r)
 with (out/'logs/new_tests.log').open('w') as f:p=subprocess.run([sys.executable,'-m','pytest',str(out/'code/test_research.py'),'-q'],cwd=out,stdout=f,stderr=subprocess.STDOUT)
 status.append(dict(stage='new_tests',returncode=p.returncode))
 checks=compare_results(root/'results',out/'results');success=p.returncode==0 and all(x['pass'] for x in checks)
 result=dict(all_pass=success,stages=status,comparison=checks,comparison_count=len(checks),source='Trimmed original pinned inputs; delivered reference results left unchanged')
 (out/'RECOMPUTATION_CHECK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 print(json.dumps({'all_pass':success,'comparison_count':len(checks),'output':str(out)}),flush=True)
 if not success:raise SystemExit(1)
if __name__=='__main__':main()
