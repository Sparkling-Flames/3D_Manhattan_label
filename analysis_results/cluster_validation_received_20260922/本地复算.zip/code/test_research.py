import importlib.util,json,gzip
from pathlib import Path
import numpy as np,pandas as pd
import core as c

def mod(name):
 s=importlib.util.spec_from_file_location(name,c.ROOT/f'code/{name}.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def test_source_cohort_identity_and_points():
 rows,recs,views,reg,_=c.load();ids=[cid for v in views.values() for cid in v['ids']]
 assert len(views)==240 and len(ids)==len(set(ids))==2444
 assert len({w for v in views.values() for w in v['workers']})==25
 for v in views.values():
  assert len(set(v['workers']))==v['N']
  assert not set(v['workers'])&{'W019','W026'}
  for cid in v['ids']:
   r=recs[cid];assert not r['row']['imputed_point'];np.testing.assert_array_equal(r['p'],r['row']['effective_points_1024x512'])

def test_rectify_does_not_mutate():
 p=np.array([[[100,30],[102,350]],[[300,40],[330,400]]],float);old=p.copy();q,use=c.rectify(p,.2)
 np.testing.assert_array_equal(p,old);np.testing.assert_array_equal(q[:,:,1],old[:,:,1]);assert q.shape==old.shape
 assert use.tolist()==[True,False]

def test_circular_midpoint_seam():
 q,_=c.rectify(np.array([[[1023,20],[1,400]]]),.2);np.testing.assert_allclose(q[:,:,0],0)

def test_point_two_percentage_points():
 q,use=c.rectify([[[100,20],[102.048,400]],[[200,20],[202.1,400]]],.2)
 assert use.tolist()==[True,False];assert np.isclose(q[0,0,0],101.024)

def test_gated_distance_bound():
 rng=np.random.default_rng(8)
 for _ in range(80):
  a=rng.uniform([0,0],[1024,512],(8,2,2));b=rng.uniform([0,0],[1024,512],(8,2,2))
  for p in [a,b]:p[:,1,0]=(p[:,0,0]+rng.uniform(-5,5,8))%1024
  x,_=c.rectify(a,.2);y,_=c.rectify(b,.2)
  assert abs(c.distance(a,b)[0]-c.distance(x,y)[0])<=2.048+1e-9

def test_shared_x_need_not_contract_max_endpoint_metric():
 a=np.array([[[0,0],[2,100]]],float);b=np.array([[[0,2],[0,100]]],float)
 x,_=c.rectify(a,None);y,_=c.rectify(b,None)
 assert c.distance(x,y)[0]>c.distance(a,b)[0]

def test_count_gate_retained():
 assert c.distance(np.zeros((4,2,2)),np.zeros((5,2,2)))[0]==c.SENTINEL

def test_cyclic_does_not_rotate_coordinates():
 a=np.array([[[10,30],[10,400]],[[200,30],[200,400]],[[600,30],[600,400]]]);b=np.roll(a,1,0)
 assert c.distance(a,b,True)[0]==0 and c.distance(a,b,False)[0]>0

def test_partition_permutation_invariance():
 d=np.array([[0,2,5,40],[2,0,4,40],[5,4,0,40],[40,40,40,0]],float);ids=['D','A','C','B']
 for method in ['complete','representative']:
  a,_=c.part(d,ids,method);ix=[3,0,2,1];b,_=c.part(d[np.ix_(ix,ix)],[ids[i] for i in ix],method);z=np.argsort(ix)
  np.testing.assert_array_equal(a[:,None]==a,b[z,None]==b[z])

def test_affinity_partition_diameter_and_transitivity():
 ap=mod('02_partition');d=np.array([[0,2,8],[2,0,7],[8,7,0]],float);lab,info=ap.affinity_partition(d,['a','b','c'],7.5)
 assert info['certified'] and lab[0]==lab[1] and lab[0]!=lab[2]
 assert all(d[i,j]<=7.5 for i in range(3) for j in range(3) if lab[i]==lab[j])

def test_semantic_review_is_not_solver_input():
 ap=mod('02_partition');d=np.array([[0,1],[1,0]],float)
 lab,info=ap.affinity_partition(d,['b','a'],25.6);assert lab[0]==lab[1]
 # Routine arguments contain no worker quality, review choices, or convergence targets.
 import inspect
 assert 'target_same' not in inspect.signature(ap.affinity_partition).parameters

def test_supported_minority_is_allowed():
 z=c.stats(np.array([0]*10+[1]*8+[2]*2))
 assert z['few_J3_m2_s10'] and z['few_J3_m3_s10'] # 18/20 is allowed at 90%
 assert c.stats(np.arange(20))['few_J3_m2_s10']==False

def test_prefix_comparison_label_invariant():
 m=mod('06_consensus_replay');tv,flip=m.compare_prefix(np.array([1,1,2,2]),np.array([7,7,3,3,7,3]))
 assert tv==0 and flip==0

def test_prefix_split_is_detected():
 m=mod('06_consensus_replay');tv,flip=m.compare_prefix(np.array([1,1,1,1]),np.array([0,0,1,1,1]))
 assert tv>0 and flip>0

def test_review_summary_boolean_reductions():
 z=pd.read_csv(c.OUT/'review24_development_agreement.csv')
 assert (z.agree==z.decided-z.false_split-z.false_merge).all()
 assert z.decided.nunique()==1 and z.decided.iloc[0]==21

def test_exact_js_pairing_results():
 z=c.read(c.OUT/'preview_mechanism_summary.json');assert z['responses']==2444 and z['different_pair_sets']==0
 assert z['python_javascript_max_numeric_difference']<1e-9
 order=c.read(c.OUT/'preview_order_check.json');assert order['endpoint_role_differences']==0 and order['cyclic_corner_order_differences']==0

def test_all_affinity_outputs_certified_and_no_far_merges():
 z=pd.read_csv(c.OUT/'affinity_corpus.csv');assert len(z)==240 and z.certified.all() and (z.loc[z.N>1,'far_joined']==0).all()
 assert (z.loc[z.N==1,'K']==1).all()

def test_outer_building_exclusion_and_unclassified_retention():
 z=pd.read_csv(c.OUT/'worker_profiles_new.csv.gz').fillna('')
 assert all(r.heldout_building not in str(r.training_buildings).split(';') for r in z.itertuples())
 assert not z.loc[z.worker=='W022','qualified'].any()
 p=pd.read_csv(c.OUT/'worker_predictions_new.csv.gz');assert (p.worker=='W022').any()

def test_future_withdrawn_worker_not_assigned():
 z=pd.read_csv(c.OUT/'optional_collection_assignments_new.csv');assert not (z.worker=='W011').any();assert not z.known_exposure.any()

def test_raw_baseline_reproduced():
 z=c.read(c.OUT/'measurement_summary.json');assert z['baseline_matrix_max_difference']==0
