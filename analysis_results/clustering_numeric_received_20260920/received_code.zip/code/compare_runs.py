"""Compare two completed runs; gzip headers and correctly bound gzip hashes are metadata.
Run from the delivery root:
  python code/compare_runs.py results results_recomputed --output reproduction_check
"""
from __future__ import annotations
import argparse,csv,gzip,hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd

def digest(path:Path,decoded=False):
    h=hashlib.sha256()
    with (gzip.open(path,'rb') if decoded and path.suffix=='.gz' else path.open('rb')) as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def check_manifest(path:Path):
    doc=json.loads(path.read_text(encoding='utf-8'));bad=[]
    for filename,expected in doc.get('files',{}).items():
        f=path.parent/filename
        if not f.is_file() or digest(f)!=expected:bad.append(filename)
    return bad

def compare(a:Path,b:Path,output:Path):
    select=lambda f:f.is_file() and f.suffix in ('.csv','.json','.gz') and f.name!='RUN_EXECUTION.json'
    fa={p.relative_to(a).as_posix():p for p in a.rglob('*') if select(p)}
    fb={p.relative_to(b).as_posix():p for p in b.rglob('*') if select(p)}
    rows=[]
    for name in sorted(fa.keys()|fb.keys()):
        x=fa.get(name);y=fb.get(name)
        row=dict(path=name,status='',maximum_absolute_difference=None,reference_payload_sha256=None,rerun_payload_sha256=None)
        if x is None or y is None:row['status']='missing';rows.append(row);continue
        hx=digest(x,True);hy=digest(y,True);row.update(reference_payload_sha256=hx,rerun_payload_sha256=hy)
        if hx==hy:row['status']='payload_identical'
        elif name.endswith('.csv') or name.endswith('.csv.gz'):
            da=pd.read_csv(x);db=pd.read_csv(y);ok=da.shape==db.shape and da.columns.tolist()==db.columns.tolist();maximum=0.
            if ok:
                for c in da:
                    if pd.api.types.is_numeric_dtype(da[c]) and pd.api.types.is_numeric_dtype(db[c]):
                        va=da[c].to_numpy(dtype=float);vb=db[c].to_numpy(dtype=float)
                        if not np.allclose(va,vb,atol=1e-12,rtol=1e-12,equal_nan=True):ok=False
                        finite=np.isfinite(va)&np.isfinite(vb)
                        if finite.any():maximum=max(maximum,float(np.max(np.abs(va[finite]-vb[finite]))))
                    elif not da[c].fillna('__MISSING__').equals(db[c].fillna('__MISSING__')):ok=False
            row.update(status='floating_point_equivalent' if ok else 'mismatch',maximum_absolute_difference=maximum)
        elif name=='source_replay/EXPERIMENT_MANIFEST.json':
            ja=json.loads(x.read_text());jb=json.loads(y.read_text());ha=ja.pop('files',{});hb=jb.pop('files',{})
            ok=ja==jb and ha.keys()==hb.keys() and not check_manifest(x) and not check_manifest(y)
            for key in ha:
                xa=x.parent/key;yb=y.parent/key
                if not xa.is_file() or not yb.is_file() or digest(xa,True)!=digest(yb,True):ok=False
            row['status']='gzip_metadata_correctly_bound' if ok else 'mismatch'
        else:row['status']='mismatch'
        rows.append(row)
    statuses=pd.Series([r['status'] for r in rows]).value_counts().to_dict()
    ok=all(r['status'] in ('payload_identical','floating_point_equivalent','gzip_metadata_correctly_bound') for r in rows)
    output.mkdir(parents=True,exist_ok=True)
    with (output/'reproduction_comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    result=dict(passed=ok,reference_numerical_files=len(fa),rerun_numerical_files=len(fb),status_counts=statuses,
        absolute_tolerance=1e-12,relative_tolerance=1e-12,
        maximum_csv_difference=max((r['maximum_absolute_difference'] or 0 for r in rows),default=0),
        interpretation='Decoded numerical payloads, floating-point rounding, and correctly bound gzip metadata are checked separately.',
        logs_and_RUN_EXECUTION_are_execution_metadata_not_numerical_results=True)
    (output/'ISOLATED_REPRODUCTION.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return ok
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('reference',type=Path);p.add_argument('rerun',type=Path);p.add_argument('--output',type=Path,default=Path('reproduction_check'));a=p.parse_args()
    raise SystemExit(0 if compare(a.reference,a.rerun,a.output) else 1)
