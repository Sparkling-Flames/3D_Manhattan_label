"""Verify a full or reader delivery using only Python's standard library.
Usage from extracted root: python code/verify_delivery.py
Optional: --root PATH, --manifest FILE, --archive DELIVERED.zip
"""
from __future__ import annotations
import argparse,hashlib,json,sys,zipfile
from pathlib import Path

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def validate(root:Path,manifest:Path)->dict:
    root=root.resolve();doc=json.loads(manifest.read_text(encoding='utf-8'));errors=[];checked=0
    for row in doc['files']:
        path=(root/row['path']).resolve()
        if root not in path.parents:errors.append(f"Unsafe manifest path: {row['path']}");continue
        if not path.is_file():errors.append(f"Missing: {row['path']}");continue
        if path.stat().st_size!=row['bytes'] or sha256(path)!=row['sha256']:errors.append(f"Bytes/hash mismatch: {row['path']}")
        checked+=1
    source=root/'inputs/source_snapshot.zip';source_crc=None;source_blob=None
    if doc.get('package_type')=='full':
        if not source.is_file():errors.append('Full package is missing its source snapshot')
        else:
            with zipfile.ZipFile(source) as z:source_crc=z.testzip() is None
            if not source_crc:errors.append('Source ZIP CRC mismatch')
            blobhash=hashlib.sha1();blobhash.update(b'blob '+str(source.stat().st_size).encode()+b'\0')
            with source.open('rb') as f:
                for block in iter(lambda:f.read(1024*1024),b''):blobhash.update(block)
            source_blob=blobhash.hexdigest()
            if source_blob!=doc['source_git_blob']:errors.append('Source Git blob mismatch')
            if sha256(source)!=doc['source_sha256']:errors.append('Source SHA-256 mismatch')
    result=dict(passed=not errors,package_type=doc.get('package_type'),files_checked=checked,
        manifest_payload_bytes=sum(row['bytes'] for row in doc['files']),source_crc_passed=source_crc,
        source_git_blob=source_blob,errors=errors)
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--manifest',type=Path);p.add_argument('--archive',type=Path);a=p.parse_args()
    result=validate(a.root,a.manifest or a.root/'DELIVERY_MANIFEST.json')
    if a.archive:
        with zipfile.ZipFile(a.archive) as z:result['outer_archive_crc_passed']=z.testzip() is None
        result['outer_archive_sha256']=sha256(a.archive)
        result['passed']=result['passed'] and result['outer_archive_crc_passed']
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['passed'] else 1
if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,KeyError,ValueError,zipfile.BadZipFile) as e:
        print(f'Delivery verification failed: {e}',file=sys.stderr);raise SystemExit(1)
