# 2026-09-23 独立研究执行与交付

## 如何使用

将本目录的 `pro_handoff.zip` 上传给云端 Pro，并让它从包内 `source/docs/thesis_main/PRO_CONSENSUS_RESEARCH_TASK_20260923.md` 开始。任务书是后续完整研究要求；本地结果仅为输入审计、两种边界的逐作答诊断和全成员端点先行实验。本任务没有向云端发送消息。

解压后在包根运行：`python code/run_numeric.py --out . --numeric-only`。图表复算：`python code/summarize_consensus_pilot.py --input individual_quality.csv --out .`，另需 pandas、matplotlib。数值计算需要 numpy、scipy；标准 STAPLE 额外需要 SimpleITK。无 SimpleITK 时输出 unavailable，不调用替代算法。包内代码无需原仓库；重新导出原始数据才依赖本地仓库和原始路径。

## 输入与追溯

- `inputs/annotations.jsonl.gz`：3152条来源/有效记录，必须按 `accepted_before_new_review` 选出3019份起点；覆盖259图，Manual2265、OOS216、Semi538。不同条件分开分析。
- 3019份均已回查原导出点位，见 `source_verification.json`。2978份有可用上下配对；“有配对”不等于曲线一定可构造。
- `raw_points_1024x512` 是原始点，`effective_points_1024x512` 是承接既有裁决的点；实际字段以输入为准。`pairs_shared_x` 是本次逐个已确认上下点对的周期x平均，y不变；`links_zero_based` 为零基点号。共享x不是跨人员坐标平均。
- `known_wrong` 只承接 case14 两份明确裁决，保留在逐份质量和复审表；全成员端点的独立成员池隔离这两份及4份借点。原3019起点不因此改写，使用人数另列。
- `inputs/references.json.gz`：原始Matterport GT、人工修订GT、HoHoNet和BiLayout两个头，保留原始参考点、配对状态、来源。两版GT分开，模型不是GT。全局30张实质修订中28张进入当前259图面板；另两张 `7y3sRwLe3Va_9bbf903d50da4ffd9e5d1fb7c9f4d69b`、`wc2JMjhGNzB_40ea4145b9e946aab5d56de3ce179c8e` 不在起点面板，并非漏算。人工GT采用可解释的二维墙带规范化，不声称恢复未保存的三维连接顺序。
- `review_sources.json` 索引17份既有范围/审核原件与3份外部讨论；包内 `source/`、`context/` 保存相应材料。未决、暂缓和选图排除不自动变成标注排除。
- 输入提取点及来源审计入包，原图、全部历史导出、active日志和账户信息不入包。云端不能仅凭本包裁决遮挡、错标动机或真实房间拓扑。

## 数值表语义

统一墙带在512×256像素中心栅格计算，距离换算为1024×512等效像素。`mode=curve` 复用空间直线的全景投影；`linear` 为二维直线敏感性。失败不强行生成空区域。

`individual_quality.csv`：每份起点×两种边界×两版GT均保留一行，含 `status`；报告IoU、普通ERP面积质心的水平/垂直/欧氏位移、周期方向位移与一阶矩距离。`circular_R` 小意味着方向不稳定，圆周水平大位移不直接等于实际整体错位；一阶矩距离无像素单位。逐作答测量尚未去除图片效应，不直接称为人员能力。

`review_queue.csv`：全部起点×两种边界，整体异常排序为 `min(1-最近参考IoU,1-最近独立同行IoU)`，越大表示两边都远。它只用于安排视觉复审，无自动阈值或自动新排除；参考覆盖不全、同行不足和表示失败单列。同时保存 `peer_ious` 全部适用同行IoU、最近同行摘要和所有可用参考IoU。

`endpoint_pilot.csv`：每个同图同条件组、每算法、每GT保留端点。`member_ids` 是所收集的作答ID顺序，`k` 是收集的唯一人员数；`used_member_ids`/`used_k` 是实际参加聚合者，`raw_accepted_n` 是起点作答数。缺GT、无合法成员、重复人员或算法不可用均明确记录。此表尚无全前缀、随机顺序、支持图、概率图、区域文件、人员分类或同房预测结果。

`model_difficulty.csv` 是BiLayout两个头的曲线区域不一致量；这是候选难度特征，不是已验证的难度真值。`representation_failures.json` 保留表示失败原因，不能据失败直接删除原标注。

`numeric_summary.json` 为实际计数；`centroid_summary.csv` 和 `centroid_diagnostics.png` 展示可计算样本的质心量级；失败率需同时参考前述全量表。`gt_sensitivity_summary.csv` 对实质修订图的同一作答作两版GT配对比较。`handoff_manifest.json` 为实际包清单。

## 方法状态与边界

Lee多数投票（≥50%）已进入当前合同和两份SOP；严格多数、真实medoid、单正确率EM、greedy是对照。EM/greedy只称思路适配，未取得完整技术报告，不宣称作者完整复现。标准STAPLE依赖成熟库；MAP-STAPLE和MACCHIatO尚待独立核验实现及周期适配。尚无根据把任何候选宣布为最终共识方法。

新的当前合同为 `consensus_research_20260923_v1`。旧v23 JSON、渲染文档和改前研究文档已保留；历史工具明确读取dated v23。本次修改研究合同/SOP/统计计划/当前状态与索引，及研究输入导出、区域聚合和测试。不改原始导出、既有采集分发、运营路由或旧结果含义；历史未提交改动保留。

完整曲线、外建筑校准权重、人员/图片效应、真实人员组成和同房预测交由Pro继续数值研究；清洗最终裁决与几何例图解释由用户和本地助手视觉复审。不能将本轮端点结果代替完整任务验收。

## 验证与交接

- 新旧合同、区域边界、失败分母、既有数据处理及历史C1调用链共52项pytest通过；质心/GT配对摘要的合成自检通过。
- 新当前合同与dated v23的渲染检查通过；Git差异空白检查通过。执行入口采用 `python -m tools.thesis_main.analysis...`，不依赖直接运行脚本的导入路径。
- 本地数值依赖：numpy 1.26.4、scipy 1.11.4。标准STAPLE库本地未安装，MAP-STAPLE/MACCHIatO未执行。未运行全仓测试、完整重放和预测：本次没有改运营流程，完整研究是Pro后续任务。
- 项目地图和README索引已登记本轮任务书、旧合同保存位置、数值/摘要工具及执行入口；历史文档快照保留原字节，不覆盖旧结果。
- 原始导出没有写回；已有Project93旧快照删除与新快照未跟踪状态保持原状。本轮没有提交、发布或推送。

## 本轮实际结果

284个同图同条件组，6038条复审行，12076条逐作答质量行（其中11590条可评价、486条不可评价）；这是两种边界×两版GT展开后的记录数，不是独立作答数。3408条共识端点结果中2808条ok、562条标准STAPLE不可用、36条不可评价、2条EM达到迭代上限。没有自动新增视觉排除。

曲线＋修订GT可评价2897/3019份。Manual为2185/2265份，绝对垂直质心偏移中位数2.58px、P95为11.70px；圆周水平方向偏移中位数14.06px、P95为268.86px，后者受低R方向不稳定影响，不能据此说整体横移了几百像素。完整分层见[质心与GT敏感性说明](centroid_findings.md)和[图表](centroid_diagnostics.png)。

人工修订图中，Manual曲线表示的两版GT共同可评价集为21图384份，IoU差（修订减原始）中位数+0.0448。该变化体现参考版本对评价的影响，不足以单独判定哪版GT更正确，也不说明人员因修订而提高能力。其余条件及直线敏感性另表报告。

独立包已在仓库外临时目录实际解压运行：24份真实作答小组的MV/medoid四条GT端点与全量结果一致，图表脚本也运行通过；临时副本已清理。包约5.6 MB，可直接交给Pro。
