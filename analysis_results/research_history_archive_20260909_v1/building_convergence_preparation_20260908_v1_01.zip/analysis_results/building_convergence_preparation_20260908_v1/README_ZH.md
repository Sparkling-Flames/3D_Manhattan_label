> 当前研究意图与执行规则统一见[相似场景标注稳定性分析SOP](../../docs/thesis_main/相似场景标注稳定性分析SOP.md)。本文只解释原计算及其字段；旧阶段划分、软点数分簇、稳定人数和复现命令不代表新口径已完成。旧叙述/Word已撤下，数据与图保留审计。

# 历史计算与字段说明

## 本次核对的覆盖

统一底座有2501份canonical、26名历史人员、214张历史图、22个building、270个完整context。当前20人全部属于历史26人，不是另一批新人。候选166张没有历史真人响应，其中164张分布在历史building内的13栋；另外2张不在历史building集合内。候选与历史标注样本量分开。

| 阶段／条件 | context | 每图同条件人数范围 | 原始人数≥20的context | 覆盖的building数（≥20部分） |
|---|---:|---:|---:|---:|
| P1 Manual | 30 | 25–26 | 30 | 12 |
| C1 Manual | 87 | 5–23 | 12 | 5 |
| C2-B Manual | 46 | 1–20 | 4 | 3 |
| C2-A-RP Manual | 55 | 1–4 | 0 | 0 |
| P1 Semi | 18 | 26 | 18 | 10 |
| C1 Semi | 25 | 4–5 | 0 | 0 |
| P1 oos | 9 | 26 | 9 | 6 |

oos单列，不默认纳入Manual研究。一个building里不同阶段和条件的同图响应不被加成更多独立人员；每图人员数取worker_id去重，不把整栋累计人数当作每图支持。`building_summary.csv`的`building_union_worker_count`只是该楼出现过的不同人员总数。

`building_stage_condition_support.csv`有两个明确视图：`all_contexts`为该楼、该阶段条件全部context；`raw_support_ge20_coverage_only`为原始独立人数≥20的子集，仅用于展示高密度资料覆盖，不是资格筛选、结果优选或新招募方案。两个视图均报告所有所列context的人员交集，不能相加为两套独立数据。空子集标记`no_context_in_this_coverage_view`，不称为已经验证。

## 已有曲线的口径不能合并成一个人数

[existing_curve_inventory.csv](existing_curve_inventory.csv)登记21个实际文件、生成代码是否存在、指标、参照人群、全量参照是否包含所评价子样本、簇是否固定、已观察k范围及可复用限制。可按完整context可靠连接的15329个既有源行放在[existing_curves_context_links.csv.gz](existing_curves_context_links.csv.gz)，只保留原行JSON和来源，不改指标名称或数值。源行数不是新样本量，且包含多个指标/阈值/重复k及辅助回放。

| 来源系列 | 实际内容 | 可复用用途与限制 |
|---|---|---|
| historical42 | 42份分区，当前也对应42图/42context；无参考状态曲线k3–20，固定第二模式回放k5/8/12/16/20 | 旧人员与几何筛选口径；参考质量曲线共同支持止于k13，不能写为41图共同k20实测或12–15平台证明 |
| extended73 | 73个阶段条件单元，本文件恰好也有73张不同图；438个k15–20源行 | 原始支持≥20的单元集合；可计算状态和严格人数随单元变化，状态恢复不等于质量 |
| strict medoid补充 | 69个context，414个k15–20源行 | 用选中子样本medoid对剩余同图历史人员，剩余人员与选中集合不重叠；k=N没有剩余，不补成正确 |
| 完整preflight | task_inventory为230context；precision曲线1648行、70个严格N≥20单元、k2至每图N（最大26） | 不能把230当全部270，也不能把原始73替换严格70；旧context顺序是stage/block/condition/image，已按字段转换连接 |
| preflight不同指标 | finite_sd、经验iid_sd、medoid步长、medoid到剩余人员、medoid到参考 | finite_sd到k=N机械归零；iid是从经验分布有放回抽样的诊断，不是真正新人；剩余人员和参考布局的比较参照不同，参考来源独立性另行核实 |
| preflight阈值／幂函数 | 已有epsilon .005/.01/.02、事后medoid稳定步、幂函数尾部敏感性 | 原有诊断保留，不采纳为新停止规则；`medoid_hindsight_first_stable_k`查看直到20的所有后续步长，是事后量 |
| fixed_panel_vs_independent | 按stage/condition固定共同图像的跨图面板均值方差；单行可含多个building | 不是一栋building的曲线。用于识别“所有图同一组人员”和“每图另抽人员”的区别 |
| 后续固定簇恢复 | distribution_recovery为66个有效分区的历史全部/current20曲线；固定完整current20汇总使用51分区 | TV、缺失概率质量、簇数覆盖的目标是全体历史固定簇；全量目标包含被抽子样本，不是外部新组验证 |
| roster_mixture | 51分区，固定total_k20，当前20人与历史其余人员的构成变化 | “outside current20”是历史其他人员，不是新人；不转成真实新队列验证 |
| bottleneck_reanalysis目录 | 目前仅核到READING_GUIDE说明，所指bottleneck_models_20260906.py未找到 | 不能宣称该说明对应完整可执行分析；本包依赖可定位的完整preflight与后续结果 |

115个历史partition记录包含103个保存成员的分区和12个原表明确`not_evaluable`的记录，后者member_count和cluster_count均为0。它们不是单簇或无分歧，也不应误报为文件丢失。partition状态和原始行保存在`cluster_partition_index.csv.gz`，其成员版本核对见主任务审计。

指标含义的最小区分是：平均两两差异的估计精度、选中代表布局的变化、相对参考的测量、整个响应分布的恢复、少数簇的发现可以有不同曲线。本包没有把其中任意一个自动命名为“标注质量上限”或“图像固有歧义”。

`full_reference_contains_evaluated_subset`讨论的是全体历史响应作为目标时是否含被抽子样本。参考布局质量行标为`not_applicable_reference_layout_provenance_separate`：这里没有人员全体均值参照，不等于已证明参考来源独立。参考布局的来源和形成过程需单独核对。

## 人员分组可行性算术

`same_image_disjoint_group_arithmetic.csv`按每个完整context逐一列出k15–20。若已有N位不同人员，两组同样大小且互不重叠的历史组要求`2k≤N`；最大等规模k为`floor(N/2)`。本批每图N≤26，因此两组历史15–20人均不可行。N25／26仅能提供两组12／13人的人数上界，且实际几何可算、同楼跨图固定人员交集可能更小。

在N26图中，第一组15人后最多剩11人，第一组20人后最多剩6人。N23图中分别剩8和3人；N20、k20时剩0人。有限历史人员内k接近N产生的稳定不能作为另一组同规模人员复现。

这不意味着剩余人员完全没有验证价值：互不重叠的少量剩余人员仍可评价15人组的代表布局或某些分布预测，只需明确评价人数和估计不确定性。它检验的是前组输出对剩余响应的预测，不能据此声称“另一组自身在15人也收敛”。

当前20人若拆成互不重叠的两组，同图人数上限为10/10；“当前有20人”不能解释为“历史20人之外新增20人”。没有历史同图记录的当前人员单独列示，但这只表示底座中未见其作答，不证明此前从未看过图片或模型输出；已标过同图者再标属于重复测量。需要未来人员时，表中只给“还缺多少不同响应”的算术，不把这些位置当已招募新人。

## 文件和字段入口

| 文件 | 粒度、关键内容 |
|---|---|
| `building_image_context_coverage.csv` | 270context；完整身份、每图人员清单、当前20覆盖、原几何可算数、两读法状态计数、初始化追溯/旧来源并列、已有分区/评论/图片URL；原字段未知保持未知 |
| `response_identity_index.csv.gz` | 2501canonical的来源、实际初始化追溯、簇/模型/参考连接；为上游已核对索引快照，不重选canonical |
| `building_summary.csv` | 22楼总图/contexts/响应/人员并集、每context支持范围和候选数；不定义全楼收敛人数 |
| `building_stage_condition_support.csv` | 按building×stage×condition×scope，全部context及高密度覆盖视图，跨所列context的共同人员与两组人数上界 |
| `candidate_images.csv` | 166候选且历史响应为0；building是否已有历史资料、房间类别属性、URL、既有人30/AI50/后续case连接、图片获取命令 |
| `worker_roster.csv` | 26人及当前20属性，不含新人员或推断类型 |
| `same_image_disjoint_group_arithmetic.csv` | 270context×6个k=1620行；一组支持、剩余人数、双组同k是否可能、所缺不同响应、有限总体端点标志 |
| `cluster_partition_index.csv.gz` | 115历史分区版本、状态、支持与原来源行，不新分簇或赋语义 |
| `existing_human_comment_index.csv`、`response_comment_links.jsonl` | 已有50图评论（45非空）及原对象连接；图级评语不能赋给整个簇或工人，空白裁决保持空白 |
| `existing_curve_inventory.csv` | 来源、生成器、度量、参照人群、固定簇/子样本关系、k范围和状态；汇总表未强行挂逐图 |
| `existing_curves_context_links.csv.gz` | 15329源行及context连接状态；original_row_json保留源值、原状态，source_row为0起始的数据行号 |
| `PREPARATION_QA.json`、`SOURCE_FILES.json`、`VALIDATION.json`、`FILE_LIST.json` | 整理覆盖、实际读取输入、输出关系校验和本目录交付清单；audit目录由主任务单独维护，未检测图片网络访问 |
| `audit/` | 协作主任务负责的独立原始来源、版本、数学与连接审计；不由本生成器写入 |

几何状态使用已有计算输出，仅作可计算性，不是视觉合法性或曼哈顿规则裁决。`room_instance_id`仍为空或未知，region_class房间类别不能补成实体房间ID。C1 Semi的历史旧初始化缺失标签与后续追溯来源并列，追溯到planned import也不等于有证据证明标注者实际看过哪个版本。

## 复现与读取

在仓库根目录，使用已有pandas及Python即可，无GPU或模型权重：

```powershell
.venv/Scripts/python.exe -m tools.thesis_main.data_prep.prepare_building_convergence_20260908 --root .
.venv/Scripts/python.exe -m tools.thesis_main.data_prep.prepare_building_convergence_20260908 --verify-only
.venv/Scripts/python.exe -m pytest -q tests/test_prepare_building_convergence_20260908.py
```

生成器只读仓库相对的输入包路径；`--root`指定其他checkout，`--out`可指定独立输出目录。原来源字段中的本机路径仅保留为追溯属性，不用于加载外部模型。CSV和gz可直接用pandas读取；原始全景不重复上传，按候选表命令或下例从已有URL获取：

```powershell
python analysis_results/uncertainty_cloud_inputs_20260906_v1/cloud_inputs.py image --package analysis_results/uncertainty_cloud_inputs_20260906_v1 --image-id IMAGE_ID --output panorama.jpg
```

本轮未进行网络图片访问验证；URL存在不等于云端一定可访问。图片读取与坐标/覆盖统计的离线完整性分开报告，不因没下载图片而假称已视觉检查。

相关3项测试通过，覆盖重复版本不增样本、同人跨block身份、building并集与每图支持区别、候选0响应、未知布尔拒绝、旧context顺序和有效键不能掩盖元数据冲突。这里只新增单个整理脚本及最小测试；不修改旧包或共享索引，索引同步由协作主任务最后完成。更改输入后应重新核对本说明的快照数量。
