> 当前研究意图与执行规则统一见[相似场景标注稳定性分析SOP](../../docs/thesis_main/相似场景标注稳定性分析SOP.md)。本文只解释原计算及其字段；旧阶段划分、软点数分簇、稳定人数和复现命令不代表新口径已完成。旧叙述/Word已撤下，数据与图保留审计。

# 历史计算与字段说明

## 实际修复与新增分析

- 修复旧inventory入口仅解析test_pano的根因；四组图像/标签清单全部参与连接，single视图合并到building+panorama身份。8个原始清单副本、2079条目标图行证据均保留。
- 380图中已连接唯一数值类别由123增至297：历史81→178/214，候选42→119/166；新增174图，83图仍缺，0冲突。原123图类别不变。
- 整数类别的语义名称尚未核实，全部380图仍缺已确认room instance与世界位置连接。不把数值类别称为客厅，不称已确认同室或异室。
- 复用原P1 Manual30图的固定历史分类TV曲线；全部435个图对，415个有共同有效排列。分别列同/异数值类别、未知类别与同/异building，报告图对等权与楼/楼对等权两个描述均值。
- 类别比较纳入所有30图；原building比较只纳入7栋多图楼的25图。重叠300图对身份、状态、共同排列相同；不以新范围的均值覆盖旧权重结果。
- 独立读取全部380图映射，核对原19218条数值输入并独立复算435图对及6组汇总。最大差均小于1e-12，为CSV保存精度量级。

## 文件及字段合同

[core/README_ZH.md](core/README_ZH.md)完整定义底层11张CSV、原始来源、副本与状态，含270context支持及24楼缺失.house清单。

顶层独立审查输出均为描述性派生资料，不能覆盖原始导出。空类别不强选；无共享有效排列的图对保留缺失，不记零。

| 文件 | 粒度与字段含义 |
|---|---|
| review/independent_images_380.csv | 一图一行；image_id/building_id/population_role；独立重读的class_code；class_name/room_instance_id为空；old_class_values_json与old_room_instance_id保留旧对照 |
| review/mapping_coverage.csv | 一图像池一行；旧/新连接、缺失与总数；字段见FILE_LIST |
| review/class_counts.csv | 数值类别1–12及unknown共13行；historical_images/candidate_images；buildings是两池合计的去重楼数，跨类别不可相加 |
| review/independent_class_pairs.csv | 435个无序图对；左右context/image/building/class_code；class_relation和building_relation为same/different/unknown；shared_replicates及JSON列表；status与curve_distance。unknown仅用于类别关系 |
| review/class_pair_summary.csv | 6种类别×楼关系；total_pairs候选数，image_pairs有效数；images/buildings/building_blocks为有效支持；pair_equal_mean/pair_median；block_equal_mean先楼/楼对内均值再单位均值；shared_replicates_min/max与pair_replicate_records（重复出现总量，不是独立样本数） |
| review/p1_class_curves.csv | 30图×6人数节点=180行；保留原context、阶段、block、条件、初始化、scheme/config/max_k/path/measure、k/mean/split_q10/split_q90/valid_splits，附class_code。各图自身固定窗口，不是图对共同支持 |
| review/INDEPENDENT_AUDIT.json | 原文件重读、旧映射、原曲线输入、图对与汇总的计数及最大误差；source_geometry_recomputed=false、source_curve_values_changed=false |
| review/REPORT_CONTENT_MANIFEST.json | 已撤下旧Word的图片来源顺序和全部表头/表体及来源说明；记录生成器与样式，不作为原统计真源 |
| review/DOCX_QA.json | 当时从旧Word ZIP/XML独立回读表格、图片、文本、宽度与使用的样式；图片字节与来源一致性。逐页分页渲染状态单列 |
| review/VISUAL_CHECKS.json | 本轮实际阅读图片的路径和范围；不新增人工语义或3D裁决 |
| DELIVERY_CHECKS.json / FILE_LIST.json | 历史交付记录及文档清理状态与当前文件大小、CSV列和行数；文件清单不包含自身 |

curve_distance先在每个k对图对共有排列各自平均TV，再取两条均值曲线的绝对差并平均6节点。不是逐排列绝对差的平均。200次重复历史人员排列不是200次独立实验；图对重复使用图像。两种权重均值未匹配类别组间的楼、人员、有效排列或图像内容，不能直接解释为类别因果效应、预测增益或最少人数。

## 复现与检查

在仓库根目录执行：

```powershell
.venv/Scripts/python.exe -m tools.thesis_main.data_prep.prepare_scene_similarity_revision_20260909
.venv/Scripts/python.exe tools/thesis_main/analysis/review_scene_similarity_revision_20260909.py --figures
.venv/Scripts/python.exe -m pytest -q tests/test_prepare_scene_similarity_revision_20260909.py tests/test_inventory_annotation_research_assets_20260905.py tests/test_review_scene_similarity_revision_20260909.py
```

底层11个不同测试已通过（含一次完整inventory集成和最后新增回归）；独立审查3项通过。准确运行分批见[core/TEST_RUN.txt](core/TEST_RUN.txt)及review检查记录，不把重复运行相加成测试数量。

已尝试标准render_docx.py，因没有LibreOffice可执行文件失败；隐藏Word COM也因登录会话不可用失败。本次能核对Word结构与图片来源，未能核对Word最终逐页分页。没有虚报PDF、页数或排版全通过。旧Word本次已撤下，以上仅说明当时的检查范围。

## 交付边界与后续

保留原始响应、坐标、点序、版本谱系、旧簇、问卷及用户确认派生记录；不改变正式协议、LS分发或人员资格。未新增采集、模型推理或3D审查，166候选远程可用性本轮未重测。没有提交或上传。

新工具/测试和本结果目录已检查项目地图，并在docs索引和地图增加本修订入口；原有未提交内容保留。

可继续的准备是取得并连接缺失房间元数据、核实数值字典、按同室多视点及同类异室整理联系表与支持清单。报告中的12图×16响应=192仅为估工示例，不是功效分析或正式任务分配。
