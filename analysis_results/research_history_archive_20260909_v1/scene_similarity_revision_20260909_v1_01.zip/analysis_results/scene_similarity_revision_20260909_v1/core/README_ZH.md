> 当前研究意图与执行规则统一见[相似场景标注稳定性分析SOP](../../../docs/thesis_main/相似场景标注稳定性分析SOP.md)。本文只解释原计算及其字段；旧阶段划分、软点数分簇、稳定人数和复现命令不代表新口径已完成。旧叙述/Word已撤下，数据与图保留审计。

# 场景相似性解释修订：底层资料与字段

本包修复类别清单的连接遗漏，并复用已有图像曲线作描述。原始标注、几何、旧结果和正式协议不改。building 是减少筛选成本的粗代理，不是房间实例；同一房间换位置与不同房间同类别是不同验证问题。既有曲线仍是同图留出历史人员的结果，不能改称新图预测成功或人数已足够。

## 修复根因

旧入口 `tools/thesis_main/data_prep/inventory_annotation_research_assets_20260905.py` 的 `_room_region_mapping_audit` 只取候选路径数组最后两项，即 test_pano 的图像/标签文件。其他 train 与 single 文件只登记存在性，未参与连接。其 `_aligned_pano_region_records` 也只识别 `data/mp_sb/<building>/<pano>.jpg`。

修复为遍历所有 `*_image.txt` 并连接同名 `*_label.txt`，同时识别 `<building>/undistorted_color_images/<pano>_i<camera>_<yaw>.jpg`；ID 使用 building+panorama，不能只用同名 UUID，也不能把透视图朝向当不同全景。保留原始行号，空行/格式不符/标签非整数/行数不一致显式报错，不分别删除空行导致错位。冲突标签保留为集合，不强选类别；新包生成遇到无法解析的来源会停止。

仅改代码，不重新生成旧历史目录。旧资料用于差异对照，后续消费者应读取本包 `images_380.csv`。

## 来源和覆盖

官方本地副本：`D:/Work/Manhattan_3D/mp3d_layout_gt_sources/Matterport_official/tasks/region_classification/data/`。本包 `sources/` 保留 train/test × pano/single × image/label 的8个原文件副本，总5,637,071字节；源文件没有被修改。

| 人群 | 总图数 | 有唯一数值类别 | 缺失 | 冲突 |
|---|---:|---:|---:|---:|
| 历史标注图 | 214 | 178 | 36 | 0 |
| 无历史标注候选 | 166 | 119 | 47 | 0 |

相比旧连接新增174图：97历史图、77候选图。原有123图保持原数值类别；另83图仍缺失。297图的 pano 与 single 来源一致，2079条原文件行连接证据可追溯。同一 pano 的多张透视图不是多个独立场景。类别覆盖增加不增加真人标注支持。

## 数值类别名称仍未核实

官方[分类任务 README](https://github.com/niessner/Matterport/blob/master/tasks/region_classification/README.md)只说明任务；本地 DataLoader.lua 直接将标签转整数并取最大类数，未定义1–12的语义字典。[数据组织说明](https://github.com/niessner/Matterport/blob/master/data_organization.md)使用字符区域标签，例如 l 为 living room，另有 f/familyroom、n/lounge；这不能证明整数12等于字符l。mpcat40/category_mapping 是物体类别，不能拿来代替房间类别。

2026-09-09只读核查官方分类目录、README、DataLoader及数据组织说明，未找到可靠整数→房间名称映射。官方仓库 [issue 52](https://github.com/niessner/Matterport/issues/52)存在用户对相同编码问题的提问，读取到的页面没有可用官方解答；提问本身不是编码事实证据。尝试读取官方 metadata/panorama_to_region.txt 未成功，不能据此声称该资产不存在。该检索未阻塞其它工作，也未下载图像/mesh。

因此本包只能比较“同数值类别”与“不同数值类别”，`class_name` 全部为空，不称“同客厅”。同类别也不等于已核实视觉相似。

## 字段与文件

| 文件 | 内容与关键字段 |
|---|---|
| images_380.csv | image_id/building_id/split/population_role；class_values_json 是全部观测标签；唯一时 class_code 有值；mapping_status=mapped_numeric_class/missing/conflict；class_name 为空；source_image_files_json；room_instance_id/position_x/y/z 为空且相应状态为缺失 |
| mapping_diff.csv | 380图旧/新类别集合，change=unchanged/newly_connected/changed_or_conflict |
| source_files.csv | 8个文件名、原路径、字节、行数、train/test、pano/single、解析状态和官方URL |
| mapping_evidence.csv.gz | image_id/class_code/source_image_file/source_label_file/line_number/source_split/source_kind；行号从1开始 |
| historical_context_support.csv | 270个完整context，含阶段、block、条件、初始化、图/building/数值类别、raw_workers/computable_workers/raw_versions，以及2/3方案窗口5/8/15人数支持划分数 |
| class_stage_coverage.csv | 按 stage/block/raw_condition/initialization_kind/class_code/mapping_status 分层的图数、context数、楼数、canonical总数、每图人数最小/最大与15人窗口支持；缺类别也保留 |
| curve_support.csv.gz | 91663条既有 context_curves 行，逐行附类别；原metric/path/config/scheme/window/k/有效分母及数值保留，未重算几何 |
| pair_curve_inputs.csv.gz | 19218条既有数值：P1/manual/block0、cap30/t6、2/3、full_history_fixed/distribution_tv、窗口3/5/8/10/12/15；META+split_id/replicate/k/value。每图使用旧固定窗口全节点有值集合 |
| class_pair_curves.csv | 30图全部435个无序图对；左右图/context/building/类别，class_relation 与 building_relation；shared_replicates及完整JSON、status、curve_distance。无共同排列保留NaN，类别缺失记unknown |
| class_pair_summary.csv | 3种类别关系×2种building关系，共6行；候选/有效图对、有效图数/楼数/楼单位数、两种权重均值、共享排列最小/最大/总出现次数/去重数，及支持状态 |
| missing_house_files.csv | 24栋楼、历史/候选图数、所需 `<building>/house_segmentations/<building>.house` 路径及字段。实例键需building+region_index，不是单一跨楼region编号 |
| RUN_QA.json | 来源、覆盖、行数、缺失及旧图对重叠核查结果 |

META 指 context_key/image_id/building_id/stage/block_index/raw_condition/initialization_kind。`raw_workers` 是该完整context的canonical人数，同人跨条件/阶段不自动成为新独立人员。人数支持与曲线指标真正可计算支持不同，应结合 curve_support、固定窗口mask读取。

## 图对口径和限制

每图沿用15人窗口有效划分集合；每图对先取共同 replicate，再在各 k 上分别平均TV，取两图均值差绝对值，最后6个节点等权平均。计算的是平均曲线差，不是逐排列绝对差的平均，不是几何误差本身。不同图对共有排列集合不同；200次是同批历史人员组成敏感性，不是200次独立实验。

本轮类别问题不要求每栋楼至少两图，因此30图均进入；旧同楼/异楼对照为25图、300图对。本包包含这些旧图对，其有效状态与共同排列人数完全相同，最大数值差4.94e-13来自旧文件小数保存；另135图对不是对旧结果的覆盖。旧总体同楼均值仍按旧人口定义保留。

`pair_equal_mean` 对有效图对等权；`building_unit_equal_mean` 先在同楼内或同一无序楼对内平均图对，再对楼/楼对等权。图多的楼在第一种口径权重更大。各类别关系的图/楼/有效排列集合不同，两个均值都仅为描述，不能直接相减解释类别因果效应或新图预测增益；本轮不追加显著性检验，不挑阈值，不从好看曲线反选场景。unknown 关系单列，不混入不同类别。

同数值类别同楼有效10对；同类异楼86对；异类同楼17对；异类异楼194对。支持最少的部分图对只共享1次排列，应结合各行分母阅读，不能当稳定差异证明。

## 实例与位置仍缺失

380图全部没有已确认 room_instance_id/世界位置连接。已检查的两工作目录及官方副本未找到实际 MP3D `.house` 数据。官方说明及 `code/gaps/apps/mpview/mp.cpp` 读取代码表明：.house 内 panorama 的 UUID/region_index/位置和 R 区域记录可建立连接。房间区域元数据仍不自动等于全景所见布局的边界；未确认前不得推断同房多视点，也无每房至少3全景位置保证。

仅为实例、区域类别与全景位置，文本.house足够，无须先下载原图或mesh；但官方分发的house_segmentations归档可能含mesh，归档体积不能直接称“小”。世界相机完整朝向另需外参资料，不能由现有布局坐标猜。缺失清单是本次有界本地检查结果，不是断言其它机器或官方没有这些资产。

## 复现

```powershell
.venv/Scripts/python.exe -m tools.thesis_main.data_prep.prepare_scene_similarity_revision_20260909
.venv/Scripts/python.exe -m pytest -q tests/test_prepare_scene_similarity_revision_20260909.py tests/test_inventory_annotation_research_assets_20260905.py
```

可用 `--root`、`--official-root`、`--out` 指定来源/输出。不需要GPU、权重或新增标注。生成只写新core；原解析器的修复不自动覆盖旧审计。顶层完整报告、解释勘误、图/Word与地图由协作任务统一完成。
