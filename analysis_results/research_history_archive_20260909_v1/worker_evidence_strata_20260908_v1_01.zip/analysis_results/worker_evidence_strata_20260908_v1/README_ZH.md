# 逐工人证据与暂定分层（探索性，2026-09-08）

本包执行用户固定的人员差异与留出验证计划。主分析为C1 Manual，P1 Manual为跨阶段对照，C2为补充，Semi单独分析。全部26人、2501份canonical和2513条版本谱系保留；没有按旧资格整体删除人员，没有增加标注或人数收敛模拟。原始标注、旧分类、人工裁决和正式协议均不改变。

先读[导师汇报增补稿](导师汇报增补稿.md)和[26人工人证据表](26人工人证据表.md)。完整成员见[strata_membership_summary.csv](strata_membership_summary.csv)，完整数值见[worker_evidence_26.csv](worker_evidence_26.csv)及[逐阶段证据](worker_stage_metric_evidence.csv)。表中W前缀只供显示，CSV的worker_id为原编号。

## 固定方法和适用边界

- 三轴分别计算：原始端点数/2；相机到地面的高度统一为1时地面面积的自然对数；地面Jaccard距离 `d_E−d_X`，其中 `d=1−IoU`。后两者并列原邻接与历史pairmap读法。Bi native_uv为主，旧整数和像素中心整数为敏感性。
- 原端点数必须是非空偶数数组才计算数量。它不保证上下点配对正确。地面多边形可算也不证明满足曼哈顿约束或范围正确；本轮不移动角点、不强制拟合正交、不覆盖原序。
- 使用完整context_key，不把跨block同名任务拼成一个任务。同人同context只保留已核对的canonical。缺失值、无同伴的context保留在证据表，但不为人员相对差异提供信息。
- 消去任务固定效应后拟合人员固定效应；每个图连接分量内以人员等权均值为零。每个全量及留出训练拟合均与仓库已有固定效应实现核对；分量之间不能全局排名。
- 每次按building恰好抽500次，种子以20260908为基础确定。不对building内任务二次抽样，不补抽缺人或断连的重采样。只要阶段、条件、留出折及人员/building清单相同，读法、精度和来源敏感性使用同一批随机抽样，隔离Monte Carlo波动。
- 95%区间完全在零一侧才给出高/低候选，跨零为uncertain；可用building少于3或有效重采样不足80%为insufficient。区间是探索性逐人区间，未经多人多轴同时推断校正，不是人格概率。
- 每折仅在训练building内重新分层。高/低层预测取该层训练人员效应的等人均值；uncertain/insufficient作零预测的弃权，**不是中等型人群**。测试中实际值、连续预测、分层预测在完全相同的context×训练分量×留出同伴集合中心化。
- 表中的 `*_r2 = 1−模型MSE/无人员效应基线MSE`。记录等权直接平均平方误差；building等权先算各building的MSE再等权平均，**不是平均各building的R²**。无分歧导致分母为零时R²为空。双权重均大于零只表示达到本轮预定的描述性保留门槛，不是显著性证明。
- `decision=retain_strata` 是验证门槛状态；是否存在可交付的全量成员还须看 `delivery_status` 和成员列。可能出现折内模型略优但全量固定人员组重采样失败过多，最终没有可分成员。
- C1→其他阶段/条件的迁移也排除目标building；只评价共同人员。属于历史资料的跨阶段验证，不是假装按时间前瞻收集的独立试验。不能把不同全量人员零点的效应直接相减。

## 敏感性与辅助资料

`available`保留该读法全部可用记录；`common_geometry`固定C1两读法及Bi三种精度均可用的canonical集合；`no_revision_or_crosscondition`仅在C1 Manual排除4条有修订记录和2条同人同图存在另一条件的记录。后二者是敏感性，不是新资格规则，主分析不变。时间顺序未被用来猜测未观测的模型暴露。

单图删除表只诊断全量连续效应是否由单一图像支撑，不重新找类别。单building评分删除表只检查总体留出收益是否由一栋支撑，不等同于再次完成外层交叉验证。Semi按初始化来源分解的是原留出预测误差，不另行训练来源专属分类。

参考指标按原来源、指标名称和争议状态保存。4条源文件明确标记的坏GT记录单列；其余“available”或“reference_ready”也不被推断为人工已确认无争议。C1辅助参考仅用已有worker_final/c1_iou_to_gt数值，不制造P1 Manual缺少的对应指标。已有用户确认点序派生另表保留。

时间辅助效应使用log(active_time_seconds)，不以lead_time补缺。C1严格版本仅使用formal_available且timing_status=eligible；partial_session_coverage与protocol_deviation分别保留，另给纳入这些标志记录的敏感性。辅助效应/秩相关只作描述，不另设速度或质量类型。

C1 Semi的106条记录有既有改动指标，但初始化来源仍为`missing_required_initialization`；不能仅凭这些指标宣称已独立找全历史实际初始化。P1的control_natural、trap_natural和trap_synthetic_disjoint_source分开报告。

## 文件与字段字典

| 文件 | 粒度、关键字段与用途 |
|---|---|
| `inputs/worker_metrics.csv.gz` | canonical×metric×reading×representation；value、status并存，保留身份、几何失效和Bi双头距离；原始值不会因建模不适用而消失 |
| `inputs/canonical_index.csv.gz`、`annotation_version_lineage.csv.gz`、`response_history_flags.csv` | canonical、版本谱系和修订/已观察跨条件属性；版本不增加独立样本 |
| `inputs/worker_stage_condition_coverage.csv` | 26人×7阶段条件，含P1 oos；没有该阶段用0表示覆盖，成绩不补0 |
| `inputs/auxiliary_worker_summary.csv` | worker×阶段条件×family×来源/状态×metric，903行；source_rows、observed_values、missing_values为明确分母；见[辅助字段说明](inputs/AUXILIARY_README_ZH.md) |
| `worker_evidence_26.csv`、`26人工人证据表.md` | 26人的总入口，C1主画像、各阶段覆盖、辅助差异、训练折标签次数和解释限制 |
| `worker_stage_metric_evidence.csv` | 26人×阶段条件×轴版本×cohort，2184行；stage_total/cohort_rows/finite_rows/informative_rows逐级覆盖，coverage_status解释缺席/缺失/单人context/独立分量 |
| `worker_strata_results.csv` | 可估计的全量worker×轴版本：effect/lower/upper/label、bootstrap_valid_fraction、component、reference_workers、decision及验证收益 |
| `strata_membership_summary.csv` | 每轴版本的高/低候选、跨零、支持不足与无分成员，decision和delivery_status分别报告验证与交付状态 |
| `worker_profiles_all_folds.csv.gz` | 全量与每折训练画像；fit_id、fold、seed、training_buildings可追踪训练隔离 |
| `bootstrap_diagnostics.csv.gz` | 每fit恰500行；replicate从0计数，status、rank、missing_workers和按training_buildings排序的building_counts_json；失败不补抽 |
| `heldout_predictions.csv.gz` | 每个实际验证响应；evaluation区分within_stage_lobo/C1_manual_transfer，target与两预测均同批同伴中心化，附三种平方误差 |
| `heldout_exclusions.csv.gz` | 已有可算同伴记录在留出折/迁移中无法预测的清单；几何失效与原单人context另见完整逐阶段证据和inputs |
| `validation_summary.csv`、`validation_by_building.csv` | 总体双权重R²、支持门槛，以及各building的实际MSE和样本数 |
| `worker_bi_residuals.csv`、`bi_counterexample_candidates.csv` | 双头差值、双头间距、到两头的距离及最小残差；反例候选按连续数值排序，不是新增歧义/质量标签 |
| `auxiliary_adjusted_effects.csv`、`auxiliary_axis_associations.csv` | C1参考与时间的独立任务调整效应、与三轴的共同人员秩相关；不做综合分数或独立验证宣称 |
| `cross_stage_common_reference_effects.csv` | 阶段之间先连接共同人员，再在每对分量交集内重置零点；用作描述，真正预测见heldout |
| `semi_validation_by_initialization.csv` | 原Semi留出预测按实际来源类别分解的误差；不外推到未知初始化 |
| `leave_one_image_influence.csv.gz`、`leave_one_building_score_influence.csv` | 单图连续效应/单building评分贡献诊断，非新增分层规则 |
| `RULES_AND_QA.json`、`SUMMARY_QA.json`、`DELIVERY_QA.json`、`FILE_LIST.json` | 规则、覆盖、独立读取校验和实际文件清单 |
| `METHOD_REVIEW.md` | 子智能体独立实现与数值复算审查；主任务核对后形成报告 |

Bi轴的high/low是**任务调整后的差值相对零点**；即使是high，个人原始均值仍可能更近enclosed。无论正负，都不能省略到两头的残差。

## 复现与验收

在仓库根目录运行；使用现有Python环境（numpy、pandas、scipy、shapely、matplotlib、pytest），无需GPU、模型权重或新依赖。

```powershell
.venv/Scripts/python.exe -m tools.thesis_main.analysis.prepare_worker_evidence_metrics_20260908
.venv/Scripts/python.exe -m tools.thesis_main.analysis.fit_worker_evidence_strata_20260908
.venv/Scripts/python.exe -m tools.thesis_main.analysis.summarize_worker_evidence_20260908
.venv/Scripts/python.exe -m tools.thesis_main.analysis.summarize_worker_evidence_20260908 --verify-only
.venv/Scripts/python.exe -m pytest -q tests/test_fit_worker_evidence_strata_20260908.py tests/test_prepare_worker_evidence_metrics_20260908.py tests/test_audit_bilayout_precision.py tests/test_prepare_human_bi_comparisons_20260908.py
```

前两步复用已整理底座、模型比较和原始来源解析；只读取本包已有输入后重做拟合可从第二步开始。仅核验交付表可运行第四步。汇报稿是基于本次运行的人工撰写分析，改变输入后需重新核对文字，不能把旧解释原封不动套到新数值。

相关11项测试覆盖完整身份、修订不增样本、图断连、缺失几何、固定比较基准、训练/验证隔离、相同抽样的精度敏感性、争议参考、原序保持，以及有/无真实人员差异的合成数据。未运行全仓库训练、旧正式实验或Label Studio运营测试，因为这次不改这些路径。实际读取校验与独立复算见QA和审查文件。

项目地图和README以探索性结果入口登记。本包完成后停止，不因未得到理想类别继续换算法、调阈值或扩展样本；没有进行新标注、疲劳模拟、人数上限拟合、论文定稿或Git发布。

统计护栏检查通过：已核对现有SAP和Overleaf统计章节；本轮为用户指定的独立历史探索，不解释正式阶段效应，不改T1/V1估计目标、failure/行政删失、routing、停止规则或正式active_time口径。未写入Label Studio运营工件。新增三份分析脚本、两份测试及本包；索引只增加探索入口，保留其他任务的未提交改动。
