# 独立辅助证据汇总

`auxiliary_worker_summary.csv` 以 worker_id × stage × raw_condition 分层，family 区分 reference、active_time、initialization；每个 family 的进一步分组字段见下文。仅有事实记录的组生成行，无记录的阶段不得补零或借另一阶段代替。

- reference：按 measurement_role、metric_name、source_path、reference_type、reference_quality_status、reference_dispute_status、measurement_status 分开。metric=source_metric_name 表示实际指标名称见 metric_name。原分数可用不代表参考无争议；明确坏 GT 与未知分别保留。均值为描述性原量纲，不用于跨任务质量排序或新综合分数。
- active_time：按 active_time_formal_available、timing_status、timing_rule_version、active_time_source 分开。partial_session_coverage、protocol_deviation、fallback 均不混入无此问题的组。非正式可用但有数值的 fallback 仍作为单列来源资料，不当正式 active_time；lead_time 未参与任何汇总。无值的 mean/median/minimum/maximum 留空。
- initialization：按实际 initialization_source_kind、source_path 分开。exact_geometry_equal 与 topology_changed 的 mean 是已观察布尔响应中的比例，分母 observed_values；RMSE 仅在已有可计算记录中汇总，结构变化后缺失不填零。不把这些指标命名为正确性或新综合保留率。

所有行的 source_rows 是该来源分组记录数；canonical_responses、contexts、buildings 是该组独立身份覆盖；observed_values 是有限数值的分母，missing_values=source_rows−observed_values。stage_condition_total_canonical 是该工人在阶段条件内的完整 canonical 总数，用于覆盖对照。reference 多个指标行不能相加作为人数或样本数。主表的阶段覆盖总入口继续使用 worker_stage_condition_coverage.csv（26人×7条件）；所有无该阶段的人员仍留在总表，分数不填。
