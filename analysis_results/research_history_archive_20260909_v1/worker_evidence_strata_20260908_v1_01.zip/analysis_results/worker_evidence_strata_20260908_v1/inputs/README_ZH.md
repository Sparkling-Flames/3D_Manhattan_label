# 人员分析指标输入

生成：`.venv/Scripts/python.exe -m tools.thesis_main.analysis.prepare_worker_evidence_metrics_20260908`。

`worker_metrics.csv.gz` 使用 canonical_annotation_id × metric × reading × representation 唯一键；context_key 保留阶段、block、条件。value 缺失与 status 同时保留，不删除失败响应。

- corner_pair_count：原始点数/2，仅完整偶数数组可算；不证明垂直配对或建筑角点正确。坐标无效不消除已知点数。
- log_floor_area：同相机高度单位的地面多边形面积自然对数。原邻接与历史 pairmap 分列，后者不等于作者确认邻接。representation 为 raw_float_coordinates。
- bi_delta：d_enclosed − d_extended，负值相对更近 enclosed；正值相对更近 extended。同时保留 d_bi、minimum_residual、两头距离及失败状态。native_uv 为主要对照，两个整数版本仅敏感性。距离为地面 1−IoU，不是语义类型或正确性。

用户确认派生仅见两个 user_confirmed 文件，不覆盖任何 canonical 原序。source_kind 区分响应和参考。

辅助表保持来源合同：reference_measurement 内 reference_identity/type/quality_status 和 metric_name 原样保留，reference_dispute_status 仅将源文件明确 researcher_confirmed_bad_gt 标为 source_researcher_confirmed_bad_gt，其余为 unknown_not_adjudicated，不能当作无争议；需结合既有语义证据逐个限制。active_time_context 的可靠性沿用 formal_available/timing_status/source，lead_time 永不补 active_time。proposal_response 使用 canonical 身份连接，保留 exact_geometry_equal/topology_changed/RMSE 和自然或合成初始化类别，不定义新的保留率。

worker_stage_condition_coverage 是 26 人 × 已观察阶段条件的完整覆盖；零覆盖不补成绩。本模块不拟合、不分层，不改变旧资格和人工裁决。

response_history_flags.csv 保留 2501 canonical 的 raw_version_count/has_revision，完整谱系见 annotation_version_lineage.csv.gz（2513版本；9份canonical有额外12版本）。worker_image_context_count/worker_image_condition_count 按同人同图统计已观察条件，multiple_condition_observed 与当前响应的 assistance_exposure 分开。C1有4条响应属于2个同人同图多条件配对；这不证明条件时间先后或未观测的模型暴露，不使用提交时间反推暴露史。
