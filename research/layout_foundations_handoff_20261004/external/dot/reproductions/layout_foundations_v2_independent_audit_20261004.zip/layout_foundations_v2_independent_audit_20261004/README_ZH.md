# 独立核验最小包

先读`REPORT_ZH.md`。本包含所用080949原仓库文件、作者v2必要运行代码/最小案例输入、独立验证器、已执行结果及两幅实际查看的图，不含整个研究库。

## 一条命令重放

建议Python 3.12或3.13；本次独立环境是Python 3.12.14，NumPy 2.3.5、SciPy 1.17.0、Shapely 2.1.2。作者为Python 3.13.5，三项数值依赖相同。

```sh
python -m pip install -r requirements.txt
python run_audit.py --out ./NEW_AUDIT_RUN --plots
```

输出必须为新目录或空目录。入口复制必要代码/案例到新目录，运行32项原测试、作者四阶段、原仓库函数交叉核验和独立压缩检查。不会改写包内源文件或已交付结果。省略`--plots`可不重新绘图。Matplotlib只用于图。

`source/`是8个已按Git blob校验的仓库原文件；`replay/`是作者v2必要代码和输入副本。当前原Lee/点算法以未经修改函数体AST隔离执行，详见报告，不能宣称整仓正常导入集成通过。`expected_replay_hashes.json`保存作者29份交付的SHA-256；当前环境重跑29份全部相同。其他平台如仅哈希不同应看具体数值，不能自动称算法错误。

## 主要工件

- `rerun_results/`：本次实际重跑的29份作者格式结果；构造与GT评价仍分阶段，构造散列先冻结
- `*_pinned_original_points.json`：080949原点函数的完整身份、支持和失败/歧义返回
- `*_pinned_lee.json`：080949原Lee函数结果几何与tile支持
- `pinned_method_comparison.json`：四个图×规则设置的对照数值
- `compression_independent_validation.json`：十个压缩配置及203条边的独立误差账本
- `source_manifest.json`、`input_manifest.json`：代码来源与最小输入哈希
- `unit_tests.log`、`rerun.log`、`independent_validation.log`、`portable_acceptance.json`：执行证据
- `figures/`：两图全员/点/精确弧/压缩叠图，上下差异单列，未叠原照片或GT

源数据未修补、资格未恢复、GT未更换、原环未重排、未发布GitHub。完整源字段核查与真实照片语义核验不属于本包已完成事项。
