"""Render independently reproduced source/current/arc comparisons without GT."""
import json,pathlib,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'replay/src'),str(ROOT/'replay')]
from run_research import normalized_cases
from arc_consensus import Ring,W,TAU,footprint

OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
for label,image,records,_ in normalized_cases():
    ff=json.loads((ROOT/'rerun_results'/f'{label}_fusion.json').read_text());exact=ff['methods'][ff['bev_mv50_complete_method']]
    compressed=json.loads((ROOT/'rerun_results'/f'{label}_compressed_0.5px.json').read_text())
    point=json.loads((ROOT/f'{label}_pinned_original_points.json').read_text())['mv50']['candidate']
    x=np.unique(np.r_[np.linspace(0,W,4097)[:-1],np.array(exact['points'])[::2,0],np.array(compressed['points'])[::2,0]])
    vals=[Ring(r).evaluate(x/W*TAU) for r in [exact,compressed,point]]
    fig,ax=plt.subplots(2,2,figsize=(14,8.5),layout='constrained')
    colors=['#147d92','#ab327c','#d37910'];names=['Exact arc (Lee >=50% floor)','Compressed 0.5 px','080949 original point >=50%']
    for r in records:
        y=Ring(r).evaluate(x/W*TAU)
        ax[0,0].plot(x,y[0],color='.75',lw=.6,alpha=.6);ax[0,0].plot(x,y[1],color='.75',lw=.6,alpha=.6)
        f=footprint(r)[0];f=np.r_[f,f[:1]];ax[0,1].plot(f[:,0],f[:,1],color='.75',lw=.65,alpha=.55)
    for r,y,col,name in zip([exact,compressed,point],vals,colors,names):
        for side in [0,1]:ax[0,0].plot(x,y[side],color=col,lw=1.25,label=name if side==0 else None)
        f=footprint(r)[0];f=np.r_[f,f[:1]];ax[0,1].plot(f[:,0],f[:,1],color=col,lw=1.5,label=name)
    ax[0,0].set(xlim=(0,W),ylim=(512,0),xlabel='ERP x (px)',ylabel='ERP y (px)',title=f'{len(records)} complete input records; no GT')
    ax[0,0].axhline(256,color='.45',lw=.6,ls=':');ax[0,0].legend(fontsize=8,loc='center')
    ax[0,1].set_aspect('equal');ax[0,1].set(xlabel='Floor X / h',ylabel='Floor Z / h',title='Same camera and source ring; no alignment')
    for side,name,col in [(0,'top','#6b50a1'),(1,'bottom','#21926b')]:
        ax[1,0].plot(x,vals[1][side]-vals[0][side],color=col,label=name,lw=1)
        ax[1,1].plot(x,vals[2][side]-vals[0][side],color=col,label=name,lw=1)
    ax[1,0].axhline(.5,color='.5',ls='--');ax[1,0].axhline(-.5,color='.5',ls='--')
    for a in [ax[1,0],ax[1,1]]:a.axhline(0,color='.5',lw=.5);a.set(xlim=(0,W),xlabel='ERP x (px)',ylabel='Signed y difference (px)');a.legend(fontsize=8)
    ax[1,0].set_title('Compressed minus exact: separate approximation budget')
    ax[1,1].set_title('Point medians minus exact arc: different aggregation target')
    fig.suptitle(f'{image} | point consensus {len(point["points"])//2}, exact knots {exact["pair_count"]}, compressed {compressed["pair_count"]}',fontsize=13)
    fig.savefig(OUT/f'{label}_independent_comparison.png',dpi=150);plt.close(fig)
    print(OUT/f'{label}_independent_comparison.png')
