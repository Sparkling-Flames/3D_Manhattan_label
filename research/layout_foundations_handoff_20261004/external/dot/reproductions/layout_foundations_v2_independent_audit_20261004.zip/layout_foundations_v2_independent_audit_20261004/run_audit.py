"""Portable read-only-input replay into a fresh directory supplied by --out."""
import argparse,pathlib,shutil,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser(__doc__);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--plots',action='store_true');a=p.parse_args()
    out=a.out.resolve()
    if out.exists() and any(out.iterdir()):raise ValueError('Use a new or empty output directory')
    out.mkdir(parents=True,exist_ok=True)
    for folder in ['source','replay']:shutil.copytree(ROOT/folder,out/folder,ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
    for name in ['verify_algorithms.py','plot_audit.py','source_manifest.json','expected_replay_hashes.json']:
        shutil.copy2(ROOT/name,out/name)
    def run(args,cwd,log):
        with (out/log).open('w') as stream:
            proc=subprocess.run([sys.executable,*args],cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
        if proc.returncode:raise RuntimeError('Failed stage; see '+log)
    run(['-m','unittest','discover','-s','tests','-v'],out/'replay','unit_tests.log')
    run(['run_research.py','--out','../rerun_results','--stage','all'],out/'replay','rerun.log')
    run(['verify_algorithms.py'],out,'independent_validation.log')
    if a.plots:run(['plot_audit.py'],out,'plots.log')
    print('Completed tests, fresh construction/evaluation/controls/synthetics and independent checks.')
    print('Read independent_validation.log and replay_comparison.json in',out)
if __name__=='__main__':main()
