"""Independent v2 review. Never writes input/replay source; no GT in construction.
Exact repository function bodies are AST-loaded from hash-verified pinned files.
This is a function-level reproduction, not a full-repository integration test.
"""
import ast,copy,csv,hashlib,importlib.util,json,math,pathlib,sys,warnings
from collections import defaultdict
import numpy as np
import scipy
from scipy.cluster.hierarchy import fcluster,linkage
from scipy.spatial.distance import squareform
from scipy.optimize import minimize_scalar
import shapely
from shapely import contains_xy
from shapely.geometry import Polygon,mapping
from shapely.ops import polygonize,unary_union
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'replay/src'))
sys.path.insert(0,str(ROOT/'replay'))
from arc_consensus import Ring,TAU,W,H,footprint,digest
from run_research import normalized_cases

def dump(name,obj):
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False))

def extract(path,names,ns):
    p=ROOT/'source'/path;tree=ast.parse(p.read_text())
    tree.body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert len(tree.body)==len(names),(path,names)
    exec(compile(tree,str(p),'exec'),ns)

def load_source():
    manifest=json.loads((ROOT/'source_manifest.json').read_text())
    for row in manifest['files']:
        b=(ROOT/'source'/row['path']).read_bytes()
        row['actual_blob_sha']=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        row['match']=row['actual_blob_sha']==row['git_blob_sha']
    assert all(r['match'] for r in manifest['files'])
    dump('source_verification.json',manifest)
    spec=importlib.util.spec_from_file_location('pinned_geometry',ROOT/'source/tools/label_studio/panorama_studio/geometry.py')
    geometry=importlib.util.module_from_spec(spec);spec.loader.exec_module(geometry)
    ns=dict(np=np,analyze=geometry.analyze,copy=copy,math=math,defaultdict=defaultdict,linkage=linkage,
      fcluster=fcluster,squareform=squareform,SCHEMA='global_pair_consensus_20261004_v1',
      warnings=warnings,Polygon=Polygon,unary_union=unary_union,polygonize=polygonize,contains_xy=contains_xy)
    base='tools/thesis_main/analysis/'
    for f,names in [('paired_split_research/study.py',['angular']),('point_pattern_demo_20261003.py',['_pairs']),
      ('research_round_20260929.py',['reconstruct']),('union_branch_consensus_20260926.py',['_ring_key']),
      ('global_pair_consensus_20261004.py',['_identities','_ring_diagnostics','_result','build_global_pair_consensuses','build_global_pair_consensus']),
      ('audit_supervisor_gt_sensitivity_20260922.py',['region_mesh']),('lee_tile_stage1_20261002.py',['tile_consensus'])]:
        extract(base+f,names,ns)
    return ns

def compare_saved_replay():
    rows=[]
    expected_path=ROOT/'expected_replay_hashes.json'
    if expected_path.exists():
        for name,expected in json.loads(expected_path.read_text()).items():
            p=ROOT/'rerun_results'/name
            actual=hashlib.sha256(p.read_bytes()).hexdigest()
            rows.append(dict(file=name,byte_identical=actual==expected,expected_sha256=expected,actual_sha256=actual))
        dump('replay_comparison.json',rows)
        return rows
    def compare(a,b,path,stats):
        if isinstance(a,dict):
            assert set(a)==set(b),(path,'keys');[compare(a[k],b[k],path+'/'+k,stats) for k in a]
        elif isinstance(a,list):
            assert len(a)==len(b),(path,'length');[compare(x,y,path+'/'+str(i),stats) for i,(x,y) in enumerate(zip(a,b))]
        elif isinstance(a,(float,int)) and not isinstance(a,bool):
            stats['numeric_fields']+=1;stats['max_abs_delta']=max(stats['max_abs_delta'],abs(a-b))
            assert np.isclose(a,b,rtol=1e-10,atol=1e-10),(path,a,b)
        else:assert a==b,(path,a,b)
    for p in sorted((ROOT/'replay/results/final').iterdir()):
        q=ROOT/'rerun_results'/p.name
        if not q.exists():continue
        stats=dict(file=p.name,byte_identical=p.read_bytes()==q.read_bytes(),numeric_fields=0,max_abs_delta=0.)
        if p.suffix=='.json' and p.name!='construction_freeze.json':compare(json.loads(p.read_text()),json.loads(q.read_text()),p.name,stats)
        elif p.suffix=='.csv':
            aa=list(csv.DictReader(p.open(encoding='utf-8-sig')));bb=list(csv.DictReader(q.open(encoding='utf-8-sig')))
            assert len(aa)==len(bb)
            for a,b in zip(aa,bb):
                for k in a:
                    try:x,y=float(a[k]),float(b[k])
                    except ValueError:assert a[k]==b[k];continue
                    compare(x,y,p.name+'/'+k,stats)
        rows.append(stats)
    dump('replay_comparison.json',rows)
    return rows

def independent_max_error(c,d,lo,hi):
    # Separate numerical method: 1001-point scan plus bounded local maximization.
    # Does not call author's polynomial stationary-point solver. Not a proof.
    def f(x):return H/np.pi*abs(np.arctan(c@[np.sin(x),np.cos(x)])-np.arctan(d@[np.sin(x),np.cos(x)]))
    x=np.linspace(lo,hi,1001);M=np.c_[np.sin(x),np.cos(x)]
    y=H/np.pi*abs(np.arctan(M@c)-np.arctan(M@d));best=float(y.max());arg=float(x[y.argmax()])
    peaks=np.flatnonzero((y[1:-1]>=y[:-2])&(y[1:-1]>=y[2:]))+1
    if y.max()<1e-10:return best,arg
    for k in peaks:
        res=minimize_scalar(lambda z:-f(z),bounds=(x[k-1],x[k+1]),method='bounded',options={'xatol':1e-14})
        if -res.fun>best:best=-float(res.fun);arg=float(res.x)
    return best,arg

def check_compression(label,exact):
    rows=[];q=np.array(exact['points']).reshape(-1,2,2);u=q[:,0,0]/W*TAU;u=np.r_[u,u[0]+TAU];ring=Ring(exact)
    for eps in [0.,.25,.5,1.,2.]:
        c=json.loads((ROOT/'rerun_results'/f'{label}_compressed_{eps:g}px.json').read_text());cr=Ring(c);details=[]
        for edge in c['connections']:
            i,j=edge['exact_edge_range'];new=cr.active(((u[i]+u[j])/2)%TAU).coeff;mx=0.;at=None
            for k in range(i,j):
                old=ring.active(((u[k]+u[k+1])/2)%TAU).coeff
                for side in [0,1]:
                    value,x=independent_max_error(old[side],new[side],u[k],u[k+1])
                    if value>mx:mx=value;at=dict(side=['top','bottom'][side],longitude_x=(x/TAU*W)%W,exact_segment=k)
            assert mx<=eps+1e-7,(label,eps,mx)
            assert abs(mx-edge['error_px'])<1e-7,(label,eps,mx,edge)
            details.append(dict(**edge,independent_max_px=mx,maximum_at=at))
        mx=max(e['independent_max_px'] for e in details)
        rows.append(dict(case=label,epsilon=eps,pairs=c['pair_count'],stored_max_px=c['maximum_vertical_curve_error_px'],
          independent_max_px=mx,bev_change_h2=Polygon(exact['footprint']).symmetric_difference(Polygon(c['footprint'])).area,edges=details))
    return rows

def main():
    ns=load_source();replays=compare_saved_replay();results=[];compressions=[]
    for label,image,records,_ in normalized_cases():
        original=digest(records);out=ns['build_global_pair_consensuses'](records,threshold_deg=5.)
        assert digest(records)==original
        dump(f'{label}_pinned_original_points.json',out)
        source=[dict(id=r['id'],worker=r['worker'],footprint=ns['reconstruct'](r)['floor'].tolist()) for r in records]
        lee=ns['tile_consensus'](source)
        dump(f'{label}_pinned_lee.json',dict(regions={k:mapping(v) for k,v in lee['regions'].items()},
          tile_count=len(lee['mesh']['tiles']),warnings=lee['warnings'],source_ids=[r['id'] for r in records],
          support_counts=lee['mesh']['votes'].sum(axis=0).tolist()))
        exact=json.loads((ROOT/'rerun_results'/f'{label}_fusion.json').read_text());simplified=json.loads((ROOT/'rerun_results'/f'{label}_point_baseline.json').read_text())
        for rule in ['mv50','mv_strict']:
            p=out[rule];ex=exact['methods'][rule];dual='mv_strict' if len(records)%2==0 and rule=='mv50' else 'mv50' if len(records)%2==0 else rule
            delta=Polygon(ex['footprint']).symmetric_difference(lee['regions'][dual]).area
            assert delta<1e-10
            diff=float(np.max(abs(np.asarray(p['candidate']['points'])-np.asarray(simplified[rule]['points']))))
            assert diff<1e-10
            results.append(dict(case=label,image=image,n=len(records),rule=rule,source_coordinate_hash=original,
              pinned_point_status=p['status'],pinned_point_reason=p['candidate']['reason'],
              point_to_author_replica_max_coordinate_delta=diff,
              point_support=p['candidate']['point_support_counts'],
              point_edges_support=[e['support'] for e in p['ring_diagnostics']['edges']],
              partition_tie_check=p['correspondence_diagnostics']['partition_tie_check'],
              competing_worker_matches=p['correspondence_diagnostics']['competing_worker_matches'],
              erp_to_pinned_lee_dual_symdiff_h2=delta,erp_pairs=ex['pair_count'],
              exact_point_vs_exact_erp_bev_symdiff_h2=Polygon(p['candidate']['footprint']).symmetric_difference(Polygon(ex['footprint'])).area))
        compressions+=check_compression(label,exact['methods'][exact['bev_mv50_complete_method']])
    dump('pinned_method_comparison.json',results);dump('compression_independent_validation.json',compressions)
    dump('independent_environment.json',dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,shapely=shapely.__version__))
    print(json.dumps(dict(pinned_comparison=results,compression_max_ledger_delta=max(abs(r['stored_max_px']-r['independent_max_px']) for r in compressions),
      replay_files=len(replays),byte_identical_files=sum(r['byte_identical'] for r in replays)),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
