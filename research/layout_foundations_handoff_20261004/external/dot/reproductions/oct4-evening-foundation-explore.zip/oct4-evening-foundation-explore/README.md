# 同秩墙顶高度与原标注支持：隔离增量研究

固定仓库提交：080949f5971000a32310d4e4ebf9028dab831a91。

研究问题：ERP上下边界由不同人员提供时，三维墙顶高度是否仍在逐人高度包络内？像素误差预算的压缩是否保持该性质？

预先固定范围：新v2包的两张真图（3人、24人），两ERP票数规则、已保存的0/0.25/0.5/1/2px压缩，以及080949原点融合函数。未读取GT，不改变点、环、资格，不发布远程。

停止条件：给出同秩比值性质的证明、按源事件区间和解析根的连续数值核验、两图定量结果及限制；不扩展全库或新人员模型。

运行：PYTHONPATH=/workspace/scratch/a365811da80c/audit-oct1-deps:/workspace/scratch/a365811da80c/audit-oct1-testdeps python run_height_support.py

结果只写results目录。source为GitHub连接器读取的冻结源码；vendor与inputs/artifacts为新v2包的独立副本。不会改源包或仓库。
