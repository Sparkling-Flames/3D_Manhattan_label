"""Independent dense numerical cross-check, explicitly not continuous proof."""
import json
import numpy as np
from run_height_support import ROOT,Ring,cases,TAU,H,dump

N=20001
u=(np.arange(N)+.371)*TAU/N
rows=[]
summaries={r['label']:r for r in json.loads((ROOT/'results/summary.json').read_text())}
for name,image,records in cases():
    src=np.stack([Ring(r).evaluate(u) for r in records]);zz=np.tan(np.pi*(.5-src/H))
    hs=-zz[:,0]/zz[:,1];lower=hs.min(axis=0);upper=hs.max(axis=0)
    f=json.loads((ROOT/'artifacts'/f'{name}_fusion.json').read_text())
    outs=[(f'{name}_exact_{k}',v) for k,v in f['methods'].items()]
    outs += [(f'{name}_compressed_{e:g}px',json.loads((ROOT/'artifacts'/f'{name}_compressed_{e:g}px.json').read_text())) for e in [0.,.25,.5,1.,2.]]
    p=json.loads((ROOT/'results'/f'{name}_pinned_point_result.json').read_text())
    outs += [(f'{name}_point5_{k}',v['candidate']) for k,v in p.items()]
    for label,c in outs:
        y=Ring(c).evaluate(u);z=np.tan(np.pi*(.5-y/H));hc=-z[0]/z[1]
        violation=np.maximum(np.maximum(lower-hc,hc-upper),0.)
        contained=np.sum((src[:,0]<=y[0]+1e-8)&(src[:,1]>=y[1]-1e-8),axis=0)
        exact=summaries[label];hist={str(k):float(np.mean(contained==k)) for k in range(len(records)+1)}
        delta=max(abs(hist[k]-exact['whole_column_containment_longitude_distribution'].get(k,0.)) for k in hist)
        rows.append(dict(label=label,sample_count=N,max_height_violation_h=float(violation.max()),
           continuous_max_height_violation_h=exact['maximum_height_envelope_violation_h'],
           dense_minus_continuous_max_h=float(violation.max())-exact['maximum_height_envelope_violation_h'],
           sampled_min_column_containment=int(contained.min()),continuous_min_column_containment=exact['min_original_bands_containing_whole_generated_column'],
           max_containment_fraction_difference=delta))
        assert rows[-1]['dense_minus_continuous_max_h']<1e-8
        assert int(contained.min())>=exact['min_original_bands_containing_whole_generated_column']
controls=json.loads((ROOT/'results/controlled_compression.json').read_text())
for c in controls:
    src=np.stack([Ring(r).evaluate(u) for r in c['inputs']]);z=np.tan(np.pi*(.5-src/H));hs=-z[:,0]/z[:,1]
    y=Ring(c['compressed']).evaluate(u);z=np.tan(np.pi*(.5-y/H));hc=-z[0]/z[1]
    v=np.maximum(np.maximum(hs.min(axis=0)-hc,hc-hs.max(axis=0)),0.)
    a=c['compressed_audit'];rows.append(dict(label='control_'+c['name'],sample_count=N,max_height_violation_h=float(v.max()),
        continuous_max_height_violation_h=a['maximum_height_envelope_violation_h'],
        dense_outside_fraction=float(np.mean(v>1e-9)),continuous_outside_fraction=a['height_envelope_outside_longitude_fraction']))
    assert float(v.max())<=a['maximum_height_envelope_violation_h']+1e-8
dump(ROOT/'results/dense_crosscheck.json',dict(method='ERP-evaluate then tan ratio, 20001 shifted columns; cross-check only',rows=rows))
print('Dense cross-check passed:',len(rows),'outputs')
