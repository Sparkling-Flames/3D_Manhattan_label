"""Read-only/source-preserving diagnostic for an explicitly chosen candidate.

Example: python inspect_candidate.py --records inputs/real24_points.json
 --candidate artifacts/real24_compressed_1px.json --out-prefix adhoc_candidate
Reports violations; does not reject, repair, choose epsilon or consult GT.
"""
import argparse,json
from run_height_support import ROOT,Ring,Unsupported,source_envelope,candidate_audit,dump

p=argparse.ArgumentParser(__doc__)
p.add_argument('--records',required=True)
p.add_argument('--candidate',required=True)
p.add_argument('--out-prefix',required=True)
a=p.parse_args()
if any(s in a.out_prefix for s in ('/','\\','..')):raise ValueError('simple_output_prefix_required')
x=json.load(open(a.records));rs=x if isinstance(x,list) else x.get('records')
if rs is None:raise ValueError('records_array_required')
for key in ('id','worker'):
    v=[r.get(key) for r in rs]
    if None in v or len(set(v))!=len(v):raise ValueError('unique_'+key+'_required')
c=json.load(open(a.candidate))
if 'candidate' in c:c=c['candidate']
out=ROOT/'results'/f'{a.out_prefix}.json'
try:
    s=candidate_audit(rs,source_envelope([Ring(r) for r in rs]),c,a.out_prefix)
    s.update(status='diagnostic_only',source_records_modified=False,gt_used=False,
      decision='No automatic accept/reject; retain exact output and inspect changed support separately')
except Unsupported as e:
    s=dict(status='unsupported_preserved',reason=str(e),n_requested=len(rs),source_records_modified=False,gt_used=False)
dump(out,s);print(out)
