"""Fixed-geometry existence controls; bounded epsilon trial history is saved."""
from __future__ import annotations
import copy,json,sys
import numpy as np
from run_height_support import ROOT,Ring,source_envelope,candidate_audit,dump,values,TAU
sys.path.insert(0,str(ROOT/'vendor'))
from arc_consensus import project,fuse
from simplify import compress

def record(poly,height,name):
    p=np.array(poly,float);h=np.broadcast_to(height,len(p));a=project(np.c_[p[:,0],h,p[:,1]]);b=project(np.c_[p[:,0],-np.ones(len(p)),p[:,1]])
    q=np.stack([a,b],axis=1)
    return dict(id=name,worker=name,image='synthetic_height_preservation',points=q.reshape(-1,2).tolist(),
      independent=True,consensus_eligible=True,condition='synthetic',evidence_kind='synthetic_control',
      source_pair_indices=list(range(len(p))),source_point_indices=list(range(2*len(p))),
      ring_confirmed=False,order_status='explicit_synthetic_ring')

def main():
    # Predeclared fixture: clipped 4m/h square, identical footprints, parallel planar roofs.
    # No input-node insertion, hidden structure, changed adjacency, or measured-human claim.
    poly=[[-2,-1.98],[-1.98,-2],[1.98,-2],[2,-1.98],[2,1.98],[1.98,2],[-1.98,2],[-2,1.98]]
    x=np.array(poly)[:,0];result=[]
    for name,slope in [('sloped',.1),('flat',0.)]:
        records=[record(poly,1+slope*x+delta,f'{name}_{i}') for i,delta in enumerate([-1e-5,0.,1e-5])]
        before=copy.deepcopy(records);f=fuse(records);exact=f['methods']['mv50'];compressed=compress(exact,1.)
        cells=source_envelope([Ring(r) for r in records])
        e=candidate_audit(records,cells,exact,f'control_{name}_exact',2)
        c=candidate_audit(records,cells,compressed,f'control_{name}_compressed')
        top=np.array(compressed['top_xyz']);plane_residual=float(np.max(abs(top[:,1]-(1+slope*top[:,0]))))
        result.append(dict(name=name,inputs=records,exact=exact,compressed=compressed,exact_audit=e,compressed_audit=c,
          retained_central_roof_plane_max_vertex_residual_h=plane_residual,
          design=dict(roof_slope_x=slope,offsets_h=[-1e-5,0.,1e-5],epsilon_px=1.,
            source_footprints_identical=True,fixture_count=2,parameter_search='bounded_epsilon_trials',random_draws=0,
            interpretation='existence/regression fixture, not occurrence-rate evidence')))
        assert records==before
        print(name,exact['pair_count'],compressed['pair_count'],compressed['maximum_vertical_curve_error_px'],c['maximum_height_envelope_violation_h'],c['height_envelope_outside_longitude_fraction'])
    assert result[0]['compressed_audit']['maximum_height_envelope_violation_h']>1e-5
    assert result[1]['compressed_audit']['maximum_height_envelope_violation_h']<1e-9
    dump(ROOT/'results/controlled_compression.json',result)
    dump(ROOT/'results/control_development_history.json',dict(
      random_seed=None,random_draws=0,geometry_variants=1,roof_slopes=[.1,0.],
      epsilon_attempts=[dict(epsilon=.5,sloped_pairs=8,flat_pairs=8,result='no_compression; initial positive-violation assertion failed'),
        dict(epsilon=1.,sloped_pairs=4,result='height-envelope violation 0.0019700990049501543 h'),
        dict(epsilon=2.,sloped_pairs=4,result='same candidate as 1px')],
      final_regression_epsilon=1.,selection='First tested epsilon that actually compressed this fixed fixture; no GT used',
      stopping_condition='One explicit compression counterexample and matched constant-height preservation check; no frequency claim'))

if __name__=='__main__':main()
