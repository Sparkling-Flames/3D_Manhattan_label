"""Continuous same-rank height-envelope and joint-column-source diagnostics.

No ground truth is read. No source point, ring or eligibility is changed.
Root classifications use floating-point analytic trigonometric equations;
the theorem, not these calculations, proves the exact aggregation property.
"""
from __future__ import annotations
import ast, copy, csv, hashlib, importlib.util, json, math, sys
from collections import defaultdict
from itertools import combinations
from pathlib import Path
import numpy as np
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import squareform

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
from arc_consensus import Ring, Unsupported, W,H,TAU

ANGLE_EPS=2e-11
HEIGHT_EPS=1e-9
CONTAIN_EPS=1e-10

def dump(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')

def unique(xs):
    out=[]
    for x in sorted(map(float,xs)):
        if not out or x-out[-1]>ANGLE_EPS:out.append(x)
    return out

def trig_quadratic_roots(q,lo,hi):
    """q[0] sin² + q[1] sin cos + q[2] cos² == 0."""
    ss,sc,cc=q
    a=(ss+cc)/2.; b=(cc-ss)/2.; c=sc/2.
    r=math.hypot(b,c); scale=max(map(abs,q))
    if scale==0 or r<=1e-13*scale:return []
    z=-a/r
    if abs(z)>1+1e-12:return []
    z=max(-1.,min(1.,z)); phase=math.atan2(c,b); d=math.acos(z)
    roots=[]
    for s in (-1,1):
        base=(phase+s*d)/2.
        for k in range(-3,5):
            x=base+k*math.pi
            if lo+ANGLE_EPS<x<hi-ANGLE_EPS:roots.append(x)
    return unique(roots)

def trig_linear_roots(c,lo,hi):
    if np.linalg.norm(c)<=1e-13:return []
    base=math.atan2(-c[1],c[0])
    return unique(base+k*math.pi for k in range(-3,5) if lo+ANGLE_EPS<base+k*math.pi<hi-ANGLE_EPS)

def product(a,b):
    return np.array([a[0]*b[0],a[0]*b[1]+a[1]*b[0],a[1]*b[1]])

def difference_numerator(a,b):
    # a,b each contain positive numerator U and positive denominator D.
    return product(a[0],b[1])-product(b[0],a[1])

def stationary_roots(a,b,lo,hi):
    da=a[0,0]*a[1,1]-a[0,1]*a[1,0]
    db=b[0,0]*b[1,1]-b[0,1]*b[1,0]
    return trig_quadratic_roots(da*product(b[1],b[1])-db*product(a[1],a[1]),lo,hi)

def positive_coeff(piece):
    c=piece.coeff.copy();c[1]*=-1.;return c

def values(c,u):
    v=np.array([math.sin(u),math.cos(u)])
    z=c@v
    if np.any(z[...,1]<=0):raise Unsupported('nonpositive_height_denominator')
    if np.any(z[...,0]<=0):raise Unsupported('nonpositive_upper_height')
    return z[...,0]/z[...,1]

def linear_min(c,lo,hi):
    x=[lo,hi]
    base=math.atan2(c[0],c[1])
    x += [base+k*math.pi for k in range(-3,5) if lo<base+k*math.pi<hi]
    return min(c[0]*math.sin(u)+c[1]*math.cos(u) for u in x)

def source_envelope(rings):
    """Partition continuously wherever a source edge or source height order changes."""
    base=unique([0.,TAU]+[x for r in rings for p in r.pieces for x in (p.lo,p.hi)])
    cells=[]
    for lo,hi in zip(base[:-1],base[1:]):
        active=[r.active((lo+hi)/2) for r in rings]
        C=np.array([positive_coeff(p) for p in active]);cuts=[lo,hi]
        if min(linear_min(c,lo,hi) for z in C for c in z)<=0:
            raise Unsupported('nonpositive_source_height_inside_edge')
        for i,j in combinations(range(len(rings)),2):
            cuts+=trig_quadratic_roots(difference_numerator(C[i],C[j]),lo,hi)
        cuts=unique(cuts)
        for a,b in zip(cuts[:-1],cuts[1:]):
            hh=values(C,(a+b)/2)
            cells.append(dict(lo=a,hi=b,C=C,active=active,lower=int(np.argmin(hh)),upper=int(np.argmax(hh))))
    return cells

def candidate_audit(records,source_cells,candidate,label,threshold=None):
    ring=Ring(candidate);workers=[r['worker'] for r in records];n=len(records)
    knots=unique([0.,TAU]+[x for p in ring.pieces for x in (p.lo,p.hi)])
    rows=[];global_containers=set(workers);outside=0.;lower_out=0.;upper_out=0.
    max_violation=0.;worst=None;contain_measure=defaultdict(float);min_contain=n
    for cell in source_cells:
        lo,hi=cell['lo'],cell['hi'];cuts=unique([lo,hi]+[x for x in knots if lo+ANGLE_EPS<x<hi-ANGLE_EPS])
        for aa,bb in zip(cuts[:-1],cuts[1:]):
            cp=ring.active((aa+bb)/2);C=cell['C'];cc=positive_coeff(cp)
            if min(linear_min(c,aa,bb) for c in cc)<=0:raise Unsupported('nonpositive_candidate_height_inside_edge')
            c2=[aa,bb]
            # Envelope-crossing and whole-column-containment transitions.
            for j in (cell['lower'],cell['upper']):
                c2+=trig_quadratic_roots(difference_numerator(cc,C[j]),aa,bb)
            for z in C:
                for side in (0,1):c2+=trig_linear_roots(cc[side]-z[side],aa,bb)
            c2=unique(c2)
            for a,b in zip(c2[:-1],c2[1:]):
                mid=(a+b)/2;hs=values(C,mid);hc=float(values(cc,mid));L=float(hs[cell['lower']]);U=float(hs[cell['upper']])
                sv=np.array([math.sin(mid),math.cos(mid)]);zz=C@sv;zc=cc@sv
                # A source contains generated ERP column iff its U and D both exceed generated U,D.
                container=[workers[i] for i in range(n) if zz[i,0]>=zc[0]-CONTAIN_EPS and zz[i,1]>=zc[1]-CONTAIN_EPS]
                global_containers.intersection_update(container);count=len(container);min_contain=min(min_contain,count)
                contain_measure[count]+=b-a
                side='inside'
                if hc<L-HEIGHT_EPS:side='below';lower_out+=b-a;outside+=b-a
                elif hc>U+HEIGHT_EPS:side='above';upper_out+=b-a;outside+=b-a
                # Between height-order and crossing events envelope donors are fixed.
                candidates=[a,b]
                for j in (cell['lower'],cell['upper']):candidates+=stationary_roots(cc,C[j],a,b)
                local_max=0.
                for x in candidates:
                    h=float(values(cc,x));s=values(C,x);violation=max(float(np.min(s))-h,h-float(np.max(s)),0.)
                    local_max=max(local_max,violation)
                    if violation>max_violation:
                        max_violation=violation;worst=dict(theta_rad=x,x_px=x/TAU*W,candidate_height_h=h,
                          min_source_height_h=float(np.min(s)),max_source_height_h=float(np.max(s)),
                          source_heights_h={workers[i]:float(s[i]) for i in range(n)},
                          candidate_edge=cp.edge,source_edges={workers[i]:int(cell['active'][i].edge) for i in range(n)})
                rows.append(dict(lo_rad=a,hi_rad=b,lo_px=a/TAU*W,hi_px=b/TAU*W,
                    candidate_edge=cp.edge,lower_worker=workers[cell['lower']],upper_worker=workers[cell['upper']],
                    midpoint_height_h=hc,midpoint_min_source_height_h=L,midpoint_max_source_height_h=U,
                    height_envelope_position=side,maximum_envelope_violation_h=local_max,
                    column_containment_count=count,column_containment_workers='|'.join(container),
                    source_edges='|'.join(f'{workers[i]}:{cell["active"][i].edge}' for i in range(n))))
    coverage=sum(r['hi_rad']-r['lo_rad'] for r in rows)
    if abs(coverage-TAU)>1e-9:raise AssertionError('event_coverage_not_one_turn')
    path=ROOT/'results'/f'{label}_events.csv'
    with path.open('w',encoding='utf8',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
    summary=dict(label=label,n=n,pair_count=len(candidate['points'])//2,source_envelope_cells=len(source_cells),
      continuous_event_cells=len(rows),height_envelope_outside_longitude_fraction=outside/TAU,
      height_envelope_below_longitude_fraction=lower_out/TAU,height_envelope_above_longitude_fraction=upper_out/TAU,
      maximum_height_envelope_violation_h=max_violation,worst_violation=worst,
      min_original_bands_containing_whole_generated_column=min_contain,
      original_bands_containing_whole_generated_band=sorted(global_containers),
      whole_column_containment_longitude_distribution={str(k):v/TAU for k,v in sorted(contain_measure.items())},
      erp_threshold=threshold,theoretical_column_containment_minimum=None if threshold is None else max(0,2*threshold-n),
      exact_same_rank_height_theorem_applies=threshold is not None,
      numerical_height_threshold_h=HEIGHT_EPS,container_coefficient_tolerance=CONTAIN_EPS,
      angle_deduplication_tolerance_rad=ANGLE_EPS,event_csv=path.name)
    if threshold is not None:
        assert max_violation<HEIGHT_EPS,(label,max_violation)
        assert min_contain>=max(0,2*threshold-n),(label,min_contain)
    return summary

def load_original_point_functions():
    p=ROOT/'source';gpath=p/'tools/label_studio/panorama_studio/geometry.py'
    spec=importlib.util.spec_from_file_location('pinned_geometry',gpath)
    geom=importlib.util.module_from_spec(spec);spec.loader.exec_module(geom)
    ns=dict(np=np,analyze=geom.analyze,copy=copy,math=math,defaultdict=defaultdict,
      linkage=linkage,fcluster=fcluster,squareform=squareform,SCHEMA='global_pair_consensus_20261004_v1')
    paths=[('paired_split_research/study.py',['angular']),('point_pattern_demo_20261003.py',['_pairs']),
      ('research_round_20260929.py',['reconstruct']),('union_branch_consensus_20260926.py',['_ring_key']),
      ('global_pair_consensus_20261004.py',['_identities','_ring_diagnostics','_result','build_global_pair_consensuses','build_global_pair_consensus'])]
    for name,functions in paths:
        path=p/'tools/thesis_main/analysis'/name;tree=ast.parse(path.read_text());
        tree.body=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in functions]
        exec(compile(tree,str(path),'exec'),ns)
    return ns

def cases():
    x=json.loads((ROOT/'inputs/current_excerpt.json').read_text())['images'][0]
    y=json.loads((ROOT/'inputs/real24_points.json').read_text())
    for label,image,rs in [('pilot3',x['code'],x['annotations']),('real24',y['image'],y['records'])]:
        rs=copy.deepcopy(rs)
        for r in rs:r.update(image=image,evidence_kind='human_observed')
        yield label,image,rs

def main():
    (ROOT/'results').mkdir(exist_ok=True)
    manifests={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for sub in ['source','vendor','inputs','artifacts'] for p in sorted((ROOT/sub).rglob('*')) if p.is_file() and '__pycache__' not in str(p)}
    point=load_original_point_functions();summaries=[];comparison=[]
    for label,image,records in cases():
        before=copy.deepcopy(records);source_cells=source_envelope([Ring(r) for r in records])
        f=json.loads((ROOT/'artifacts'/f'{label}_fusion.json').read_text())
        for method,out in f['methods'].items():
            s=candidate_audit(records,source_cells,out,f'{label}_exact_{method}',out['erp_threshold'])
            s['different_top_bottom_donor_longitude_fraction']=out['different_top_bottom_donor_longitude_fraction'];summaries.append(s)
            print(label,method,'exact',s['maximum_height_envelope_violation_h'],flush=True)
        for eps in [0.,.25,.5,1.,2.]:
            out=json.loads((ROOT/'artifacts'/f'{label}_compressed_{eps:g}px.json').read_text())
            s=candidate_audit(records,source_cells,out,f'{label}_compressed_{eps:g}px');s['epsilon_px']=eps;s['maximum_vertical_curve_error_px']=out['maximum_vertical_curve_error_px'];summaries.append(s)
            print(label,'compression',eps,s['maximum_height_envelope_violation_h'],s['height_envelope_outside_longitude_fraction'],flush=True)
        raw=point['build_global_pair_consensuses'](records,5.0)
        dump(ROOT/'results'/f'{label}_pinned_point_result.json',raw)
        saved=json.loads((ROOT/'artifacts'/f'{label}_point_baseline.json').read_text())
        for method,out in raw.items():
            p=out['candidate'];same=np.array_equal(np.array(p['points']),np.array(saved[method]['points']))
            comparison.append(dict(case=label,method=method,points_exactly_equal_v2_numeric_baseline=bool(same),
                source_status=out['status'],reason=p['reason'],point_support_counts=p['point_support_counts'],
                direct_edge_support=[e['support'] for e in out['ring_diagnostics']['edges']],
                exact_original_identity_ring_support=out['ring_diagnostics']['exact_source_ring_support']))
            if p['points'] is None:continue
            s=candidate_audit(records,source_cells,p,f'{label}_point5_{method}');s['original_source_status']=out['status'];summaries.append(s)
            print(label,'point',method,s['maximum_height_envelope_violation_h'],s['height_envelope_outside_longitude_fraction'],flush=True)
        assert records==before
    assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in manifests.items())
    dump(ROOT/'results/summary.json',summaries);dump(ROOT/'results/pinned_point_comparison.json',comparison)
    dump(ROOT/'results/input_hashes.json',manifests)
    flatkeys=['label','n','pair_count','source_envelope_cells','continuous_event_cells','height_envelope_outside_longitude_fraction','maximum_height_envelope_violation_h','min_original_bands_containing_whole_generated_column','erp_threshold','theoretical_column_containment_minimum','epsilon_px','maximum_vertical_curve_error_px']
    with (ROOT/'results/summary.csv').open('w',encoding='utf8',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=flatkeys);wr.writeheader();wr.writerows({k:s.get(k) for k in flatkeys} for s in summaries)
    dump(ROOT/'results/environment.json',dict(python=sys.version,numpy=np.__version__,float_type='IEEE float64',scope='analytic event/critical roots, not interval arithmetic',ground_truth_files_opened=False,input_mutation=False))

if __name__=='__main__':main()
