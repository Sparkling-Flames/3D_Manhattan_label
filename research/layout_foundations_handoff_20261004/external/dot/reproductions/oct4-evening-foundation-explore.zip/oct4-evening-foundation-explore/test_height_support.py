import copy,json,math,unittest
import numpy as np
from run_height_support import *
from run_controls import record

class Tests(unittest.TestCase):
    def test_same_rank_ratio_property(self):
        rng=np.random.default_rng(8046102)
        for n in range(1,11):
            for _ in range(100):
                u=rng.lognormal(size=n);d=rng.lognormal(size=n)
                lower=min(u/d);upper=max(u/d)
                for t in range(n):
                    h=sorted(u,reverse=True)[t]/sorted(d,reverse=True)[t]
                    self.assertGreaterEqual(h,lower-1e-12);self.assertLessEqual(h,upper+1e-12)

    def test_same_rank_flat_height(self):
        d=np.array([.1,.3,.3,1.,3.]);u=2.7*d
        self.assertTrue(np.allclose(np.sort(u)/np.sort(d),2.7))

    def test_mismatched_rank_not_same_theorem(self):
        u=d=np.array([1.,2.,100.])
        self.assertEqual(max(u)/np.median(d),50.)
        self.assertTrue(np.all(u/d==1.))

    def test_joint_column_bound(self):
        rng=np.random.default_rng(8046103)
        for n in range(1,15):
            for _ in range(25):
                u=rng.uniform(.1,2,size=n);d=rng.uniform(.1,2,size=n)
                for t in range(1,n+1):
                    U=np.sort(u)[-t];D=np.sort(d)[-t]
                    self.assertGreaterEqual(np.count_nonzero((u>=U)&(d>=D)),max(0,2*t-n))

    def test_quadratic_root_known_case(self):
        roots=trig_quadratic_roots(np.array([1.,0.,-1.]),0.,TAU)
        self.assertTrue(np.allclose(roots,np.pi/4+np.arange(4)*np.pi/2))

    def test_quadratic_roots_residual(self):
        rng=np.random.default_rng(8046104)
        for _ in range(300):
            q=rng.normal(size=3)
            for u in trig_quadratic_roots(q,0.,TAU):
                residual=q[0]*np.sin(u)**2+q[1]*np.sin(u)*np.cos(u)+q[2]*np.cos(u)**2
                self.assertLess(abs(residual),1e-11)

    def test_stationary_max_vs_dense(self):
        rng=np.random.default_rng(8046105)
        for _ in range(200):
            c=rng.uniform(.1,2,size=(2,2));d=rng.uniform(.1,2,size=(2,2))
            lo=.03;hi=1.5;u=np.linspace(lo,hi,10001);M=np.c_[np.sin(u),np.cos(u)]
            z=M@c.T;w=M@d.T;dense=z[:,0]/z[:,1]-w[:,0]/w[:,1]
            events=[lo,hi]+stationary_roots(c,d,lo,hi)
            actual=[float(values(c,x)-values(d,x)) for x in events]
            self.assertLessEqual(float(max(dense)),max(actual)+1e-10)
            self.assertGreaterEqual(float(min(dense)),min(actual)-1e-10)

    def test_nonpositive_top_is_unsupported(self):
        r=record([[-2,-2],[2,-2],[2,2],[-2,2]],-.2,'below')
        with self.assertRaises(Unsupported):Ring(r)

    def test_two_real_pools_18_outputs(self):
        s=json.loads((ROOT/'results/summary.json').read_text())
        self.assertEqual(len(s),18)
        self.assertEqual(sum(x['exact_same_rank_height_theorem_applies'] for x in s),4)
        self.assertTrue(all(x['height_envelope_outside_longitude_fraction']==0 for x in s))

    def test_counterexample_and_flat_regression(self):
        r=json.loads((ROOT/'results/controlled_compression.json').read_text())
        self.assertGreater(r[0]['compressed_audit']['maximum_height_envelope_violation_h'],.001)
        self.assertEqual(r[0]['compressed']['pair_count'],4)
        self.assertLess(r[1]['compressed_audit']['maximum_height_envelope_violation_h'],1e-9)

    def test_source_point_coordinates_match_v2(self):
        r=json.loads((ROOT/'results/pinned_point_comparison.json').read_text())
        self.assertTrue(all(x['points_exactly_equal_v2_numeric_baseline'] for x in r))

if __name__=='__main__':unittest.main(verbosity=2)
