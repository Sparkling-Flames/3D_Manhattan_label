# 质量指标独立审核：可移植复现包

先读 `AUDIT_ZH.md`。原始完整结果保留在 `results.json`，原始运行记录保留在 `run.log`。

## 运行

需要 Python 3.12 与 NumPy、SciPy、Shapely；实测版本见 `environment.json`。在解包后的目录执行：

```bash
python -m pip install -r requirements.txt
python audit_quality.py --out recomputed > recomputed.log 2>&1
```

默认读取脚本旁边的 `source_package/`，不依赖原机器的路径或工作目录。输出目录必须是新目录或空目录，避免覆盖旧结果。后续重跑可使用其他名字，例如 `--out second_run`。

如已有完整作者包，也支持：

```bash
python audit_quality.py --package /path/to/layout_foundations_20261004_v2 --out external_package_run
```

运行时不会访问网络，也不会修改输入包。依赖安装可能需要访问包仓库；已有同版本依赖时可跳过安装。

## 内容

- `AUDIT_ZH.md`：中文数学、实现与评价对象审计
- `audit_quality.py`：独立球面最近弧 oracle、全部18行重算及合成控制
- `results.json`、`run.log`：原始完整审计数值与日志
- `source_package/`：复现所需的最小作者源码、参考输入与预测结果，逐文件原样复制
- `source_provenance.json`：被复制文件的SHA-256与作者包版本
- `relocation_verification.json`：在新的解包位置执行后的核验结果
- `MANIFEST.sha256`：本交付各文件的完整性散列

`source_package/REPORT_ZH.md` 为作者原报告，用于核对论述；此处不是作者完整发布包，其展示页面、图片、无关实验和入口未收录。本审核只依赖所附的最小文件集。

额外控制只是合成指标边界实验，不代表真人发生率，也没有改动GT、人员、源环、正式阈值或远程内容。
