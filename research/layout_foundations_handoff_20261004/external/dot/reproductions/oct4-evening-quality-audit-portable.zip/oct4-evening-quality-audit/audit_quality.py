"""Read-only independent check of the Oct 4 foundation quality contract.

Stop after replaying all published real-quality rows, checking a separate
closest-arc oracle, and one bounded metric stress control (fixed three levels).
No upstream input, prediction, source, or remote is modified.
"""
import sys
sys.dont_write_bytecode = True
import argparse, copy, csv, hashlib, json, math
from pathlib import Path
import numpy as np
from shapely.geometry import Polygon

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--package', type=Path, default=HERE / 'source_package',
                    help='Input package root; defaults to bundled source_package.')
parser.add_argument('--out', type=Path, default=HERE / 'recomputed',
                    help='New output directory; original results.json is preserved.')
OPTIONS = parser.parse_args()
PACKAGE = OPTIONS.package.expanduser().resolve()
OUT = OPTIONS.out.expanduser().resolve()
if not (PACKAGE / 'src/quality.py').is_file():
    parser.error('Input package must contain src/quality.py; supply --package.')
if OUT.exists() and any(OUT.iterdir()):
    parser.error('Output directory must be new or empty; supply --out.')
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(PACKAGE / 'src'))
import quality as implementation
from arc_consensus import Ring
from cases import rectangle, thin_feature


def rays(record, side):
    p = np.asarray(record['points'], float).reshape(-1, 2, 2)[:, side]
    theta = p[:, 0] * (2 * np.pi / 1024)
    phi = np.pi / 2 - p[:, 1] * (np.pi / 512)
    return np.stack((-np.cos(phi) * np.sin(theta), np.sin(phi),
                     np.cos(phi) * np.cos(theta)), axis=-1)


def angle(a, b):
    return np.arctan2(np.linalg.norm(np.cross(a, b), axis=-1),
                      np.sum(a * b, axis=-1))


def arcs(record, side):
    u = rays(record, side)
    v = np.roll(u, -1, axis=0)
    length = angle(u, v)
    use = length > 1e-12
    u, v, length = u[use], v[use], length[use]
    tangent = v - np.cos(length)[:, None] * u
    tangent /= np.linalg.norm(tangent, axis=-1)[:, None]
    return u, v, tangent, length


def nearest(points, target, side):
    """Independent oracle: maximize A cos(s)+B sin(s), 0<=s<=arc length.

    This uses the great-circle parameter's stationary point, not the package's
    two half-space tests and perpendicular-distance formula.
    """
    u, v, tangent, length = arcs(target, side)
    result = []
    for w in np.array_split(points, max(1, math.ceil(len(points) / 256))):
        A, B = w @ u.T, w @ tangent.T
        at_end = w @ v.T
        phase = np.arctan2(B, A) % (2 * np.pi)
        interior = phase <= length[None, :]
        endpoint_phase = np.where(A >= at_end, 0., length[None, :])
        best_phase = np.where(interior, phase, endpoint_phase)
        score = A * np.cos(best_phase) + B * np.sin(best_phase)
        idx = np.argmax(score, axis=1)
        s = best_phase[np.arange(len(w)), idx]
        q = u[idx] * np.cos(s)[:, None] + tangent[idx] * np.sin(s)[:, None]
        result.append(angle(w, q))
    return np.concatenate(result)


def directed(source, target, side, step=.05):
    u, v, t, length = arcs(source, side)
    points, weights = [], []
    max_width = 0.
    for a, tangent, L in zip(u, t, length):
        n = int(np.ceil(np.degrees(L) / step))
        h = L / n
        s = (np.arange(n) + .5) * h
        points.append(a * np.cos(s)[:, None] + tangent * np.sin(s)[:, None])
        weights.extend([h] * n)
        max_width = max(max_width, h)
    w = np.asarray(weights)
    d = np.degrees(nearest(np.concatenate(points), target, side))
    order = np.argsort(d)
    p95 = d[order[np.searchsorted(np.cumsum(w[order]) / w.sum(), .95)]]
    return {'mean_deg': float(np.dot(w, d) / w.sum()), 'p95_deg': float(p95),
            'max_lower_deg': float(d.max()),
            'max_upper_deg': float(d.max() + np.degrees(max_width) / 2),
            'mean_absolute_numerical_bound_deg': float(np.degrees(max_width) / 4),
            'length_deg': float(np.degrees(w.sum())), 'sample_n': len(w)}


def polygon(record):
    v = rays(record, 1)
    return Polygon(v[:, [0, 2]] / -v[:, 1, None])


def load(name):
    return json.loads((PACKAGE / name).read_text())


def prediction(case, method):
    if method.startswith('exact_erp_'):
        return load(f'results/final/{case}_fusion.json')['methods'][method[10:]]
    if method.startswith('compressed_'):
        return load(f'results/final/{case}_{method}.json')
    return load(f'results/final/{case}_point_baseline.json')[method[7:]]


def digest_inputs():
    return {str(p.relative_to(PACKAGE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(PACKAGE.rglob('*')) if p.is_file()}


def stress_record(reference, wiggle_n):
    """Fixed broad error plus extra low-amplitude, non-retraced oscillations.

    The footprint and large error on x=128..512 are identical at every level.
    All top rings remain strictly single-valued and horizon-straddling.
    """
    base = Ring(reference)
    knots = {0.: 0., 128.: 0., 192.: -20., 384.: -20., 448.: -20., 512.: 0.,
             600.: 0., 640.: 0., 896.: 0., 1000.: 0.}
    if wiggle_n:
        # Skip corners and fixed knots exactly, retain them in the union.
        for j, x in enumerate(np.linspace(600., 1000., wiggle_n + 2)[1:-1]):
            if x not in knots:
                knots[float(x)] = 1. if j % 2 else -1.
    r = copy.deepcopy(reference)
    r['points'] = []
    for x, dy in sorted(knots.items()):
        yy = base.evaluate(x / 1024 * 2 * np.pi)
        r['points'].extend([[x, float(yy[0] + dy)], [x, float(yy[1])]])
    r.pop('source_pair_indices', None)
    r.pop('source_point_indices', None)
    Ring(r)  # Required domain check; no repair or reordering of input data.
    return r


def subdivide(record):
    ring = Ring(record)
    xx = np.asarray(record['points'])[::2, 0]
    new_x = []
    for i, x in enumerate(xx):
        span = (xx[(i + 1) % len(xx)] - x) % 1024
        new_x.extend((x + np.arange(5) * span / 5) % 1024)
    r = copy.deepcopy(record)
    r['points'] = []
    for x in sorted(new_x):
        y = ring.evaluate(x / 1024 * 2 * np.pi)
        r['points'].extend([[float(x), float(y[0])], [float(x), float(y[1])]])
    Ring(r)
    return r


def main():
    before = digest_inputs()
    details = load('results/final/real_quality_details.json')
    refs = {'pilot3': next(r for r in load('inputs/reference_excerpt.json')['references']
                          if r['code'] == '2t7WUuJeko7-06' and r['version'] == 'original'),
            'real24': load('inputs/real24_reference.json')}
    rows, max_boundary_diff, max_area_diff = [], 0., 0.
    for item in details:
        case, method, published = item['case'], item['method'], item['quality']
        pred, ref = prediction(case, method), refs[case]
        A, G = polygon(pred), polygon(ref)
        area = {'iou': A.intersection(G).area / A.union(G).area,
                'omission_h2': G.difference(A).area, 'extension_h2': A.difference(G).area,
                'reference_area_h2': G.area, 'candidate_area_h2': A.area,
                'centroid_distance_h': A.centroid.distance(G.centroid)}
        max_area_diff = max(max_area_diff, max(abs(area[k] - published[k]) for k in area))
        area['centroid_dx_h'] = A.centroid.x - G.centroid.x
        area['centroid_dz_h'] = A.centroid.y - G.centroid.y
        area['omission_fraction_reference'] = area['omission_h2'] / G.area
        area['extension_fraction_reference'] = area['extension_h2'] / G.area
        area['extension_fraction_candidate'] = area['extension_h2'] / A.area
        area['reconstructed_iou'] = (G.area - area['omission_h2']) / (G.area + area['extension_h2'])
        row = {'case': case, 'method': method, **area}
        for side, name in ((0, 'top'), (1, 'bottom')):
            ab, ba = directed(pred, ref, side), directed(ref, pred, side)
            row[name + '_candidate_to_reference'] = ab
            row[name + '_reference_to_candidate'] = ba
            row[name + '_equal_direction_mean_deg'] = (ab['mean_deg'] + ba['mean_deg']) / 2
            row[name + '_pooled_length_mean_deg'] = (ab['mean_deg'] * ab['length_deg'] + ba['mean_deg'] * ba['length_deg']) / (ab['length_deg'] + ba['length_deg'])
            for suffix, result in (('candidate_to_reference', ab), ('reference_to_candidate', ba)):
                q = published[name + '_' + suffix]
                for key in ('mean_deg', 'p95_deg', 'max_lower_deg', 'max_upper_deg', 'mean_absolute_numerical_bound_deg'):
                    max_boundary_diff = max(max_boundary_diff, abs(result[key] - q[key]))
        rows.append(row)
    # Finer quadrature on the exact-vs-point comparisons used in the narrative.
    refined = []
    for case in refs:
        for method in ('point5_mv50', 'exact_erp_mv50' if case == 'pilot3' else 'exact_erp_mv_strict', 'compressed_0.5px'):
            pred, ref = prediction(case, method), refs[case]
            row = {'case': case, 'method': method}
            for side, name in ((0, 'top'), (1, 'bottom')):
                ab, ba = directed(pred, ref, side, .005), directed(ref, pred, side, .005)
                row[name + '_equal_direction_mean_deg'] = (ab['mean_deg'] + ba['mean_deg']) / 2
                row[name + '_mean_bound_deg'] = (ab['mean_absolute_numerical_bound_deg'] + ba['mean_absolute_numerical_bound_deg']) / 2
            refined.append(row)
    # Separate oracle validity over points anywhere on the sphere.
    rng = np.random.default_rng(1042026)
    oracle_errors = []
    for _ in range(20):
        target = rectangle()
        xs = rng.uniform(0, 1024, 9)
        ys = rng.uniform(.1, 255.9, 9)
        target['points'] = [p for x, y in zip(xs, ys) for p in [[x, y], [x, 350.]]]
        target.pop('source_pair_indices', None); target.pop('source_point_indices', None)
        w = rng.normal(size=(300, 3)); w /= np.linalg.norm(w, axis=1)[:, None]
        oracle_errors.extend(np.degrees(abs(nearest(w, target, 0) - implementation.point_arc_dist(w, target, 0))).tolist())
    # Replay the narrow fixture in both directions; the published value is directed.
    base, changed = thin_feature()
    narrow = {'candidate_to_reference': directed(changed, base, 0, .005),
              'reference_to_candidate': directed(base, changed, 0, .005)}
    narrow['equal_direction_mean_deg'] = (narrow['candidate_to_reference']['mean_deg'] + narrow['reference_to_candidate']['mean_deg']) / 2
    # Additional control: strict single-valued oscillations, not repeated edges.
    ref = rectangle()
    controls = []
    sample_x = np.linspace(128, 512, 2001)
    fixed_error = None
    for n in (0, 200, 1000):
        pred = stress_record(ref, n)
        delta = Ring(pred).evaluate(sample_x / 1024 * 2 * np.pi)[0] - Ring(ref).evaluate(sample_x / 1024 * 2 * np.pi)[0]
        if fixed_error is None: fixed_error = delta
        ab, ba = directed(pred, ref, 0, .05), directed(ref, pred, 0, .05)
        grid = (np.arange(32768) + .5) * 2 * np.pi / 32768
        column_difference = abs(Ring(pred).evaluate(grid)[0] - Ring(ref).evaluate(grid)[0])
        controls.append({'additional_oscillation_nodes': n, 'pairs': len(pred['points']) // 2,
                         'domain': 'strict_single_valued_horizon_straddling',
                         'new_wiggle_endpoint_amplitude_px': 1. if n else 0.,
                         'fixed_error_region_change_px': float(np.max(abs(delta - fixed_error))),
                         'azimuth_mean_absolute_top_difference_px': float(column_difference.mean()),
                         'dense_max_absolute_top_difference_px': float(column_difference.max()),
                         'bev_iou': polygon(pred).intersection(polygon(ref)).area / polygon(pred).union(polygon(ref)).area,
                         'candidate_to_reference': ab, 'reference_to_candidate': ba,
                         'equal_direction_mean_deg': (ab['mean_deg'] + ba['mean_deg']) / 2,
                         'prediction': pred})
    rho, dphi = 2 * np.sqrt(2), 4 * np.pi / 512
    phi = np.arctan(1 / rho)
    top_moved_height = rho * np.tan(phi + dphi)
    floor_moved_radius = 1 / np.tan(phi - dphi)
    floor_moved_height = floor_moved_radius / rho
    original = controls[0]['prediction']
    split = subdivide(original)
    initial_ab, initial_ba = directed(original, ref, 0, .005), directed(ref, original, 0, .005)
    split_ab, split_ba = directed(split, ref, 0, .005), directed(ref, split, 0, .005)
    subdivision = {'original_pairs': len(original['points']) // 2,
                   'subdivided_pairs': len(split['points']) // 2,
                   'curve_max_difference_px': float(abs(Ring(original).evaluate(grid) - Ring(split).evaluate(grid)).max()),
                   'footprint_symdiff_h2': polygon(original).symmetric_difference(polygon(split)).area,
                   'total_top_arc_length_difference_deg': split_ab['length_deg'] - initial_ab['length_deg'],
                   'candidate_to_reference_mean_difference_deg': split_ab['mean_deg'] - initial_ab['mean_deg'],
                   'reference_to_candidate_mean_difference_deg': split_ba['mean_deg'] - initial_ba['mean_deg'],
                   'original': {'candidate_to_reference': initial_ab, 'reference_to_candidate': initial_ba},
                   'subdivided': {'candidate_to_reference': split_ab, 'reference_to_candidate': split_ba}}
    result = {'read_only_input_hashes_unchanged': before == digest_inputs(),
              'real_rows_recomputed': len(rows), 'max_published_boundary_diff_deg': max_boundary_diff,
              'max_published_area_scalar_diff': max_area_diff,
              'point_arc_oracle_tests': len(oracle_errors), 'point_arc_oracle_max_error_deg': max(oracle_errors),
              'real_quality_recomputed': rows, 'refined_real_comparisons': refined,
              'narrow_fixture_independent': narrow, 'added_oscillation_control': controls,
              'pure_subdivision_null_control': subdivision,
              'height_coupling_independent_analytic': {
                  'top_only_height_difference_h': float(top_moved_height - 1),
                  'top_only_bev_iou': 1.,
                  'bottom_only_height_difference_h': float(floor_moved_height - 1),
                  'bottom_only_bev_iou': float((rho / floor_moved_radius)**2)},
              'roof_volume_conventions': {'perimeter_Y': 1., 'floor_Y': -1., 'area_h2': 16.,
                  'apex_Y_2_volume_h3': 32 + 16 / 3, 'apex_Y_2_iou': 6 / 7,
                  'rise_2_apex_Y_3_volume_h3': 32 + 32 / 3, 'rise_2_apex_Y_3_iou': .75},
              'stop_condition': 'All published rows replayed; independent oracle tested; fixed 0/200/1000-node control and a pure-subdivision null control completed. No parameter search or remote changes.'}
    (OUT / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
    assert result['read_only_input_hashes_unchanged']
    assert result['real_rows_recomputed'] == 18
    assert result['max_published_boundary_diff_deg'] < 1e-10
    assert result['max_published_area_scalar_diff'] < 1e-12
    assert result['point_arc_oracle_max_error_deg'] < 1e-10
    assert all(abs(c['bev_iou'] - 1) < 1e-12 for c in controls)
    assert all(c['fixed_error_region_change_px'] == 0 for c in controls)
    assert controls[-1]['azimuth_mean_absolute_top_difference_px'] > controls[0]['azimuth_mean_absolute_top_difference_px']
    assert controls[-1]['equal_direction_mean_deg'] < controls[0]['equal_direction_mean_deg'] - .5
    assert subdivision['curve_max_difference_px'] < 1e-9
    assert abs(subdivision['total_top_arc_length_difference_deg']) < 1e-9
    assert abs(subdivision['candidate_to_reference_mean_difference_deg']) < .0001
    assert abs(subdivision['reference_to_candidate_mean_difference_deg']) < 1e-10
    print(json.dumps({k: v for k, v in result.items() if k not in ['real_quality_recomputed', 'added_oscillation_control']}, ensure_ascii=False, indent=2))
    print('STRESS CONTROL SUMMARY')
    print(json.dumps([{k:v for k,v in row.items() if k != 'prediction'} for row in controls], ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
