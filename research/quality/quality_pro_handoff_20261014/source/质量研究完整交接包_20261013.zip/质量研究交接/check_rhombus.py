import math,json

def area(p):
 return abs(sum(p[i][0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p)))/2)
def clip(p,axis,bound,sign):
 out=[]
 for a,b in zip(p,p[1:]+p[:1]):
  ai=sign*(a[axis]-bound)<=0;bi=sign*(b[axis]-bound)<=0
  if ai:out.append(a)
  if ai!=bi:
   t=(bound-a[axis])/(b[axis]-a[axis]);out.append(tuple(a[k]+t*(b[k]-a[k]) for k in (0,1)))
 return out
rows=[]
for theta in [90,60,45,30,10,1]:
 t=math.radians(theta);c,s=math.cos(t),math.sin(t)
 p=[(-(1+c)/2,-s/2),((1-c)/2,-s/2),((1+c)/2,s/2),((-1+c)/2,s/2)]
 inter=p
 for axis,bound,sign in [(0,.5,1),(0,-.5,-1),(1,.5,1),(1,-.5,-1)]:inter=clip(inter,axis,bound,sign)
 I=area(inter)/(1+area(p)-area(inter))
 edges=[(b[0]-a[0],b[1]-a[1]) for a,b in zip(p,p[1:]+p[:1])]
 angles=[math.degrees(math.atan2(y,x)) for x,y in edges]
 lengths=[math.hypot(x,y) for x,y in edges]
 best=min(sum(w*((a-j/1000+45)%90-45)**2 for a,w in zip(angles,lengths))/sum(lengths) for j in range(90001))
 D=.5*min(theta,90-theta);F=s*(1-c/4)/(1+s*c/4)
 hill=1.5*D*D/(D*D+37.5)
 assert abs(I-F)<1e-12 and abs(math.sqrt(best)-D)<1e-7
 rows.append(dict(theta=theta,D_numeric=math.sqrt(best),D_formula=D,iou_polygon_clip=I,iou_formula=F,edge_lengths=lengths,hill=100*I/(1+hill),tail=100*I/(1+hill+(D/12)**4),simple=100*I/(1+D*D/64)))
print(json.dumps({'method':'independent polygon clipping plus 0.001-degree axis search; ablation only','rows':rows},indent=2))
