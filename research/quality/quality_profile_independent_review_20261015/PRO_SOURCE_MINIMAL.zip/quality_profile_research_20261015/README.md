# Q-Profile-20261015

研究候选：原WQ指数＋普通manual有序五档读数＋参考相对容忍边界/结构诊断。不是默认评分替换。

先读REPORT_ZH.md和CONFIG.json。原始依据见provenance/；外部文献与官方实现见REFERENCES.md。

主要结果：results/same_binding_1145_scores.csv（全部1145行与原资格字段）；TWO_IMAGE_CHANGELOG_36.csv（36份当前两图变更账本）；edge_level_evidence.csv（逐边依据）；ordinary_frozen_calibration.json及ordinal_evaluation.csv（五档拟合及开发留出敏感性）；worker_sensitivity.csv及fusion_fixed_endpoint_pairs.csv（下游）；next_review_bindings.csv（20份新普通绑定，尚未取得其几何）。

打开review/READOUT.html查看五档研究读数；review/TWO_IMAGE_REVIEW.html查看当前两图几何并可加载自己的原图目录。没有复制原图。新顶界始终为空，除非人明确提交待核验建议；页面不会写回GT。N18_POSITION_EVIDENCE.html用于已曝光机制检查，不是盲审。

## 重跑

安装requirements.txt后：

`python -X utf8 reproduce.py --output <新目录>`

--no-plots只跳过图。当前包的正式数值测试32项；真实浏览器检查脚本另需playwright与Chromium，具体执行边界见tests/BROWSER_CHECK.json。原图及完整loader获取失败见SOURCE_AVAILABILITY.json。

## 在具备全库文件的本地水合20份普通盲审卡

`python -X utf8 hydrate_next_review.py --repo <实际仓库根目录> --images <263原图解压根目录> --output <新目录>`

此入口必须实际调用当前统一loader并验证冻结分项。它没有在本轮成功执行；不能把代码或绑定名单视为已经完成的视觉卡。它不下载或打包原图、不选择最高质量参考、不改变冻结选择。

## 文件状态

原始输入保持在inputs/，不回写；结果是独立研究输出。所有新完整两图评分/顶界保持NA，原排除/暂缓不恢复。模拟、几何控制和人类作答分开。粗档概率只是该开发选样条件下的模型输出，不是正确率或一般人群概率。ZIP不包含字体、全量照片、LFS本体或个人凭证。
