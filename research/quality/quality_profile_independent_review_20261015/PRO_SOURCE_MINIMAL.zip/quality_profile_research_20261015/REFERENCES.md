# 原始文献与迁移边界

阅读记录：本轮读取原论文文字与下列官方实现。Boundary IoU及RoomFormer PDF截图已实际呈现；JMIR PDF可读文字，截图请求失败，不声称查看了其未呈现的图。没有使用二手中文网站给参数背书。

## 1. 容忍带与合格边界比例

Stanislav Nikolov, Sam Blackwell, Alexei Zverovitch, et al. (2021). **Clinically Applicable Segmentation of Head and Neck Anatomy for Radiotherapy: Deep Learning Algorithm Development and Validation Study.** *Journal of Medical Internet Research*, 23(7), e26151. DOI: 10.2196/26151.

官方PDF：https://www.jmir.org/2021/7/e26151/PDF

官方正文：https://www.jmir.org/2021/7/e26151/

官方实现：https://github.com/google-deepmind/surface-distance/blob/master/surface_distance/metrics.py

核对 `compute_surface_dice_at_tolerance`：分别累计两方向落入容忍带的表面元素面积，以总表面面积归一。论文容忍值由专家间标注差异并结合临床任务确定、单位为毫米。可迁移的是明确容忍定义、双向覆盖及按测度积分；不能迁移毫米常数或“0.95就是可接受”到全景标注。本轮Cτ使用球面弧长，不是原医学生物表面面积，也不是实体几何准确率。

## 2. 区域与边界不同敏感性

Bowen Cheng, Ross Girshick, Piotr Dollár, Alexander C. Berg, Alexander Kirillov. (2021). **Boundary IoU: Improving Object-Centric Image Segmentation Evaluation.** *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition*, 15334–15342.

作者PDF：https://arxiv.org/pdf/2103.16562

官方实现：https://github.com/bowenc0221/boundary-iou-api/blob/master/boundary_iou/utils/boundary_utils.py

核对默认 `dilation_ratio=0.02`、图像对角线尺度、pad和腐蚀生成内边界带。论文Boundary AP/PQ使用min(Mask IoU, Boundary IoU)。该min是两个特定量的保守组合，不证明本项目I、Sb、D重复，也不证明任意max损失正确。本轮MAX仅为同一组合思想的挑战，不称其Boundary IoU；BC的Cτ也不是栅格Boundary IoU。

## 3. 参考角与匹配覆盖

Yuanwen Yue, Theodora Kontogianni, Konrad Schindler, Francis Engelmann. (2023). **Connecting the Dots: Floorplan Reconstruction Using Two-Level Queries.** *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition*, 845–854.

作者PDF：https://arxiv.org/pdf/2211.15658

官方评价器：https://github.com/ywyue/RoomFormer/blob/main/s3d_floorplan_eval/Evaluator/Evaluator.py

核对：先房间对应，定位门内的参考角与预测角比较；脚本 `corner_metric_thresh=10`、`angle_metric_thresh=5`。定位阈值是其平面图像素域，不能当成1024×512 ERP的10px。本轮改为球面位置门2°及BEV有向内角门10°，两者只是待检验诊断尺度。匹配使用最大基数、最小位置距离的循环保序动态规划，并非逐字移植其最近角点实现。不让角度误差或质量总分选择匹配；未匹配角度留空，但角点/角度precision和recall分母保留未匹配部分。

## 4. 有序读数

Peter McCullagh. (1980). **Regression Models for Ordinal Data.** *Journal of the Royal Statistical Society: Series B (Methodological)*, 42(2), 109–127. DOI: 10.1111/j.2517-6161.1980.tb01109.x.

官方页面：https://academic.oup.com/jrsssb/article/42/2/109/7027621

核对了官方题录、摘要和比例优势模型说明。该页提示正文为PDF，但本轮没有获得可用直接PDF下载地址，因此不虚构链接或声称重新验证全文推导。本轮实现正斜率累积logit；岭项、图片等权、置信展示规则均为本次设计，不是原文推荐的本项目参数。

## 5. 原3D IoU对照与空间解释

Cheng Sun, Min Sun, Hwann-Tzong Chen. (2021). **HoHoNet: 360 Indoor Holistic Understanding With Latent Horizontal Features.** *CVPR*, 2573–2582.

作者PDF：https://arxiv.org/pdf/2011.11498
官方实现：https://github.com/sunset1995/HoHoNet/blob/master/eval_layout.py

本轮直接重跑的是随前次研究代码保留的现用均高棱柱对照，并用28份冻结数据核验一致；没有重训HoHoNet。角点算术均高不是任意起伏顶部的实体体积积分，冗余顶点会改变前者而不改变声明墙带。

Yu-Ju Tsai, Jin-Cheng Jhang, Jingjing Zheng, Wei Wang, Albert Y. C. Chen, Min Sun, Cheng-Hao Kuo, Ming-Hsuan Yang. (2024). **No More Ambiguity in 360° Room Layout via Bi-Layout Estimation.** *CVPR*, 28056–28065.

作者PDF：https://arxiv.org/pdf/2404.09993

使用既有研究已核对的enclosed/extended区别来限定目标语义；本轮未借文献裁决两图原图，也没有按最高Q选参考。新底面的用户确认继续保留，新增顶界与作答空间归属仍分别登记。
