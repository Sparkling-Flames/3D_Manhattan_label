"""Offline browser review with exact frozen geometry, no original images repackaged."""
from __future__ import annotations
import pathlib,json,sys
ROOT=pathlib.Path(__file__).resolve().parent

def write_viewer(cards,dest,mode='scope',title='两图当前作答复核',intro=None):
    payload={'panel_id':'quality_next_20261015_'+mode,'mode':mode,'title':title,'exposure':'known_developmental' if mode=='scope' else 'not_used_current_fit_historical_exposure_unknown','intro':intro or '本页提供34份当前可用作答及2份配对不可用记录。未迁移旧顶界，未授予新参考资格。加载原图后逐份复核；无分数显示。','cards':cards}
    text=(ROOT/'review/viewer_template.html').read_text(encoding='utf-8');s=json.dumps(payload,ensure_ascii=False).replace('</','<\\/')
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text.replace('__PAYLOAD__',s),encoding='utf-8')

def run(results,review):
    views=json.loads((results/'current_geometry_view_data.json').read_text());cards=[]
    for c in views:c=dict(c);c['display_id']=c['image_code']+' / '+c['record_id'];c['crop_center_x']=0 if c['image_code'].startswith('Uw') else 805;cards.append(c)
    ledger=json.loads((results/'two_image_36_ledger.json').read_text())
    for c in ledger:
        if c['execution_status'].startswith('pairing_unavailable'):cards.append(dict(display_id=c['image_code']+' / '+c['record_id'],record_id=c['record_id'],image_id=c['image_id'],floor=None,condition=c['condition'],cleaning=c['cleaning_disposition']))
    cards.sort(key=lambda c:(c.get('image_id',''),c['record_id']));write_viewer(cards,review/'TWO_IMAGE_REVIEW.html')
    # Readout tool is deliberately separate from blind-review pages.
    calib=json.loads((results/'ordinary_frozen_calibration.json').read_text())['WQ']
    html='''<!doctype html><meta charset="utf-8"><title>普通作答五档研究读数</title><style>body{font:17px/1.7 system-ui;max-width:850px;margin:35px auto;padding:20px}table{border-collapse:collapse}td,th{padding:10px;border:1px solid #bbb}</style><h1>普通作答五档研究读数</h1><p>仅解释固定WQ的读数，不修改WQ，不是正确概率。仅适用于同范围、完整参考的普通manual开发域；不用于门洞、OOS、参考暂缓、仅底面或人员资格自动裁决。</p><label>WQ（0–100）：<input id="q" type="number" min="0" max="100" value="70" step=".1"></label><button id="go">查看</button><h2 id="median"></h2><p id="warning"></p><table id="probs"></table><p>模型：正斜率累积logit。30份开发反馈、26图、9建筑，五档支持为1／2／12／10／5（由差至好）。下端两个切点证据特别弱。显示的是该选样条件下的模型读数，不能外推为一般人群评价比例。</p><script>const cfg=__CAL__,labels=['较差','一般与较差之间','一般','较好与一般之间','较好'];function render(){let q=Number(document.getElementById('q').value);if(!Number.isFinite(q)||q<0||q>100)return;let c=cfg.thresholds.map(t=>1/(1+Math.exp(-(t-cfg.slope*q/100)))),all=[0,...c,1],p=all.slice(1).map((x,i)=>x-all[i]);document.getElementById('median').textContent='暂定中位粗档：'+labels[c.filter(x=>x<.5).length];document.getElementById('warning').textContent=q<40?'低分端支持不足：只作待核验候选，不可靠地区分两个低档。':((q>=52.9&&q<=62.8)||(q>=78.8&&q<=85.8))?'接近建筑重采样的切点不稳定区：允许相邻档意见。':'仍为开发读数，需要下一批人工核验。';document.getElementById('probs').innerHTML='<tr><th>粗档</th><th>模型读数（非总体概率）</th></tr>'+p.map((x,i)=>'<tr><td>'+labels[i]+'</td><td>'+(100*x).toFixed(1)+'%</td></tr>').join('')}document.getElementById('go').onclick=render;render()</script>'''.replace('__CAL__',json.dumps(calib))
    (review/'READOUT.html').write_text(html,encoding='utf-8')
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--results',type=pathlib.Path,default=ROOT/'results');p.add_argument('--review',type=pathlib.Path,default=ROOT/'review');a=p.parse_args();run(a.results,a.review)
