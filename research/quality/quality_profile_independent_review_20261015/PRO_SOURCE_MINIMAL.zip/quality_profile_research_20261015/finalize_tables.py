from pathlib import Path
import sys,json
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from native_geometry import project
from build_review import write_viewer
from ordinal import predict

def run(out,review):
 ledger=json.loads((out/'two_image_36_ledger.json').read_text());pair=pd.read_csv(out/'two_image_68_floor_pairs.csv');old=pd.read_csv(out/'two_image_34_original_conditional_scores.csv').set_index('record_id');joint=pd.read_csv(ROOT/'inputs/JOINT_COMPARISON_1145.csv').set_index('record_id');routes=pd.read_csv(out/'two_image_route_sensitivity.csv');rows=[];miss=[]
 for x in ledger:
  rid=x['record_id'];base={k:x[k] for k in ['record_id','object_id','image_id','image_code','worker_id','condition','cleaning_disposition','worker_quality_gate','ring_confirmed','order_status','execution_status']};base.update(prior_restrictions=json.dumps(x['prior_ledger_qualification'],ensure_ascii=False),updated_full_WQ=None,updated_full_IoU3D=None,selected_reference=None,new_top_confirmed=False,eligibility_changed=False,original_image_visually_checked=False)
  base['previous_frozen_WQ']=float(joint.loc[rid,'WQ']) if rid in joint.index else None
  if rid in old.index:
   rr=routes[routes.record_id==rid].iloc[0];base['geometric_scope_hint']=rr.route_hint
   for label,prefix in [('original','old_floor'),('new_floor_only','new_floor')]:
    r=pair[(pair.record_id==rid)&(pair.reference_kind==label)].iloc[0]
    for k in ['I','Sb','D','WQ_full_upper_bound']:base[prefix+'_'+k]=float(r[k])
   base['change']='current_geometry_recomputed_prior_full_parity' if rid in joint.index else 'newly_refreshed_diagnostics_original_hold_or_exclusion_unchanged'
  else:base['change']='pairing_unavailable_exclusion_preserved'
  rows.append(base)
 pd.DataFrame(rows).to_csv(out/'TWO_IMAGE_CHANGELOG_36.csv',index=False)
 refs=json.loads((ROOT/'inputs/TWO_IMAGE_SCOPE_DELTA.json').read_text())['records']
 for x in refs:
  for i,(a,z) in enumerate(x['new_floor_polygon_xz_h']):
   u=(np.arctan2(a,-z)/(2*np.pi)+.5)*1024;y=(.5+np.arctan2(1,np.hypot(a,z))/np.pi)*512
   miss.append(dict(image_code=x['image_code'],image_id=x['image_id'],new_reference_id=x['new_floor_candidate_id'],corner=i,erp_x=u,bottom_erp_y=y,top_erp_y=None,new_top_status='not_confirmed',request='Confirm corresponding top y and role of protocol-closure ceiling; leave unknown rather than transplant old ceiling.'))
 pd.DataFrame(miss).to_csv(out/'TOP_BOUNDARY_REQUEST_8_LOCATIONS.csv',index=False)
 q=json.loads((ROOT/'inputs/targeted_archive_triples.json').read_text())['triples'];cards=[]
 for rid,t in q.items():
  a,h=project(t);cards.append(dict(display_id=('N18 / ' if rid=='R03034' else '')+rid,image_id='uNb9QFRL6hY_13a430466eb64e2087e7fb5acde7a398',floor=a.tolist(),height=h.tolist(),original_floor=None,new_floor=None,crop_center_x=900))
 write_viewer(cards,review/'N18_POSITION_EVIDENCE.html','mechanism','N18逐边定位机制复核','只显示已读取的作答几何；该图GT坐标未取得，不作参考相对总分比较。重点看x约870–928、bottom y约292–301的墙面细节。已曝光开发例；不是盲验证。')
 # Publish only developmental profile semantics, not a new production index.
 config={'name':'Q-Profile-20261015','version':'research-v1','adopt':'unchanged WQ index + ordinary ordinal readout + reference-relative tolerance/structure diagnostics',
 'production_default_changed':False,'numeric_index':'WQ-LS08 unchanged',
 'readout':json.loads((out/'ordinary_frozen_calibration.json').read_text())['WQ'],
 'grade_order_low_to_high':['较差','一般与较差之间','一般','较好与一般之间','较好'],
 'readout_scope':'conditional ordinary manual same-target/full-reference only; not automatic eligibility',
 'low_end_warning':'only 1 poor and 2 average-poor fit examples; two lower cuts unstable',
 'boundary_profile':{'tolerances_spherical_deg':[.5,1.,2.],'sampling_per_direction':4096,'recommended_as_total':False,'noise_calibrated':False},
 'corner_diagnostic':{'position_gate_spherical_deg':2.,'angle_gate_BEV_deg':10.,'correspondence':'cyclic maximum-cardinality minimum-position-distance; no Q or angle fitting','unmatched_angle':'NA with precision/recall denominator retained','recommended_as_hard_total_guard':False},
 'rejected_for_adoption_now':['T1/T2/T4 global-D deadband','MAX floor-family max loss','RGP max floor geometry without D','BC tolerance total','BC hard corner guard'],
 'aggregation':'retain WQ scale for existing worker/fusion statistics; do not average grade labels or transformed readouts as if same estimand',
 'next_panel':{'n':20,'current_fit_images_excluded':True,'historical_exposure_certified':False,'geometry_hydrated_in_this_run':False}}
 (out.parent/'CONFIG.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
 availability={'main':'7b785104d676af1d4dfbb10c441619f1f2cbca20','source':'GitHub connected branch metadata; uploaded independent supplement has precedence for its explicit additions','supplement_parsed':True,'joint_csv_rows':1145,'current_two_image_objects':38,'full_LFS_json_downloaded':False,'full_current_loader_executed':False,'original_release_metadata_read':True,'original_images_downloaded':0,'original_images_visually_read':0,'binary_retrieval_failures':['container network DNS unavailable','web release asset cache miss','web media.githubusercontent.com request inaccessible'],
 'effect':'complete full-component scalar challenges possible on 1145 rows; new boundary/corner measures limited to 34 two-image answers + synthetic controls; 7 additional ordinary archived geometries allow own-axis/noise evidence only',
 'not_claimed':['263 photos visually reviewed','3152 records rescored from current loader','new ceiling established','two-image legal-space visual adjudication','20 ordinary visual cards already hydrated','actual policy selection or fusion rerun'],
 'zip_policy':'no SHA manifest requested; export checked by ZIP read/test and actual file existence'}
 (out.parent/'SOURCE_AVAILABILITY.json').write_text(json.dumps(availability,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results');p.add_argument('--review',type=Path,default=ROOT/'review');a=p.parse_args();run(a.results,a.review)
