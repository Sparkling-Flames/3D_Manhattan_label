"""Materialize the FROZEN ordinary review bindings from the actual repository loader.
Read-only. No best-score reference search, no original-photo copying. Reject stale
score components rather than silently changing the review cohort.
This live-data path was NOT executed in the research container (network unavailable).
"""
from __future__ import annotations
import argparse,json,pathlib,sys
import pandas as pd,numpy as np
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from native_geometry import erp_triples,project,direction,bottom_distance,iou,height_components,prism_iou
from models import score
from build_review import write_viewer

def hydrate(repo,images,output):
    if output.exists():raise FileExistsError('Use a new output directory; never overwrite review receipts.')
    sys.path.insert(0,str(repo.resolve()))
    from tools.thesis_main.data_prep.consolidate_research_input import load_current_bundle
    bundle=load_current_bundle();objects={o['object_id']:o for o in bundle['data']['objects']}
    sel=pd.read_csv(ROOT/'results/next_review_private_manifest.csv')
    photo={p.stem:p for p in images.rglob('*') if p.suffix.lower() in ['.png','.jpg','.jpeg']}
    cards=[];audit=[]
    for r in sel.itertuples():
        a=objects[r.object_id];g=objects[r.reference_id]
        if a['image_id']!=r.image_id or g['image_id']!=r.image_id:raise ValueError('Frozen reference-image mismatch '+r.record_id)
        if a['condition']!='manual' or a['cleaning_disposition']!='retained':raise ValueError('Current condition/cleaning changed '+r.record_id)
        if a['points_1024x512'] is None or g['points_1024x512'] is None:raise ValueError('Missing current paired geometry '+r.record_id)
        x,h=project(erp_triples(a['points_1024x512']));y,k=project(erp_triples(g['points_1024x512']))
        I=iou(x,y);S=bottom_distance(x,y);D=direction(x);M,L=height_components(x,h,y,k)
        computed=[I,S,D,M,L,float(score(I,S,D,M,L)),100*prism_iou(x,h,y,k)]
        frozen=[r.iou_2d,r.S_bottom_deg,r.dir,r.Hmean,r.Hcenter,r.WQ,r.IoU3D100]
        delta=float(np.max(np.abs(np.array(computed)-frozen)))
        if delta>1e-6:raise ValueError(f'{r.record_id}: current geometry differs from frozen metrics ({delta}); reconcile version before materializing')
        if r.image_id not in photo:raise FileNotFoundError('Original image missing: '+r.image_id)
        with Image.open(photo[r.image_id]) as im:
            im.verify()
        cards.append(dict(display_id=r.blind_id,image_id=r.image_id,floor=x.tolist(),height=h.tolist(),original_floor=y.tolist(),original_height=k.tolist(),new_floor=None,photo_path=photo[r.image_id].resolve().as_uri()))
        audit.append(dict(blind_id=r.blind_id,record_id=r.record_id,object_id=r.object_id,reference_id=r.reference_id,max_component_error=delta,original_photo_path=str(photo[r.image_id]),score_and_worker_identity_embedded=False))
    output.mkdir(parents=True)
    write_viewer(cards,output/'NEXT_ORDINARY_REVIEW.html','ordinary','普通作答粗核验：匿名20卡','20张图未参与本轮读数拟合；不保证历史从未曝光。先看原图与参考，只选五档或指出超过容忍的部位。没有模型身份和分数。')
    (output/'PRIVATE_BINDING_AUDIT.json').write_text(json.dumps(dict(loader_validation=bundle['validation'],bindings=audit),ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Created {len(cards)} verified same-binding cards. Original images not copied.')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=pathlib.Path,required=True);p.add_argument('--images',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();hydrate(a.repo,a.images,a.output)
