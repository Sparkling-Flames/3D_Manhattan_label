"""Run through Python-visible tool for plotted deliverables. Matplotlib defaults."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def generate(results,figures):
 results,figures=Path(results),Path(figures);figures.mkdir(parents=True,exist_ok=True)
 def save(fig,name):fig.tight_layout();fig.savefig(figures/name,dpi=160);plt.close(fig)
 g=pd.read_csv(results/'geometric_controls.csv');h=g[g.family=='shear']
 fig,ax=plt.subplots(figsize=(9,5))
 for m in ['WQ','T2','MAX','BC0.5','BC1','BC2']:ax.plot(np.degrees(np.arctan(h.amplitude)),h[m],marker='o',label=m)
 ax.set(xlabel='True wall-angle deviation from reference / degrees',ylabel='Score',ylim=(0,102),title='Same shear geometry: tolerance is a substantive choice');ax.legend();ax.grid(alpha=.25);save(fig,'shear_tolerance.png')
 r=pd.read_csv(results/'readout_table_0_100.csv')
 fig,ax=plt.subplots(figsize=(9,5))
 for k,label in enumerate(['Poor','Average-poor','Average','Good-average','Good']):ax.plot(r.WQ,r[f'p_grade_{k}'],label=label)
 ax.set(xlabel='Unchanged WQ index',ylabel='Developmental ordinal model output',ylim=(0,1),title='30 exposed ordinary reviews; not population-calibrated probabilities');ax.legend();ax.grid(alpha=.25);save(fig,'ordinal_readout.png')
 ed=pd.read_csv(results/'edge_level_evidence.csv');n=ed[ed.record_id=='R03034']
 fig,ax=plt.subplots(figsize=(9,5));ax.bar(n.edge,100*n.D2_share,label='Share of observed D squared');ax.plot(n.edge,100*n.length_share,marker='o',label='Share of floor perimeter');ax.set(xlabel='N18 edge index (0-based)',ylabel='Percent',title='N18: dominant burden is not on the shortest edge');ax.set_xticks(n.edge);ax.legend();save(fig,'N18_edge_contributions.png')
 fig,ax=plt.subplots(figsize=(9,5));ax.bar(n.edge,n.sigma_angle_deg_per_1px);ax.set(xlabel='N18 edge index (0-based)',ylabel='Linearized angle SD / degrees',title='1 ERP-pixel noise scenario — not measured annotation noise');ax.set_xticks(n.edge);save(fig,'N18_position_sensitivity.png')
 fig,ax=plt.subplots(figsize=(9,5));xx=g[g.family=='branch'];ax.plot(xx.amplitude,xx.WQ,marker='o',label='WQ');ax.plot(xx.amplitude,xx.BC1,marker='o',label='1-degree boundary coverage score');ax.plot(xx.amplitude,xx.BC1_corner_guard,marker='o',label='Hard corner guard');ax.set(xlabel='Omitted branch width / camera height',ylabel='Score',ylim=(0,102),title='Area/arc-length vs corner-count weighting');ax.legend();save(fig,'branch_tradeoff.png')
 fig,ax=plt.subplots(figsize=(9,5));xx=g[g.family=='subdivision'];ax.plot(xx.amplitude,xx.WQ,marker='o',label='WQ');ax.plot(xx.amplitude,xx.BC1,marker='x',label='BC1');ax.plot(xx.amplitude,xx.IoU3D100,marker='o',label='Existing vertex-mean 3D IoU');ax.set(xlabel='Extra exactly collinear points',ylabel='Score',ylim=(88,101),title='Declared 3D boundary unchanged');ax.legend();save(fig,'subdivision.png')
 fig,ax=plt.subplots(figsize=(9,5));xx=g[g.family=='rhombus'];ax.plot(xx.amplitude,xx.dir,marker='o',label='Own-axis D');ax.plot(xx.amplitude,90-xx.amplitude,marker='o',label='True angle error vs square');ax.set(xlim=(91,0),xlabel='Acute rhombus angle / degrees',ylabel='Degrees',title='Changing axis family is not restored structure');ax.legend();save(fig,'axis_family.png')
 d=pd.read_csv(results/'same_binding_1145_scores.csv');d=d[d.analysis_group=='ordinary_manual_conditional']
 fig,ax=plt.subplots(figsize=(7,6));ax.scatter(d.calc_WQ,d.calc_T2,s=12,alpha=.45,label='T2');ax.scatter(d.calc_WQ,d.calc_MAX,s=12,alpha=.45,marker='x',label='MAX');ax.plot([0,100],[0,100],linestyle='--');ax.set(xlim=(0,101),ylim=(0,101),xlabel='WQ',ylabel='Challenge score',title='931 same-binding ordinary manual records');ax.legend();save(fig,'ordinary_931.png')
 return 8
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--figures',type=Path,required=True);a=p.parse_args();generate(a.results,a.figures)
