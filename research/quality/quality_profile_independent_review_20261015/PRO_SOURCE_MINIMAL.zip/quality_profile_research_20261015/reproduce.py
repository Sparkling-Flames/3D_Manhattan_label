"""Fresh-directory numerical reproduction; does not change repository defaults or GT."""
from pathlib import Path
import argparse,os,subprocess,sys,json
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--no-plots',action='store_true');p.add_argument('--bootstrap',type=int,default=120);a=p.parse_args()
if a.output.exists():raise FileExistsError('Output directory must not exist.')
a.output.mkdir(parents=True);res=a.output/'results';rev=a.output/'review';rev.mkdir();env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',QUALITY_RESULTS_DIR=str(res.resolve()))
commands=[['run_empirical.py','--input',str(ROOT/'inputs'),'--output',str(res),'--bootstrap',str(a.bootstrap)],['run_geometry.py','--input',str(ROOT/'inputs'),'--output',str(res)],['run_readout_sensitivity.py','--output',str(res)],['build_review.py','--results',str(res),'--review',str(rev)],['finalize_tables.py','--results',str(res),'--review',str(rev)]]
if not a.no_plots:commands.append(['plot_results.py','--results',str(res),'--figures',str(a.output/'figures')])
for cmd in commands:
 run=subprocess.run([sys.executable,'-X','utf8',str(ROOT/cmd[0]),*cmd[1:]],cwd=ROOT,env=env,capture_output=True,text=True)
 (a.output/(cmd[0]+'.log')).write_text(run.stdout+run.stderr,encoding='utf-8')
 if run.returncode:raise RuntimeError(cmd[0]+' failed; inspect log')
test=subprocess.run([sys.executable,'-m','pytest','-q',str(ROOT/'tests/test_study.py')],cwd=ROOT,env=env,capture_output=True,text=True)
(a.output/'TEST_RESULTS.txt').write_text(test.stdout+test.stderr,encoding='utf-8')
if test.returncode:raise RuntimeError('tests failed')
print('Numerical reproduction and tests completed:',a.output)
