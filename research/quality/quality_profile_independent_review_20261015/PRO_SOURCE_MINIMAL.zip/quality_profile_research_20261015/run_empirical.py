from __future__ import annotations
import sys,json,itertools,pathlib,shutil
import numpy as np,pandas as pd
from scipy.stats import spearmanr
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from models import score
from ordinal import fit,predict,median_grade,loss_stats
MODELS=['WQ','T1','T2','T4','MAX','RGP','IoU3D100']
GRADE={'poor':0,'average_poor':1,'average':2,'good_average':3,'good':4}
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def attach(d):
    d=d.copy();mask=d[['iou_2d','S_bottom_deg','dir','Hmean','Hcenter']].notna().all(axis=1)
    for m in MODELS[:-1]:
        d['calc_'+m]=np.nan;d.loc[mask,'calc_'+m]=score(*[d.loc[mask,k].to_numpy() for k in ['iou_2d','S_bottom_deg','dir','Hmean','Hcenter']],m)
    d['calc_IoU3D100']=d['IoU3D100'];return d

def run(inp,out,bootstrap=120):
    out.mkdir(exist_ok=True,parents=True)
    d=pd.read_csv(inp/'JOINT_COMPARISON_1145.csv');assert len(d)==1145 and d.record_id.is_unique
    d=attach(d);err=float(abs(d.WQ-d.calc_WQ).max());assert err<1e-9
    assert d.formal_eligibility_newly_granted.eq(False).all()
    two=['B6ByNegPMKs-37','UwV83HsGsw3-10']
    # Excludes new two-image target issue across all responses, not only N05/N28.
    d['this_study_scope_hold']=d.image_code.isin(two)
    d['analysis_group']=np.select([
      d.this_study_scope_hold,
      (d.role=='manual_development_candidate')&~d.latest_step_reference_pending&~d.same_target_quality_hold,
      (d.role=='manual_development_candidate'),
      (d.role=='semi_secondary_candidate'),
      (d.role=='severe_exception_candidate'),
      (d.stage=='doorway')&~d.same_target_quality_hold,
      (d.stage=='doorway')],
      ['two_image_scope_diagnostic','ordinary_manual_conditional','ordinary_target_held','semi_separate','severe_separate','doorway_conditional','doorway_target_held'],default='historical_diagnostic')
    p=pd.read_csv(inp/'selection_provenance.csv');manifest=json.load(open(inp/'coarse_manifest.json'));rec=json.load(open(inp/'human_receipt_44.json'))['decisions'];rr=[]
    for c in manifest['cards']:
        b=c['bindings'][0];r=rec[c['id']];x=p[p.record_id==b['record_id']].iloc[0].to_dict()
        assert x['object_id']==b['object_id'] and x['reference_id']==b['reference_object_id']
        x.update(card_id=c['id'],grade=r['grade'],grade_ordinal=GRADE.get(r['grade'],np.nan),comment=r['comment'],score_exposed_here=bool(r.get('score_revealed_at')),current_feedback_is_blind=False)
        rr.append(x)
    h=attach(pd.DataFrame(rr));h['fit_used']=(h.phase=='ordinary')&~h.card_id.isin(['N05','N28'])&h.grade_ordinal.notna()
    # Ordinary phase chooses no geometric tolerance from human scores. It only fits
    # separate ordinal readouts for frozen challenges; there is no winner optimizer.
    train=h[h.fit_used].copy();configs={};evals=[];cv=[]
    for m in MODELS:
        key='calc_'+m
        # One image has two selected annotations: equal image weighting during fit.
        w=1/train.groupby('image_id').record_id.transform('size').to_numpy()
        f=fit(train[key],train.grade_ordinal,w);configs[m]=f
        probs=predict(f,train[key]);evals.append(dict(split='ordinary_resubstitution_not_validation',model=m,**loss_stats(probs,train.grade_ordinal)))
        for groupby in ['image_id','building_id']:
            allp=np.zeros((len(train),5))
            for group in train[groupby].unique():
                mask=train[groupby].eq(group).to_numpy();tr=train[~mask];ww=1/tr.groupby('image_id').record_id.transform('size').to_numpy()
                ff=fit(tr[key],tr.grade_ordinal,ww);pp=predict(ff,train.loc[mask,key]);allp[mask]=pp
                for rid,pro in zip(train.loc[mask,'record_id'],pp):cv.append(dict(model=m,grouping=groupby,held_group=group,record_id=rid,**{f'p_{j}':float(pro[j]) for j in range(5)}))
            evals.append(dict(split='leave_'+groupby+'_development_sensitivity',model=m,**loss_stats(allp,train.grade_ordinal)))
        for name,hh in [('ordinary_stricter_scope_comments',h[h.fit_used&~h.card_id.isin(['N08','N20'])]),('ordinary_all_30_repeat',train)]:
            evals.append(dict(split=name,model=m,**loss_stats(predict(f,hh[key]),hh.grade_ordinal)))
        d['ordinal_median_'+m]=median_grade(f,d[key])
        d['p_at_least_good_average_'+m]=predict(f,d[key])[:,3:].sum(axis=1)
        h['ordinal_median_'+m]=median_grade(f,h[key]);h['p_at_least_good_average_'+m]=predict(f,h[key])[:,3:].sum(axis=1)
    # Freeze ordinary calibration BEFORE doorway results. Same config, no re-fit.
    dump(out/'ordinary_frozen_calibration.json',configs)
    # Frozen file exists before first doorway transfer result in this run.
    doorway=h[(h.phase=='doorway')&h.grade_ordinal.notna()]
    for m in MODELS:
        evals.append(dict(split='doorway_weak_transfer_no_refit',model=m,**loss_stats(predict(configs[m],doorway['calc_'+m]),doorway.grade_ordinal)))
    # Grade projections outside the calibration domain stay diagnostic, not labels.
    d['provisional_grade_WQ']=d['ordinal_median_WQ'].where(d.analysis_group=='ordinary_manual_conditional')
    d['provisional_grade_status']=np.where(d.analysis_group=='ordinary_manual_conditional','developmental_ordinal_readout_not_certified','not_assigned_outside_readout_domain')
    d=d.rename(columns={f'ordinal_median_{m}':f'diagnostic_ordinal_median_{m}' for m in MODELS})
    rng=np.random.default_rng(20261015);builds=train.building_id.unique();bs=[]
    for k in range(bootstrap):
        sampled=rng.choice(builds,len(builds),replace=True);pieces=[]
        for i,b in enumerate(sampled):
            a=train[train.building_id==b].copy();a['boot_image']=str(i)+'|'+a.image_id;pieces.append(a)
        t=pd.concat(pieces,ignore_index=True);w=1/t.groupby('boot_image').record_id.transform('size').to_numpy()
        model=fit(t.calc_WQ,t.grade_ordinal,w)
        bs.append(dict(replicate=k,n=len(t),converged=model['converged'],**{f'cut_{j}':v for j,v in enumerate(model['q_at_cumulative_half'])}))
    bsf=pd.DataFrame(bs);bsf.to_csv(out/'WQ_cut_building_bootstrap.csv',index=False)
    dump(out/'WQ_cut_uncertainty.json',{f'cut_{j}':{q:float(bsf[f'cut_{j}'].quantile(v)) for q,v in [('q05',.05),('q50',.5),('q95',.95)]} for j in range(4)})
    # Nonindependent same-image same-reference pairwise descriptions.
    pair=[];sums=[];ordinary=d[d.analysis_group=='ordinary_manual_conditional'].copy()
    for group,sub in d.groupby('analysis_group'):
        for m in MODELS:
            vals=sub['calc_'+m];sums.append(dict(group=group,model=m,n=len(sub),mean=vals.mean(),median=vals.median(),min=vals.min(),max=vals.max(),rho_to_WQ=spearmanr(sub.calc_WQ,vals).statistic if len(sub)>2 else None))
    for m in MODELS:
        nn=op=mat=eq=0
        for _,g in ordinary.groupby(['image_id','reference_id','condition']):
            vals=g[['worker_id','calc_WQ','calc_'+m]].to_numpy() if m!='WQ' else g[['worker_id','calc_WQ','calc_T1']].to_numpy()
            for a,b in itertools.combinations(vals,2):
                if a[0]==b[0]:continue
                x=float(a[1]-b[1]);y=x if m=='WQ' else float(a[2]-b[2])
                if abs(x)<1e-10 and abs(y)<1e-10:eq+=1;continue
                nn+=1;op+=int(x*y<-1e-10);mat+=int(x*y<-1e-10 and abs(x)>=5 and abs(y)>=5)
        pair.append(dict(model=m,n_pairs=nn,opposite=op,material_both_gap_ge5=mat,tied_both=eq))
    # Worker cell means, unchanged eligibility and row set for every model.
    cols=['calc_'+m for m in MODELS]+['p_at_least_good_average_WQ']
    o=ordinary[ordinary.personnel_barriers.eq('[]')&ordinary.context_barriers.eq('[]')&~ordinary.original_holdout].copy();o['cell']=o.image_id+'|'+o.reference_id+'|'+o.condition
    cells=o.groupby(['worker_id','cell','building_id'])[cols].mean().reset_index()
    for c in cols:cells['centered_'+c]=cells[c]-cells.groupby('cell')[c].transform('mean')
    support=cells.groupby('worker_id').cell.nunique();keep=support[support>=5].index
    wc=cells[cells.worker_id.isin(keep)].groupby('worker_id')[['centered_'+c for c in cols]].mean();wc['n_cells']=support.loc[wc.index]
    ws=[]
    for c in cols:
        wc['rank_'+c]=wc['centered_'+c].rank(ascending=False,method='average')
    base=wc['rank_calc_WQ'];basegroup=pd.cut((base-1)/max(1,len(wc)),[-.01,1/3,2/3,1.01],labels=['top','middle','bottom'])
    common=cells[cells.worker_id.isin(keep)].groupby('cell').worker_id.nunique();common=common[common==len(keep)].index
    for c in cols:
        group=pd.cut((wc['rank_'+c]-1)/max(1,len(wc)),[-.01,1/3,2/3,1.01],labels=['top','middle','bottom'])
        ws.append(dict(metric=c,n_workers=len(wc),n_cells=len(cells.cell.unique()),n_common_cells=len(common),spearman=spearmanr(base,wc['rank_'+c]).statistic,max_rank_change=float(abs(base-wc['rank_'+c]).max()),relative_tercile_changes=int((basegroup!=group).sum()),terciles_are_not_absolute_quality_grades=True))
    wc.to_csv(out/'worker_centered_scores.csv');cells.to_csv(out/'worker_cell_scores.csv',index=False);pd.DataFrame(ws).to_csv(out/'worker_sensitivity.csv',index=False)
    # Re-score frozen endpoints; enrich holds from matching latest reference units.
    fusion=attach(pd.read_csv(inp/'FUSION_220_SCORES.csv'));assert len(fusion)==220
    badunits=set(zip(d[d.latest_step_reference_pending|d.same_target_quality_hold|d.this_study_scope_hold].image_id,d[d.latest_step_reference_pending|d.same_target_quality_hold|d.this_study_scope_hold].reference_id))
    fusion['joined_reference_hold']=[(r.image_id,r.reference_id) in badunits for _,r in fusion.iterrows()]
    good=(fusion.status=='complete')&(fusion.stage=='ordinary')&fusion.member_restrictions.eq('[]')&fusion.holdout_members.eq('[]')&~fusion.joined_reference_hold
    complete=fusion.status=='complete';fusion['p_at_least_good_average_WQ']=np.nan;fusion.loc[complete,'p_at_least_good_average_WQ']=predict(configs['WQ'],fusion.loc[complete,'calc_WQ'])[:,3:].sum(axis=1)
    fpair=[]
    for (im,ref),sub in fusion[good].groupby(['image_id','reference_id']):
        if len(sub)!=2 or set(sub.version)!=set(['automatic','assisted']):continue
        aa=sub[sub.version=='assisted'].iloc[0];bb=sub[sub.version=='automatic'].iloc[0]
        rec=dict(image_id=im,reference_id=ref,n_auto=int(bb.n),n_assisted=int(aa.n))
        for c in cols:rec[c]=aa[c]-bb[c]
        fpair.append(rec)
    pd.DataFrame(fpair).to_csv(out/'fusion_fixed_endpoint_pairs.csv',index=False);fusion.to_csv(out/'fusion_all_220.csv',index=False)
    d.to_csv(out/'same_binding_1145_scores.csv',index=False);h.to_csv(out/'feedback_44_scores.csv',index=False)
    pd.DataFrame(evals).to_csv(out/'ordinal_evaluation.csv',index=False);pd.DataFrame(cv).to_csv(out/'ordinal_held_predictions.csv',index=False)
    pd.DataFrame(sums).to_csv(out/'stratum_summary.csv',index=False);pd.DataFrame(pair).to_csv(out/'same_cell_rank_changes.csv',index=False)
    # New-review candidates exclude all current 44 images, both scope updates and holds.
    pool=ordinary[~ordinary.image_id.isin(h.image_id)&ordinary.personnel_barriers.eq('[]')&ordinary.context_barriers.eq('[]')].copy()
    rng=np.random.default_rng(20261016);selected=[];used=set()
    for lo,hi in [(0,35),(35,50),(50,65),(65,80),(80,101)]:
        cand=pool[(pool.calc_WQ>=lo)&(pool.calc_WQ<hi)].sample(frac=1,random_state=int(rng.integers(1e7)))
        take=0
        for _,r in cand.iterrows():
            if r.image_id in used:continue
            used.add(r.image_id);r=r.to_dict();r['selection_reason']=f'coverage of frozen WQ interval [{lo},{hi}); no outcome targeted';selected.append(r);take+=1
            if take==4:break
    sel=pd.DataFrame(selected);sel=sel.sample(frac=1,random_state=20261016).reset_index(drop=True);sel['blind_id']=['B%02d'%(i+1) for i in range(len(sel))]
    sel['used_for_current_calibration']=False;sel['historically_unexposed_certified']=False
    sel.to_csv(out/'next_review_private_manifest.csv',index=False)
    sel[['blind_id','record_id','object_id','image_id','image_code','reference_id','condition','used_for_current_calibration','historically_unexposed_certified']].to_csv(out/'next_review_bindings.csv',index=False)
    audit={'joint_rows':len(d),'unique_records':int(d.record_id.nunique()),'joint_images':int(d.image_id.nunique()),'max_WQ_parity':err,'groups':d.analysis_group.value_counts().to_dict(),'ordinary_fit_n':len(train),'ordinary_fit_images':int(train.image_id.nunique()),'ordinary_fit_buildings':len(builds),'ordinary_frozen_before_doorway_no_fine_tuning':True,'bootstrap_buildings':bootstrap,'formal_eligibility_changed':False,'production_default_changed':False,'full_loader_executed':False,'fusion_frozen_endpoints_complete':int(complete.sum()),'fusion_comparison_endpoints':int(good.sum()),'fusion_comparison_pairs':len(fpair),'new_review_bindings':len(sel),'new_review_full_geometries_available':False}
    dump(out/'empirical_execution.json',audit);print(json.dumps(audit,indent=2))

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',type=pathlib.Path,default=ROOT/'inputs');p.add_argument('--output',type=pathlib.Path,default=ROOT/'results');p.add_argument('--bootstrap',type=int,default=120);a=p.parse_args();run(a.input,a.output,a.bootstrap)
