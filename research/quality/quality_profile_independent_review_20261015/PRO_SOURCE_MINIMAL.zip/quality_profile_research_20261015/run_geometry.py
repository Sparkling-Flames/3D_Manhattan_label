"""Current two-image ledger, tolerance profiles, exact-control and ERP sensitivity study."""
from __future__ import annotations
import sys,json,pathlib,math
import numpy as np,pandas as pd
from scipy.optimize import minimize
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from native_geometry import *
from geometry_candidates import *
from models import score,boundary_score
MODELS=['WQ','T1','T2','T4','MAX','RGP']
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def full(a,ah,g,gh,n=2048,nh=4096):
    I=iou(a,g);Sb=bottom_distance(a,g,n);D=direction(a);Hm,Hc=height_components(a,ah,g,gh,nh)
    v=dict(iou_2d=I,S_bottom_deg=Sb,dir=D,Hmean=Hm,Hcenter=Hc,IoU3D100=100*prism_iou(a,ah,g,gh))
    v.update({m:float(score(I,Sb,D,Hm,Hc,m)) for m in MODELS})
    for t in [.5,1.,2.]:
        z=boundary_coverage(a,g,t,n*2);v.update({f'C{t:g}_{k}':x for k,x in z.items()});v[f'BC{t:g}']=float(boundary_score(I,z['coverage'],Hm,Hc))
    corners=corner_metrics(a,g);v.update({f'corner_{k}':v for k,v in corners.items()})
    c=min(I,v['C1_coverage'],v['corner_angle_f1']);v['BC1_corner_guard']=float(boundary_score(c,c,Hm,Hc))
    return v

def route(a,g,new,code,margin=.1):
    # Endpoint/region attribution, never final-quality or highest-reference selection.
    # Status remains diagnostic pending RGB and policy adjudication.
    ap,gp,np_=polygon(a),polygon(g),polygon(new)
    common=gp.intersection(np_);union=gp.union(np_)
    basic=dict(common_coverage=ap.intersection(common).area/common.area,
      outside_both_fraction=ap.difference(union).area/ap.area,
      original_exclusive_coverage=ap.intersection(gp.difference(np_)).area/gp.difference(np_).area if gp.difference(np_).area>1e-9 else None)
    if code.startswith('B6'):
        # GT branch support only; corridor extent outside both not assigned a third reference.
        branch=gp.difference(np_);share=ap.intersection(branch).area/branch.area
        label='original_branch_compatible' if share>=.8 else ('new_no_branch_compatible' if share<=.2 else 'branch_partly_covered_unresolved')
        basic.update(route_hint=label,branch_coverage=share)
    else:
        # identify the two farthest-z vertices, not the best scoring reference.
        ids=np.argsort(np.asarray(a)[:,1])[-2:];ends=np.asarray(a)[ids,1];near=float(np.max(new[:,1]));far=float(np.max(g[:,1]));mid=(near+far)/2;eps=margin*(far-near)
        side=np.where(ends<mid-eps,0,np.where(ends>mid+eps,1,-1))
        label='new_near_stop_compatible' if np.all(side==0) else ('original_far_stop_compatible' if np.all(side==1) else 'mixed_or_margin_unresolved')
        basic.update(route_hint=label,stop_vertices=ids.tolist(),stop_z=ends.tolist(),margin_fraction=margin)
    basic.update(visual_scope_confirmed=False,selected_scoring_reference=None)
    return basic

def synthetic():
    square=np.array([[-2,-2],[2,-2],[2,2],[-2,2]],float);const=lambda x:np.full(len(x),2.4)
    out=[]
    def add(name,a,g=square,ah=None,gh=None,family='other',amplitude=None):
        out.append(dict(case=name,family=family,amplitude=amplitude,a=np.asarray(a).tolist(),g=np.asarray(g).tolist(),ah=const(a).tolist() if ah is None else np.asarray(ah).tolist(),gh=const(g).tolist() if gh is None else np.asarray(gh).tolist()))
    add('perfect',square)
    for sh in [.005,.01,.025,.05,.1,.2,.4]:
        a=square.copy();a[:,0]+=sh*a[:,1];add(f'shear_{sh}',a,family='shear',amplitude=sh);add(f'nonorthogonal_self_{sh}',a,a,family='self',amplitude=sh)
    for deg in [90,75,60,45,30,15,5,1]:
        th=np.radians(deg);v=np.array([np.cos(th),np.sin(th)])*2
        a=np.array([-np.array([2.,0])-v,np.array([2.,0])-v,np.array([2.,0])+v,-np.array([2.,0])+v]);add(f'rhombus_{deg}',a,family='rhombus',amplitude=deg)
    for w in [.02,.1,.5,1.]:
        g=np.array([[-2,-2],[2,-2],[2,2],[w/2,2],[w/2,4],[-w/2,4],[-w/2,2],[-2,2]])
        add(f'branch_omission_{w}',square,g,family='branch',amplitude=w)
    concave=np.array([[-2,-2],[2,-2],[2,0],[0,0],[0,2],[-2,2]],float)
    add('legal_concave_self',concave,concave,family='self')
    # Cyclic/reversal/collinear representation equivalence, full height interpolation.
    h=np.array([2.16,2.16,2.64,2.64]);refh=const(square)
    for k in [0,1,3,10,100]:
        a=np.vstack([square[0],*[square[0]+j/(k+1)*(square[1]-square[0]) for j in range(1,k+1)],square[1:]])
        ah=np.r_[h[0],np.full(k,h[0]),h[1:]];add(f'subdivision_{k}',a,square,ah,refh,'subdivision',k)
    for ratio in [.2,.5,.8,.9,1,1.1,1.2,1.5,2,4]:add(f'height_{ratio}',square,square,const(square)*ratio,const(square),'height',ratio)
    for rms in [.02,.05,.1,.2]:
        ah=2.4*(1+np.array([-1,1,-1,1])*rms*np.sqrt(3));add(f'local_height_{rms}',square,square,ah,refh,'localheight',rms)
    return out

def run(inp,out):
    out.mkdir(parents=True,exist_ok=True);objs=json.loads((inp/'CURRENT_TWO_IMAGE_MINIMAL_38.json').read_text())['objects'];delta=json.loads((inp/'TWO_IMAGE_SCOPE_DELTA.json').read_text())['records'];refs={r['image_code']:r for r in delta};joint=pd.read_csv(inp/'JOINT_COMPARISON_1145.csv').set_index('record_id')
    ledger=[];floorrows=[];fullrows=[];edges=[];views=[];parity=[];selfs=[];routes=[]
    for o in objs:
        if o['object_kind']!='annotation':continue
        row={k:v for k,v in o.items() if k not in ['points_1024x512']};row.update(new_full_WQ=None,new_full_IoU3D100=None,new_reference_ready=False,new_top_boundary=None,formal_eligibility_changed=False)
        if o['points_1024x512'] is None:
            row.update(execution_status='pairing_unavailable_retained_exclusion');ledger.append(row);continue
        q=erp_triples(o['points_1024x512']);a,ah=project(q);r=refs[o['image_code']]
        g,gh=project(erp_triples(r['original_reference_points_1024x512']));new=np.array(r['new_floor_polygon_xz_h'])
        row['execution_status']='current_geometry_diagnostic_only';row['n_pairs']=len(a);ledger.append(row)
        m=full(a,ah,g,gh);m.update(record_id=o['record_id'],object_id=o['object_id'],condition=o['condition'],cleaning_disposition=o['cleaning_disposition'],reference_id=r['original_reference_object_id'],scope_status='retained_original_reference_counterfactual_not_new_adoption');fullrows.append(m)
        if o['record_id'] in joint.index:
            j=joint.loc[o['record_id']];parity.append(dict(record_id=o['record_id'],**{k:abs(float(m[k])-float(j[k])) for k in ['iou_2d','S_bottom_deg','dir','Hmean','Hcenter','WQ','IoU3D100']}))
        for label,x,rid in [('original',g,r['original_reference_object_id']),('new_floor_only',new,r['new_floor_candidate_id'])]:
            I=iou(a,x);Sb=bottom_distance(a,x);D=direction(a);z=dict(record_id=o['record_id'],object_id=o['object_id'],image_code=o['image_code'],condition=o['condition'],cleaning=o['cleaning_disposition'],reference_kind=label,reference_id=rid,I=I,Sb=Sb,D=D,full_score=None,grade=None)
            # Height-free upper bound, explicitly not a full score.
            z['WQ_full_upper_bound']=float(score(I,Sb,D,0,0));z['reference_new_top_confirmed']=False
            for t in [.5,1.,2.]:z.update({f'coverage_{t:g}_{k}':v for k,v in boundary_coverage(a,x,t).items()})
            c=corner_metrics(a,x);z.update({'corner_'+k:v for k,v in c.items()});floorrows.append(z)
        for margin in [0,.1,.2]:routes.append(dict(record_id=o['record_id'],condition=o['condition'],cleaning=o['cleaning_disposition'],image_code=o['image_code'],**route(a,g,new,o['image_code'],margin)))
        for e in edge_noise_diagnostics(q):edges.append(dict(record_id=o['record_id'],condition=o['condition'],origin='current_two_image',**e))
        ss=full(a,ah,a,ah,n=512,nh=512);selfs.append(dict(record_id=o['record_id'],D=ss['dir'],**{k:ss[k] for k in MODELS+['BC1','BC1_corner_guard']}))
        views.append(dict(record_id=o['record_id'],object_id=o['object_id'],image_id=o['image_id'],image_code=o['image_code'],condition=o['condition'],cleaning=o['cleaning_disposition'],floor=a.tolist(),height=ah.tolist(),triples=q.tolist(),original_floor=g.tolist(),original_height=gh.tolist(),new_floor=new.tolist(),new_height=None,route=route(a,g,new,o['image_code']),qualifications=o['prior_ledger_qualification']))
    archive=json.loads((inp/'targeted_archive_triples.json').read_text())['triples'];ap=[]
    for rid,q in archive.items():
        a,ah=project(q);D=direction(a);ap.append(dict(record_id=rid,D=D,frozen_D=joint.loc[rid,'dir'],D_parity_abs=abs(D-joint.loc[rid,'dir']),current_full_array_verified=False))
        for e in edge_noise_diagnostics(q):edges.append(dict(record_id=rid,condition='manual',origin='archived_ordinary_D_parity_only',**e))
    # Boundary interpolation density convergence on 6 deterministic paired rows.
    convergence=[]
    for v in views[:6]:
        for ref in ['original_floor','new_floor']:
            for tol in [.5,1.,2.]:
                l=boundary_coverage(v['floor'],v[ref],tol,2048);h=boundary_coverage(v['floor'],v[ref],tol,16384)
                convergence.append(dict(record_id=v['record_id'],ref=ref,tolerance_deg=tol,C2048=l['coverage'],C16384=h['coverage'],absolute_difference=abs(l['coverage']-h['coverage'])))
    # Empirical ERP perturbations of existing polygons. Noise scenarios are not observed noise.
    noise=[];rng=np.random.default_rng(1957)
    for rid,q in archive.items():
        q=np.array(q,float);baseline=direction(project(q)[0])
        for sigma in [.5,1.,2.]:
            vals=[];bad=0
            for _ in range(240):
                a=q.copy();a[:,0]+=rng.normal(0,sigma,len(a));a[:,2]+=rng.normal(0,sigma,len(a))
                try:vals.append(direction(project(a)[0]))
                except ValueError:bad+=1
            noise.append(dict(record_id=rid,sigma_ERP_px=sigma,n=240,valid=len(vals),invalid=bad,D_baseline=baseline,D_mean=float(np.mean(vals)),D_q05=float(np.quantile(vals,.05)),D_q95=float(np.quantile(vals,.95)),noise_is_measured=False,independent_endpoint_scenario=True))
    # How much endpoint motion is needed to align N18's dominant edge with its
    # original own-axis family? Solve a local bounded minimax positioning problem.
    # Fixed original axes; all other vertices fixed; no corrected score enters fit.
    q=np.array(archive['R03034']);a,_=project(q);phi,rs,ll,ee=axis_details(a);i=3;j=4
    th=np.degrees(np.arctan2(ee[i,1],ee[i,0]));target=phi+90*round((th-phi)/90);normal=np.array([-np.sin(np.radians(target)),np.cos(np.radians(target))])
    def modified(z):
        qq=q.copy();qq[[i,j],0]+=z[[0,2]];qq[[i,j],2]+=z[[1,3]];return qq
    def residual(z):
        # Project raw endpoints only, avoiding full-polygon validity within solver.
        qq=modified(z);u=(qq[:,0]/1024-.5)*2*np.pi;v=(qq[:,2]/512-.5)*np.pi;r=1/np.tan(v);xx=np.c_[r*np.sin(u),-r*np.cos(u)];return float(normal@(xx[j]-xx[i]))
    candidates=[]
    cons=[{'type':'eq','fun':residual},{'type':'ineq','fun':lambda z:z[4]-z[:4]},{'type':'ineq','fun':lambda z:z[4]+z[:4]}]
    for start in [np.array([0,0,0,0,5.]),np.array([0,-3,0,3,6.]),np.array([-3,0,3,0,6.])]:
        opt=minimize(lambda z:z[4],start,method='SLSQP',bounds=[(-20,20)]*4+[(0,20)],constraints=cons,options={'ftol':1e-11,'maxiter':600})
        try:project(modified(opt.x));valid=True
        except ValueError:valid=False
        candidates.append(dict(success=bool(opt.success),message=str(opt.message),max_coordinate_move_px=float(opt.x[4]),delta_x_y_each_endpoint=opt.x[:4].reshape(2,2).tolist(),alignment_residual_h=residual(opt.x),result_polygon_valid=valid))
    controls=synthetic();ct=[]
    for c in controls:
        m=full(np.array(c['a']),np.array(c['ah']),np.array(c['g']),np.array(c['gh']));m.update({k:c[k] for k in ['case','family','amplitude']});m['camera_below_all_ceiling_vertices']=bool(min(c['ah'])>1 and min(c['gh'])>1);ct.append(m)
    # Exact definitions, not visual adjudication. No fake grade for unavailable top.
    dump(out/'two_image_36_ledger.json',ledger);dump(out/'current_geometry_view_data.json',views);dump(out/'synthetic_geometries.json',controls)
    for name,rows in [('two_image_68_floor_pairs.csv',floorrows),('two_image_34_original_conditional_scores.csv',fullrows),('two_image_28_frozen_parity.csv',parity),('two_image_route_sensitivity.csv',routes),('edge_level_evidence.csv',edges),('geometric_self_scores.csv',selfs),('archived_7_D_parity.csv',ap),('boundary_sampling_convergence.csv',convergence),('ERP_noise_scenarios.csv',noise),('geometric_controls.csv',ct)]:pd.DataFrame(rows).to_csv(out/name,index=False)
    dump(out/'N18_dominant_edge_alignment_counterfactual.json',{'edge':3,'target_own_axis_deg':target,'starts':candidates,'global_minimum_proven':False,'actual_annotation_noise_measured':False,'original_modified':False})
    aud=dict(current_objects=len(objs),current_answers=len(ledger),current_geometric_answers=len(views),current_unusable_answers=len(ledger)-len(views),new_floor_comparisons=len(floorrows),new_full_scores_assigned=0,original_images_read=0,new_legal_scope_adjudications=0,new_top_references=0,full_frozen_comparisons=len(parity),max_frozen_WQ_error=max(x['WQ'] for x in parity),archived_ordinary_D_checks=len(ap),max_archive_D_error=max(x['D_parity_abs'] for x in ap),geometric_control_count=len(ct),boundary_max_sampling_change=max(x['absolute_difference'] for x in convergence),noise_scenario_draws=sum(x['n'] for x in noise))
    dump(out/'geometry_execution.json',aud);print(json.dumps(aud,indent=2))
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',type=pathlib.Path,default=ROOT/'inputs');p.add_argument('--output',type=pathlib.Path,default=ROOT/'results');a=p.parse_args();run(a.input,a.output)
