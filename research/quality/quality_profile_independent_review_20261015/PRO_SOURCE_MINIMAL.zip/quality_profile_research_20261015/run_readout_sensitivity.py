from __future__ import annotations
import sys,json,pathlib
import numpy as np,pandas as pd
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from ordinal import fit,predict,loss_stats
from models import score

def run(out):
 h=pd.read_csv(out/'feedback_44_scores.csv');train=h[h.fit_used].copy();rows=[]
 for rid in [0,.001,.01,.1]:
  for weighting in ['image_equal','row_equal']:
   for scope in ['30_ordinary','28_scope_comment_excluded']:
    t=train if scope=='30_ordinary' else train[~train.card_id.isin(['N08','N20'])]
    w=1/t.groupby('image_id').record_id.transform('size').to_numpy() if weighting=='image_equal' else np.ones(len(t))
    f=fit(t.calc_WQ,t.grade_ordinal,w,ridge=rid)
    rows.append(dict(ridge=rid,weighting=weighting,subset=scope,slope=f['slope'],converged=f['converged'],**{f'cut_{j}':x for j,x in enumerate(f['q_at_cumulative_half'])},**loss_stats(predict(f,t.calc_WQ),t.grade_ordinal)))
 pd.DataFrame(rows).to_csv(out/'readout_prior_weight_scope_sensitivity.csv',index=False)
 model=json.loads((out/'ordinary_frozen_calibration.json').read_text())['WQ'];q=np.arange(101);p=predict(model,q)
 pd.DataFrame({'WQ':q,**{f'p_grade_{j}':p[:,j] for j in range(5)},'median_grade':(np.cumsum(p,axis=1)<.5).sum(axis=1)}).to_csv(out/'readout_table_0_100.csv',index=False)
 # Concrete one-factor response anchors for judging the readout, not realizability claims.
 rows=[]
 for component,values in [('D',[0,1,2,3,5,10]),('I',[1,.95,.9,.8,.5,.1]),('Hm',[0,.1,.2,.5,1,3]),('Hc',[0,.02,.05,.1,.2,.5]),('Sb',[0,1,2,5,10])]:
  for v in values:
   x=dict(I=1.,Sb=0.,D=0.,Hm=0.,Hc=0.);x[component]=v;Q=float(score(**x));pro=predict(model,[Q])[0]
   rows.append(dict(component=component,value=v,Q=Q,grade_projection=int((np.cumsum(pro)<.5).sum()),prob_at_least_good_average=float(pro[3:].sum()),abstract_single_factor_only=True))
 pd.DataFrame(rows).to_csv(out/'readout_response_anchors.csv',index=False)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--output',type=pathlib.Path,default=ROOT/'results');a=p.parse_args();run(a.output)
