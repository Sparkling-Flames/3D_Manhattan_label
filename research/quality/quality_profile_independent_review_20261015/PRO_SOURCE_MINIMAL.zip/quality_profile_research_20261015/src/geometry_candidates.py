"""Reference-relative geometric diagnostics, no modification of input points.
Continuous spherical arc weighting; distances are degrees on unit sphere.
This is not the medical Surface Dice implementation or a 2-D raster Boundary IoU.
"""
from __future__ import annotations
import math
import numpy as np
from native_geometry import polygon,unit,arc_basis,arc_samples,points_to_arcs,angles,project


def floor_ring(x):
    x=np.asarray(x,float);polygon(x)
    return np.c_[x[:,0],-np.ones(len(x)),x[:,1]]


def boundary_coverage(a,g,tolerance_deg=1.,samples=4096):
    if tolerance_deg<=0:raise ValueError('positive spherical tolerance required')
    ar,gr=floor_ring(a),floor_ring(g)
    la,lg=arc_basis(ar)[-1].sum(),arc_basis(gr)[-1].sum()
    da=np.degrees(points_to_arcs(arc_samples(ar,samples),gr))
    dg=np.degrees(points_to_arcs(arc_samples(gr,samples),ar))
    pa,rg=float(np.mean(da<=tolerance_deg)),float(np.mean(dg<=tolerance_deg))
    # Combined arc length, not point count, weight; invariant to exact subdivision.
    return dict(precision=pa,recall=rg,coverage=float((la*pa+lg*rg)/(la+lg)),
                floor_arc_a_rad=float(la),floor_arc_g_rad=float(lg),
                p95_a_deg=float(np.quantile(da,.95)),p95_g_deg=float(np.quantile(dg,.95)))


def canonical_floor(x):
    """Drop strictly collinear intermediate floor points only, in a comparison copy.
    Not a simplification tolerance. Full 3-D height knots are never removed here.
    """
    x=np.asarray(x,float).copy();original=np.arange(len(x));polygon(x)
    changed=True
    while changed and len(x)>3:
        changed=False
        for i in range(len(x)):
            p=x[i]-x[i-1];q=x[(i+1)%len(x)]-x[i]
            denom=np.linalg.norm(p)*np.linalg.norm(q)
            if abs(p[0]*q[1]-p[1]*q[0])<=1e-10*denom and np.dot(p,q)>0:
                x=np.delete(x,i,0);original=np.delete(original,i);changed=True;break
    signed=np.sum(x[:,0]*np.roll(x[:,1],-1)-x[:,1]*np.roll(x[:,0],-1))
    if signed<0:x=x[::-1];original=original[::-1]
    return x,original


def corner_metrics(a,g,position_tolerance_deg=2.,angle_tolerance_deg=10.):
    """Maximum-cardinality, min-position-cost order-preserving cyclic assignment.
    No angle or quality score enters matching. Unmatched vertices reduce P/R;
    their angle residuals remain absent rather than set to zero.
    """
    a,ai=canonical_floor(a);g,gi=canonical_floor(g);n,m=len(a),len(g)
    ua,ug=unit(floor_ring(a)),unit(floor_ring(g))
    dist=np.degrees(np.arctan2(np.linalg.norm(np.cross(ua[:,None,:],ug[None,:,:]),axis=-1),ua@ug.T))
    best=None
    for start in range(m):
        order=np.roll(np.arange(m),-start);d=dist[:,order]
        # entry (n_matched, sum_distance, tuple_of_pairs). Lexicographic objective.
        dp=[[None]*(m+1) for _ in range(n+1)];dp[0][0]=(0,0.,())
        def prefer(u,v):
            return u if v is None or (-u[0],u[1],u[2])<(-v[0],v[1],v[2]) else v
        for i in range(n+1):
            for j in range(m+1):
                s=dp[i][j]
                if s is None:continue
                if i<n:dp[i+1][j]=prefer(s,dp[i+1][j])
                if j<m:dp[i][j+1]=prefer(s,dp[i][j+1])
                if i<n and j<m and d[i,j]<=position_tolerance_deg+1e-12:
                    t=(s[0]+1,s[1]+float(d[i,j]),s[2]+((i,int(order[j])),))
                    dp[i+1][j+1]=prefer(t,dp[i+1][j+1])
        s=dp[n][m];best=prefer(s,best)
    pairs=best[2];aa,ag=angles(a),angles(g)
    residual=[abs(float(aa[i]-ag[j])) for i,j in pairs]
    good=sum(x<=angle_tolerance_deg for x in residual);k=len(pairs)
    return dict(corners_a=n,corners_g=m,matched=k,position_precision=k/n,position_recall=k/m,
                position_f1=2*k/(n+m),angle_pass_count=good,angle_precision=good/n,angle_recall=good/m,
                angle_f1=2*good/(n+m),matched_angle_rms_deg=float(np.sqrt(np.mean(np.square(residual)))) if k else None,
                matched_angle_max_deg=max(residual) if k else None,
                pairs_original=[[int(ai[i]),int(gi[j])] for i,j in pairs],
                angle_residuals_deg=residual,unmatched_a=[int(ai[i]) for i in range(n) if i not in [p[0] for p in pairs]],
                unmatched_g=[int(gi[j]) for j in range(m) if j not in [p[1] for p in pairs]])


def axis_details(x):
    x=np.asarray(x,float);polygon(x);e=np.roll(x,-1,axis=0)-x;l=np.linalg.norm(e,axis=1)
    th=np.degrees(np.arctan2(e[:,1],e[:,0]));br=np.unique(np.r_[0.,90.,(th+45)%90]);sol=[]
    for lo,hi in zip(br[:-1],br[1:]):
        mid=(lo+hi)/2;r=(th-mid+45)%90-45
        p=float(np.clip(mid+np.average(r,weights=l),lo,hi))
        for p in [p,float(lo),float(hi)]:
            resid=(th-p+45)%90-45;sol.append((float(np.average(resid**2,weights=l)),p,resid))
    loss,phi,resid=min(sol,key=lambda s:(s[0],s[1]))
    return phi,resid,l,e


def edge_noise_diagnostics(triples,sigma_px=1.):
    """First-order independent isotropic ERP x/y noise scenario, not measured noise.
    Sigma in continuous 1024x512 ERP pixels. Shared endpoints produce covariance;
    axis-fixed individual variances are reported, not treated as independent D.
    """
    q=np.asarray(triples,float);x,_=project(q);phi,r,l,e=axis_details(x)
    u=(q[:,0]/1024-.5)*2*np.pi;v=(q[:,2]/512-.5)*np.pi;rho=1/np.tan(v);k=np.pi/512
    J=np.zeros((len(x),2,2))
    J[:,0,0]=k*rho*np.cos(u);J[:,1,0]=k*rho*np.sin(u)
    dr=-k/(np.sin(v)**2)
    J[:,0,1]=dr*np.sin(u);J[:,1,1]=-dr*np.cos(u)
    cov=J@J.transpose(0,2,1)*sigma_px**2;n=np.c_[-e[:,1],e[:,0]]/l[:,None]
    var=np.einsum('ni,nij,nj->n',n,cov+np.roll(cov,-1,axis=0),n)/(l*l)
    sd=np.degrees(np.sqrt(var));parts=l*r*r/l.sum()
    return [dict(edge=i,next_vertex=(i+1)%len(x),length_h=float(l[i]),length_share=float(l[i]/l.sum()),
      residual_deg=float(r[i]),D2_contribution=float(parts[i]),D2_share=float(parts[i]/parts.sum()) if parts.sum()>1e-14 else 0.,
      endpoint_x_px=float(q[i,0]),endpoint_bottom_y_px=float(q[i,2]),
      next_x_px=float(q[(i+1)%len(x),0]),next_bottom_y_px=float(q[(i+1)%len(x),2]),
      sigma_angle_deg_per_1px=float(sd[i]),linearization_reliable=bool(sd[i]<15),
      min_horizon_distance_px=float(min(q[i,2],q[(i+1)%len(x),2])-256)) for i in range(len(x))]
