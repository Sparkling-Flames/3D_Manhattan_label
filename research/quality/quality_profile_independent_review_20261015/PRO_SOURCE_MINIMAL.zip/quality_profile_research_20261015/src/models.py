"""Small frozen research challenges. No changes to production WQ defaults."""
from __future__ import annotations
import numpy as np


def terms(I,Sb,D,Hm,Hc):
    values=np.broadcast_arrays(*[np.asarray(x,float) for x in [I,Sb,D,Hm,Hc]])
    I,Sb,D,Hm,Hc=values
    if not all(np.isfinite(x).all() for x in values):raise ValueError('missing/nonfinite components: full score unavailable')
    if np.any((I < -1e-12)|(I > 1+1e-12)) or any(np.any(x<0) for x in [Sb,D,Hm,Hc]):raise ValueError('components out of range')
    return Sb**2/32,1.5*D**2/(D**2+37.5),(Hm/.8)**2,(Hc/.25)**2


def score(I,Sb,D,Hm,Hc,model='WQ'):
    B,d,G,L=terms(I,Sb,D,Hm,Hc);I=np.clip(np.asarray(I,float),0.,1.)
    if model=='WQ':return 100*I/(1+I*(B+d+G+L))
    if model.startswith('T'):
        eps=float(model[1:]);e=np.maximum(np.asarray(D)-eps,0.);de=1.5*e*e/(e*e+37.5)
        return 100*I/(1+I*(B+de+G+L))
    if model=='MAX':
        # Equivalent reciprocal max(O,B,d) without division at I=0.
        return 100*I/(I+np.maximum.reduce([1-I,I*B,I*d])+I*(G+L))
    if model=='RGP':
        return 100*I/(I+np.maximum(1-I,I*B)+I*(G+L))
    raise ValueError(model)


def boundary_score(I,coverage,Hm,Hc):
    terms(I,0.,0.,Hm,Hc)
    coverage=np.asarray(coverage,float)
    if not np.isfinite(coverage).all() or np.any((coverage < -1e-12)|(coverage > 1+1e-12)):
        raise ValueError('coverage missing or out of range')
    c=np.minimum(np.clip(I,0.,1.),np.clip(coverage,0.,1.))
    return 100*c/(1+c*((np.asarray(Hm)/.8)**2+(np.asarray(Hc)/.25)**2))
