"""Positive-slope proportional-odds calibration to 5 ordered categories.
No equally spaced category targets are fitted. Not universal quality probabilities.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit

def fit(scores,grades,weights=None,ridge=0.01):
    x=np.asarray(scores,float)/100;y=np.asarray(grades,int)
    if len(x)<5 or not np.isfinite(x).all() or not set(y)<=set(range(5)):raise ValueError('bad ordinal training set')
    w=np.ones(len(y)) if weights is None else np.asarray(weights,float)
    # Threshold initialization from category proportions. Missing categories allowed,
    # but a missing category cannot acquire empirical evidence from this safeguard.
    cum=np.clip([(np.sum(w[y<=j])+.2)/(np.sum(w)+.4) for j in range(4)],.005,.995)
    t=np.log(cum/(1-cum))+8*np.average(x,weights=w);t=np.maximum.accumulate(t+np.arange(4)*.001)
    init=np.r_[8.,t[0],np.log(np.maximum(np.diff(t),.05))]
    def unpack(p):return p[0],np.r_[p[1],p[1]+np.cumsum(np.exp(p[2:]))]
    def loss(p):
        b,t=unpack(p);cdf=expit(t[None,:]-b*x[:,None]);prob=np.diff(np.c_[np.zeros(len(x)),cdf,np.ones(len(x))],axis=1)
        return -np.sum(w*np.log(np.maximum(prob[np.arange(len(y)),y],1e-14)))+ridge*b*b/2
    res=minimize(loss,init,method='L-BFGS-B',bounds=[(1e-5,100),(-100,100)]+[(-9,5)]*3,options={'maxiter':700,'ftol':1e-11})
    b,t=unpack(res.x)
    return {'slope':float(b),'thresholds':t.tolist(),'q_at_cumulative_half':(100*t/b).tolist(),'ridge':ridge,'converged':bool(res.success),'objective':float(res.fun),'n':len(y),'class_counts':np.bincount(y,minlength=5).tolist()}

def predict(model,scores):
    x=np.asarray(scores,float)/100;t=np.asarray(model['thresholds']);b=model['slope']
    cdf=expit(t[None,:]-b*x[:,None])
    return np.diff(np.c_[np.zeros(len(x)),cdf,np.ones(len(x))],axis=1)

def median_grade(model,scores):
    p=predict(model,scores);return (np.cumsum(p,axis=1)<.5).sum(axis=1)

def loss_stats(probs,y):
    y=np.asarray(y,int);pred=(np.cumsum(probs,axis=1)<.5).sum(axis=1)
    # Category-gap stats descriptive only; not fitting equal-distance numerical labels.
    return dict(n=len(y),exact=int(np.sum(pred==y)),within_one=int(np.sum(abs(pred-y)<=1)),
      gap_ge_two=int(np.sum(abs(pred-y)>=2)),nll=float(-np.mean(np.log(np.maximum(probs[np.arange(len(y)),y],1e-14)))),
      ordered_brier=float(np.mean((np.cumsum(probs,axis=1)[:,:4]-(y[:,None]<=np.arange(4)))**2)))
