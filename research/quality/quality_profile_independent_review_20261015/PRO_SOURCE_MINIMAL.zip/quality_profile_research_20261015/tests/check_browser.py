"""Actual headless Chromium UI checks. No original photograph was available."""
import json,pathlib
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1200,'height':900},accept_downloads=True);errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
 page.set_content((ROOT/'review/TWO_IMAGE_REVIEW.html').read_text(encoding='utf-8'));page.wait_for_timeout(200)
 assert page.locator('#choice option').count()==36
 initial=page.evaluate('JSON.stringify(payload.cards)')
 page.locator('#grade').select_option('cannot_judge');page.locator('#comment').fill('TEST ONLY — no original photo');page.locator('#save').click()
 assert page.evaluate('Object.values(responses)[0].photo_seen')==False
 page.locator('#bev').click();page.locator('#next').click();page.locator('#prev').click()
 assert page.locator('#grade').input_value()=='cannot_judge'
 assert initial==page.evaluate('JSON.stringify(payload.cards)')
 with page.expect_download() as dl:page.locator('#export').click()
 data=json.loads(pathlib.Path(dl.value.path()).read_text());assert all(not r['photo_seen'] for r in data['decisions'])
 assert data['no_scores_or_model_identity_shown']
 page.locator('#choice').select_option('0');page.screenshot(path=str(ROOT/'tests/review_browser_check.png'),full_page=True)
 page.set_content((ROOT/'review/READOUT.html').read_text(encoding='utf-8'));page.locator('#q').fill('70');page.locator('#go').click();assert '较好与一般之间' in page.locator('#median').inner_text()
 page.locator('#q').fill('20');page.locator('#go').click();assert '低分端' in page.locator('#warning').inner_text()
 page.close();page=b.new_page();page.on('pageerror',lambda err:errors.append(str(err)));page.set_content((ROOT/'review/N18_POSITION_EVIDENCE.html').read_text(encoding='utf-8'));assert page.locator('#choice option').count()==7
 assert not errors,errors
 b.close()
 (ROOT/'tests/BROWSER_CHECK.json').write_text(json.dumps({'headless_chromium_executed':True,'36_scope_cards':True,'same_page_navigation_and_save':True,'local_file_navigation':'blocked_by_environment_policy; DOM/content injection used','persistent_localStorage_not_tested':True,'unknown_image_not_marked_seen':True,'receipt_export_checked':True,'geometry_unchanged':True,'readout_page_checked':True,'7_ordinary_mechanism_cards':True,'errors':errors,'original_photo_interaction_not_tested':True},indent=2),encoding='utf-8')
 print('Chromium UI checks passed; no real photo or live hydration tested.')
