from pathlib import Path
import sys,json,itertools,os
import numpy as np,pandas as pd,pytest
ROOT=Path(__file__).resolve().parents[1];RESULTS=Path(os.environ.get('QUALITY_RESULTS_DIR',str(ROOT/'results')));sys.path.insert(0,str(ROOT/'src'))
from models import score,boundary_score
from native_geometry import *
from geometry_candidates import *
from ordinal import predict,median_grade
square=np.array([[-2,-2],[2,-2],[2,2],[-2,2]],float)
@pytest.mark.parametrize('model',['WQ','T1','T2','T4','MAX','RGP'])
def test_perfect_zero_monotone(model):
 assert score(1,0,0,0,0,model)==100
 assert score(0,4,10,.1,.2,model)==0
 for key in range(5):
  x=[np.ones(100)*.8,np.ones(100)*2,np.ones(100)*3,np.ones(100)*.05,np.ones(100)*.08]
  x[key]=np.linspace(0,1 if key in [0,3,4] else 40,100)
  diff=np.diff(score(*x,model));assert np.all(diff>=-1e-10) if key==0 else np.all(diff<=1e-10)
@pytest.mark.parametrize('model',['WQ','T1','T2','T4','MAX','RGP'])
def test_missing_and_roundoff(model):
 with pytest.raises(ValueError):score(.9,1,np.nan,.1,.1,model)
 with pytest.raises(ValueError):score(1.2,1,2,.1,.1,model)
 assert score(1+2e-16,0,0,0,0,model)<=100
 assert 0<=score(.8,3,5,.1,.1,model)<=100

def test_direction_steepest():
 d=np.sqrt(5);step=1e-5
 derivative=(score(1,0,d+step,0,0)-score(1,0,d-step,0,0))/(2*step)
 assert abs(derivative+10.0623059)<1e-6

def test_max_masks_lesser_error():
 assert score(.5,0,0,0,0,'MAX')==score(.5,1,0,0,0,'MAX')
 assert score(.5,0,0,0,0,'WQ')>score(.5,1,0,0,0,'WQ')

def test_no_constant_height_budget():
 for model in ['WQ','T2','MAX','RGP']:assert score(1,0,0,20,0,model)<.2
 assert boundary_score(1,1,20,0)<.2
 with pytest.raises(ValueError):boundary_score(1,np.nan,0,0)

def test_native_top_missing_not_zero():
 ledger=json.loads((RESULTS/'two_image_36_ledger.json').read_text())
 assert len(ledger)==36
 assert sum(r['execution_status']=='current_geometry_diagnostic_only' for r in ledger)==34
 assert all(r['new_full_WQ'] is None and r['new_top_boundary'] is None for r in ledger)
 assert sum(r['condition']=='semi' for r in ledger)==4
 assert sum(r['cleaning_disposition']!='retained' for r in ledger)==4

def test_source_fields_unchanged():
 a=pd.read_csv(ROOT/'inputs/JOINT_COMPARISON_1145.csv');b=pd.read_csv(RESULTS/'same_binding_1145_scores.csv')
 pd.testing.assert_frame_equal(a,b[a.columns],check_dtype=False,check_exact=False,atol=1e-12,rtol=1e-12)
 assert len(a)==1145 and b.record_id.is_unique
 assert b[b.analysis_group!='ordinary_manual_conditional'].provisional_grade_WQ.isna().all()
 assert b[b.analysis_group=='ordinary_manual_conditional'].shape[0]==931

def test_current_parity():
 p=pd.read_csv(RESULTS/'two_image_28_frozen_parity.csv');assert len(p)==28
 assert p.select_dtypes('number').max().max()<1e-8

def test_near_reference_self_identity():
 x=square.copy();x[:,0]+=.1*x[:,1]
 assert iou(x,x)==1 and bottom_distance(x,x)<1e-10
 assert score(1,0,direction(x),0,0,'WQ')<80
 c=boundary_coverage(x,x);assert c['coverage']==1
 assert boundary_score(1,c['coverage'],0,0)==100
 assert corner_metrics(x,x)['angle_f1']==1

def test_concave_and_collinear():
 x=np.array([[-2,-2],[2,-2],[2,0],[0,0],[0,2],[-2,2]],float)
 assert 270 in angles(x);assert corner_metrics(x,x)['angle_f1']==1
 y=np.insert(square,1,(square[0]+square[1])/2,axis=0)
 assert len(canonical_floor(y)[0])==4
 assert corner_metrics(y,square)['corners_a']==4
 assert boundary_coverage(y,square)['coverage']==1
 z=y.copy();z[1,1]+=.001;assert len(canonical_floor(z)[0])==5

def test_representation_permutation():
 x=np.array([[-2,-2],[2,-2],[2,0],[0,0],[0,2],[-2,2]],float)
 for k in range(len(x)):
  for sign in [1,-1]:
   y=np.roll(x,k,axis=0)[::sign];c=corner_metrics(y,x)
   assert c['angle_f1']==1 and c['matched_angle_rms_deg']<1e-9

def test_unmatched_not_zero_angles():
 far=square*.2;c=corner_metrics(far,square,position_tolerance_deg=.01)
 assert c['matched']==0 and c['matched_angle_rms_deg'] is None and c['angle_recall']==0

def test_branch_diagnostic_not_total_guarantee():
 g=pd.read_csv(RESULTS/'geometric_controls.csv').set_index('case');r=g.loc['branch_omission_0.1']
 assert r.WQ>98 and r.BC1>95 and r.corner_position_f1<.7
 assert g.loc['shear_0.1','BC1_corner_guard']==0

def test_collinear_height_prism_problem():
 d=pd.read_csv(RESULTS/'geometric_controls.csv');d=d[d.family=='subdivision']
 assert d.WQ.max()-d.WQ.min()<1e-9
 assert d.BC1.max()-d.BC1.min()<1e-9
 assert d.IoU3D100.max()-d.IoU3D100.min()>9

def test_axis_folding():
 d=pd.read_csv(RESULTS/'geometric_controls.csv').set_index('case')
 assert d.loc['rhombus_5','dir']<d.loc['rhombus_45','dir']
 assert d.loc['rhombus_5','WQ']<d.loc['rhombus_45','WQ']

def test_projection_jacobian():
 q=np.array(json.loads((ROOT/'inputs/targeted_archive_triples.json').read_text())['triples']['R03034'])
 edges=edge_noise_diagnostics(q);step=1e-5
 def heading(t,i):
  x,_=project(t);e=x[(i+1)%len(x)]-x[i];return np.degrees(np.arctan2(e[1],e[0]))
 for i in range(len(q)):
  grad=[]
  for vertex in [i,(i+1)%len(q)]:
   for axis in [0,2]:
    plus=q.copy();minus=q.copy();plus[vertex,axis]+=step;minus[vertex,axis]-=step
    dd=(heading(plus,i)-heading(minus,i)+180)%360-180;grad.append(dd/(2*step))
  assert abs(np.linalg.norm(grad)-edges[i]['sigma_angle_deg_per_1px'])<1e-5

def test_edge_contributions_and_N18():
 d=pd.read_csv(RESULTS/'edge_level_evidence.csv');a=pd.read_csv(RESULTS/'archived_7_D_parity.csv').set_index('record_id')
 for rid in a.index:
  g=d[d.record_id==rid];assert abs(g.D2_contribution.sum()-a.loc[rid,'D']**2)<1e-8
 n=d[d.record_id=='R03034'].set_index('edge');assert n.loc[3,'D2_share']>.84 and n.loc[4,'D2_share']<.005

def test_ordinal_order_probability():
 f=json.loads((RESULTS/'ordinary_frozen_calibration.json').read_text())['WQ'];p=predict(f,np.arange(101))
 assert np.all(p>=0) and np.max(abs(p.sum(axis=1)-1))<1e-12
 assert f['slope']>0 and np.all(np.diff(f['thresholds'])>0)
 assert np.all(np.diff(p[:,3:].sum(axis=1))>0)
 assert np.all(np.diff(median_grade(f,np.arange(101)))>=0)
 assert f['class_counts']==[1,2,12,10,5]

def test_fit_domain_and_review_independence():
 h=pd.read_csv(RESULTS/'feedback_44_scores.csv');s=pd.read_csv(RESULTS/'next_review_private_manifest.csv')
 assert len(h[h.fit_used])==30 and not h[h.fit_used].card_id.isin(['N05','N28']).any()
 assert set(s.image_id).isdisjoint(h.image_id) and len(s)==20 and s.image_id.is_unique
 assert not s.used_for_current_calibration.any() and not s.historically_unexposed_certified.any()

def test_downstream_monotone_mean_not_preserved():
 w=pd.read_csv(RESULTS/'worker_sensitivity.csv').set_index('metric')
 assert w.loc['p_at_least_good_average_WQ','spearman']<1
 assert w.loc['p_at_least_good_average_WQ','max_rank_change']>0

def test_only_geometry_diagnostics_when_reference_pending():
 p=pd.read_csv(RESULTS/'two_image_68_floor_pairs.csv');assert len(p)==68
 assert p.full_score.isna().all() and p.grade.isna().all()
 assert not p.reference_new_top_confirmed.any()

def test_reference_match_independent_of_height():
 a=square+.01;g=square
 c=corner_metrics(a,g);assert c['position_f1']==1
 # Floor matching API has no height or total-score input at all.
 assert set(c['pairs_original'][0])<=set(range(4))
