全景布局质量完整研究轻量交付
2026年10月9日

本次交付是两份普通ZIP，无需合并分片
01_完整研究数值核心_20261009.zip：当前4页报告、全部当前审计、全259图/3152记录结果、脚本与完整数值复现必需输入。
02_完整研究证据图册_20261009.zip：9张代表多人三维卡＋17张全源标注总览。
将两份ZIP解压到同一父目录，都会进入quality_research_20261009文件夹；图册只添加图像文件，不覆盖数值核心。只解压核心也能独立完成数值复算。

先读当前综合审查.pdf或同名TXT，再看scope_scan/中文量化报告.txt及visual_review/视觉核验说明.txt。
当前结论与原完整包一致：规整性仍扣总分；GT仍是当前唯一固定参考；争议交用户决定。当前清洗加wc2JMjhGNzB-14暂停视图2930＝2898Q＋32NA；3152全库存原结果保留。没有改点、改GT、改分或新选参数。

为什么能缩小
原310MB包重复嵌入165MB原结果包和23MB原资料ZIP，内含旧大图册、全分辨率原图、重复联表及再次复制的历史复跑目录。
本核心直接保留解包后的数值输入：冻结合同42项全部原字节不变，全部3152原CSV/JSON、旧36和38控制、完整当前审计和新研究表、必要snapshot源数据俱全。
删除的仅为全分辨率照片/旧重复图册、重复展示联表与复跑副本、可由已保留几何和脚本重画的PNG/网格缓存。每项范围与来源哈希有清单，不冒称保留全部原归档。

数值复算不依赖310MB文件
在quality_research_20261009文件夹执行：
python -B reproduce/verify_package.py
python -m pip install -r reproduce/requirements.txt
python -B reproduce/run_all.py --work-dir ../quality_reproduction_new --jobs 4

需要Python 3.12及所列依赖。输出目录必须是本包之外的新/空目录。入口直接读取inputs/baseline与inputs/snapshot，不下载、不索取原310MB包，不需要照片。完整数值脚本仍可重复3152＋38冻结回放、独立公式、3441对象绑定、NA/资格及本轮全图检索。
打包验证只确认上述数值入口和已知结果一致，不重新选择研究方法或重作人工裁决。
更多分步命令见reproduce/复算说明.txt。

影像范围清楚分开
配套图册完整保留26张本轮正式证据卡。44张全分辨率案例原图、旧217卡和旧图册未放入这两份ZIP；全分辨率原图来源见ORIGINAL_PHOTO_SCOPE.csv，它们仍在Library的“全景布局质量_完整审计与共同范围研究_20261009.zip”及原三个图片源包中。
GT追溯的坐标、历史来源与结论保留在gt_trace；此前GT原图双版本的大图在保真归档。数值复算无需这些图片。重画精确全景投影照片卡才需另备相应原图，不能把“能重算数值”说成“不用照片也能重建照片”。
图册不把全部源记录当有效支持人数；manual/oos、semi、排除和暂停按表中口径读取。

追溯与验证
原保真ZIP：310,265,301字节。
SHA256：ab797035c3830737a3c7cca184f066aff2c746507c0a46645ee705576b04c34f
原归档保留未动。ARCHIVE_MEMBER_SHA256.json保留原两嵌套包986成员的来源校验。
inputs/baseline/LIGHTWEIGHT_SCOPE.json列原baseline保留与省略项目；LIGHTWEIGHT_DELIVERY_SCOPE.json说明本次影像/缓存/重复项范围。
本核心的MANIFEST_SHA256.json只要求本次实际保留文件；配套图册有ATLAS_MANIFEST_SHA256.json。原baseline MANIFEST是历史完整清单，不能拿它要求轻量版也附旧图片；全部42项数值合同仍严格验证。
这两份ZIP使用通用Deflate压缩，不是LZMA，不是需拼接的分片。此前分片合并说明不适用于本次交付。

inputs内原README及历史脚本保留作来源材料，实际运行以本层README和reproduce入口为准；旧机器路径不作为本次运行依赖。
