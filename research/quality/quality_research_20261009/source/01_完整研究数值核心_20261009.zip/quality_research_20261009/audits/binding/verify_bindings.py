#!/usr/bin/env python3
"""Independent input/binding audit. Never imports package scoring or audit code.
Rebuilds periodic pair x, source index views, ERP projection, inverse projection,
polygon validity, source-derived NA causes, fixed reference selection and groups.
Published results/tables are comparison targets only. Does not recompute Q.
"""
import argparse, collections, csv, hashlib, json, math
from fractions import Fraction
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def write_csv(path, data):
    if not data:
        path.write_text('', encoding='utf-8')
        return
    keys=list(dict.fromkeys(k for d in data for k in d))
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w=csv.DictWriter(f,keys); w.writeheader()
        for d in data:
            w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in d.items()})


def delta(a,b):
    if a is None or b is None:
        return 0.0 if a==b else math.inf
    if len(a)!=len(b):return math.inf
    return max((abs(x-y) for aa,bb in zip(a,b) for x,y in zip(aa,bb)),default=0.0)


def orient(a,b,c):
    x=(b[0]-a[0])*(c[1]-a[1]);y=(b[1]-a[1])*(c[0]-a[0]);d=x-y
    if abs(d)>32*math.ulp(1.0)*(abs(x)+abs(y)):
        return (d>0)-(d<0)
    a,b,c=([Fraction(v) for v in p] for p in (a,b,c))
    d=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    return (d>0)-(d<0)


def on_segment(p,a,b):
    return orient(a,b,p)==0 and all(min(a[k],b[k])<=p[k]<=max(a[k],b[k]) for k in [0,1])


def geometry_errors(top,bottom):
    """Independent necessary geometry and spherical-boundary checks for this set."""
    if top is None or bottom is None:return ['no_projection']
    n=len(bottom)
    if n<3:return ['too_few_pairs']
    errors=[]
    if len(top)!=n:return ['top_bottom_size_mismatch']
    if not all(math.isfinite(v) for ring in [top,bottom] for pt in ring for v in pt):return ['nonfinite_3d']
    scale=max(1.0,max(abs(v) for ring in [top,bottom] for pt in ring for v in pt));tol=64*math.ulp(1.0)*scale
    if any(abs(b[1]+1)>tol for b in bottom):errors.append('nonhorizontal_floor')
    if any(math.dist((t[0],t[2]),(b[0],b[2]))>tol for t,b in zip(top,bottom)):errors.append('nonvertical_pairs')
    if any(t[1]-b[1]<=64*math.ulp(1.0)*max(1,abs(t[1]),abs(b[1])) for t,b in zip(top,bottom)):errors.append('nonpositive_wall_height')
    p=[(b[0],b[2]) for b in bottom]
    es=[(p[i],p[(i+1)%n]) for i in range(n)]
    if any(math.dist(a,b)<=tol for a,b in es):errors.append('zero_or_unresolved_edge')
    for i,(a,b) in enumerate(es):
        for j in range(i+1,n):
            c,d=es[j];adj=(j==i+1 or (i==0 and j==n-1))
            signs=[orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)]
            if signs==[0,0,0,0]:
                k=max(range(2),key=lambda k:abs(a[k]-b[k]))
                lo=max(min(a[k],b[k]),min(c[k],d[k]));hi=min(max(a[k],b[k]),max(c[k],d[k]))
                if hi>lo:errors.append('overlapping_edges')
                elif hi==lo and not adj:errors.append('nonadjacent_contact')
            elif not adj and ((signs[0]*signs[1]<0 and signs[2]*signs[3]<0) or any(on_segment(pt,u,v) for pt,u,v in [(a,c,d),(b,c,d),(c,a,b),(d,a,b)])):
                errors.append('nonadjacent_intersection')
    rel=[(v[0]-p[0][0],v[1]-p[0][1]) for v in p]
    products=[(a[0]*b[1],a[1]*b[0]) for a,b in zip(rel,rel[1:]+rel[:1])]
    area=math.fsum(a-b for a,b in products)/2
    area_tol=64*math.ulp(1.0)*max(1,math.fsum(abs(a)+abs(b) for a,b in products))/2
    if abs(area)<=area_tol:errors.append('zero_or_unresolved_area')
    for ring in [top,bottom]:
        unit=[[v/math.sqrt(sum(x*x for x in pt)) for v in pt] for pt in ring]
        for a,b in zip(unit,unit[1:]+unit[:1]):
            cross=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
            angle=math.atan2(math.sqrt(sum(x*x for x in cross)),sum(x*y for x,y in zip(a,b)))
            if angle<=1e-12 or math.pi-angle<=1e-10:errors.append('spherical_edge_domain')
    return sorted(set(errors))


def project(points):
    if points is None:return None,None,'no_final_points'
    if len(points)%2 or not all(isinstance(p,list) and len(p)==2 for p in points):return None,None,'malformed_final_points'
    if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for p in points for v in p):return None,None,'nonnumeric_final_points'
    if any(not(0<=x<=1024 and 0<=y<=512) for x,y in points):return None,None,'annotation_input_domain_invalid'
    bottom=[];top=[]
    for (xt,yt),(xb,yb) in zip(points[::2],points[1::2]):
        if not(256<yb<512 and 0<yt<512):return None,None,'projection_model_not_applicable'
        # Derivation with colatitude: ground horizontal radius is tan(pi-yb*pi/512).
        radius=-1/math.tan((0.5-yb/512)*math.pi)
        tb=2*math.pi*xb/1024;tt=2*math.pi*xt/1024
        bottom.append([-radius*math.sin(tb),-1.0,radius*math.cos(tb)])
        top.append([-radius*math.sin(tt),radius*math.tan((0.5-yt/512)*math.pi),radius*math.cos(tt)])
    return top,bottom,None


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]/'source/quality_v1_1_expanded_repro_20261009');ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);args=ap.parse_args()
    p=args.root.resolve();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    g=read(p/'prepared/frozen_expanded_geometry.json');ims=g['images'];objects=[(im,a) for im in ims for a in im['annotations']+im['groundtruths']]
    old=read(p/'historical_inputs/inputs/frozen_geometry.json')['images'];oldmap={a['id']:a for im in old for a in im['annotations']+im['groundtruths']}
    oldratings=read(p/'historical_inputs/inputs/review36_user_20261008.json')['ratings'];oldbindings={(x['imageCode'],x['recordId']):(x['referenceId'],x['referenceVersion']) for x in oldratings}
    oldcodes={im['code'] for im in old};dev={im['building'] for im in old}
    parameters=read(p/'frozen_engine/frozen_parameters.json');manifest=read(p/'source_package_documentation/image_manifest.json');mm={x['image_code']:x for x in manifest}
    result=read(p/'results_fixed/all_records_results.json');rm={a['record_id']:a for a in result}
    bm={a['record_id']:a for a in rows(p/'prepared/reference_bindings_before_scores.csv')}
    gm={a['image_code']:a for a in rows(p/'prepared/image_groups_before_scores.csv')}
    reg={a['id']:a for a in rows(p/'inventory/record_group_registry.csv')}
    image_reg={a['image_code']:a for a in rows(p/'inventory/image_group_registry.csv')}
    building_reg={a['building']:a for a in rows(p/'inventory/building_group_registry.csv')}
    path_reg={a['image_code']:a for a in rows(p/'inventory/image_code_to_path.csv')}
    policies={a['image_code']:a for a in read(p/'prepared/reference_policies_before_scores.json')}
    checks=collections.Counter();errors=[];object_rows=[];na_rows=[];binding_rows=[];group_rows=[];hold_rows=[];origin_changes=[];recomputed={}
    def check(ok,code,**details):
        checks[code]+=1
        if not ok:errors.append({'check':code,**details})
    def eq(a,b,code,**details):check(a==b,code,actual=a,expected=b,**details)
    check(dev==set(parameters['development_buildings']),'development_buildings_match_old_input')
    for key,vals in [('object_id',[a['id'] for _,a in objects]),('canonical_id',[a['source_record']['canonical_object_id'] for _,a in objects]),('image_code',[im['code'] for im in ims]),('image_id',[im['imageId'] for im in ims])]:
        eq(len(vals),len(set(vals)),'unique_'+key)
    eq(set(rm),{a['id'] for im in ims for a in im['annotations']},'results_preserve_all_annotation_ids')
    eq(set(bm),set(rm),'bindings_preserve_all_annotation_ids');eq(set(reg),set(rm),'registry_preserve_all_annotation_ids')
    for im,a in objects:
        s=a['source_record'];rid=a['id'];context={'record_id':rid}
        for ak,sk in [('id','id'),('version','version'),('points','points_1024x512'),('preprocessing','preprocessing'),('sourcePointIndices','ordered_source_point_indices'),('sourcePairIndices','ordered_source_pair_indices'),('sourceExistingRingConnections','existing_ring_connections')]:eq(a.get(ak),s.get(sk),'source_to_prepared_'+ak,**context)
        for sk,val in [('image_code',im['code']),('image_id',im['imageId']),('building',im['building']),('room',im.get('room') or '')]:eq(s[sk] or '',val or '','source_identity_'+sk,**context)
        raw=s['original_export_points'] or [];bef=s['before_preprocessing_points'] or [];pre=s['preprocessed_points'];oi=s['original_export_indices'];final=s['points_1024x512'];links=s['links_zero_based'] or []
        eq(len(bef),len(oi),'original_index_length',**context)
        for i,j in enumerate(oi):
            if j is not None:check(0<=j<len(raw) and bef[i]==raw[j],'retained_original_coordinate_exact',record_id=rid,effective_index=i,original_index=j)
        removed=sorted(set(range(len(raw)))-{j for j in oi if j is not None});added=[i for i,j in enumerate(oi) if j is None]
        if raw!=bef:origin_changes.append({'record_id':rid,'image_code':im['code'],'raw_count':len(raw),'effective_count':len(bef),'removed_original_indices':removed,'added_effective_indices':added,'has_final':final is not None,'repair_evidence':s.get('repair_evidence'),'notes':s.get('initialization_notes'),'deleted_previous_point_indices':s.get('deleted_previous_point_indices')})
        pre_delta=None
        if pre is not None:
            calc=[pt.copy() for pt in bef]
            for l,r in links:
                mu=(bef[l][0]+((bef[r][0]-bef[l][0]+512)%1024-512)/2)%1024
                calc[l][0]=mu;calc[r][0]=mu
            pre_delta=delta(calc,pre);check(pre_delta==0,'periodic_shared_x_recomputed_exact',record_id=rid,max_difference=pre_delta)
        if final is not None:
            spi=s['ordered_source_point_indices'];spair=s['ordered_source_pair_indices'];n=len(final)//2
            eq([v for i in spair for v in links[i]],spi,'source_pairs_to_source_points',**context)
            eq([pre[i] for i in spi],final,'source_points_to_final',**context)
            eq(sorted(spi),list(range(len(pre))),'final_points_are_permutation',**context)
            eq(sorted(spair),list(range(len(links))),'final_pairs_are_permutation',**context)
            ec={'top_edges':[[2*i,2*((i+1)%n)] for i in range(n)],'bottom_edges':[[2*i+1,2*((i+1)%n)+1] for i in range(n)],'paired_edges':[[2*i,2*i+1] for i in range(n)]}
            for k,v in ec.items():eq(s['existing_ring_connections'][k],v,'existing_final_'+k,**context)
            eq(s['matterport_links_zero_based'],ec['paired_edges'],'final_point_pair_contract',**context)
        if s['ring_confirmed']:
            eq(s['order_status'],'human_confirmed','confirmed_order_status',**context)
            eq((s.get('order_record') or {}).get('order'),s['ordered_source_pair_indices'],'confirmed_order_record',**context)
        top,bottom,project_cause=project(final);max3d=max(delta(top,a['top3d']),delta(bottom,a['bottom3d']))
        check(max3d<=1e-10,'independent_erp_projection',record_id=rid,max_abs_h=max3d)
        geom_errors=geometry_errors(top,bottom) if project_cause is None else [project_cause]
        recomputed[rid]={'top':top,'bottom':bottom,'projection_cause':project_cause,'geometry_errors':geom_errors}
        inv_error=0.0
        if top is not None:
            for pts,ring in [(final[::2],a['top3d']),(final[1::2],a['bottom3d'])]:
                for (x,y),(xx,yy,zz) in zip(pts,ring):
                    bx=math.atan2(-xx,zz)/(2*math.pi)*1024%1024;by=(0.5-math.atan2(yy,math.hypot(xx,zz))/math.pi)*512
                    inv_error=max(inv_error,abs((bx-x+512)%1024-512),abs(by-y))
            check(inv_error<=1e-9,'independent_3d_inverse_to_erp',record_id=rid,max_abs_px=inv_error)
        if rid in oldmap:
            for k in ['points','top3d','bottom3d','sourcePointIndices','sourcePairIndices','sourceExistingRingConnections','preprocessing']:
                eq(a[k],oldmap[rid][k],'historical44_'+k,**context)
        object_rows.append({'record_id':rid,'image_code':im['code'],'object_kind':s['object_kind'],'source_order_status':s['order_status'],'human_confirmed':s['ring_confirmed'],'raw_points':len(raw),'final_points':len(final) if final is not None else None,'preprocessing_max_abs_px':pre_delta,'projection_max_abs_h':max3d,'inverse_projection_max_abs_px':inv_error,'geometry_errors':geom_errors,'source_pairing_basis':s['pairing_basis']})
    for im in ims:
        code=im['code'];refs={(a['id'],a['version']):a for a in im['groundtruths']};ii=im['source_image_inventory'];m=mm[code]
        chosen=next(((a['id'],a['version']) for a in im['groundtruths'] if a['version']=='manual_revision'),next(((a['id'],a['version']) for a in im['groundtruths'] if a['version']=='original'),None))
        old_choices={v for (c,r),v in oldbindings.items() if c==code}
        if old_choices:
            eq(len(old_choices),1,'one_historical_reference_per_image',image_code=code);chosen=next(iter(old_choices))
        eq((im['defaultReferenceId'],im['defaultReferenceVersion']),chosen,'default_reference_rederived',image_code=code)
        eq({(x['referenceId'],x['referenceVersion']) for x in im['annotations']}, {chosen} if im['annotations'] else set(),'single_fixed_reference_all_image_records',image_code=code)
        group='historical_development_image' if code in oldcodes else ('additional_image_in_development_building' if im['building'] in dev else 'additional_image_in_new_building')
        eq(im['evaluation_group'],group,'group_from_historical_input',image_code=code)
        eq(gm[code]['evaluation_group'],group,'prepared_group_matches',image_code=code)
        eq(gm[code]['building_held_out_from_current_parameters'],str(im['building'] not in dev),'prepared_building_holdout_matches',image_code=code)
        for k,v in [('image_id',im['imageId']),('building',im['building']),('room',im.get('room') or ''),('population',im['population'])]:
            eq(ii[k] or '',v or '','inventory_image_'+k,image_code=code);eq(m[k] or '',v or '','manifest_image_'+k,image_code=code)
        eq(ii['annotation_n'],len(im['annotations']),'source_annotation_counts',image_code=code);eq(im['imageInternalPath'],m['internal_path'],'image_internal_path',image_code=code)
        eq(ii['references'],{a['source_record']['object_kind']:a['id'] for a in im['groundtruths']},'source_reference_inventory',image_code=code)
        review=ii.get('review') or {};reason=None
        if review.get('gt_substantive_error_mark'):reason='reference_adjudicated_error'
        # Derive explicit holds from retained source gate/reasons, not adapter's hard-coded image list.
        gate_holds=[a for a in im['annotations'] if a['source_record']['worker_quality_gate']=='hold_all_analysis' and 'explicit_user_hold' in a['source_record']['review']['analysis_gate_reasons']]
        if gate_holds:
            eq(len(gate_holds),len(im['annotations']),'full_image_hold_source_consistent',image_code=code);reason='historical_explicit_analysis_hold'
        expected_policy='reference_not_applicable' if reason else 'conditional_geometry'
        eq(im['target_reason_kind'],reason,'target_reason_rederived_from_source',image_code=code);eq(im['targetApplicability'],expected_policy,'target_policy_rederived_from_source',image_code=code)
        eq(policies[code]['target_reason_kind'],reason,'policy_file_reason_matches',image_code=code)
        if reason:
            hold_rows.append({'image_code':code,'records':len(im['annotations']),'reference_id':chosen[0],'reason':reason,'source_error_flag':bool(review.get('gt_substantive_error_mark')),'source_explicit_hold_count':len(gate_holds),'source_gt_evidence_count':len(im['target_evidence'])})
        if im['annotations']:
            for k,v in [('image_id',im['imageId']),('building',im['building']),('room',im.get('room') or ''),('annotation_n',str(len(im['annotations']))),('independent_blind_test','False')]:eq(image_reg[code][k],v,'inventory_image_registry_'+k,image_code=code)
            expected_source_group='current_parameter_development_image' if code in oldcodes else ('same_building_new_image_not_used_for_current_parameter_selection' if im['building'] in dev else 'new_building_not_used_for_current_v1_v11_parameter_selection')
            eq(path_reg[code]['internal_path'],im['imageInternalPath'],'inventory_path_binding',image_code=code)
            group_rows.append({'image_code':code,'building':im['building'],'records':len(im['annotations']),'group':group,'building_held_out_from_current_parameters':im['building'] not in dev,'available_Q':sum(rm[a['id']]['status']=='available' for a in im['annotations'])})
        for a in im['annotations']:
            rid=a['id'];s=a['source_record'];r=rm[rid];b=bm[rid];gt=refs[chosen];rr=recomputed[rid];expected_na='available'
            for k,v in [('canonical_object_id',s['canonical_object_id']),('image_code',code),('building',im['building']),('room',im.get('room') or ''),('old_selected36',str((code,rid) in oldbindings)),('historical_quality_gate',s['worker_quality_gate']),('source_pairing_basis',s['pairing_basis'])]:eq(reg[rid][k],v,'inventory_record_registry_'+k,record_id=rid)
            if a['points'] is None:expected_na='annotation_points_unavailable' if s['pairing_basis']=='no_effective_points' else 'existing_pairing_unresolved'
            elif rr['projection_cause']:expected_na=rr['projection_cause']
            elif rr['geometry_errors']:expected_na='annotation_geometry_invalid'
            elif reason:expected_na=reason
            elif recomputed[gt['id']]['geometry_errors']:expected_na='reference_geometry_invalid'
            eq(r['unavailable_primary_reason'],expected_na,'result_na_reason_from_independent_input_checks',record_id=rid)
            eq(r['quality_score'] is None,expected_na!='available','Q_null_matches_input_eligibility',record_id=rid)
            eq(r['status']=='available',expected_na=='available','status_matches_input_eligibility',record_id=rid)
            for k,v in [('reference_id',chosen[0]),('reference_version',chosen[1]),('target_reason_kind',reason),('ring_order_status',s['order_status']),('ring_human_confirmed',s['ring_confirmed']),('evaluation_group',group),('canonical_object_id',s['canonical_object_id'])]:eq(r[k],v,'result_binding_'+k,record_id=rid)
            for k,v in [('reference_id',chosen[0]),('reference_version',chosen[1]),('target_applicability',expected_policy)]:
                if k=='target_applicability':k='target_policy'
                eq(b[k],v,'prepared_csv_'+k,record_id=rid)
            if (code,rid) in oldbindings:eq(chosen,oldbindings[(code,rid)],'old36_exact_reference',record_id=rid)
            if reason:
                eq(r['metrics'].get('iou_2d') is not None,True,'hold_keeps_diagnostic_2d_iou',record_id=rid)
                for k in ['iou_3d_corner_mean','iou_3d_perimeter_mean']:eq(r['metrics'].get(k) is not None,True,'hold_keeps_diagnostic_'+k,record_id=rid)
            if expected_na!='available':na_rows.append({'record_id':rid,'image_code':code,'independently_derived_reason':expected_na,'reported_reason':r['unavailable_primary_reason'],'source_gate':s['worker_quality_gate'],'source_pairing_basis':s['pairing_basis'],'geometry_errors':rr['geometry_errors'],'quality_score':r['quality_score'],'iou_2d':r['metrics'].get('iou_2d')})
            binding_rows.append({'record_id':rid,'image_code':code,'reference_id':chosen[0],'reference_version':chosen[1],'old36_record':(code,rid) in oldbindings,'same_as_image_default':chosen==(a['referenceId'],a['referenceVersion'])})
    new=[x for x in group_rows if x['building_held_out_from_current_parameters']];additional=[x for x in group_rows if x['image_code'] not in oldcodes]
    for building in sorted({x['building'] for x in group_rows}):
        bx=[x for x in group_rows if x['building']==building];br=building_reg[building]
        for k,v in [('research_images',len(bx)),('annotations',sum(x['records'] for x in bx)),('previous_six_images',sum(x['image_code'] in oldcodes for x in bx)),('additional_images',sum(x['image_code'] not in oldcodes for x in bx))]:eq(int(br[k]),v,'inventory_building_'+k,building=building)
        eq(br['building_group_role'],'development_building' if building in dev else 'fixed_parameter_validation_building','inventory_building_group_role',building=building)
    annrows=[x for x in object_rows if x['object_kind']=='annotation']
    report={'method':'Independent arithmetic and source-field derivations; no author scoring/audit module imported; no Q full recomputation.','input_sha256':hashlib.sha256((p/'prepared/frozen_expanded_geometry.json').read_bytes()).hexdigest(),'counts':{'all_images':len(ims),'research_images':len(group_rows),'gt_only_images':len(ims)-len(group_rows),'research_buildings':len({x['building'] for x in group_rows}),'annotations':len(rm),'all_objects':len(objects),'references':len(objects)-len(rm),'objects_with_final_erp':sum(a['points'] is not None for _,a in objects),'objects_projectable_and_inverse_checked':sum(x['top'] is not None for x in recomputed.values()),'objects_not_projectable':sum(x['top'] is None for x in recomputed.values()),'objects_valid_geometry_including_references':sum(not x['geometry_errors'] for x in recomputed.values()),'annotations_projectable':sum(recomputed[a['id']]['top'] is not None for im in ims for a in im['annotations']),'annotations_valid_3d_geometry':sum(not recomputed[a['id']]['geometry_errors'] for im in ims for a in im['annotations']),'Q_available_by_independent_eligibility':len(rm)-len(na_rows),'Q_unavailable':len(na_rows),'human_confirmed_annotations':sum(x['human_confirmed'] for x in annrows),'default_unreviewed_annotations':sum(x['source_order_status']=='default_unreviewed' for x in annrows),'default_unreviewed_Q_available':sum(r['ring_order_status']=='default_unreviewed' and r['status']=='available' for r in result),'source_raw_to_effective_changed_records':len(origin_changes),'source_raw_to_effective_changed_with_final':sum(x['has_final'] for x in origin_changes),'source_added_points_with_final':sum(len(x['added_effective_indices']) for x in origin_changes if x['has_final']),'source_removed_points_with_final':sum(len(x['removed_original_indices']) for x in origin_changes if x['has_final'])},'checks':dict(checks),'failed_checks':errors,'failed_check_count':len(errors),'projection_max_abs_h':max(x['projection_max_abs_h'] for x in object_rows),'inverse_projection_max_abs_px':max(x['inverse_projection_max_abs_px'] for x in object_rows),'preprocessing_max_abs_px':max(x['preprocessing_max_abs_px'] or 0 for x in object_rows),'unavailable_reasons':dict(collections.Counter(x['independently_derived_reason'] for x in na_rows)),'holds':hold_rows,'current_selection_holdout':{'buildings':sorted({x['building'] for x in new}),'building_count':len({x['building'] for x in new}),'images':len(new),'records':sum(x['records'] for x in new),'Q_available':sum(x['available_Q'] for x in new),'claim':'not used by current six-image parameter selection; NOT an independent historical blind test'},'additional_images':{'images':len(additional),'records':sum(x['records'] for x in additional),'Q_available':sum(x['available_Q'] for x in additional)},'old_six_image_bindings':[{'image_code':im['code'],'records':len(im['annotations']),'old36_records':sum((im['code'],a['id']) in oldbindings for a in im['annotations']),'reference_id':im['defaultReferenceId'],'reference_version':im['defaultReferenceVersion']} for im in ims if im['code'] in oldcodes],'source_gate_and_Q_counts':dict(collections.Counter(r['snapshot_quality_gate']+'|'+r['status'] for r in result)),'limitations':['Original four source ZIP archives and complete data_snapshot are absent in this review workspace; embedded source_record copies support internal raw-to-current tracing but cannot independently certify upstream archive completeness, source bytes, or authorization chronology.','The 1887 default_unreviewed source rings are retained as supplied, not independently confirmed as correct. 1729 receive available Q under conditional geometric validity.','Raw-to-effective upstream point additions/deletions and two raw-reinitialization notes are retained; no point/source/person/vote deduplication or edits performed.','Fixed GT selection and exact projection do not establish physical GT accuracy or target-scope correctness.','Historical exposure source files are not in this bundle; sixteen-building separation is verified only against current six-image development inputs, not against all prior work.']}
    (out/'binding_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    for name,data in [('object_binding_projection.csv',object_rows),('record_reference_bindings.csv',binding_rows),('unavailable_rederived.csv',na_rows),('image_groups_rederived.csv',group_rows),('source_raw_to_effective_changes.csv',origin_changes),('reference_holds_rederived.csv',hold_rows)]:write_csv(out/name,data)
    print(json.dumps({k:report[k] for k in ['counts','failed_check_count','projection_max_abs_h','inverse_projection_max_abs_px','preprocessing_max_abs_px','unavailable_reasons','current_selection_holdout']},ensure_ascii=False,indent=2))
    if errors:print(json.dumps(errors[:20],ensure_ascii=False,indent=2))

if __name__=='__main__':main()
