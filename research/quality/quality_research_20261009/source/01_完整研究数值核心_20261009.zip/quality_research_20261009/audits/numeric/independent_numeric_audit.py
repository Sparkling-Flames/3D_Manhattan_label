#!/usr/bin/env python3
"""Read-only numeric audit of the supplied bundle, independent of its audit reports.

The vertical-slice polygon intersection, means, scalar score and sensitivity
calculations below do not import the supplied scoring implementation. Only the
explicitly labelled self-copy/probe replays import its frozen score_geometry.
Run with python -B to avoid writes to the supplied source tree.
"""
import argparse, collections, csv, hashlib, itertools, json, math, sys
from pathlib import Path
import numpy as np
from scipy.optimize import brentq, minimize_scalar


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def dump(p, value):
    Path(p).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')


def csvdump(p, rows):
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with Path(p).open('w', encoding='utf-8-sig', newline='') as f:
        w=csv.DictWriter(f, fieldnames=keys);w.writeheader();w.writerows(rows)


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def area(poly):
    # Centering reduces cancellation. This is not a change to the input ring.
    p=np.asarray(poly,float);p=p-p[0]
    return abs(sum(float(x[0]*y[1]-x[1]*y[0]) for x,y in zip(p,np.roll(p,-1,axis=0)))/2)


def cross(a,b):
    return a[0]*b[1]-a[1]*b[0]


def slice_intervals(p,x):
    ys=[]
    for a,b in zip(p,np.roll(p,-1,axis=0)):
        if min(a[0],b[0]) < x < max(a[0],b[0]):
            ys.append(a[1]+(x-a[0])*(b[1]-a[1])/(b[0]-a[0]))
    ys.sort()
    if len(ys)%2:raise ValueError('Odd scanline crossing count')
    return list(zip(ys[::2],ys[1::2]))


def intersection_by_slices(p,q):
    """Exact-in-real-arithmetic vertical slab integration for simple polygons.

    Split at both polygons' vertex x coordinates and cross-polygon edge
    intersections. Within each open slab the overlap length is linear, so its
    midpoint value times slab width integrates it exactly. No triangulation,
    polygon repair, snapping, buffering, rasterization or supplied geometry
    function is used.
    """
    p,q=np.asarray(p,float),np.asarray(q,float)
    origin=p[0].copy();p,q=p-origin,q-origin
    xs=[*p[:,0],*q[:,0]]
    for a,b in zip(p,np.roll(p,-1,axis=0)):
        e=b-a
        for c,d in zip(q,np.roll(q,-1,axis=0)):
            f=d-c;den=cross(e,f)
            if den==0:continue
            t,u=cross(c-a,f)/den,cross(c-a,e)/den
            if 0<t<1 and 0<u<1:xs.append(a[0]+t*e[0])
    xs=sorted(set(xs));terms=[]
    for lo,hi in zip(xs,xs[1:]):
        x=lo+(hi-lo)/2
        if not lo<x<hi:continue
        pi,qi=slice_intervals(p,x),slice_intervals(q,x)
        length=sum(max(0.,min(b,d)-max(a,c)) for a,b in pi for c,d in qi)
        terms.append((hi-lo)*length)
    return math.fsum(terms)


def heights(record):
    b,t=np.asarray(record['bottom3d'],float),np.asarray(record['top3d'],float)
    hh=t[:,1]-b[:,1];p=b[:,[0,2]]
    ls=np.sqrt(np.sum((np.roll(p,-1,axis=0)-p)**2,axis=1))
    return float(np.mean(hh)), float(sum(l*(a+c)/2 for l,a,c in zip(ls,hh,np.roll(hh,-1)))/sum(ls))


def formula(m,s=4.,h=.5,prior=.15):
    d2=m['dir']**2;f2=m['flat']**2
    intrinsic=1-prior/2*(d2/(d2+25)+f2/(f2+4))
    return 100*m['iou']*intrinsic/(1+(m['S_top_deg']**2+m['S_bottom_deg']**2)/(2*s*s)+(m['Hstar']/h)**2)


def band(q,shift=0):
    return 'high' if q>=95+shift else 'good' if q>=85+shift else 'fair' if q>=50+shift else 'poor'


def own_independent(record):
    """Independent implementation of the declared D/F definitions.

    Direction: dense interval bracketing followed by local minimization.
    Flatness: root of the objective derivative, rather than the bundle's
    bounded minimizer. Same declared 512 floor-midpoint sampling is retained.
    """
    b,t=np.asarray(record['bottom3d'],float),np.asarray(record['top3d'],float)
    edges=np.roll(b[:,[0,2]],-1,axis=0)-b[:,[0,2]]
    ls=np.linalg.norm(edges,axis=1)
    ang=np.arctan2(edges[:,1],edges[:,0]);period=np.pi/2
    def d_obj(ax):
        res=(ang-ax+period/2)%period-period/2
        return float(sum(ls*res*res)/sum(ls))
    grid=np.linspace(0,period,721)
    vals=np.array([d_obj(ax) for ax in grid]);minimum=float(vals.min())
    for i in range(1,len(grid)-1):
        if vals[i]<=vals[i-1] and vals[i]<=vals[i+1]:
            fit=minimize_scalar(d_obj,bounds=(grid[i-1],grid[i+1]),method='bounded',options={'xatol':1e-14})
            minimum=min(minimum,float(fit.fun))
    # Include wrap-around minima at zero.
    fit=minimize_scalar(d_obj,bounds=(-period/720,period/720),method='bounded',options={'xatol':1e-14})
    minimum=min(minimum,float(fit.fun))
    directions=math.degrees(math.sqrt(max(0.,minimum)))
    cum=np.cumsum(np.r_[0.,ls]);ss=(np.arange(512)+.5)*sum(ls)/512
    ix=np.searchsorted(cum,ss,side='right')-1;u=(ss-cum[ix])/ls[ix]
    pts=t[ix]+u[:,None]*(np.roll(t,-1,axis=0)[ix]-t[ix])
    radial=np.hypot(pts[:,0],pts[:,2]);phi=np.arctan2(pts[:,1],radial)
    def deriv(level):
        return float(np.mean((np.arctan2(level,radial)-phi)*radial/(radial**2+level**2)))
    lo,hi=float(pts[:,1].min()),float(pts[:,1].max())
    level=lo if hi==lo else brentq(deriv,lo,hi,xtol=1e-13)
    flat=math.degrees(float(np.sqrt(np.mean((phi-np.arctan2(level,radial))**2))))
    return directions,flat


def main():
    p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    b,o=a.bundle.resolve(),a.out.resolve();o.mkdir(parents=True,exist_ok=True)
    geom=read(b/'prepared/frozen_expanded_geometry.json');results=read(b/'results_fixed/all_records_results.json')
    lookup={r['record_id']:r for r in results};pairs={};refs={};images={};ann_order=collections.Counter()
    for im in geom['images']:
        images[im['code']]=im
        for gt in im['groundtruths']:refs[(im['code'],gt['id'],gt['version'])]=gt
        for ann in im['annotations']:
            key=(im['code'],ann['referenceId'],ann['referenceVersion'])
            pairs[ann['id']]=(ann,refs[key],im,key)
            ann_order[str(ann['source_record']['order_status'])]+=1
    assert len(lookup)==len(results)==len(pairs)
    available=[r for r in results if r['status']=='available']
    nulls=[r for r in results if r['quality_score'] is None]
    counts={'records':len(results),'prepared_annotations':len(pairs),'images_with_annotations':len({x['image_code'] for x in results}),
            'all_prepared_images':len(geom['images']),'gt_only_images':[im['code'] for im in geom['images'] if not im['annotations']],
            'buildings':len({r['building'] for r in results}),'Q_available':len(available),'Q_null':len(nulls),
            'available_images':len({r['image_code'] for r in available}),'null_has_zero_instead':sum(r['quality_score']==0 for r in results if r['status']!='available'),
            'status_null_consistent':all((r['status']=='available')==(r['quality_score'] is not None) for r in results),
            'null_reasons':dict(collections.Counter(r['unavailable_primary_reason'] for r in nulls)),
            'ring_order_status':dict(ann_order),'ring_human_confirmed':sum(r['ring_human_confirmed'] for r in results),
            'ring_not_human_confirmed':sum(not r['ring_human_confirmed'] for r in results),
            'band_counts':dict(collections.Counter(band(r['quality_score']) for r in available)),
            'metric_available':{k:sum(r['metrics'].get(k) is not None for r in results) for k in ['iou_2d','iou_3d_corner_mean','iou_3d_perimeter_mean']},
            'old36':sum(r['old36_record'] for r in results),
            'target_policy_counts':dict(collections.Counter(r['target_applicability'] for r in results))}
    dump(o/'independent_denominators.json',counts)
    print('Denominators',json.dumps(counts,ensure_ascii=False),flush=True)

    # An independent polygon algorithm and literal prism formula for every
    # available traditional metric, from prepared coordinates, not CSV features.
    traditional=[];maxerr=collections.defaultdict(float);mismatches=[]
    for rid,(ann,gt,im,key) in pairs.items():
        r=lookup[rid];m=r['metrics']
        if m.get('iou_2d') is None:continue
        pa,pg=np.asarray(ann['bottom3d'])[:,[0,2]],np.asarray(gt['bottom3d'])[:,[0,2]]
        aa,ag,ii=area(pa),area(pg),intersection_by_slices(pa,pg)
        vals={'iou_2d':ii/(aa+ag-ii),'area_h2':aa,'reference_area_h2':ag,'intersection_area_h2':ii}
        if m.get('iou_3d_perimeter_mean') is not None:
            ca,ha=heights(ann);cg,hg=heights(gt)
            for metric,ap,gp in [('iou_3d_corner_mean',ca,cg),('iou_3d_perimeter_mean',ha,hg)]:
                inter=ii*min(ap,gp);vals[metric]=inter/(aa*ap+ag*gp-inter)
            vals.update(height_vertex_mean_h=ca,reference_height_vertex_mean_h=cg,height_perimeter_mean_h=ha,reference_height_perimeter_mean_h=hg)
        row={'record_id':rid,'image_code':im['code']}
        for k,v in vals.items():
            if m.get(k) is None:continue
            delta=v-m[k];maxerr[k]=max(maxerr[k],abs(delta));row[k]=v;row[k+'_delta']=delta
            if abs(delta)>1e-9*max(1,abs(m[k])):mismatches.append({'record_id':rid,'metric':k,'actual':v,'expected':m[k]})
        traditional.append(row)
    csvdump(o/'independent_traditional_all.csv',traditional)
    trad_report={'rows':len(traditional),'method':'independent vertical-slab polygon intersection; direct shoelace and conditional-prism formulas',
                 'max_absolute_errors':dict(maxerr),'relative_or_absolute_tolerance':1e-9,'mismatches':mismatches,
                 'not_checked':'invalid/missing inputs are counted, not repaired or assigned zero; official full depth/RMSE/delta1 pipeline is not executed'}
    dump(o/'independent_traditional_summary.json',trad_report);print('Traditional',json.dumps(trad_report),flush=True)

    # Recompute final scalar and all nine alternatives without importing engine.
    grid=list(itertools.product([3.5,4.,4.5],[.4,.5,.6]));sens=[];candidate={x:[] for x in grid};default_delta=[];grid_bands_changed=0;grid_ranges=[]
    defects=[]
    for r in available:
        m=r['metrics'];q=r['quality_score'];computed=formula(m);default_delta.append(abs(q-computed))
        if q<0 or q>100*m['iou']+1e-9: defects.append([r['record_id'],'range_cap'])
        if abs(m['Hstar']-max(m['Hmean'],m['Hlocal']))>1e-12: defects.append([r['record_id'],'Hstar'])
        if q>m['mean_height_only_score_same_parameters']+1e-9: defects.append([r['record_id'],'height_cap'])
        qq=[formula(m,s,h) for s,h in grid];grid_ranges.append(max(qq)-min(qq));grid_bands_changed+=len(set(map(band,qq)))>1
        for gh,v in zip(grid,qq):
            candidate[gh].append((q,v));sens.append({'record_id':r['record_id'],'image_code':r['image_code'],'S':gh[0],'H':gh[1],'Q':v,'delta':v-q,'band_changed':band(v)!=band(q)})
    csvdump(o/'independent_sensitivity_all.csv',sens)
    compact=[]
    for (s,h),vv in candidate.items():
        ds=np.array([v-q for q,v in vv]);compact.append({'S':s,'H':h,'n':len(vv),'band_changed':sum(band(q)!=band(v) for q,v in vv),'median_delta':float(np.median(ds)),'max_abs_delta':float(np.abs(ds).max())})
    published={}
    with (b/'validation/expanded_sensitivity_all_records_nine_candidates.csv').open(encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):published[(r['record_id'],float(r['boundary_half_deg']),float(r['height_relative_half']))]=float(r['candidate_Q'])
    compare=max(abs(r['Q']-published[(r['record_id'],r['S'],r['H'])]) for r in sens)
    byim=collections.defaultdict(list)
    for r in available:byim[r['image_code']].append(r)
    evaluated=flips=0;widest_flip=0
    for rr in byim.values():
        for x,y in itertools.combinations(rr,2):
            d=x['quality_score']-y['quality_score']
            if abs(d)<=1e-8:continue
            evaluated+=1
            differences=[formula(x['metrics'],s,h)-formula(y['metrics'],s,h) for s,h in grid]
            if any(e*d<0 and abs(e)>1e-8 for e in differences):flips+=1;widest_flip=max(widest_flip,abs(d))
    sens_summary={'recomputed_Q_count':len(available),'max_abs_default_Q_error':max(default_delta),
                  'arithmetic_defects':defects,'nine_grid_compared_rows':len(sens),'max_abs_grid_vs_published_error':compare,
                  'same_band_all_nine':len(available)-grid_bands_changed,'band_varies_in_grid':grid_bands_changed,
                  'median_grid_range':float(np.median(grid_ranges)),'max_grid_range':max(grid_ranges),
                  'within_image_nontie_pairs':evaluated,'within_image_pairs_reversing_in_at_least_one_candidate':flips,'max_default_gap_among_reversals':widest_flip,
                  'threshold_shift_band_changes':{str(shift):sum(band(r['quality_score'],shift)!=band(r['quality_score']) for r in available) for shift in [-3,0,3]},
                  'candidates':compact,'interpretation':'Sensitivity is arithmetic robustness, not accuracy; no parameter candidate is selected.'}
    dump(o/'independent_sensitivity_summary.json',sens_summary);print('Sensitivity',json.dumps(sens_summary),flush=True)

    # The separately published removal-of-prior candidate is post hoc. Check
    # its arithmetic over every record, but do not select it as a new default.
    with (b/'validation/prior_ablation/all_records_default_vs_no_prior.csv').open(encoding='utf-8-sig') as f:
        published_prior={r['record_id']:r for r in csv.DictReader(f)}
    prior_rows=[];prior_null_mismatch=[]
    for r in results:
        pub=published_prior[r['record_id']]
        if r['quality_score'] is None:
            if pub['Q_no_intrinsic_prior']!='':prior_null_mismatch.append(r['record_id'])
            continue
        q0=formula(r['metrics'],prior=0)
        prior_rows.append({'record_id':r['record_id'],'image_code':r['image_code'],'Q':r['quality_score'],
                           'Q_no_prior_independent':q0,'boost':q0-r['quality_score'],
                           'delta_from_published':q0-float(pub['Q_no_intrinsic_prior']),
                           'default_band':band(r['quality_score']),'no_prior_band':band(q0)})
    prior_map={r['record_id']:r for r in prior_rows};prior_flips=0;prior_flip_gap=0
    for rr in byim.values():
        for x,y in itertools.combinations(rr,2):
            d=x['quality_score']-y['quality_score'];e=prior_map[x['record_id']]['Q_no_prior_independent']-prior_map[y['record_id']]['Q_no_prior_independent']
            if abs(d)>1e-8 and abs(e)>1e-8 and d*e<0:prior_flips+=1;prior_flip_gap=max(prior_flip_gap,abs(d))
    prior_report={'records_compared':len(results),'numeric_rows':len(prior_rows),'null_rows':len(nulls),
                  'null_mismatch':prior_null_mismatch,'max_abs_numeric_delta_from_published':max(abs(r['delta_from_published']) for r in prior_rows),
                  'band_changed':sum(r['default_band']!=r['no_prior_band'] for r in prior_rows),
                  'boost_median':float(np.median([r['boost'] for r in prior_rows])),
                  'boost_max':max(r['boost'] for r in prior_rows),'max_boost_case':max(prior_rows,key=lambda r:r['boost']),
                  'within_image_strict_order_reversals':prior_flips,'max_default_gap_of_reversal':prior_flip_gap,
                  'no_prior_band_counts':dict(collections.Counter(r['no_prior_band'] for r in prior_rows)),
                  'scope':'Post-hoc diagnostic only; increased scores are an algebraic consequence of removing a deduction, not evidence of better quality accuracy.'}
    csvdump(o/'independent_no_prior_all.csv',prior_rows);dump(o/'independent_no_prior_summary.json',prior_report)

    # Explicitly same-kernel replays with independent feature/score checks.
    sys.dont_write_bytecode=True;sys.path.insert(0,str(b/'frozen_engine/core'))
    from quality_v11 import Parameters, score_geometry
    bound=sorted({p[3] for p in pairs.values()});available_bound={(r['image_code'],r['reference_id'],r['reference_version']) for r in available}
    copy_rows=[]
    for key in bound:
        gt=refs[key];default=score_geometry(gt,gt);no_prior=score_geometry(gt,gt,Parameters(intrinsic_max_discount=0))
        row={'image_code':key[0],'reference_id':key[1],'reference_version':key[2],'used_by_available_Q':key in available_bound,
             'image_target_policy':images[key[0]]['targetApplicability'],'self_geometry_status':default['status'],'Q':default['quality_score'],'Q_no_prior':no_prior['quality_score']}
        if default['status']=='available':
            m=default['metrics'];d,f=own_independent(gt)
            deduct_d=7.5*d*d/(d*d+25);deduct_f=7.5*f*f/(f*f+4)
            row.update(dir_engine=m['dir'],flat_engine=m['flat'],dir_independent=d,flat_independent=f,
                       direction_deduction_points=deduct_d,flatness_deduction_points=deduct_f,
                       Q_analytic_independent=100-deduct_d-deduct_f,analytic_minus_engine=(100-deduct_d-deduct_f)-default['quality_score'],
                       dir_difference=d-m['dir'],flat_difference=f-m['flat'],IoU=m['iou'],Hstar=m['Hstar'],S_top=m['S_top_deg'],S_bottom=m['S_bottom_deg'])
        else:row['reason_codes']='|'.join(default['reason_codes'])
        copy_rows.append(row)
    csvdump(o/'all_bound_GT_self_copies.csv',copy_rows)
    def copy_summary(rr):
        valid=[r for r in rr if r['Q'] is not None]
        return {'total':len(rr),'geometry_available':len(valid),'below_95':sum(r['Q']<95 for r in valid),'minimum_Q':min(r['Q'] for r in valid),
                'max_abs_no_prior_error_from_100':max(abs(r['Q_no_prior']-100) for r in valid),
                'max_abs_independent_analytic_error':max(abs(r['analytic_minus_engine']) for r in valid),
                'max_abs_direction_difference':max(abs(r['dir_difference']) for r in valid),
                'max_abs_flatness_difference':max(abs(r['flat_difference']) for r in valid),
                'cases_below_95':sorted([r for r in valid if r['Q']<95],key=lambda r:r['Q'])}
    cs={'all_bound_references_with_geometry_policy_forced_for_diagnostic':copy_summary(copy_rows),
        'references_actually_used_by_available_Q':copy_summary([r for r in copy_rows if r['used_by_available_Q']]),
        'policy_note':'Eight target-inapplicable images are included only in the first diagnostic set. The second set is the 251 actually usable fixed references. No default/reference/production algorithm was changed.',
        'identity_note':'A self-copy can score below 95 entirely because D/F are absolute annotation priors, not annotation-versus-reference error.'}
    dump(o/'GT_self_copy_summary.json',cs);print('GT copies',json.dumps(cs,ensure_ascii=False),flush=True)

    def rec(xz,hh):
        return {'bottom3d':[[x,-1.,z] for x,z in xz],'top3d':[[x,h-1.,z] for (x,z),h in zip(xz,hh)]}
    probes=[]
    for name,gt in [('slanted_parallelogram_exact_copy',rec([[-2,-1],[2,-1],[3,1],[-1,1]],[2]*4)),
                    ('sloping_roof_exact_copy',rec([[-3,-2],[3,-2],[3,2],[-3,2]],[1,5,5,1]))]:
        rr=score_geometry(gt,gt);no=score_geometry(gt,gt,Parameters(intrinsic_max_discount=0))
        probes.append({'name':name,'annotation':gt,'reference':gt,'result':rr,'no_prior_result':no})
    # Same piecewise-linear boundary, biased corner density. Traditional
    # corner-mean 3D IoU changes, whereas perimeter-mean IoU and Q are invariant.
    g=rec([[-3,-2],[3,-2],[3,2],[-3,2]],[1,5,5,1]);t=np.array(g['top3d']);bb=np.array(g['bottom3d']);at=[];ab=[]
    for i in range(4):
        us=[0,.1,.2,.3,.4,.5,.6,.7,.8,.9] if i==1 else [0]
        for u in us:at.append((t[i]+u*(t[(i+1)%4]-t[i])).tolist());ab.append((bb[i]+u*(bb[(i+1)%4]-bb[i])).tolist())
    ann={'top3d':at,'bottom3d':ab};rr=score_geometry(ann,g)
    probes.append({'name':'same_boundary_uneven_collinear_subdivision','annotation':ann,'reference':g,'result':rr,
                   'analytic_corner_mean':sum(np.array(at)[:,1]+1)/len(at),
                   'analytic_reference_corner_mean':3.,'analytic_perimeter_mean':3.,
                   'expected_corner_mean_IoU':3/(sum(np.array(at)[:,1]+1)/len(at)),
                   'expected_perimeter_mean_IoU':1.,'reference_self_Q':score_geometry(g,g)['quality_score']})
    # Same footprint and same mean height but reversed linear roof. A true
    # pair of sloping prisms has intersection/union 1/2 (integral min=2,
    # integral max=4), while both uniform-mean IoUs equal 1.
    ann=rec([[-3,-2],[3,-2],[3,2],[-3,2]],[5,1,1,5]);rr=score_geometry(ann,g)
    probes.append({'name':'opposed_linear_roofs_same_mean','annotation':ann,'reference':g,'result':rr,
                   'analytic_true_sloping_polyhedron_IoU':.5,'analytic_conditional_mean_prism_IoU':1.,
                   'interpretation':'Traditional mean-prism IoU cannot distinguish reversed height fields; it is not general nonflat volume IoU.'})
    dump(o/'independent_synthetic_probes.json',probes)
    print('Probes',json.dumps([{'name':p['name'],'Q':p['result']['quality_score'],'IoU2':p['result']['metrics'].get('iou_2d'),
                                'IoU3_corner':p['result']['metrics'].get('iou_3d_corner_mean'),'IoU3_perimeter':p['result']['metrics'].get('iou_3d_perimeter_mean')} for p in probes]),flush=True)

    # Provenance files are compared to current bytes, not treated as timestamp
    # attestation. Historical expected results are an internal baseline only.
    manifest=read(b/'MANIFEST.json');hashrows=[]
    for r in manifest['files']:
        f=b/r['path'];hashrows.append({'path':r['path'],'expected':r['sha256'],'actual':sha(f),'passed':sha(f)==r['sha256'] and f.stat().st_size==r['bytes']})
    contract=read(b/'portable_support/bundle_numeric_contract.json');contract_rows=[{'path':k,'passed':sha(b/k)==v} for k,v in contract['sha256'].items()]
    analysis=read(b/'validation/analysis_contract_frozen_before_expanded_scores.json')
    freeze_rows=[{'path':k,'passed':sha(b/'frozen_engine'/k)==v} for k,v in analysis['source_sha256'].items()]
    definition=read(b/'frozen_engine/frozen_parameters.json')
    definition_rows=[{'path':k,'same_as_original_definition_freeze_bytes':sha(b/'frozen_engine'/k)==v,'definition_hash':v,'current_hash':sha(b/'frozen_engine'/k)} for k,v in definition['definition_freeze_code_sha256'].items()]
    provenance={'manifest_files':len(hashrows),'manifest_all_passed':all(x['passed'] for x in hashrows),'manifest_rows':hashrows,
                'numeric_contract_files':len(contract_rows),'numeric_contract_all_passed':all(x['passed'] for x in contract_rows),'numeric_contract_rows':contract_rows,
                'preexpanded_analysis_contract_current_hashes':freeze_rows,'original_definition_freeze_current_byte_comparison':definition_rows,
                'what_it_proves':'Current bundle bytes match included hash lists; source stays unchanged; all-record score replay and independent formulas are reproducible from included prepared coordinates.',
                'what_it_does_not_prove':['Hash lists and claimed timestamps are supplied by the same author; no independent timestamp attestation is established.',
                  'Original four source ZIP files were not independently re-extracted by this numeric audit; prepared source records are bundled evidence, not an independent chain of custody.',
                  'Original photos and semantic correctness of reference/target/ring ordering were not inspected by this numeric audit.',
                  'Old36 equality is to the supplied geometric baseline, not independently retrieved historical originals; two explicit diagnostic-only additions are excluded by the supplied full-JSON comparator.',
                  'Replaying or reimplementing formulas does not establish calibration, held-out blindness, or quality accuracy.']}
    dump(o/'provenance_scope.json',provenance)
    # Verify complete current CSV and JSON bytes independently of harness.
    rp=o.parent/'reproduction'
    if rp.exists():
        byte_check={n:{'baseline_sha256':sha(b/'results_fixed'/n),'replay_sha256':sha(rp/'scores'/n),'byte_identical':sha(b/'results_fixed'/n)==sha(rp/'scores'/n)} for n in ['all_records_scores.csv','all_records_results.json']}
        dump(o/'independent_replay_byte_check.json',byte_check)


if __name__=='__main__':main()
