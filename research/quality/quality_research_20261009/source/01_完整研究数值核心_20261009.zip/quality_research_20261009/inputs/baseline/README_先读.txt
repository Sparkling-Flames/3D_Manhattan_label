全景布局质量 v1.1 扩大验证：完整复现包

结论与阅读顺序
保持默认 geom_quality_research_v1.1.0 及4°/0.5/5°/2°/15%参数。
该分数是固定目标、固定GT与条件三维假设下、带弱结构先验的几何研究分；
不是所有范围、吊顶/坡顶语义下的绝对实际质量真值。95/85/50只是暂定研究档位。
先读 reports/01_中文研究报告.pdf，再看02图册，03包含全部173份不可评价。
逐条中文表和完整表、图片/建筑汇总在delivery_tables/。原评分不改、不拟合、不出现在图册。

本轮分母
259张研究图、22建筑、3152份标注，2979份Q有效、173份Q=null。
261张原图含2张GT-only；四个输入包全部读取成功。
新增253张图片；16个未用于当前选参的建筑含136张图，但不能称历史独立盲测。
仅通过几何有效性不等于已经人工确认环序：1265 human_confirmed，1887 default_unreviewed。

数值复现（不需要原图或旧工作目录）
在此包根目录，用Python 3.12及requirements.txt所列实测版本：
  python -m pip install -r requirements.txt
  python reproduce.py --out reproduction_run1 --jobs 4
也可直接：
  python portable_support/reproduce.py --bundle . --out reproduction_run1 --jobs 4
输出必须为新/空目录。入口核对42项冻结输入、核、配置、基线哈希，重算3152+38，
比较完整CSV/JSON、各类null、原因、GT绑定；旧36数值也单独核对。
已在无原图、无PDF、无旧目录的模拟包实际运行，26.84秒，全量CSV和JSON字节相同。
可移植说明及证据见portable_support/中文复现说明.txt和verification_simulated_bundle/。
评分依赖是numpy/scipy/pandas；不需要GPU、PyTorch或联网服务。

传统指标
2D IoU使用相同未改底面。角点均高条件棱柱3D IoU复算HoHoNet官方IoU分支定义，
另列周长均高条件棱柱；都不等于真实非平顶多面体体积交并或实测3D。
不调用官方完整depth/RMSE/delta1流程；非法输入不填0。

有限调参
validation/含事前固定的九组S/H尺度敏感性，不按旧分选参数。
validation/prior_ablation/是看过全量结果/原图后提出的无弱先验候选，默认未替换。
可单独复现：
  python validation/prior_ablation/run_prior_ablation.py --root . --out prior_diagnostic_run1
提升分数是取消扣分的代数结果，不等于质量准确率改善。

原图与图册复现
visuals/cards/包含217张无旧人工分的证据卡：42真实案例、173不可评价、2个GT复制控制。
reports/含三本PDF；图卡与PDF都可放大。原三包照片约490MB，不在结果包重复提供；
将三个用户原图ZIP展开到同一原图目录，形成 images/<building>/<code>__<id>.png。
  python -m pip install -r requirements_visuals.txt
  python render_evidence.py --images-dir <包含images子目录的原图目录>
  python build_publication.py --out reports_regenerated
图卡按原几何投影；蓝/橙同尺度，不给失败输入补连接。不同页视域可变，h单位不变。

从原始四包重做库存/适配
本包prepared已自包含每份源记录、原点、现有效点、既定点对和环、投影、GT与政策。
库存源包README/清单在source_package_documentation/；原完整455文件仍在用户配套ZIP。
要重新核查原包，请把配套ZIP按原目录展开至data_snapshot，将原图展开至original_images。
原适配器的旧线程输入已按原字节保留在historical_inputs/inputs/，可显式传入：
  python prepare_expanded.py --snapshot data_snapshot --old-source historical_inputs --out prepared_rebuilt
已有库存/audit脚本保留原来源路径和参数；它们的历史提取步骤需要原四包，
不能把其暂未解包误当成数据不存在。正常数值复现不运行这些历史提取步骤。

版本与原始材料
release_config.json记本轮实际覆盖；frozen_engine/frozen_parameters.json保留原冻结时的历史
validation_status，未篡改成“当时已读取扩展数据”。所有当前核文件与扩展开始前SHA一致。
适配器仅新增原始数值类型检查，拒绝混合bool/字符串/复数；来源坐标未动，完整回投影已核对。
historical_inputs/inputs/review36_user_20261008.json原样保留旧评分/备注，仅作历史材料，
评分、选例、图册和参数诊断入口均不读取这些分数。
UwV83HsGsw3-09固定使用已确认R02557 manual_revision及[7,6,0,1,2,3,4,5]点对环序。
不逐份选更有利参考。24份GT实质错误与4份历史hold分开；这28份仅保留条件IoU。

复现边界
算分一致不证明目标/GT正确。范围差、矮墙/高包络、多层顶、柜体/墙、GT细节遗漏、
极短窄凹口和高度脉冲仍可能高估或低估。不同图片均值只描述本次混合抽样库存。
不扩展到人员分类、难度预测或融合算法。没有新增要求用户先全面重评的前置条件。

校验
MANIFEST.json列全部包内文件哈希，供传输与归档核对；numeric_contract是评分前独立冻结合同，
不要为使检查通过而重写。所有输出另存；本包不含访问链接、传输凭据或私有上传工具。
