#!/usr/bin/env python3
"""Assemble the immutable study release, without original photo ZIPs or credentials."""
from pathlib import Path
import hashlib, importlib.metadata, json, shutil, zipfile
from datetime import datetime,timezone
import pandas as pd
import fitz

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output/layout_quality_v1_1_expanded_20261009'
BUNDLE=OUT/'quality_v1_1_expanded_repro_20261009'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def cp(a,b):
    b=Path(b);b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
def cpdir(a,b):shutil.copytree(a,b,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.tmp','_simulation*','baseline36_interface_check'))

def main():
    OUT.mkdir(parents=True,exist_ok=True);BUNDLE.mkdir(parents=True,exist_ok=True)
    before=read(ROOT/'provenance/frozen_engine_before.json')
    assert all(sha(ROOT/'frozen_engine'/x['relative_path'])==x['sha256'] for x in before)
    for name in ['frozen_engine','prepared','results_fixed','delivery_tables','inventory','audit_geometry','validation','portable_support']:
        cpdir(ROOT/name,BUNDLE/name)
    for name in ['prepare_expanded.py','run_expanded.py','select_atlas.py','render_evidence.py','build_publication.py','qa_publication.py','assemble_release.py']:
        cp(ROOT/name,BUNDLE/name)
    cp(ROOT/'portable_support/vendor_license/HoHoNet_LICENSE',BUNDLE/'frozen_engine/traditional/vendor/LICENSE')
    for name in ['adapter_interface_fix_after_first_replay.json','frozen_engine_before.json','data_archive_members.json']:
        cp(ROOT/'provenance'/name,BUNDLE/'provenance'/name)
    for p in (ROOT/'visuals/cards').glob('*.jpg'):cp(p,BUNDLE/'visuals/cards'/p.name)
    for name in ['atlas_selection.csv','selection_policy.json','cards_manifest.json','case_captions_zh.json']:
        cp(ROOT/'visuals'/name,BUNDLE/'visuals'/name)
    for p in OUT.glob('*.pdf'):cp(p,BUNDLE/'reports'/p.name)
    cp(OUT/'01_中文研究报告.txt',BUNDLE/'reports/01_中文研究报告.txt')
    for p in (OUT/'figures').glob('*.png'):cp(p,BUNDLE/'reports/figures'/p.name)
    for p in (ROOT/'publication_qa').glob('*.json'):cp(p,BUNDLE/'publication_qa'/p.name)
    # The complete source objects are already embedded in prepared. The named
    # original archives remain user-owned inputs; no private app transfer metadata.
    for name in ['README.md','field_contract.json','REPLAY_MATERIALS.md','VERIFICATION.json','package_summary.json','image_manifest.json','source_inventory.csv']:
        p=ROOT/'data_snapshot'/name
        if p.is_file():cp(p,BUNDLE/'source_package_documentation'/name)
    for name in ['frozen_geometry.json','review36_user_20261008.json']:
        cp(ROOT.parents[1]/'source/oct8-pro-quality-handoff/inputs'/name,BUNDLE/'historical_inputs/inputs'/name)
    for name in ['scores36_geometry_only.csv','control_replay.csv','results_full.json']:
        p=ROOT.parents[1]/'work/research_v1_1/results'/name
        if p.exists():cp(p,BUNDLE/'historical_results_v11'/name)
    (BUNDLE/'reproduce.py').write_text('''#!/usr/bin/env python3
"""Convenience entry for the unchanged portable verification runner."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).resolve().parent / "portable_support/reproduce.py"), run_name="__main__")
''',encoding='utf-8')
    cp(ROOT/'portable_support/requirements.txt',BUNDLE/'requirements.txt')
    visual_pkgs=['matplotlib','Pillow','reportlab','PyMuPDF']
    (BUNDLE/'requirements_visuals.txt').write_text('-r requirements.txt\n'+''.join(f'{n}=={importlib.metadata.version(n)}\n' for n in visual_pkgs))
    source_orig=ROOT.parents[1]/'source/oct8-pro-quality-handoff/inputs/review36_user_20261008.json'
    release={
      'release_id':'quality_v1_1_expanded_20261009','created_utc':datetime.now(timezone.utc).isoformat(),
      'algorithm_version':'geom_quality_research_v1.1.0','definition_frozen_at_utc':'2026-10-08T16:20:18.693419+00:00',
      'recommendation_zh':'保留并冻结默认v1.1，作为固定目标和固定GT下、包含最多15%弱结构先验的条件几何研究分；粗档尚未主观标定。',
      'parameters':read(ROOT/'frozen_engine/frozen_parameters.json')['parameters'],
      'numerical_settings':read(ROOT/'frozen_engine/frozen_parameters.json')['numerical_settings'],
      'bands':{'high':{'min_inclusive':95},'good':{'min_inclusive':85,'max_exclusive':95},'fair':{'min_inclusive':50,'max_exclusive':85},'poor':{'max_exclusive':50},'unavailable':'null; never assigned to poor'},
      'formula':'Q = 100*I/(1+(S/4)^2+(Hstar/0.5)^2) * (1 - 0.075*(D^2/(D^2+25)+Fflat^2/(Fflat^2+4)))',
      'S_definition':'S=sqrt((S_top_deg^2+S_bottom_deg^2)/2); each S curve uses symmetric arc-length mean nearest great-circle distance',
      'Hstar_definition':'max(relative perimeter mean height error, symmetric nearest finite footprint projection relative height RMS)',
      'D_F_interpretation':'Bounded near-Manhattan and near-common-height research preference, not universally verified physical error',
      'normalization':'BEV dimensionless overlap; angular degrees; common camera-floor h; height residual/reference perimeter mean; no image-wise normalization',
      'archive_audit':{'archives_read':4,'research_images':259,'GT_only_images':2,'actual_original_images':261,'annotation_records':3152,'original_GTs':259,'manual_GTs':30,'access_failures':0,'missing_original_images':0,'duplicate_image_files':0},
      'fixed_results':read(ROOT/'results_fixed/summary.json'),
      'coverage_additional_images':{'images':253,'images_with_Q':245,'records':3003,'Q_available':2841},
      'coverage_additional_buildings':{'buildings':16,'images':136,'images_with_Q':130,'records':1186,'Q_available':1106,'interpretation':'not used in current v1/v1.1 selection, not a blind test'},
      'parameters_changed_this_expansion':False,'GT_changed_this_expansion':False,'annotation_coordinates_changed':False,
      'old_human_scores_used_for_fitting_or_atlas':False,'old_human_scores_preserved_sha256':sha(source_orig),
      'source_ring_status_counts':{'human_confirmed':1265,'default_unreviewed':1887},
      'traditional_metrics':'same unmodified footprint; HoHoNet IoU-branch corner-mean prism and separately perimeter-mean conditional prism; not physical nonflat 3D intersection or full official depth pipeline',
      'known44_matches_snapshot':True,'Uw_fixed_reference':{'image':'UwV83HsGsw3-09','id':'R02557','version':'manual_revision','ordered_source_pair_indices':[7,6,0,1,2,3,4,5]},
      'held_out_result_use':'Frozen default replay first. S/H grid sensitivity contract fixed before expanded scores. Intrinsic ablation proposed after scores and visual evidence; diagnostic only, no default replacement.',
      'posthoc_candidate':'validation/prior_ablation/diagnostic_parameters_no_intrinsic_prior.json',
      'historical_metadata_note':'frozen_engine/frozen_parameters.json preserves the earlier no-expanded-bytes validation_status; this release supplies the actual expanded coverage, without rewriting historical metadata.',
      'frozen_engine_hashes_unchanged_from_expansion_start':True,'frozen_engine_current_hashes':{x['relative_path']:x['sha256'] for x in before},
      'adapter_fix_log':'provenance/adapter_interface_fix_after_first_replay.json',
      'portable_reproduction':{'all_passed':True,'rows':3152,'controls':38,'full_output_max_numeric_difference':0,'CSV_and_JSON_byte_identical':True,'report':'portable_support/verification_simulated_bundle/reproduction_summary.json'},
      'claim_limits':['not an absolute human quality calibration','not an independent blind test','archive means do not estimate image population quality or difficulty','scope, ceiling level, occlusion, GT details, very short features and weak shape-prior bias remain unresolved'],
    }
    dump(BUNDLE/'release_config.json',release);dump(OUT/'11_冻结参数与版本说明.json',release)
    (BUNDLE/'README_先读.txt').write_text('''全景布局质量 v1.1 扩大验证：完整复现包

结论与阅读顺序
保持默认 geom_quality_research_v1.1.0 及4°/0.5/5°/2°/15%参数。
该分数是固定目标、固定GT与条件三维假设下、带弱结构先验的几何研究分；
不是所有范围、吊顶/坡顶语义下的绝对实际质量真值。95/85/50只是暂定研究档位。
先读 reports/01_中文研究报告.pdf，再看02图册，03包含全部173份不可评价。
逐条中文表和完整表、图片/建筑汇总在delivery_tables/。原评分不改、不拟合、不出现在图册。

本轮分母
259张研究图、22建筑、3152份标注，2979份Q有效、173份Q=null。
261张原图含2张GT-only；四个输入包全部读取成功。
新增253张图片；16个未用于当前选参的建筑含136张图，但不能称历史独立盲测。
仅通过几何有效性不等于已经人工确认环序：1265 human_confirmed，1887 default_unreviewed。

数值复现（不需要原图或旧工作目录）
在此包根目录，用Python 3.12及requirements.txt所列实测版本：
  python -m pip install -r requirements.txt
  python reproduce.py --out reproduction_run1 --jobs 4
也可直接：
  python portable_support/reproduce.py --bundle . --out reproduction_run1 --jobs 4
输出必须为新/空目录。入口核对42项冻结输入、核、配置、基线哈希，重算3152+38，
比较完整CSV/JSON、各类null、原因、GT绑定；旧36数值也单独核对。
已在无原图、无PDF、无旧目录的模拟包实际运行，26.84秒，全量CSV和JSON字节相同。
可移植说明及证据见portable_support/中文复现说明.txt和verification_simulated_bundle/。
评分依赖是numpy/scipy/pandas；不需要GPU、PyTorch或联网服务。

传统指标
2D IoU使用相同未改底面。角点均高条件棱柱3D IoU复算HoHoNet官方IoU分支定义，
另列周长均高条件棱柱；都不等于真实非平顶多面体体积交并或实测3D。
不调用官方完整depth/RMSE/delta1流程；非法输入不填0。

有限调参
validation/含事前固定的九组S/H尺度敏感性，不按旧分选参数。
validation/prior_ablation/是看过全量结果/原图后提出的无弱先验候选，默认未替换。
可单独复现：
  python validation/prior_ablation/run_prior_ablation.py --root . --out prior_diagnostic_run1
提升分数是取消扣分的代数结果，不等于质量准确率改善。

原图与图册复现
visuals/cards/包含217张无旧人工分的证据卡：42真实案例、173不可评价、2个GT复制控制。
reports/含三本PDF；图卡与PDF都可放大。原三包照片约490MB，不在结果包重复提供；
将三个用户原图ZIP展开到同一原图目录，形成 images/<building>/<code>__<id>.png。
  python -m pip install -r requirements_visuals.txt
  python render_evidence.py --images-dir <包含images子目录的原图目录>
  python build_publication.py --out reports_regenerated
图卡按原几何投影；蓝/橙同尺度，不给失败输入补连接。不同页视域可变，h单位不变。

从原始四包重做库存/适配
本包prepared已自包含每份源记录、原点、现有效点、既定点对和环、投影、GT与政策。
库存源包README/清单在source_package_documentation/；原完整455文件仍在用户配套ZIP。
要重新核查原包，请把配套ZIP按原目录展开至data_snapshot，将原图展开至original_images。
原适配器的旧线程输入已按原字节保留在historical_inputs/inputs/，可显式传入：
  python prepare_expanded.py --snapshot data_snapshot --old-source historical_inputs --out prepared_rebuilt
已有库存/audit脚本保留原来源路径和参数；它们的历史提取步骤需要原四包，
不能把其暂未解包误当成数据不存在。正常数值复现不运行这些历史提取步骤。

版本与原始材料
release_config.json记本轮实际覆盖；frozen_engine/frozen_parameters.json保留原冻结时的历史
validation_status，未篡改成“当时已读取扩展数据”。所有当前核文件与扩展开始前SHA一致。
适配器仅新增原始数值类型检查，拒绝混合bool/字符串/复数；来源坐标未动，完整回投影已核对。
historical_inputs/inputs/review36_user_20261008.json原样保留旧评分/备注，仅作历史材料，
评分、选例、图册和参数诊断入口均不读取这些分数。
UwV83HsGsw3-09固定使用已确认R02557 manual_revision及[7,6,0,1,2,3,4,5]点对环序。
不逐份选更有利参考。24份GT实质错误与4份历史hold分开；这28份仅保留条件IoU。

复现边界
算分一致不证明目标/GT正确。范围差、矮墙/高包络、多层顶、柜体/墙、GT细节遗漏、
极短窄凹口和高度脉冲仍可能高估或低估。不同图片均值只描述本次混合抽样库存。
不扩展到人员分类、难度预测或融合算法。没有新增要求用户先全面重评的前置条件。

校验
MANIFEST.json列全部包内文件哈希，供传输与归档核对；numeric_contract是评分前独立冻结合同，
不要为使检查通过而重写。所有输出另存；本包不含访问链接、传输凭据或私有上传工具。
''',encoding='utf-8')
    direct={'quality_scores_3152_zh.csv':'04_逐份评分_3152_中文简表.csv','quality_scores_3152_full.csv':'05_逐份评分_3152_完整字段.csv','by_image_259.csv':'06_按图片汇总_259.csv','by_building_22.csv':'07_按建筑汇总_22.csv','manual_review_173.csv':'08_不可评价复审清单_173.csv','metric_availability_counts.csv':'09_各指标有效样本数.csv','metric_failure_reasons.csv':'10_各指标缺失与失败原因.csv'}
    for src,dst in direct.items():cp(ROOT/'delivery_tables'/src,OUT/dst)
    # Verify exact transfer of frozen contract and source grade preservation.
    contract=read(BUNDLE/'portable_support/bundle_numeric_contract.json')
    paths=contract.get('sha256',{})
    if not paths:raise RuntimeError('Unexpected numeric contract schema')
    for rel,expected in paths.items():
        expected=expected['sha256'] if isinstance(expected,dict) else expected
        assert sha(BUNDLE/rel)==expected,rel
    assert sha(source_orig)==sha(BUNDLE/'historical_inputs/inputs/review36_user_20261008.json')
    manifest=[]
    for p in sorted(BUNDLE.rglob('*')):
        if p.is_file() and p.name!='MANIFEST.json':manifest.append({'path':p.relative_to(BUNDLE).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    dump(BUNDLE/'MANIFEST.json',{'release_id':release['release_id'],'files':manifest})
    archive=OUT/'quality_v1_1_expanded_repro_20261009.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(BUNDLE.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(OUT))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(manifest)+1
    dump(OUT/'交付文件校验.json',{'release':release['release_id'],'bundle_files':len(manifest)+1,'bundle_zip_crc_ok':True,'numeric_contract_hashes_checked':len(paths),'original_human_scores_sha256_unchanged':True,'frozen_engine_unchanged':True,'files':[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ['交付文件校验.json','publication_build.json']]})
    print(json.dumps({'bundle_files':len(manifest)+1,'zip_MiB':round(archive.stat().st_size/2**20,2),'numeric_contract_files':len(paths)},ensure_ascii=False))

if __name__=='__main__':main()
