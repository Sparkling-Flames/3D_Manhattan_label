#!/usr/bin/env python3
"""Read-only independent audit of fixed expanded Q and traditional outputs.

Checks identity/count conservation, output unavailability, the declared scalar
formula, both explicitly defined prism IoUs from unchanged geometry, exact
old36 full-precision replay and reported aggregates. No fitting or tuning.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from audit_snapshot_contract import write_csv, write_json


def shoelace(b):
    p=np.asarray(b,dtype=float)[:,[0,2]]
    p=p-p[0]
    return abs(math.fsum(float(a[0]*c[1]-a[1]*c[0])
                        for a,c in zip(p,np.roll(p,-1,axis=0)))/2)


def means(rec):
    b=np.asarray(rec['bottom3d']);t=np.asarray(rec['top3d']);h=t[:,1]-b[:,1]
    p=b[:,[0,2]];lens=np.linalg.norm(np.roll(p,-1,axis=0)-p,axis=1)
    perimeter=math.fsum(map(float,lens))
    mean=math.fsum(float(l*(u+v)/2) for l,u,v in zip(lens,h,np.roll(h,-1)))/perimeter
    return float(np.mean(h)),mean


def scalar(i,st,sb,dr,fl,h):
    boundary_sq=(st*st+sb*sb)/2
    intrinsic=1-.075*(dr*dr/(dr*dr+25)+fl*fl/(fl*fl+4))
    return 100*i/(1+boundary_sq/16+h*h/.25)*intrinsic


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--work',type=Path,required=True)
    ap.add_argument('--v11',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    result_path=args.work/'results_fixed/all_records_results.json'
    prepared_path=args.work/'prepared/frozen_expanded_geometry.json'
    full=json.loads(result_path.read_text())
    pre=json.loads(prepared_path.read_text())['images']
    frame=pd.read_csv(args.work/'results_fixed/all_records_scores.csv')
    frecords={r['record_id']:r for r in full}
    immap={im['code']:im for im in pre}
    raw_ann={r['id']:r for im in pre for r in im['annotations']}
    old=json.loads((args.v11/'results/reference_specific_results48.json').read_text())
    oldmap={r['record_id']:r for r in old if r['is_rating_reference']}
    formula_rows=[];trad_rows=[];oldrows=[];status_rows=[];failures=[]
    for r in full:
        ann=raw_ann[r['record_id']];im=immap[r['image_code']]
        gt=next(g for g in im['groundtruths'] if (g['id'],g['version'])==(r['reference_id'],r['reference_version']))
        m=r['metrics'];available=r['status']=='available'; q=r['quality_score']
        if available:
            q2=scalar(m['iou'],m['S_top_deg'],m['S_bottom_deg'],m['dir'],m['flat'],m['Hstar'])
            qmean=scalar(m['iou'],m['S_top_deg'],m['S_bottom_deg'],m['dir'],m['flat'],m['Hmean'])
            row={'record_id':r['record_id'],'image_code':r['image_code'],'Q':q,'Q_independent_scalar':q2,
                 'absolute_Q_error':abs(q-q2),'Q_max_IoU_violation':max(0.,q-100*m['iou']),
                 'Q_max_mean_only_violation':max(0.,q-qmean),
                 'Hstar_exact_max':m['Hstar']==max(m['Hmean'],m['Hlocal']),
                 'full_Q_is_finite_nonnegative':math.isfinite(q) and q>=0}
            formula_rows.append(row)
            if row['absolute_Q_error']>2e-12 or row['Q_max_IoU_violation']>1e-12 or row['Q_max_mean_only_violation']>1e-12 or not row['Hstar_exact_max'] or not row['full_Q_is_finite_nonnegative']:
                failures.append({'record_id':r['record_id'],'test':'independent_scalar_and_caps'})
        elif q is not None:
            failures.append({'record_id':r['record_id'],'test':'unavailable_Q_must_be_null'})

        if m.get('iou_2d') is not None:
            a,g=shoelace(ann['bottom3d']),shoelace(gt['bottom3d'])
            inter=m['intersection_area_h2']
            expected_i=inter/(a+g-inter)
            va,pa=means(ann);vg,pg=means(gt)
            def prism(ha,hg):
                vi=inter*min(ha,hg)
                return vi/(a*ha+g*hg-vi)
            cv,pv=prism(va,vg),prism(pa,pg)
            row={'record_id':r['record_id'],'image_code':r['image_code'],
                 'area_annotation_independent_h2':a,'area_reference_independent_h2':g,
                 'area_A_abs_difference':abs(a-m['area_h2']),
                 'area_G_abs_difference':abs(g-m['reference_area_h2']),
                 'iou2d_abs_difference':abs(expected_i-m['iou_2d']),
                 'corner_prism_iou3d_abs_difference':abs(cv-m['iou_3d_corner_mean']),
                 'perimeter_prism_iou3d_abs_difference':abs(pv-m['iou_3d_perimeter_mean']),
                 'annotation_vertex_height_abs_difference':abs(va-m['height_vertex_mean_h']),
                 'reference_vertex_height_abs_difference':abs(vg-m['reference_height_vertex_mean_h']),
                 'annotation_perimeter_height_abs_difference':abs(pa-m['height_perimeter_mean_h']),
                 'reference_perimeter_height_abs_difference':abs(pg-m['reference_height_perimeter_mean_h']),
                 'Hmean_abs_difference':abs(abs(pa-pg)/pg-m['Hmean']) if available else None,
                 'quality_target_policy':im['targetApplicability']}
            trad_rows.append(row)
            if max(row['iou2d_abs_difference'],row['corner_prism_iou3d_abs_difference'],row['perimeter_prism_iou3d_abs_difference'])>2e-12:
                failures.append({'record_id':r['record_id'],'test':'independent_prism_arithmetic'})

        if r['record_id'] in oldmap:
            prior=oldmap[r['record_id']]
            numeric=[];null_mismatch=[]
            for key,value in prior['metrics'].items():
                other=m.get(key)
                if isinstance(value,(int,float)) and not isinstance(value,bool):
                    if other is None:null_mismatch.append(key)
                    else:numeric.append((key,abs(value-other)))
                elif value is None and other is not None:null_mismatch.append(key)
            maxerr=max(v for k,v in numeric)
            row={'record_id':r['record_id'],'review_id':r['review_id'],
                 'image_code':r['image_code'],'reference_id':r['reference_id'],
                 'same_exact_reference':(r['reference_id'],r['reference_version'])==(prior['reference_id'],prior['reference_version']),
                 'Q_abs_difference_full_precision':abs(q-prior['quality_score']),
                 'numeric_metric_cells_checked':len(numeric),'max_metric_abs_difference':maxerr,
                 'null_availability_mismatch':';'.join(null_mismatch),
                 'same_metric_availability':r['metric_availability']==prior['metric_availability'],
                 'same_annotation_geometry_digest':r['annotation_geometry_sha256']==prior['annotation_geometry_sha256'],
                 'same_reference_geometry_digest':r['reference_geometry_sha256']==prior['reference_geometry_sha256']}
            oldrows.append(row)
            if maxerr>2e-12 or null_mismatch or not all(row[k] for k in ['same_exact_reference','same_metric_availability','same_annotation_geometry_digest','same_reference_geometry_digest']):
                failures.append({'record_id':r['record_id'],'test':'known36_full_precision_parity'})

        if ann['points'] is None:
            expected='annotation_points_unavailable' if ann['source_record']['pairing_basis']=='no_effective_points' else 'existing_pairing_unresolved'
        elif np.any(np.asarray(ann['points'])[:,1]>512):expected='annotation_input_domain_invalid'
        elif len(ann['points'])<6:expected='annotation_geometry_invalid'
        elif im.get('target_reason_kind'):expected=im['target_reason_kind']
        else:expected='available'
        row={'record_id':r['record_id'],'image_code':r['image_code'],
             'expected_current_primary_reason':expected,'actual_primary_reason':r['unavailable_primary_reason'],
             'matches_expected_reason':expected==r['unavailable_primary_reason'],
             'annotation_3d_valid':r['annotation_validity']['valid_3d'],
             'quality_available':available,'has_numeric_2d_IoU':m.get('iou_2d') is not None,
             'has_numeric_3d_IoU':m.get('iou_3d_corner_mean') is not None,
             'kernel_downstream_missing_3d':r['failure_classes']==['data_missing'],
             'adapter_root_reason':';'.join(x['code'] for x in r.get('adapter_issues',[]))}
        status_rows.append(row)
        if not row['matches_expected_reason']:failures.append({'record_id':r['record_id'],'test':'failure_cause_priority'})
        if expected in ('reference_adjudicated_error','historical_explicit_analysis_hold') and (available or not(row['has_numeric_2d_IoU'] and row['has_numeric_3d_IoU'])):
            failures.append({'record_id':r['record_id'],'test':'target_hold_retains_diagnostic_iou'})

    aggreg=[]
    for scope,key,name in [('image','image_code','by_image.csv'),('building','building','by_building.csv')]:
        table=pd.read_csv(args.work/'results_fixed'/name)
        for _,row in table.iterrows():
            grp=frame[frame[key]==row[key]];valid=grp[grp.score_status=='available']
            expected={'records_all':len(grp),'available_Q':len(valid),'unavailable_Q':len(grp)-len(valid)}
            for lab in ['高','较好','一般','较差']:expected['band_'+lab]=int((valid.quality_band==lab).sum())
            wrong=[k for k,v in expected.items() if v!=row[k]]
            aggreg.append({'scope':scope,'id':row[key],'checks':len(expected),'failed_checks':';'.join(wrong)})
            if wrong:failures.append({'record_id':row[key],'test':'aggregate_conservation'})
    write_csv(args.out/'independent_scalar2979.csv',formula_rows)
    write_csv(args.out/'independent_traditional_prism3007.csv',trad_rows)
    write_csv(args.out/'old36_full_precision_parity.csv',oldrows)
    write_csv(args.out/'unavailability_and_diagnostics3152.csv',status_rows)
    write_csv(args.out/'aggregate_count_audit281.csv',aggreg)
    write_json(args.out/'failed_assertions.json',failures)
    full_ids=Counter(r['record_id'] for r in full);csv_ids=Counter(frame.record_id)
    summary={'full_json_records':len(full),'csv_records':len(frame),
             'all_prepared_annotation_ids_preserved_once':full_ids==Counter(raw_ann.keys())==csv_ids,
             'independent_scalar_cases':len(formula_rows),'scalar_max_Q_abs_error':max(r['absolute_Q_error'] for r in formula_rows),
             'Q_le_100_IoU_max_violation':max(r['Q_max_IoU_violation'] for r in formula_rows),
             'Q_le_mean_only_max_violation':max(r['Q_max_mean_only_violation'] for r in formula_rows),
             'independent_traditional_cases':len(trad_rows),
             'traditional_corner_iou_max_abs_error':max(r['corner_prism_iou3d_abs_difference'] for r in trad_rows),
             'traditional_perimeter_iou_max_abs_error':max(r['perimeter_prism_iou3d_abs_difference'] for r in trad_rows),
             'old36_cases':len(oldrows),'old36_exact_JSON_Q_max_difference':max(r['Q_abs_difference_full_precision'] for r in oldrows),
             'old36_numeric_metric_cells':sum(r['numeric_metric_cells_checked'] for r in oldrows),
             'old36_max_metric_difference':max(r['max_metric_abs_difference'] for r in oldrows),
             'status_counts':dict(Counter(r['actual_primary_reason'] for r in status_rows)),
             'target_hold_records_with_preserved_IoU':sum(r['actual_primary_reason'] in ('reference_adjudicated_error','historical_explicit_analysis_hold') and r['has_numeric_2d_IoU'] and r['has_numeric_3d_IoU'] for r in status_rows),
             'all_unavailable_Q_null':all(r['quality_score'] is None for r in full if r['status']!='available'),
             'aggregate_rows_checked':len(aggreg),'aggregate_count_assertions':sum(r['checks'] for r in aggreg),
             'failed_assertions':len(failures),
             'result_sha256':hashlib.sha256(result_path.read_bytes()).hexdigest(),
             'limits':'Prism arithmetic uses the already computed original-polygon intersection; it is not an independent polygon-intersection engine. Values relative to known-bad GT remain diagnostics only. No scores/parameters/inputs changed.'}
    write_json(args.out/'fixed_results_audit_summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
