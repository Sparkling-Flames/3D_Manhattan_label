#!/usr/bin/env python3
"""Independent, read-only baseline for auditing a new raw-data adapter.

Reprojects the preserved 44 point/ring records without using production
projection functions, then replays the 36 explicitly bound references.
Human grades and text never enter the test. Output stays outside old inputs.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np


def hash_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    ensure_ascii=False).encode()).hexdigest()


def write_csv(path, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def independent_project(points):
    p = np.asarray(points, dtype=float)
    upper, lower = p[::2], p[1::2]
    longitude_b = 2 * np.pi * lower[:, 0] / 1024
    elevation_b = np.pi / 2 - np.pi * lower[:, 1] / 512
    r = -1 / np.tan(elevation_b)
    bottom = np.column_stack((-r*np.sin(longitude_b), -np.ones(len(r)),
                              r*np.cos(longitude_b)))
    longitude_t = 2 * np.pi * upper[:, 0] / 1024
    elevation_t = np.pi / 2 - np.pi * upper[:, 1] / 512
    top = np.column_stack((-r*np.sin(longitude_t), r*np.tan(elevation_t),
                           r*np.cos(longitude_t)))
    return top, bottom


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--v11', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    sys.path.insert(0, str(args.v11/'core'))
    from quality_v11 import score_geometry, load_parameters
    from strict_geometry import validate_record

    args.out.mkdir(parents=True, exist_ok=True)
    geometry_path = args.source/'inputs/frozen_geometry.json'
    bindings_path = args.source/'inputs/review36_user_20261008.json'
    params_path = args.v11/'frozen_parameters.json'
    original_scores = args.v11/'results/scores36_geometry_only.csv'
    guarded = [geometry_path, bindings_path, params_path,
               args.v11/'core/quality_v11.py',
               args.v11/'core/score_dataset.py',
               args.v11/'validity/strict_geometry.py',
               args.v11/'height_revision/height_revision.py']
    before = {str(p): hash_file(p) for p in guarded}
    data = json.loads(geometry_path.read_text())
    binding_entries = json.loads(bindings_path.read_text())['ratings']
    bindings = {(r['imageCode'], r['recordId']):
                (r['referenceId'], r['referenceVersion'], r['reviewId'])
                for r in binding_entries}
    scores = {r['record_id']: r for r in
              csv.DictReader(original_scores.open(encoding='utf-8-sig'))}
    params = load_parameters(params_path)
    geometry_rows, replay_rows, raw_witness = [], [], []
    for im in data['images']:
        references = {(r['id'], r['version']): r for r in im['groundtruths']}
        for role, records in [('annotation', im['annotations']),
                              ('reference', im['groundtruths'])]:
            for r in records:
                p = np.asarray(r['points'])
                t, b = independent_project(p)
                validation = validate_record(r, role=role)
                n = len(p)//2
                expected = {'top_edges': [[2*i, 2*((i+1) % n)] for i in range(n)],
                            'bottom_edges': [[2*i+1, 2*((i+1) % n)+1] for i in range(n)],
                            'paired_edges': [[2*i, 2*i+1] for i in range(n)]}
                observed = r['sourceExistingRingConnections']
                geometry_rows.append({
                    'image_code': im['code'], 'record_id': r['id'], 'role': role,
                    'version': r.get('version'), 'review_id': r.get('reviewId'),
                    'pair_count': n, 'points_sha256': digest(r['points']),
                    'top3d_sha256': digest(r['top3d']),
                    'bottom3d_sha256': digest(r['bottom3d']),
                    'source_pair_indices_identity': r['sourcePairIndices']==list(range(n)),
                    'source_point_indices_identity': r['sourcePointIndices']==list(range(2*n)),
                    'declared_connections_match_stored_ring':
                        all(observed[k]==v for k,v in expected.items()),
                    'max_pair_x_difference_px': float(np.max(np.abs(p[::2,0]-p[1::2,0]))),
                    'min_bottom_y_px': float(p[1::2,1].min()),
                    'max_top_projection_error_h': float(np.max(np.abs(t-np.asarray(r['top3d'])))),
                    'max_bottom_projection_error_h': float(np.max(np.abs(b-np.asarray(r['bottom3d'])))),
                    'valid_2d': validation['valid_2d'],
                    'valid_3d': validation['valid_3d'],
                    'complete_quality_input': validation['available'],
                    'source_ring_confirmed': r['sourceRingConfirmed'],
                    'source_order': r['sourceOrder'],
                })
                raw_witness.append({'image_code': im['code'], 'role': role,
                                    **{k:r.get(k) for k in ('id','version','reviewId',
                                        'points','top3d','bottom3d','sourcePointIndices',
                                        'sourcePairIndices','sourceExistingRingConnections')}})
        for ann in im['annotations']:
            refid, version, review = bindings[(im['code'], ann['id'])]
            result = score_geometry(ann, references[(refid, version)], params)
            old = scores[ann['id']]
            old_q = float(old['quality_score'])
            replay_rows.append({
                'image_code': im['code'], 'review_id': review,
                'record_id': ann['id'], 'reference_id': refid,
                'reference_version': version,
                'image_default_reference_id': im['defaultReferenceId'],
                'image_default_reference_version': im['defaultReferenceVersion'],
                'image_default_differs_from_explicit_binding':
                    (im['defaultReferenceId'],im['defaultReferenceVersion']) != (refid,version),
                'status': result['status'], 'quality_score': result['quality_score'],
                'frozen_published_quality_score': old_q,
                'absolute_quality_difference': abs(result['quality_score']-old_q)
                    if result['quality_score'] is not None else None,
                'iou_2d': result['metrics'].get('iou_2d'),
                'Hmean': result['metrics'].get('Hmean'),
                'Hlocal': result['metrics'].get('Hlocal'),
                'Hstar': result['metrics'].get('Hstar'),
            })
    write_csv(args.out/'baseline_geometry_contract44.csv', geometry_rows)
    write_csv(args.out/'baseline_explicit_reference_replay36.csv', replay_rows)
    (args.out/'baseline_exact_geometry_witness44.json').write_text(
        json.dumps(raw_witness,ensure_ascii=False,indent=2)+'\n')
    summary = {
        'image_count': len(data['images']), 'unique_geometry_records': len(geometry_rows),
        'annotation_count': len(replay_rows),
        'nonidentity_source_pair_indices': sum(not r['source_pair_indices_identity'] for r in geometry_rows),
        'nonidentity_source_point_indices': sum(not r['source_point_indices_identity'] for r in geometry_rows),
        'all_connections_match_stored_points_ring': all(r['declared_connections_match_stored_ring'] for r in geometry_rows),
        'all_stored_pairs_exact_common_x': all(r['max_pair_x_difference_px']==0 for r in geometry_rows),
        'max_independent_projection_difference_h': max(max(r['max_top_projection_error_h'],r['max_bottom_projection_error_h']) for r in geometry_rows),
        'max_replayed_Q_difference': max(r['absolute_quality_difference'] for r in replay_rows),
        'explicit_bindings_differing_from_image_default': sum(r['image_default_differs_from_explicit_binding'] for r in replay_rows),
        'original_files_hashes': before,
        'guarded_files_unchanged': before == {str(p): hash_file(p) for p in guarded},
        'human_grades_used': False,
        'quality_parameters_changed': False,
        'scope': 'baseline identity/projection/score contract; not new-image validation',
    }
    (args.out/'baseline_audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
