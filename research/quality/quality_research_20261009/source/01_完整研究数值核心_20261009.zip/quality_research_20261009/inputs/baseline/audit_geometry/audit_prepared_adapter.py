#!/usr/bin/env python3
"""Cross-audit prepared geometry against original snapshot and frozen v1.1.

Uses an independently written ERP projection and enumerates all supplied
objects. Existing source JSONs and the prepared geometry are read only.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

from audit_snapshot_contract import project_current, write_csv, write_json


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--work', type=Path, required=True)
    ap.add_argument('--v11', type=Path, required=True)
    ap.add_argument('--known-source', type=Path, required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    source=args.work/'data_snapshot'
    rp=source/'current/records.json';pp=args.work/'prepared/frozen_expanded_geometry.json'
    records=json.loads(rp.read_text())['objects'];prepared=json.loads(pp.read_text())['images']
    rawmap={r['id']:r for r in records}
    old=json.loads((args.known_source/'inputs/frozen_geometry.json').read_text())['images']
    oldmap={r['id']:r for im in old for r in im['annotations']+im['groundtruths']}
    bindings={(r['imageCode'],r['recordId']):(r['referenceId'],r['referenceVersion'])
              for r in json.loads((args.known_source/'inputs/review36_user_20261008.json').read_text())['ratings']}
    rows=[];group_rows=[];bindrows=[]
    dev=set(json.loads((args.v11/'frozen_parameters.json').read_text())['development_buildings'])
    for im in prepared:
        refs={(g['id'],g['version']):g for g in im['groundtruths']}
        group_rows.append({'image_code':im['code'],'building':im['building'],
                           'evaluation_group':im['evaluation_group'],'room':im.get('room'),
                           'population':im['population'],'target_policy':im['targetApplicability'],
                           'target_reason_kind':im.get('target_reason_kind'),
                           'building_in_original_development':im['building'] in dev,
                           'original36_image':im['code'] in {x['code'] for x in old}})
        for role,rs in [('annotation',im['annotations']),('reference',im['groundtruths'])]:
            for r in rs:
                raw=rawmap[r['id']]; issues=[]
                checks={'original_source_record_exact':r['source_record']==raw,
                        'image_identity_exact':im['code']==raw['image_code'],
                        'raw_coordinate_points_preserved':r['points']==raw['points_1024x512'],
                        'source_point_indices_preserved':r['sourcePointIndices']==raw['ordered_source_point_indices'],
                        'source_pair_indices_preserved':r['sourcePairIndices']==raw['ordered_source_pair_indices'],
                        'source_connections_preserved':r['sourceExistingRingConnections']==raw['existing_ring_connections']}
                row={'record_id':r['id'],'image_code':im['code'],'role':role,
                     'canonical_source_id':raw['canonical_object_id'],'point_count':len(r['points'] or []),
                     'known44':r['id'] in oldmap,'has_top3d':r['top3d'] is not None,
                     'has_bottom3d':r['bottom3d'] is not None}
                if r['id'] in oldmap:
                    prior=oldmap[r['id']]
                    checks['known_xyz_bitwise_equal']=r['top3d']==prior['top3d'] and r['bottom3d']==prior['bottom3d']
                if r['top3d'] is not None and r['bottom3d'] is not None:
                    other=project_current(r['points'])
                    delta=max(float(np.max(np.abs(np.asarray(other[k])-np.asarray(r[k])))) for k in ['top3d','bottom3d'])
                    scale=max(1.,*(float(np.max(np.abs(np.asarray(r[k])))) for k in ['top3d','bottom3d']))
                    checks['independent_projection_within_roundoff']=delta<=64*np.finfo(float).eps*scale
                    row.update(max_projection_difference_h=delta,relative_scaled_projection_difference=delta/scale)
                else:
                    row.update(max_projection_difference_h=None,relative_scaled_projection_difference=None)
                    checks['missing_geometry_has_explicit_adapter_reason']=bool(r['adapter_issues'])
                row.update(assertions=len(checks),failed_assertions=';'.join(k for k,v in checks.items() if not v))
                rows.append(row)
                if role=='annotation':
                    actual=(r['referenceId'],r['referenceVersion'])
                    if (im['code'],r['id']) in bindings:
                        expected=bindings[(im['code'],r['id'])];rule='preserved_exact_old36'
                    else:
                        revised=[g for g in im['groundtruths'] if g['version']=='manual_revision']
                        original=[g for g in im['groundtruths'] if g['version']=='original']
                        g=(revised or original)[0];expected=(g['id'],g['version']);rule='predeclared_revision_priority'
                    bindrows.append({'record_id':r['id'],'image_code':im['code'],
                                     'reference_id':actual[0],'reference_version':actual[1],
                                     'expected_reference_id':expected[0],'expected_reference_version':expected[1],
                                     'binding_rule':rule,'matched_expected_reference':actual==expected,
                                     'reference_geometry_found':actual in refs})
    relative_files=['core/quality_v11.py','core/score_dataset.py','validity/strict_geometry.py',
                    'height_revision/height_revision.py','traditional/traditional_metrics.py',
                    'legacy_geometry/audit_geometry.py','legacy_geometry/geometric_components.py',
                    'frozen_parameters.json','frozen_bands.json']
    hashes=[{'relative_file':rel,'prior_sha256':sha(args.v11/rel),
             'expanded_sha256':sha(args.work/'frozen_engine'/rel),
             'identical':sha(args.v11/rel)==sha(args.work/'frozen_engine'/rel)} for rel in relative_files]
    write_csv(args.out/'prepared_geometry_projection_parity3441.csv',rows)
    write_csv(args.out/'prepared_reference_bindings_parity3152.csv',bindrows)
    write_csv(args.out/'prepared_target_and_building_groups261.csv',group_rows)
    write_csv(args.out/'frozen_engine_byte_identity.csv',hashes)
    summary={'prepared_images':len(prepared),'prepared_objects':len(rows),
             'annotations':sum(r['role']=='annotation' for r in rows),
             'reference_objects':sum(r['role']=='reference' for r in rows),
             'all_source_ids_retained':Counter(r['record_id'] for r in rows)==Counter(rawmap.keys()),
             'adapter_assertions':sum(r['assertions'] for r in rows),
             'adapter_failed_records':[r['record_id'] for r in rows if r['failed_assertions']],
             'independent_projection_max_abs_h':max(r['max_projection_difference_h'] or 0 for r in rows),
             'independent_projection_max_scaled_error':max(r['relative_scaled_projection_difference'] or 0 for r in rows),
             'reference_binding_failures':sum(not r['matched_expected_reference'] or not r['reference_geometry_found'] for r in bindrows),
             'reference_version_counts':dict(Counter(r['reference_version'] for r in bindrows)),
             'frozen_engine_files_verified':len(hashes),'frozen_engine_all_identical':all(r['identical'] for r in hashes),
             'prepared_geometry_sha256':sha(pp),'snapshot_records_sha256':sha(rp),
             'gt_policy_uses_geometry_scores':False,'old_human_grades_used':False,
             'note':'Strict geometry validity and externally recorded target suitability are separate. Historical holds are separately identified.'}
    write_json(args.out/'prepared_adapter_audit_summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
