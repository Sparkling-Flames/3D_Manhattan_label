#!/usr/bin/env python3
"""Independent audit of the supplied full snapshot; makes no input changes.

Checks all four coordinate views and source pairing/ordering, compares every
known 36+8 object, audits declared applied repair evidence, and separately
tests the frozen wall geometry contract. It does not choose a GT or fit Q.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_csv(path, rows):
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                               allow_nan=False)+'\n', encoding='utf-8')


def assess_repairs(record):
    ev = record.get('repair_evidence') or []
    evs = [ev] if isinstance(ev, dict) else ev
    results = []
    for item in evs:
        row = {'record_id': record['id'], 'image_code': record['image_code'],
               'declared_repair_status': item.get('status'),
               'operation': item.get('operation', item.get('description')),
               'initialization_notes': json.dumps(record.get('initialization_notes'),ensure_ascii=False),
               'evidence_source': item.get('evidence_source', item.get('source')),
               'confirmed_scope': item.get('approval',item.get('confirmation_source'))}
        checks, differences = [], []
        before = record.get('before_preprocessing_points')
        raw = record.get('original_export_points')
        if item.get('status') not in ('applied', 'applied_effective_override'):
            row.update(status='historical_proposal_not_applied', tested_assertions=0,
                       conflict=False, differences='[]')
            results.append(row)
            continue
        if item.get('effective_points') is not None:
            target = item['effective_points']
            checks.append(len(target)==len(before))
            if len(target)!=len(before):
                differences.append({'field':'before_preprocessing_points',
                                    'expected_n':len(target),'current_n':len(before)})
            else:
                for i,(expected,actual) in enumerate(zip(target,before)):
                    checks.append(expected==actual)
                    if expected!=actual:
                        differences.append({'source_point_index':i,
                                            'declared_effective_point':expected,
                                            'current_before_preprocessing':actual})
        if item.get('changed_points'):
            for change in item['changed_points']:
                label = change['label']
                index = record['point_labels'].index(label)
                checks.append(before[index]==change['after'])
                if before[index]!=change['after']:
                    differences.append({'source_point_index':index,'label':label,
                                        'declared_effective_point':change['after'],
                                        'current_before_preprocessing':before[index]})
        if item.get('raw_count') is not None:
            checks.append(len(raw)==item['raw_count'])
            if len(raw)!=item['raw_count']:
                differences.append({'field':'original_export_points_count',
                                    'declared':item['raw_count'],'current':len(raw)})
        if item.get('effective_count') is not None:
            checks.append(len(before)==item['effective_count'])
            if len(before)!=item['effective_count']:
                differences.append({'field':'before_preprocessing_points_count',
                                    'declared':item['effective_count'],'current':len(before)})
        if item.get('removed_labels'):
            for label in item['removed_labels']:
                checks.append(label not in record['point_labels'])
                if label in record['point_labels']:
                    differences.append({'field':'removed_labels','label_still_present':label})
        prov = item.get('provenance') or {}
        added = prov.get('coordinate_1024x512',prov.get('added_coordinate_1024x512'))
        if added is not None:
            checks.append(added in before)
            if added not in before:
                differences.append({'field':'confirmed_added_coordinate','missing':added})
        row.update(status='declared_effective_differs_from_current_reinitialization' if differences
                   else 'no_conflict_in_executable_evidence',
                   tested_assertions=len(checks), conflict=bool(differences),
                   differences=json.dumps(differences,ensure_ascii=False))
        results.append(row)
    return results


def project_current(points):
    p = np.asarray(points, dtype=float)
    # Independent equation, no production projection/ordering helper.
    upper, lower = p[::2], p[1::2]
    azimuth = lower[:,0]*(2*np.pi/1024)
    elevation_bottom = (.5-lower[:,1]/512)*np.pi
    r = -1/np.tan(elevation_bottom)
    x, z = -r*np.sin(azimuth), r*np.cos(azimuth)
    bottom = np.column_stack((x, -np.ones(len(r)), z))
    top_y = r*np.tan((.5-upper[:,1]/512)*np.pi)
    top = np.column_stack((x,top_y,z))
    return {'points':points, 'top3d':top.tolist(),'bottom3d':bottom.tolist()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--snapshot', type=Path, required=True)
    ap.add_argument('--known-geometry', type=Path, required=True)
    ap.add_argument('--v11', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(args.v11/'validity'))
    from strict_geometry import validate_record
    record_path = args.snapshot/'current/records.json'
    panel_path = args.snapshot/'current/panel.json'
    inventory_path = args.snapshot/'current/image_inventory.json'
    hashes = {str(x):sha(x) for x in (record_path,panel_path,inventory_path,args.known_geometry)}
    objects = json.loads(record_path.read_text())['objects']
    panel = json.loads(panel_path.read_text())['images']
    inventory = json.loads(inventory_path.read_text())['images']
    known = json.loads(args.known_geometry.read_text())['images']
    by_id = {r['id']:r for r in objects}
    all_panel = [(im['code'],r) for im in panel for r in im['annotations']+im['references']]
    panel_by_id = {r['id']:(code,r) for code,r in all_panel}
    known_rows = []
    for im in known:
        for r in im['annotations']+im['groundtruths']:
            current = by_id[r['id']]
            differences=[]
            for oldkey,newkey in [
                ('points','points_1024x512'),
                ('sourcePointIndices','ordered_source_point_indices'),
                ('sourcePairIndices','ordered_source_pair_indices'),
                ('sourceExistingRingConnections','existing_ring_connections'),
                ('sourceOrder','order_status'),('sourceRingConfirmed','ring_confirmed')]:
                if r[oldkey]!=current[newkey]:differences.append(oldkey)
            if current['image_code']!=im['code']:differences.append('image_code')
            if r.get('version')!=current.get('version'):differences.append('reference_version')
            known_rows.append({'image_code':im['code'],'record_id':r['id'],
                               'role':'annotation' if r.get('reviewId') else 'reference',
                               'reference_version':r.get('version'),'review_id':r.get('reviewId'),
                               'all_coordinate_order_source_fields_identical':not differences,
                               'differing_fields':';'.join(differences)})

    rows, repair_rows, validity_records = [], [], []
    for index,r in enumerate(objects):
        checks, issues = {}, []
        code,p = panel_by_id.get(r['id'],(None,{}))
        checks['panel_same_image'] = code==r['image_code']
        for pkey,rkey in [('points','points_1024x512'),
                          ('source_point_indices','ordered_source_point_indices'),
                          ('source_pair_indices','ordered_source_pair_indices'),
                          ('ring_confirmed','ring_confirmed'),('order_status','order_status')]:
            checks['panel_'+pkey] = p.get(pkey)==r.get(rkey)
        points=r.get('points_1024x512')
        row={'record_id':r['id'],'canonical_object_id':r['canonical_object_id'],
             'image_code':r['image_code'],'object_kind':r['object_kind'],
             'preprocessing_status':r['preprocessing_status'],
             'historical_geometry_status':r['geometry']['status'],
             'historical_geometry_issues':';'.join(r['geometry'].get('issues',[])),
             'raw_points_present':r.get('original_export_points') is not None,
             'canonical_points_present':points is not None,
             'declared_pairing_basis':r.get('pairing_basis')}
        if points is None:
            checks['no_canonical_for_unavailable'] = r['preprocessing_status']=='unavailable'
            row.update(canonical_point_count=None, strict_valid_2d=False,
                       strict_valid_3d=False, strict_full_geometry_input=False,
                       conversion_status='existing_pairing_unavailable',
                       conversion_reason=';'.join(r['geometry'].get('issues',[])),
                       strict_reasons='', max_shared_x_recompute_difference_px=None)
        else:
            arr=np.asarray(points)
            pre=np.asarray(r['preprocessed_points'])
            before=np.asarray(r['before_preprocessing_points'])
            ids=r['ordered_source_point_indices']; pids=r['ordered_source_pair_indices']
            links=r['links_zero_based']; n=len(points)//2
            checks['even_canonical_count']=len(points)%2==0
            checks['source_indices_permutation']=sorted(ids)==list(range(len(pre)))
            checks['source_pair_indices_permutation']=sorted(pids)==list(range(len(links)))
            checks['canonical_exact_preprocessed_selection']=points==[r['preprocessed_points'][i] for i in ids]
            checks['point_pair_order_agrees']=ids==[j for i in pids for j in links[i]]
            checks['source_links_cover_exactly_once']=sorted(j for pair in links for j in pair)==list(range(len(pre)))
            checks['final_pairs_explicit']=r['matterport_links_zero_based']==[[2*i,2*i+1] for i in range(n)]
            expected={'top_edges':[[2*i,2*((i+1)%n)] for i in range(n)],
                      'bottom_edges':[[2*i+1,2*((i+1)%n)+1] for i in range(n)],
                      'paired_edges':[[2*i,2*i+1] for i in range(n)]}
            checks['existing_connections_match_final']=all(r['existing_ring_connections'][k]==v for k,v in expected.items())
            checks['all_y_preserved_in_shared_x']=np.array_equal(before[:,1],pre[:,1])
            checks['common_x_exact']=np.array_equal(arr[::2,0],arr[1::2,0])
            xerror=0.
            for a,b in links:
                x1,x2=float(before[a,0]),float(before[b,0])
                mean=(x1+((x2-x1+512)%1024-512)/2)%1024
                xerror=max(xerror,abs(((float(pre[a,0])-mean+512)%1024)-512),
                                  abs(((float(pre[b,0])-mean+512)%1024)-512))
            checks['shared_x_formula_within_1e_9px']=xerror<=1e-9
            bad_domain=np.argwhere((arr < np.array([0,0])) | (arr > np.array([1024,512])))
            lower_horizon=np.flatnonzero(arr[1::2,1]<=256)
            row.update(canonical_point_count=len(points),max_shared_x_recompute_difference_px=xerror,
                       lower_at_or_above_horizon_count=len(lower_horizon),
                       top_below_camera_count=int(np.sum(arr[::2,1]>256)),
                       erp_domain_bad_coordinate_count=len(bad_domain))
            if len(bad_domain):
                row.update(strict_valid_2d=False,strict_valid_3d=False,strict_full_geometry_input=False,
                           conversion_status='source_coordinate_domain_invalid',
                           conversion_reason=json.dumps([{'index':int(i),'axis':int(j),'value':float(arr[i,j])}
                                                         for i,j in bad_domain]),strict_reasons='')
            elif len(lower_horizon):
                row.update(strict_valid_2d=False,strict_valid_3d=False,strict_full_geometry_input=False,
                           conversion_status='floor_ray_no_forward_intersection',
                           conversion_reason=json.dumps(lower_horizon.tolist()),strict_reasons='')
            else:
                converted=project_current(points)
                validation=validate_record(converted,role='annotation' if r['object_kind']=='annotation' else 'reference')
                row.update(strict_valid_2d=validation['valid_2d'],strict_valid_3d=validation['valid_3d'],
                           strict_full_geometry_input=validation['available'], conversion_status='converted_without_repair',
                           conversion_reason='',strict_reasons=';'.join(validation['reason_codes']))
                validity_records.append({'record_id':r['id'],'image_code':r['image_code'],
                                         'object_kind':r['object_kind'],'validation':validation})
        row['contract_checks']=len(checks)
        row['contract_checks_failed']=';'.join(k for k,v in checks.items() if not v)
        rows.append(row)
        repair_rows.extend(assess_repairs(r))
        if (index+1)%500==0:print('audited',index+1,'/',len(objects),flush=True)

    evidence=[]
    for im in inventory:
        review=im.get('review') or {}
        image_records=[r for r in objects if r['image_code']==im['image_code']]
        holds=[r for r in image_records if (r.get('main_quality_gate') or {}).get('status')=='hold_all_analysis']
        if not (review.get('gt_substantive_error_mark') or review.get('gt_uncertainty_explicit_tag') or holds):
            continue
        unique=[]
        for ev in review.get('gt_evidence',[]):
            slim={'image_comment':ev.get('image_comment'),'semantic_image_evidence':ev.get('semantic_image_evidence')}
            if slim not in unique:unique.append(slim)
        for rec in holds:
            slim={'historical_hold':rec['main_quality_gate'],
                  'semantic_image_evidence':rec['review'].get('semantic_image_evidence')}
            if slim not in unique:unique.append(slim)
        evidence.append({'image_code':im['image_code'],'image_id':im['image_id'],
                         'annotation_n':im['annotation_n'],'references':im['references'],
                         'gt_substantive_error_mark':review.get('gt_substantive_error_mark',False),
                         'gt_uncertainty_explicit_tag':review.get('gt_uncertainty_explicit_tag',False),
                         'historical_hold_all_analysis_record_ids':[r['id'] for r in holds],
                         'evidence':unique})
    write_csv(args.out/'snapshot_known44_identity_parity.csv',known_rows)
    write_csv(args.out/'snapshot_source_contract3441.csv',rows)
    write_csv(args.out/'repair_evidence_audit23.csv',repair_rows)
    write_json(args.out/'snapshot_strict_geometry_objects.json',validity_records)
    write_json(args.out/'reference_applicability_evidence.json',evidence)
    write_json(args.out/'source_coordinate_version_conflicts.json',[
        {'record_id':r['id'],'image_code':r['image_code'],
         'initialization':r.get('initialization'),'initialization_notes':r.get('initialization_notes'),
         'before_preprocessing_points':r.get('before_preprocessing_points'),
         'points_1024x512':r.get('points_1024x512'),'repair_evidence':r.get('repair_evidence')}
        for r in objects if r['id'] in {x['record_id'] for x in repair_rows if x['conflict']}])
    summary={
        'objects':len(objects),'object_ids_unique':len(by_id)==len(objects),
        'canonical_ids_unique':len({r['canonical_object_id'] for r in objects})==len(objects),
        'panel_objects':len(all_panel),'panel_ids_unique':len(panel_by_id)==len(all_panel),
        'panel_record_identity_sets_identical':set(by_id)==set(panel_by_id),
        'object_kind_counts':dict(Counter(r['object_kind'] for r in objects)),
        'known44_objects_exact_coordinate_order_source_matches':sum(r['all_coordinate_order_source_fields_identical'] for r in known_rows),
        'source_contract_assertions':sum(r['contract_checks'] for r in rows),
        'objects_with_source_contract_failures':[r['record_id'] for r in rows if r['contract_checks_failed']],
        'source_preprocessing_max_x_error_px':max(r['max_shared_x_recompute_difference_px'] or 0 for r in rows),
        'conversion_status_counts':dict(Counter(r['conversion_status'] for r in rows)),
        'strict_geometry_status_by_kind':dict(Counter(r['object_kind']+':'+str(r['strict_full_geometry_input']) for r in rows)),
        'strict_reason_counts':dict(Counter(code for r in rows for code in r['strict_reasons'].split(';') if code)),
        'repair_evidence_rows':len(repair_rows),
        'repair_conflict_record_ids':[r['record_id'] for r in repair_rows if r['conflict']],
        'repair_assertions':sum(r['tested_assertions'] for r in repair_rows),
        'gt_substantive_error_images':[r['image_code'] for r in evidence if r['gt_substantive_error_mark']],
        'gt_substantive_error_image_record_count':sum(r['annotation_n'] for r in evidence if r['gt_substantive_error_mark']),
        'historical_hold_all_images':[r['image_code'] for r in evidence if r['historical_hold_all_analysis_record_ids']],
        'source_file_hashes':hashes,
        'source_files_unchanged':hashes=={p:sha(p) for p in hashes},
        'interpretation':'Source/geometry audit only. No current Q or band policy selected; no GT repair or change applied.'}
    write_json(args.out/'snapshot_audit_summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
