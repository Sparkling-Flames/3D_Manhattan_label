#!/usr/bin/env python3
"""Build the expanded fixed-v1.1 Chinese report and evidence atlases.

Uses frozen geometric results; original subjective grades are never loaded.
The case list was selected before visual interpretation; captions explicitly
separate observed geometry from unresolved target semantics.
"""
from __future__ import annotations
import argparse, html, io, json, math, re
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image as PILImage
import fitz
from reportlab.lib import colors
from reportlab import rl_config
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether

ROOT=Path(__file__).resolve().parent
rl_config.useA85=False  # Embed the existing JPEG stream without base85 expansion.
INK='#17334b'; TEAL='#087b8c'; AMBER='#bd7432'; GREY='#526275'; W=A4[0]-80
BANDS=['高','较好','一般','较差']
REASONS={
 'existing_pairing_unresolved':'既有点对／最终环未确定',
 'annotation_points_unavailable':'缺少现有效点阵／最终环',
 'reference_adjudicated_error':'GT 已有实质错误裁决',
 'historical_explicit_analysis_hold':'历史明确暂停该图分析',
 'annotation_input_domain_invalid':'ERP 坐标超出约定域',
 'annotation_geometry_invalid':'不足三个有效点对，不能成面'}

CAPTIONS={
'R01783':'固定近处空间的范围、转折和上下界近重合。门后其他可见区域未纳入当前 GT；高分不能解释为全图所有可见空间均已表达。',
'R00604':'近处小空间主范围与 GT 一致，BEV 与条件高度接近。门外空间不是本参考目标；没有以“空间简单”额外加分。',
'R00558':'主轮廓与固定参考近重合，局部点位偏差较小。该档说明参考约定下几何吻合，仍不是实测三维认证。',
'R02450':'与本册 R00604 为同一图片，均保留主范围；此份顶边、角点及房高偏移更明显。可先比较同图几何差别，再看跨图档位。',
'R01222':'主要范围保持，局部边界与落点略有偏移；条件 3D 仍接近参考。当前较好档与图像整体表现基本相容。',
'R01520':'主范围及底面接近，顶部和局部形状存在偏移。它来自旧开发图，但此处展示的是当前冻结客观结果。',
'R01515':'主要范围保留，长边、转折和局部落点有差异。柱体、海报及局部多段表达存在语义混杂，不能把多出的折角一概判错。',
'R01710':'固定 GT 较简化；标注在柜体／墙体交界增加局部折角，是否属于房间轮廓尚不明确。其他长边和顶部确有偏移，不能将全部扣分归因于真实细节。',
'R02929':'ERP 多处看似贴线，但远端 BEV／条件 3D 明显伸长与倾斜。该例提示：一般档不保证每个局部缺陷都很轻微。',
'R03329':'长廊两端收短，上边界和局部房高也有明显差异。相对固定完整长廊目标，这是较清楚的范围与几何实现缺陷。',
'R01013':'主要省略固定 GT 的过道一翼。完整目标下低分有依据；主起居区局部边界并非全部很差，属于范围政策敏感例。',
'R02172':'主要差异涉及近墙遮挡后的 GT 延伸，若干可见边界仍贴合。单张图不能认证隐藏区域，也不能据此宣布 GT 错误。',
'R02428':'距 95 下侧约 0.09 分，主包络近重合。与上侧案例一起看：阈值附近没有可见的质量突变。',
'R00135':'95 下侧、与 R01042 同图。两份都非常贴近参考；跨过阈值不应解读成质变。',
'R01042':'95 上侧、与 R00135 同图。轻微几何差别足以让分数落在界线另一侧，适合检验高／较好档边界是否过细。',
'R01000':'95 上侧，近处轮廓和条件高度接近参考。不同图采用同一公式；没有逐图归一化。',
'R01292':'85 下侧，狭窄空间的角点、顶线与条件伸展存在差异。两档交界非常接近，不能从差几百分之一分推断稳定排序。',
'R00350':'85 下侧，长边及高度偏移可见。与相邻档案例比较缺陷幅度，勿把阈值当合格线。',
'R01407':'85 上侧，主要范围保留但局部落点、顶面有漂移。分数与下侧案例相近，图像复核比边界小数更有意义。',
'R00069':'85 上侧，窄走廊中存在局部边界和条件高度差。此处沿用阈值，不通过重新选参数让边界例更整齐。',
'R03106':'50 下侧，远端轮廓有斜切，顶面又涉及多层结构。范围与位置差是真实数值事实，具体顶界目标仍需按任务约定理解。',
'R00096':'50 下侧，BEV 中整体深度／形状偏离较明显。与上侧案例缺陷并不完全同型，不应期待同分具有相同错误组合。',
'R00896':'50 上侧，窄空间中的屋顶边界及底面几何有明显漂移。刚过 50 不代表局部误差已经轻微。',
'R03339':'50 上侧，前墙局部结构与固定包络不同，兼有位置差。参考对凸出结构的表达影响解释，保留语义限制。',
'R00421':'平均房高几乎正确（Hmean=0.00363），局部高度差较大（Hlocal=0.22254）；局部修复使 37.91 降至 33.73。地面遮挡较多，不能认证每个 GT 隐藏点。',
'R00384':'原图有跌级／托盘顶，部分高位点有真实结构依据；同份也存在右侧穿墙连线、下降及地面偏点。它展示真实细节与实际误差并存，不能用“非平顶”判定全错。',
'R01114':'原图为坡顶／矮墙空间。青线部分沿低位矮墙交界，GT 采用较高均高包络。Q=6.34 表示固定目标差异大，不能证明整份真实质量几乎为零。',
'R01672':'办公空间同时有主顶板、梁和玻璃隔断顶。青线上界偏低且各处不一致，但可能混入较低框梁／隔断边选择，不是纯随机点位误差。',
'R01360':'底面近 GT，局部上界下降接近可见吊顶／梁底转折。若目标为逐段可见墙顶，有被低估的图像依据；不能把这对样本当作已验证绝对排序。',
'R02187':'与 R01360 同图，较高均高包络与 GT 近重合。高分证明参考吻合，且 OOS 未被机械扣分；不证明另一份描出的低位结构一定错误。',
'R02141':'自身接近规整，但 BEV IoU 仅约 0.421，固定目标的延伸范围大量缺失，Q=30.09。局部规整性无法抬高 IoU 上限；仍须区分范围约定。',
'R00086':'自身较规整，长廊范围明显短于固定参考，IoU 约 0.405，Q=17.37。门／隔断可改变局部空间理解，低分按当前长廊目标解释。',
'R00768':'简化矩形与 GT 近重合，Q=97.05；原图有细柱／局部突出结构，历史也有 GT 细节遗漏提示。高分无法保证真实细节完整。',
'R01613':'多转折、门洞附近 8 对点仍可得 97.85。复杂点数与门洞类别没有直接扣分；当前 GT 也不必然表达所有可见细节。',
'R02854':'部分顶点低于相机但仍高于地板，条件几何有效，正常得 57.70。不是仅凭“wrong hemisphere”旧标签或低顶排除。',
'R00904':'本次使用当前重初始化后的坐标，p8 已按来源说明恢复原导出，而非历史坐标移动版；Q=84.34。两版差异留档，没有暗中采用更高分版本。',
'R00186':'青线清楚围合淋浴隔间，GT 表达玻璃门外整间浴室。IoU=0.11661／Q=1.13 是固定整间目标下严重范围不足；并不等于淋浴隔间本身乱画。',
'R02075':'上／下线脚和墙角支持真实斜墙。I=0.99011、S=0.295°、H*=0.00860，弱自身先验仍扣约 6.83 分。这是结构先验可能低估的实图例。',
'R00328':'柜体上部、柜角与遮挡导致房间包络目标不清。GT 条件高度起伏大，但原图不足以确认真实斜顶；不能借此自动替换 GT 或宣称标注全错。',
'R00474':'OOS 新建筑中的主包络与 GT 近重合，Q=96.15。木梁、拱顶、壁龛等真实细节不全在该简化目标中，高分不认证这些内容完整。',
'R03398':'门洞交界仍按实际几何有效处理。固定 GT 下存在范围偏移及局部高度差，Q=54.95；类别并未触发 3D 不可用。',
'R03168':'BEV IoU 约 0.959，上界差较大；默认 Q=55.27。九组尺度可使其在 48.81–60.67 之间，说明个别边界归档对研究尺度敏感。',
'GT_COPY_R02762':'控制输入：精确复制 x8-09 修订 GT，不是第 3153 份标注。I=1、S=H*=0，却因方向先验仅得 93.68；原图支持其真实斜墙，提示 95 档可能低估。',
'GT_COPY_R02739':'控制输入：精确复制 wc-14 修订 GT，不是人员标注。自身先验令其仅得 87.55。图像有柜体／房间包络目标疑问，复制 GT 得 100 也不能证明物理正确。'}

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def savej(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def fmt(x,n=2):return '—' if x is None or pd.isna(x) else f'{float(x):.{n}f}'
def esc(s):return html.escape(str(s)).replace('\n','<br/>')

class Doc:
    def __init__(self,path,title):
        self.path=Path(path);self.title=title;self.story=[];self.text=[]
        specs={'body':(9.8,15.2,INK),'small':(8.1,12,GREY),'title':(25,34,INK),'h1':(17,24,INK),'h2':(11.5,17,TEAL),'cell':(8.4,12,INK),'tiny':(7.6,10.5,INK)}
        self.styles={k:ParagraphStyle(k,fontName='CJK',fontSize=s,leading=l,textColor=colors.HexColor(c),spaceAfter=6 if k not in ['cell','tiny'] else 0,wordWrap='CJK',keepWithNext=k in ['h1','h2']) for k,(s,l,c) in specs.items()}
    def p(self,t,style='body'):
        self.story.append(Paragraph(t,self.styles[style]));self.text.append(re.sub('<[^>]+>','',html.unescape(t)))
    def page(self,title):
        if self.story:self.story.append(PageBreak())
        self.p(title,'h1')
    def table(self,heads,rows,widths=None,tiny=False):
        st=self.styles['tiny' if tiny else 'cell'];allrows=[heads]+list(rows)
        t=Table([[Paragraph(esc(v),st) for v in row] for row in allrows],colWidths=widths or [W/len(heads)]*len(heads),repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e5eef3')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f4f8fa')]),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#aebfc9')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
        self.story += [t,Spacer(1,8)];self.text += [' | '.join(map(str,row)) for row in allrows]
    def img(self,p,width=W):
        with PILImage.open(p) as im:w,h=im.size
        self.story += [Image(str(p),width=width,height=width*h/w),Spacer(1,5)]
    def build(self):
        buffer=io.BytesIO();doc=SimpleDocTemplate(buffer,pagesize=A4,leftMargin=40,rightMargin=40,topMargin=43,bottomMargin=40,title=self.title,author='Conditional geometry research',subject='Frozen v1.1 expanded validation; old subjective grades hidden')
        def footer(c,d):
            c.saveState();c.setStrokeColor(colors.HexColor('#d4dee5'));c.line(40,31,A4[0]-40,31);c.setFont('CJK',7.1);c.setFillColor(colors.HexColor(GREY));c.drawString(40,18,'固定 v1.1 · 2026-10-09 · 条件几何研究');c.drawRightString(A4[0]-40,18,str(d.page));c.restoreState()
        doc.build(self.story,onFirstPage=footer,onLaterPages=footer);self.path.write_bytes(buffer.getvalue());return len(fitz.open(self.path))

def figures(out,f,controls):
    out.mkdir(parents=True,exist_ok=True);plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
    fig=plt.figure(figsize=(11,1.9));fig.text(.02,.59,r'$Q=\frac{100I}{1+(S/4^{\circ})^2+(H^*/0.5)^2}\left[1-0.075\left(\frac{D^2}{D^2+(5^{\circ})^2}+\frac{F^2}{F^2+(2^{\circ})^2}\right)\right]$',fontsize=23,color=INK);fig.text(.02,.14,r'$S^2=(S_t^2+S_b^2)/2,\qquad H^*=\max(H_{\mathrm{mean}},H_{\mathrm{local}})$',fontsize=17,color=INK);fig.savefig(out/'formula.png',dpi=220,bbox_inches='tight');plt.close(fig)
    fig=plt.figure(figsize=(11,2));fig.text(.02,.63,r'$H_{\rm mean}=|\mu_A-\mu_G|/\mu_G,\quad H_{\rm local}=\sqrt{(E_{A\to G}+E_{G\to A})/2}/\mu_G$',fontsize=20,color=INK);fig.text(.02,.17,r'$E_{A\to G}=\frac{1}{L_A}\int_{\partial A}\left[z_A(s)-z_G\left(\pi_G(s)\right)\right]^2\,ds$',fontsize=23,color=INK);fig.savefig(out/'height_definition.png',dpi=210,bbox_inches='tight');plt.close(fig)
    c=controls.set_index('case_id');fig,axs=plt.subplots(2,2,figsize=(10.5,7.2))
    ids=['alternating_height_xz_scale_1','alternating_height_xz_scale_8','alternating_height_xz_scale_32'];g=c.loc[ids]
    axs[0,0].plot([1,8,32],g.mean_height_only_score_same_parameters,'o--',c=GREY,label='Mean height only');axs[0,0].plot([1,8,32],g.quality_score,'o-',c=TEAL,label='Frozen v1.1');axs[0,0].set(xscale='log',xticks=[1,8,32],xticklabels=['1','8','32'],ylim=(0,103),xlabel='Footprint scale / h',ylabel='Q',title='A. Alternating 1.01h / 2.99h; GT 2h');axs[0,0].legend(frameon=False,fontsize=8)
    ids=['nonflat_copy_k64','nonflat_inverse_k64','nonflat_flatten_k64'];g=c.loc[ids];x=np.arange(3);axs[0,1].bar(x-.17,g.mean_height_only_score_same_parameters,.34,color=GREY,label='Mean only');axs[0,1].bar(x+.17,g.quality_score,.34,color=TEAL,label='v1.1');axs[0,1].set(xticks=x,xticklabels=['Exact copy','Inverse','Flattened'],ylim=(0,105),ylabel='Q',title='B. Valid nonflat reference / distant');axs[0,1].legend(frameon=False,fontsize=8)
    vals=[0,.005,.01,.05,.2,.8];ids=[f'rectangle_translation_{v:g}' for v in vals];axs[1,0].plot(vals,c.loc[ids].quality_score,'o-',c=TEAL);axs[1,0].set(xlabel='Translation / sqrt(GT area)',ylabel='Q',ylim=(0,103),title='C. Same target / increasing translation')
    x=np.linspace(0,1,301)
    for t,col in [(.4,GREY),(.5,TEAL),(.6,AMBER)]:axs[1,1].plot(x,100/(1+(x/t)**2),c=col,label=f'Height scale {t:g}')
    axs[1,1].set(xlabel='H* / relative error',ylabel='Isolated response',ylim=(0,103),title='D. Chosen research scales');axs[1,1].legend(frameon=False,fontsize=8)
    for ax in axs.flat:ax.grid(alpha=.17)
    fig.tight_layout(h_pad=2,w_pad=2);fig.savefig(out/'controls.png',dpi=190);plt.close(fig)
    ok=f[f.score_status=='available'];fig,axs=plt.subplots(1,2,figsize=(10.5,4.1))
    for label,col in [('additional_image_in_new_building',TEAL),('additional_image_in_development_building','#7b91a4'),('historical_development_image',AMBER)]:
        q=ok[ok.evaluation_group==label];axs[0].scatter(q.iou,q.quality_score,s=6,alpha=.32,color=col,label={'additional_image_in_new_building':'16 new buildings','additional_image_in_development_building':'Other views / dev buildings','historical_development_image':'6 development images'}[label])
    axs[0].plot([0,1],[0,100],c=INK,lw=1,label='Q ceiling = 100 IoU');axs[0].set(xlabel='BEV IoU',ylabel='Q',ylim=(0,103));axs[0].legend(frameon=False,fontsize=7,loc='upper left')
    axs[1].hist(ok.quality_score,bins=np.arange(0,105,5),color=TEAL,edgecolor='white');axs[1].set(xlabel='Frozen Q',ylabel='Annotation records (not independent trials)')
    for t in [50,85,95]:axs[1].axvline(t,c=AMBER,lw=1,ls='--')
    for ax in axs:ax.grid(alpha=.15)
    fig.tight_layout(w_pad=2);fig.savefig(out/'fixed_distribution.png',dpi=200);plt.close(fig)

def make_report(out,f,c):
    d=Doc(out/'01_中文研究报告.pdf','全景布局质量 v1.1：扩大验证中文报告')
    d.p('全景布局客观几何质量\n扩大验证研究报告'.replace('\n','<br/>'),'title')
    d.p('冻结默认：geom_quality_research_v1.1.0　｜　资料核对与回放日期：2026-10-09','small')
    d.p('建议保留并冻结现有 v1.1，作为固定目标、固定 GT 约定下的条件几何质量分；四档先作为研究分类。它已达到可复现、可解释、可供分档查看的当前研究用途，但尚不能宣称是跨所有顶界与范围语义的绝对实际质量真值。')
    d.table(['本轮结果','实际数量／结论'],[['读取成功','配套数据包 1 个＋原图包 3 个；没有访问失败'],['全量回放','259 张研究图、22 个建筑、3,152 份标注'],['完整质量分','2,979 份；其余 173 份保留原因，不填零'],['新增图片','253 张，其中 245 张至少有一份 Q'],['跨建筑验证','136 张图来自未用于当前选参的 16 个建筑；1,106 份 Q'],['数值复现','旧 36 份完整 JSON：Q 与 2,088 个数值分项最大差均为 0'],['公式／参数','默认核与五个参数均未改；未拟合旧主观分']],widths=[113,W-113])
    d.p('最关键的问题已经从“缺少几何回放”转为“何种房间范围、哪一条顶界是评价目标”。真实坡顶、吊顶、淋浴隔间、遮挡延伸及 GT 简化，会使大几何差异与实际错误不完全等价。改变权重不能从同一份几何中自动裁决这些目标。')
    d.p('本轮不要求先重评，不改旧评分、不重建 GT，也不扩展到人员分类、难度预测或融合算法。全部 3,152 行、不可评价队列和原图证据都保留，供后续按大类查看。')
    d.p('建议先看 02 图册的四档代表，再看相邻档边界及“反例／目标歧义”页；03 是全部 173 份不可评价复审索引。完整精度、配置、代码及来源在复现包。','small')

    d.page('01　资料确实读到了哪些')
    d.table(['内容','实际收到','可读／核对结果'],[['配套 ZIP','455 个实际文件','432 条源清单路径均存在；67 JSON、33 CSV 可解析'],['原图包 01／02／03','99／64／98 张','合计 261；CRC、实际解码及路径核对均成功'],['研究原图','259 张','全部有对应原图，2048×1024'],['仅作 GT 参考原图','2 张','不加入研究图片或标注分母'],['标注／原 GT／修订 GT','3152／259／30','合计 3441 对象；身份与 panel 对应'],['当前旧36＋GT核对','36＋8 个对象','坐标、点对及连接与最新线程基线一致']],widths=[109,110,W-219])
    d.p('图片 ID、对象 ID、canonical ID、原图字节和像素哈希均无重复；没有缺图、解码失败或读取失败。旧六张图与原图包逐字节、逐像素完全一致。')
    d.p('另有两个不同的“重复”口径：12 个历史版本组涉及 26 条记录，多出 14 个版本；206 个同图最终点阵完全相同的组涉及 549 条记录，跨 125 张图，相对每种几何一份多出 343 条。全部保留，后者组内 Q 最大差为 0。它们不能当作独立几何证据，也不用于推断人员行为。')
    d.p('源清单有 7 个文件字节数与实际不同：6 个落在声明的隐私处理范围；历史 real_case_probe.json 少 140 字节的具体来源未由日志解释。所有 21 个核心入口存在；137 条背景仓库链接按说明未整包复制。以上均未记作数据不存在或几何失败，也不据此认证历史源文件逐字节一致。')
    d.p('来源：inventory/inventory_audit.json；image_archive_audit.json；image_code_to_path.csv；identical_array_score_consistency.csv。','small')

    d.page('02　GT、连接与历史版本')
    d.p('先固定参考，再算分。原 36 份严格保留各自 referenceId／referenceVersion；其余按图片采用已存在的 manual_revision，否则 original。共有 28 张研究图有修订参考。本轮没有逐份取更高 IoU、没有在多个 GT 间选最大分。')
    d.p('UwV83HsGsw3-09 使用 R02557（manual_revision），已确认的源点对环序为 [7,6,0,1,2,3,4,5]。最新线程 44 个几何对象与历史包逐项一致，本轮未发现需要裁决的新 GT 版本冲突。yqstnuAEVhm-31 使用 R02781；原 R02780 仍保留。')
    d.table(['参考政策状态','图片／记录数','处理'],[['已明确 GT 实质错误，无批准替代','6 图／24 份','完整 Q 不可评价；保留条件 IoU 诊断'],['历史明确暂停整图分析','2 图／4 份','单列历史 hold；不称为已证明 GT 错误'],['其余固定目标','251 图／3124 份','继续按每份实际输入检查']],widths=[145,95,W-240])
    d.p('六张 GT 裁决图：jtcxE69GiFV-05、jtcxE69GiFV-17、pRbA3pwrgk9-12、uNb9QFRL6hY-32、uNb9QFRL6hY-51、zsNo4HB9uLZ-05。两张历史 hold：jtcxE69GiFV-11、pRbA3pwrgk9-16。28 份的条件 IoU 有数值，但不能作为相对可信目标的质量证据。')
    d.p('23 条 repair_evidence 中，19 条为历史已应用，4 条为建议。R00904 与 R01424 的来源明写“p8:使用原始导出坐标替代历史坐标移动”。当前数组与历史移动版不同是已记录的重初始化，不用更接近参考的旧坐标覆盖。R00904 正常评价；R01424 的 y=3897.282406 超出 512，明确拒绝投影，不自动缩小十倍。')
    d.p('修订 GT 的环序已确认，不等于实测三维或逐段语义已认证。原图发现的新语义疑问只加说明，不自动更换 GT 或改可评价状态。')
    d.p('来源：prepared/reference_bindings_before_scores.csv；latest_thread_vs_snapshot_conflicts.json；audit_geometry/snapshot/repair_evidence_audit23.csv。','small')

    d.page('03　扩大验证与分组边界')
    d.table(['分组','图','有 Q 图','记录','Q 有效','Q 缺'],[['原六张开发图，全量记录',6,6,149,138,11],['开发建筑中的其他图',117,115,1817,1735,82],['16 个新建筑',136,130,1186,1106,80],['新增图片合计',253,245,3003,2841,162],['全库',259,251,3152,2979,173]],widths=[183,39,54,56,60,W-392])
    d.p('原六图除旧 36 份外，还包含 113 份新增记录，其中 102 份有 Q。这是开发图片内补充回放，不能算新增图片验证。全部 22 个建筑均至少有一份有效 Q。')
    d.p('六个开发建筑及其所有房间／视角留在开发侧，其他 16 建筑作为当前冻结参数的扩展验证侧；没有把同图不同人员或同房不同视角随机拆到两边。204 张图有房间编码，对应 102 个“建筑＋房间”组合；55 张房间未知，不把它们当 55 个独立房间。')
    d.p('“未用于当前 v1/v1.1 选参”不等于“此前从未见过”。历史明确几何输入／结果至少出现过 146 张图；新建筑的 136 张图中有 68 张可找到历史几何使用。全部 259 张都曾在历史清单、身份或评审资料中出现。没有独立盲测，也没有从历史没有命中就推断未见过。')
    d.p('资料混合了定向选例、随机抽样和历史重复版本；每图记录数不一致。各图／建筑均值、分位数只描述本次记录，不能直接估计图片总体质量或难度。没有用难度、建筑身份、人员身份、旧分或逐图归一化生成 Q。')
    d.p('扩展中，当前来源确认 OOS 的 24 图／378 份有 349 份 Q，含 6 份高档；门洞困难类 17 图／205 份有 189 份 Q，含 3 份高档。类别没有触发统一排除。后来资料的 OOS 标签口径不同，表中分开保留。')
    d.p('来源：inventory/coverage_results_audit.csv；image_group_registry.csv；record_group_registry.csv。','small')

    d.page('04　几何适配与不可评价状态')
    d.p('复用已准备的 1024×512 连续 ERP 坐标、上下点对和最终环序。按共同地面 Y=-1、相机原点投影，h 为相机到地面的共同单位；全景原图为 2048×1024，仅显示时按二倍像素对应。没有重新配对、重排原始点、删点、拉直、补环或强制曼哈顿化。')
    d.p('来源中 1,265 份环序标为 human_confirmed，1,887 份为 default_unreviewed；全部保留该状态。几何闭环有效不等于环序和表达目标已被人工确认，本轮没有把默认环序改称“已确认”。')
    d.p('严格检查包括零长度边、重叠回退边、非相邻顶点触边、自交、退化面积、配对不竖直、非正墙高及不合法球面边。无效闭环返回不可评价及局部证据。非正交、非平顶、非星形、相机在多边形外、上点低于相机但高于地面，本身均不构成排除理由。')
    d.table(['主原因（互斥）','份数','解释'],[[REASONS['existing_pairing_unresolved'],104,'99 pairing_unavailable＋5 历史 OOS 未能配对；不重新猜配对'],[REASONS['annotation_points_unavailable'],39,'34 原始数组为空；5 有原点但无现有效最终阵列'],[REASONS['reference_adjudicated_error'],24,'固定参考不适用，非单份标注几何失败'],[REASONS['historical_explicit_analysis_hold'],4,'既有整图暂停政策，非已证实无效三维'],[REASONS['annotation_input_domain_invalid'],1,'R01424 的 y 超出声明域，未裁剪／周期投影'],[REASONS['annotation_geometry_invalid'],1,'R01879 只有两对点，不能形成有效面']],widths=[150,36,W-186])
    d.p('因此，173 份不可评价不是“173 份坏标注”。其中 143 份缺已有最终点阵／配对，109 份仍有原始点；不能把它们都说成本轮实证自交或模型不适用。本轮完整 final ring 中没有新增触边、自交或回退边失败，控制实验仍覆盖这些拒绝条件。')
    d.p('输入接口额外拒绝字符串、布尔、复数及混合伪数值；该适配器修补防止 numpy 类型提升掩盖原始布尔值。冻结评分核与研究参数未动，已有实际坐标输出不变。访问失败、文件缺失、GT 缺失均单独登记；本次这些包级计数为 0。')

    d.page('05　推荐公式与分量')
    d.img(out/'figures/formula.png')
    d.table(['分量','定义／单位','为何保留'],[['I','原始已配对底面多边形 BEV IoU，无单位','内容范围与平面位置的主体；保证 Q≤100I'],['S_t、S_b','完整上下边界的球面短大圆弧；对称弧长平均最近角距，度','避免 ERP 经度多值和角点数量权重；表达投影边界偏差'],['S','sqrt((S_t²+S_b²)/2)，度','上下两条边界等权合并'],['H*','max(Hmean,Hlocal)，相对参考均高','保留整体高度惩罚，阻止局部正负抵消'],['D','周长加权边方向到最佳公共正交轴族的 RMS，度','弱近曼哈顿研究偏好；不是所有场景的客观错误'],['F','周长加权顶部角高到最佳常高模型的 RMS，度','弱近同高研究偏好；真实多层顶可能受罚']],widths=[62,251,W-313])
    d.p('S 采用球面短大圆弧，不是纬线小圆弧，也不是同经度相减。每条曲线先计算弧长加权的对称平均最近距离，再将上下结果以 RMS 合并；不要把它误读为对全部点距离直接做 RMS。F 对应结果字段 flat，不是旧诊断表中以 h 为单位的地面距离 F。')
    d.p('面积质心 C、旧 U/B 和条件 3D 线距 T/F 仍输出诊断，没有再次进入 Q。质心与 IoU／边界相关，继续加权缺乏独立证据；方向、平顶总折扣封顶 15%，既不能加分，也不能抵消范围损失。')
    d.p('式中“度”的尺度和最大折扣是可解释的研究设定，不是由物理定律推出的人类合格线。原始几何与量纲是客观事实，选定分数响应的强弱仍含建模选择。')
    d.p('实现：frozen_engine/core/quality_v11.py；legacy_geometry/geometric_components.py；height_revision/height_revision.py。','small')

    d.page('06　局部高度为何不会再被均值抵消')
    d.img(out/'figures/height_definition.png')
    d.p('这里 z_A(s) 表示沿标注底面周长线性插值的局部墙高，不是全局坐标 Z；μ 为相同周长权重的平均墙高。π_G(s) 是到参考有限底面线段的最近投影，参考高度也沿该线段线性插值。反向再算一次，取两个均方误差的平均并开根号，最后除以固定参考均高。')
    d.p('平均高度与高度离散程度相同，也可能在错误位置出现高低反转；因此只比较两个标准差仍有漏洞。当前最近底面投影引入局部位置，能区分正确非平顶复制、反相、错误压平；没有因为答案不平顶就把它排除。')
    d.p('最近点几何等距时，取这些真实最近投影中最大的平方高度残差，不按线段个数平均。该约定避免精确共线加点改变平局权重；它是保守几何匹配规则，不等于语义墙段对应。在近似平行、折返或不同范围布局上，最近墙不一定是语义对应墙，这是现有信息的边界。')
    d.table(['参数／数值设置','冻结值','意义'],[['boundary_half_deg','4°','仅边界误差时 S=4° 使参考项减半'],['height_relative_half','0.5','仅高度误差时 H*=0.5 使参考项减半'],['direction_half_deg／flatness_half_deg','5°／2°','各自有界损失达到一半；不是完整 Q 减半'],['intrinsic_max_discount','0.15','D 与 F 各占最大 7.5% 折扣'],['积分分辨率','球面 2048／方向；高度 4096／方向','固定均匀弧长／周长采样；自身平顶 512'],['数值容差','64×float64 eps 等','仅舍入与退化判断；不自动吸附／修形']],widths=[170,151,W-321],tiny=True)
    d.p('小误差采用二次响应，无硬死区：在 I=1、其他分量为零的孤立响应中，S=0.25° 约为 99.61，S=1° 为 94.12；H*=0.02 约为 99.84，H*=0.10 为 96.15。实际扰动可能同时改变 I、S 和 H，不能将这些孤立值直接当作完整案例分数。')

    d.page('07　传统指标：同一几何，不同问题')
    d.table(['输出','可算份数','口径'],[['2D IoU',3007,'同一原始底面多边形的交／并面积'],['3D IoU：角点均高',3007,'按 HoHoNet 官方 IoU 分支的角点平均房高构成等高棱柱'],['3D IoU：周长均高',3007,'已有周长权重平均房高构成等高棱柱，另列'],['完整 Q 及所需分项',2979,'须有效几何、目标适用且全部必要分量可算'],['旧 U／B 各自',2027,'经度单值上下边界诊断，不是 Q 必要项']],widths=[135,65,W-200])
    d.p('两种条件 3D IoU 都使用 V∩=J×min(hA,hG)，分母为 AA×hA+AG×hG−V∩，J 是同一底面交面积。角点均高为 mean(topY−floorY)；周长均高为沿各底边线性局部高度的周长平均。它们不是非平顶真实多面体的体积交并，也不是实测三维真值。')
    d.p('本实现对应 HoHoNet eval_layout.py 的 IoU 计算分支，并对齐官方像素中心偏移及房高估计：连续 C 坐标减 0.5 后进入官方 +0.5 约定，公共相机高度从 1 到 1.6 的缩放在 IoU 中抵消。没有将整套官方命令行的单值深度分支用于全部 OOS，因此称“官方 IoU 分支定义的复算”，不声称全套官方评测完全通过。官方异常时的填零也不替代本研究的不可评价状态。')
    d.p('精确共线非均匀加点会改变角点个数均值，因此角点均高 3D IoU 可能改变；周长均高 IoU 与 Q 不应改变。这是传统指标定义的点数依赖，不能通过删除共线点掩盖。控制中，原／低墙加点／高墙加点的角点 3D IoU 可为 1、0.55、0.689655，而周长口径均为 1，Q 均相同。')
    d.p('U/B 有 952 份在 Q 有效时不可定义：仅参考非单值 730、两边非单值 192、仅标注非单值 30。另 173 份因完整 Q 不可评价而未计算 U/B，不能都叫边界多值。缺失不填零、不重新分配 Q 权重。28 份目标不适用记录的 2D/3D IoU 仅作诊断。')
    d.p('官方来源：<link href="https://github.com/sunset1995/HoHoNet/blob/master/eval_layout.py" color="#087b8c">github.com/sunset1995/HoHoNet/blob/master/eval_layout.py</link>；本包 vendor 文件与许可证保留。逐条适用性见 metric_availability_counts.csv、legacy_UB_availability_reasons.csv。','small')

    d.page('08　修复回放与控制实验')
    d.img(out/'figures/controls.png')
    d.p('旧 36 份在当前固定 GT 下与冻结 v1.1 完全一致；本轮必要控制子集 38 个、225 个断言全部通过，先前对应 v1.1 结果最大差为 0。无效回退边、非相邻触边仍返回原因；不能因为看起来像矩形就把它修成有效闭环。')
    d.p('审核矩形例：参考墙高 2h，局部 1.01h／2.99h；XZ 放大至 32 时，均值方案约 99.59，v1.1 为 75.10。正负误差不再因平均相等及角距变小而接近满分。合法非平顶的远处复制仍为 99.95；反相为 43.29、错误压平为 75.34。')
    d.p('轻微平移 0.01×sqrt(GT 面积) 得 98.32；整体上界 +0.02h 得 99.54；正方形各边长缩半，即便非常规整，IoU=0.25、Q=1.55。精确共线细分与非均匀细分均未改变 Q。旧 v1 对重叠回退边、非相邻触边曾分别给约 69.74、10.99；v1.1 均不可评价。')
    d.p('来源：validation/focused_control_replay.csv 与 assertions；前次完整控制结果保留于历史材料。本轮表明指定缺陷修复有效，不等于覆盖所有可能几何输入。','small')

    d.page('09　固定参数全库表现与粗分档')
    d.img(out/'figures/fixed_distribution.png')
    d.table(['暂定档位','边界','份数','占有效 Q'],[['高','Q≥95',112,'3.76%'],['较好','85≤Q<95',329,'11.04%'],['一般','50≤Q<85',1297,'43.54%'],['较差','Q<50',1241,'41.66%'],['不可评价','Q=null',173,'不在上述分母内']],widths=[80,131,73,W-284])
    d.p('未按分位数均分，也没有“80 分及格”。阈值是在固定公式上暂定的缺陷强度分层：若其他误差为零，95／85／50 分别至少要求 I≥0.95／0.85／0.50；孤立 S 上限约 0.918°／1.680°／4°；孤立 H* 上限约 0.115／0.210／0.5。多个误差共存时要求更严格。这些是必要界，不是充分合格条件。')
    d.p('当前 112 份高档的最小 I=0.96402、最大 S=0.54148°、最大 H*=0.01985，说明高档确实接近当前目标。它不能证明 GT 省略的内容也完整。全库有 25 份 I<0.5 而 D<2°、F<0.5° 的较规整输入，仍没有突破范围上限。分布不被解读为难图总体质量。')
    d.p('每档保留三份不同建筑代表；每条边界上下各取两份并保证建筑多样性。代表按预定 98／90／70／25 锚点就近选，旧评分不参与。三档阈值同时下移／上移 3 分，会改变 281／236 份归档；边界标签尚未主观标定。')

    d.page('10　真实局部高度修复及相关惩罚')
    d.p('在 2,979 份有效样本上，v1.1 相对相同参数的“仅均高”结构，中位降低 0.0444 分，P90 为 0.4046、P99 为 1.1697、最大 4.1834。超过 1 分的有 52 份，分布于 26 图、10 建筑；15 份跨过当前粗档边界。这个比较是事后机制分解，不是把旧 v1 当作全部扩展资料的历史已运行结果。')
    d.table(['真实例','Hmean / Hlocal','仅均高 → v1.1','说明'],[['R00421 / jh4-02','0.00363 / 0.22254','37.91 → 33.73','平均几乎正确，局部高度差大'],['R00384 / yq-32','0.08461 / 0.16669','59.55 → 55.87','有真实跌级顶，也有实际连线／点位误差'],['R02854 / uNb-19','0.14574 / 0.19776','61.15 → 57.70','部分顶部低于相机，但合法且可评价']],widths=[129,112,107,W-348])
    d.p('为何不重复加很多高度项：H*=max(Hmean,Hlocal)，避免两项直接相加；S 与 H 放在同一分母 1+b+h，未使用 (1+b)(1+h) 产生额外交叉惩罚。自身规整性最多再乘 0.85。')
    d.p('但 I、S 和 H 并非独立证据：同一范围遗漏或位置偏移可以同时影响底面交并、球面边界与最近墙的高度匹配。当前采用相关的几何观察共同压分，不把它们解释为三个独立错误概率。结果表中的范围→边界→高度→自身扣分是为解释总分而设的顺序分解；换顺序会改变每项“扣了几分”，不改变最终 Q。')
    d.p('尺度是为“较大同目标错误应明显受罚、微小误差平滑”而固定的研究刻度。轻微控制通过，严重范围差受 I 上限限制；尚无证据证明每次相关扣分的力度都符合人的绝对感觉。图册保留远处高度敏感及目标歧义反例，不为了吻合旧排序调整。')

    d.page('11　原图核查改变了哪些解释')
    d.table(['案例与固定 Q','可见／几何事实','当前解释'],[['R00186，1.13','淋浴隔间闭环 vs GT 整间浴室；I=0.11661','固定整间目标下严重缺失；不是隔间随意乱画'],['R01114，6.34','坡顶矮墙交界 vs 较高均高包络；I=0.95881','顶界目标歧义；不能认定整份质量近零'],['R01360，52.08 / R02187，97.84','同图底面均接近，低吊顶边 vs 高包络','不可作为已验证绝对实际排序'],['R02075，91.61','线脚与墙角支持斜墙；I=.99011、S=.295°','弱方向先验可能低估；单独做消融'],['R00768，97.05','简化矩形近 GT，原图有局部突出细节','可能高估内容完整性；GT 匹配不能裁决遗漏'],['R01013，25.16 / R02172，25.03','过道翼部／遮挡后延伸未纳入标注','范围／隐藏区域敏感，不是全部可见边界差']],widths=[125,204,W-329])
    d.p('本轮 42 个真实图册案例均进行了图像卡片核查；还查看了关键案例的无叠线原图，并由多份独立目视记录区分事实和假设。新 Q 与分档在核查时可见，旧分隐藏，因此这既不是盲评，也不是新增人工金标准；没有给用户补打新分。')
    d.p('高／较好代表整体接近固定目标；一般档可能由不同缺陷组合组成；较差代表中有清楚的长廊收短，也有范围政策敏感案例。保留原先确定的代表，不把语义复杂者换掉来美化档位。')
    d.p('图册中的“错误候选”初选标签按数值产生；最终中文解释已经据原图修正。尤其 R01360 不能继续叫“已证实边界错误”，R01114 不能叫“整屋标错”。初选及修订说明均留档。')
    d.p('来源：inventory/representatives_visual_review.json；audit_geometry/visual_review_notes.json；validation/real_visual_review.json；visuals/case_captions_zh.json。','small')

    d.page('12　有限尺度对照：没有选一个更漂亮的分布')
    grid=pd.read_csv(ROOT/'validation/expanded_nine_candidates_compact_summary.csv')
    d.table(['S 尺度','H 尺度','跨档份数','中位 ΔQ','最大 |ΔQ|'],[[fmt(r.boundary_half_deg,1),fmt(r.height_relative_half,1),int(r.changed_band_vs_frozen_default),fmt(r.median_delta_Q),fmt(r.max_absolute_delta_Q)] for r in grid.itertuples()],widths=[77,77,100,115,W-369])
    d.p('这九组只覆盖 S=3.5／4／4.5°、H=0.4／0.5／0.6，其余不动。事前合同固定默认与分组，先回放全库；本表是尺度敏感性，不按旧分相关性选权，也不在留出建筑上挑最好方案。')
    d.p('2,621／2,979 份（88.0%）在九组下保持同档；新建筑为 963／1,106（87.1%）。逐份九组分数范围的中位宽度约 5.206，最大 11.855。24,518 对同图不等默认分比较中，488 对至少在一组发生翻转，其原默认差最大 3.562。小分差排序不够稳，不应解释为确定质量高低。')
    d.p('仅改 H 到 0.4 或 0.6，分别改变 22 或 10 份档位；S 的变化影响更大。实际顶界／范围歧义不能靠普遍放宽 S 或 H 解决，因此没有采用任何新默认尺度。没有为了提高旧主观吻合率、压低困难图均分或填满高分档而选参数。')
    d.p('注意：所有参数范围是人为研究刻度，稳定比例不是准确率，也不是统计置信区间。新建筑记录存在历史接触、同房视角和重复几何；本表仅描述固定资料下的数值稳健程度。')

    d.page('13　弱规整性折扣的收益、代价与候选')
    d.p('默认保留 D/F 总计最多 15% 折扣，但它是一种近曼哈顿、近同高偏好，不能全部解释为普适客观误差。251 个有效固定参考的精确复制中，仅两图低于 95：x8F5xyUWy9e-09 为 93.684；wc2JMjhGNzB-14 为 87.553。')
    d.p('x8-09 的真实斜墙有墙角、顶部线脚、踢脚线共同支持，方向先验偏罚较明确。实际 R02075 在 I、S、H 都接近参考时，Q=91.614，其中自身折扣约 6.834 分；去掉该折扣约为 98.448。wc-14 则有柜体／房间包络语义疑问，不能把其高度起伏认证为真实斜顶；取消先验令复制得 100，也不能证明物理正确。')
    d.p('因而另存一个低复杂度诊断：只把 intrinsic_max_discount 从 0.15 改为 0，D/F 仍输出，其余 I/S/H、适用性与分档边界不变。它取消了对真实非正交／多层顶的固有压分，且不会破坏 IoU 上限、局部高度惩罚或分段不变性；代价是完全移除参照之外的独立规整性偏好，无法补救 GT 的错误、短小局部遗漏或目标语义。')
    d.p('该诊断使有效 Q 中位上升 1.704 分，188／2,979 份（6.31%）改档；新建筑 72／1,106、旧六图 5／138、开发建筑其他图 111／1,735。高档从 112 增至 134，同图有 636／24,518 对不等分顺序翻转，最大原分差 6.206。R01114 仅从 6.338 到 6.377；R01360 从 52.084 到 55.798，顶界歧义仍在。')
    prior=ROOT/'validation/prior_ablation/summary.json'
    if prior.exists():
        x=read(prior);d.p('逐条差值、分组跨档与顺序变化均在 validation/prior_ablation/。该候选在默认全量结果及原图已看过之后提出，属于事后机制诊断；不称为独立验证，不用其更高分布作为采用依据。')
    else:d.p('逐条差值、分组跨档与顺序变化在 validation/prior_ablation/。该候选在默认全量结果及原图已看过之后提出，属于事后机制诊断；不称为独立验证，不用其更高分布作为采用依据。')
    d.p('本轮决策：不替换默认 v1.1，也不增加模型复杂度。现有证据足以证明 D/F 的适用边界，尚不足以证明取消折扣后成为跨所有场景更准确的绝对质量分。冻结默认时必须把这个偏好写进定义；若未来决定评价目标完全不含规整性偏好，λ=0 可作为明确、可审核的替代版本，不必再枚举大量权重。')

    d.page('14　仍未解决的反例与使用边界')
    d.table(['未解决问题','具体证据','为什么当前几何不够'],[['短小但重要的内容','宽约 0.02h、深 1h 的窄凹口填平仍可 Q=98.57','面积／周长平均对短区域权重小；语义重要性不等于几何长度'],['极短局部高度尖峰','±0.99h 的极短脉冲，Q=99.93','有限长度占比很小；局部 RMS 修复不是最坏点惩罚'],['同图不同目标','淋浴间 vs 整间；矮墙顶 vs 高包络','缺少统一目标对象／边界层级声明'],['参考缺真实细节','R00768 高分且 GT 简化；R00384 多层顶','几何近 GT 无法裁决真实内容优劣'],['最近墙不等于对应墙','不同范围、邻近折返墙的最近底面投影','没有语义墙段对应或实测空间结构'],['透视／模型条件','共同地面、竖直墙、相机尺度的条件重建','真实地面高差、曲面、独立房间等可能超出模型']],widths=[109,181,W-290])
    d.p('已验证的结论：同一目标控制下平移、范围缩减、整体和局部高度误差按预期受罚；严重缺失不被规整性补偿；共线分段不变；轻微误差响应平滑；非法闭环不修形。尚未验证的结论：每个真实低分都差、所有同分同质、95／85／50 是人的稳定边界、库存均值代表图片总体难度。')
    d.p('粗档可用于本轮组织查看与探索，使用时须同时带上 Q、分项、固定 GT、适用性、范围／顶界疑问标签。不可评价单列，不参加低质量人数，也不能静默删除。暂不把几何诊断推演成人员分类、难度模型或融合参数。')
    d.p('没有需要阻断当前方案选择的人工问题。后续你只需看各档代表与边界是否整体合适；若要进一步宣称“绝对实际质量”，最小的额外决定是顶界层级和局部隔间是否允许独立作为目标，而不是先全面重评或强行复刻旧 36 分。')

    d.page('15　版本、复现与交付索引')
    d.p('冻结评分版本保持 geom_quality_research_v1.1.0，定义冻结时间为 2026-10-08 16:20:18 UTC。本次发布是 expanded_20261009：新增适配、资料核对、全库结果、图册与有限诊断，不覆盖旧 v1 或 v1.1 结果。旧 frozen_parameters.json 的“尚未读取扩展数据”是当时历史元数据，本次实际覆盖另存 release JSON，不能把旧状态误当成本轮结论。')
    d.table(['交付','用途'],[['01_中文研究报告.pdf','独立中文结论、公式、尺度、覆盖、失败与限制'],['02_粗分档与边界图册.pdf','42 份真实案例＋2 个 GT 复制控制＋机制图；旧分隐藏'],['03_不可评价复审图册.pdf','全部 173 份，原图／原始点或原环／BEV／条件3D'],['delivery_tables/','完整逐份 CSV、中文简表、图片／建筑汇总、有效数与失败原因'],['prepared/ 与 frozen_engine/','原始源记录、既定配对／连接、固定 GT 绑定与冻结评分核'],['validation/、audit_geometry/、inventory/','38 控制、敏感性、GT消融、对照与独立核查记录'],['reproduce.py、requirements.txt','在新目录完成全量与控制复现；不需要旧主观分'],['visuals/cards/','217 张原图证据卡；PDF可放大，JPG便于逐张核对']],widths=[209,W-209])
    d.p('完整复现包包含冻结几何，重算 Q 无需重新解包三份原图。若重建图卡，将原图包解到同一目录形成 images/&lt;building&gt;/...，运行 render_evidence.py --images-dir &lt;该目录&gt;。不把约 490 MB 原图再复制入结果包；四份用户原包独立保留。')
    d.p('一般运行：python reproduce.py --out replay_local；实际依赖版本写在 requirements.txt。输出另存并与预期逐条比较，包括数值、null、状态、原因与 GT ID／版本。所有源输入坐标及旧 36 评分原样保留，未参与当前参数优化。')
    d.p('公开技术来源：HoHoNet 官方 eval_layout.py 与对应 post_proc.py（仓库许可证随代码）；其余结论直接来自本轮附带原始资料、可复现控制与记录级审计。没有把模型条件重建称为实测 3D。')
    pages=d.build();(out/'01_中文研究报告.txt').write_text('\n\n'.join(d.text)+'\n',encoding='utf-8');return pages

def card(d,out,rid,frame,heading=None,na=False):
    if rid.startswith('GT_COPY_'):
        x=pd.read_csv(ROOT/'validation/expanded_reference_copy_prior_check.csv').set_index('reference_id').loc[rid[8:]]
        d.p(f'参考精确复制控制　{rid}　Q={float(x.exact_copy_Q_from_intrinsic_prior):.2f}','h2')
    else:
        r=frame.loc[rid];title=heading or ('不可评价' if na else f'{r.quality_band}档　Q={r.quality_score:.2f}')
        d.p(f'{title}　｜　{rid}　{r.image_code}','h2')
    d.img(ROOT/'visuals/cards'/f'{rid}.jpg')
    if na:
        r=frame.loc[rid];why=REASONS.get(r.unavailable_primary_reason,r.unavailable_primary_reason)
        extra=''
        if r.unavailable_primary_reason=='annotation_input_domain_invalid':extra='原始 y=3897.282406 超出 512；保留异常点，不缩小、裁剪或修复。'
        elif r.unavailable_primary_reason=='annotation_geometry_invalid':extra='仅两对点；右图只是输入线框，不是有效实体。'
        elif r.unavailable_primary_reason=='reference_adjudicated_error':extra='沿用既有 GT 实质错误裁决，未批准替代。'
        elif r.unavailable_primary_reason=='historical_explicit_analysis_hold':extra='几何可计算；保留历史明确整图暂停，不称为实证几何失败。'
        else:extra=f'原始点数 {int(r.original_point_count)}；未发明点对或连接。'
        d.p(esc(f'{why}。{extra} 2D IoU={fmt(r.iou_2d,4)}；角点均高3D={fmt(r.iou_3d_corner_mean,4)}。'),'small')
    else:
        if not rid.startswith('GT_COPY_'):
            r=frame.loc[rid];d.p(f'I={fmt(r.iou_2d,4)}　3D角点／周长={fmt(r.iou_3d_corner_mean,4)}／{fmt(r.iou_3d_perimeter_mean,4)}　S={fmt(r.boundary_rms_deg,3)}°　H*={fmt(r.Hstar,4)}　D={fmt(r.dir,2)}°　F={fmt(r.flat,2)}°','small')
        d.p(esc(CAPTIONS[rid]),'small')
    d.story.append(Spacer(1,7))

def make_atlases(out,f,c):
    frame=f.set_index('record_id');sel=pd.read_csv(ROOT/'visuals/atlas_selection.csv')
    assert set(sel.record_id)<=set(CAPTIONS)
    savej(ROOT/'visuals/case_captions_zh.json',{'schema':'post_visual_interpretation_v1','old_subjective_ratings_used':False,'new_score_visible_during_review':True,'selection_changed_after_visual_review':False,'captions':CAPTIONS,'interpretation_corrections':{'R01360':'Initial numeric tag same_image_boundary_error is not a verified physical error; target ceiling level remains ambiguous.','R01114':'Large top discrepancy is verified; near-zero absolute actual quality is not verified.','R01672':'Lower structural-edge choice is involved; not purely random location error.'}})
    d=Doc(out/'02_粗分档与边界图册.pdf','全景布局 v1.1：粗分档、边界与反例图册')
    d.p('粗分档、边界与反例\n先看图，再判断整体'.replace('\n','<br/>'),'title')
    d.p('42 份真实记录＋2 个参考复制控制　｜　旧主观评分与备注不展示','h2')
    d.table(['研究档','范围','全库份数'],[['高','Q≥95',112],['较好','85≤Q<95',329],['一般','50≤Q<85',1297],['较差','Q<50',1241],['不可评价','单独复审，不属最低档',173]],widths=[103,270,W-373])
    d.p('阅读顺序：四档代表 → 相邻档上下边界 → 高估／低估及目标歧义 → 参考复制和控制实验。代表按 98、90、70、25 的固定锚点就近选，每档跨三个建筑；边界上下各两份。看图后只修正解释，没有换掉“不够好看”的代表。')
    d.p('青线为当前已准备标注，橙虚线为固定 GT。原图上的弯线是原三维直边的球面投影，不是重新拟合的图像边。BEV 与 3D 对同一标注／GT 共用单位、范围和真实轴比例，没有分别对齐或缩放。不同页面的视域可变，单位始终是 h（相机到地面距离），不是米。')
    d.p('高分首先表示对固定简化目标的几何吻合；低分可能包含范围、顶界选择差异。重点看整体档位是否反映缺陷程度，不将阈值两侧极小差异当成质量突变。当前 Q 在目视时已知，因此这不是盲评或新增人工金标准。')
    d.p('42 份真实案例来自 '+str(sel.image_code.nunique())+' 张图、'+str(sel.building.nunique())+' 个建筑。全部 173 份不可评价见另册；本册不混入最低质量档。','small')
    reps=sel[sel.atlas_section.str.startswith('representative')].record_id.tolist()
    borders=['R00135','R01042','R02428','R01000','R01292','R00069','R00350','R01407','R03106','R00896','R00096','R03339']
    diagnostics=sel[sel.atlas_section.str.startswith('diagnostic')].record_id.tolist()
    for label,ids in [('四档代表',reps),('相邻档边界',borders),('反例、目标歧义与机制案例',diagnostics),('参考精确复制：检验弱自身先验',['GT_COPY_R02762','GT_COPY_R02739'])]:
        for k in range(0,len(ids),2):
            d.page(f'{label}　{k//2+1}/{math.ceil(len(ids)/2)}')
            for rid in ids[k:k+2]:card(d,out,rid,frame)
    d.page('控制实验：可验证的规律与未修复盲点')
    d.img(out/'figures/controls.png')
    d.p('同目标平移／高度扰动按幅度受罚；远处高低抵消已修复；合法非平顶复制仍能高分。控制不是新真实标注，不进入 3,152 份统计。')
    d.table(['控制','v1.1 Q','解释'],[['规整但边长缩为一半',fmt(c.set_index('case_id').loc['rectangle_scale_0.5','quality_score']),'I=0.25，范围缺失不能被规整补偿'],['细窄凹口被填平','98.57','仍可能高估重要的短小结构'],['极短局部高度正负脉冲','99.93','平均/RMS 对很短区域仍不敏感'],['精确共线加点','不变','边界与高度按长度积分，非按顶点计数']],widths=[175,64,W-239])
    pages_main=d.build()
    na=f[f.score_status!='available'].sort_values(['unavailable_primary_reason','building','image_code','record_id'])
    d=Doc(out/'03_不可评价复审图册.pdf','全景布局 v1.1：全部不可评价记录')
    d.p('不可评价复审图册','title');d.p('173 份全部保留；与质量高低分开','h2')
    d.table(['主原因','记录数'],[[REASONS[k],int(v)] for k,v in na.unavailable_primary_reason.value_counts().items()],widths=[W-80,80])
    d.p('143 份缺少现成的最终点阵或配对；其中 109 份有非空原始点、34 份原数组为空。显示原始散点时不发明连接，BEV／3D 只显示可用参考。原点、既有点对和来源全部保存在逐条复审 JSON。')
    d.p('R01424 为原坐标域异常，R01879 为两点对退化。24 份因明确 GT 裁决、4 份因历史整图 hold 没有 Q；这 28 份几何有条件 IoU，但不能当作可靠目标下的完整质量分。原参考仍展示，不自动选另一版。')
    d.p('图中青线／散点为当前输入，橙线为固定参考；同一对照使用同一条件尺度。某些图片能看到有效局部形状，仍不足以授权本轮重新清洗、配对或修改源坐标。此册的任何条目均不记为零分或最低质量档。')
    ids=na.record_id.tolist()
    for k in range(0,len(ids),2):
        d.page(f'复审条目　{k+1}–{min(k+2,len(ids))} / {len(ids)}')
        for rid in ids[k:k+2]:card(d,out,rid,frame,na=True)
    pages_na=d.build();return pages_main,pages_na

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=ROOT.parents[1]/'output/layout_quality_v1_1_expanded_20261009');args=ap.parse_args();out=args.out;out.mkdir(parents=True,exist_ok=True)
    font=out/'figures/cjk.ttf';font.parent.mkdir(parents=True,exist_ok=True)
    if not font.exists():font.write_bytes(fitz.Font('china-s').buffer)
    pdfmetrics.registerFont(TTFont('CJK',str(font)))
    f=pd.read_csv(ROOT/'results_fixed/all_records_scores.csv');c=pd.read_csv(ROOT/'validation/focused_control_replay.csv');figures(out/'figures',f,c)
    a=make_report(out,f,c);b,z=make_atlases(out,f,c);savej(out/'publication_build.json',{'report_pages':a,'atlas_pages':b,'unavailable_atlas_pages':z,'records':len(f),'old_subjective_scores_loaded':False,'main_real_cases':42,'reference_copy_controls':2,'all_NA_cases':173});print(json.dumps({'report_pages':a,'atlas_pages':b,'NA_atlas_pages':z},ensure_ascii=False))

if __name__=='__main__':main()
