"""Join frozen Q results to independent inventory/grouping evidence.

No score is recomputed, no parameter is selected, and no original output is
modified. Aggregates describe these observed records only.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with Path(path).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fields); w.writeheader()
        for r in rows:
            w.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list,dict)) else v for k,v in r.items()})


def finite(r, field):
    try:
        return math.isfinite(float(r[field]))
    except (KeyError, ValueError, TypeError):
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = ap.parse_args()
    root = args.root.resolve(); inv = root / 'inventory'; scores_path = root / 'results_fixed/all_records_scores.csv'
    scores = read_csv(scores_path)
    image_groups = {r['image_code']:r for r in read_csv(inv / 'image_group_registry.csv')}
    records = {r['id']:r for r in read_csv(inv / 'record_group_registry.csv')}
    image_paths = {r['image_code']:r for r in read_csv(inv / 'image_code_to_path.csv')}
    spec = importlib.util.spec_from_file_location('frozen_legacy_ring_status_audit', root / 'frozen_engine/legacy_geometry/audit_geometry.py')
    legacy = importlib.util.module_from_spec(spec); spec.loader.exec_module(legacy)
    geometry = json.loads((root / 'prepared/frozen_expanded_geometry.json').read_text())
    geometry_lookup = {r['id']:r for im in geometry['images'] for r in im['annotations']+im['groundtruths']}
    status_cache = {}
    legacy_UB_rows = []
    assert len(scores) == len(records) == 3152
    assert len({r['record_id'] for r in scores}) == len(scores)
    assert set(r['record_id'] for r in scores) == set(records)
    joined = []
    for r in scores:
        rid = r['record_id']; ig = image_groups[r['image_code']]; rg = records[rid]
        assert rg['image_code'] == r['image_code'] and rg['building'] == r['building']
        assert rg['old_selected36'] == r['old36_record']
        row = dict(r)
        row.update(inventory_parameter_group=ig['current_parameter_group'],
                   inventory_building_group_role=ig['building_group_role'],
                   inventory_historical_geometry_result_found=ig['historical_geometry_result_found'],
                   inventory_historical_geometry_sources=ig['historical_geometry_sources'],
                   inventory_historical_identity_mentioned=ig['historical_identity_mentioned'],
                   inventory_historical_identity_sources=ig['historical_identity_sources'],
                   inventory_historical_exposure=ig['historical_exposure'],
                   inventory_room_known=bool(r['room']),
                   inventory_independent_blind_test=False,
                   inventory_duplicate_version_group=rg['duplicate_version_group'],
                   decoded_original_image_path=image_paths[r['image_code']]['extracted_path'])
        n = int(r['pair_count']) if r['pair_count'] else None
        row['inventory_pair_count_category'] = ('missing_final_geometry' if n is None else
                                                 'under_3' if n < 3 else
                                                 '3_to_4' if n <= 4 else
                                                 '5_to_6' if n <= 6 else
                                                 '7_to_8' if n <= 8 else
                                                 '9_to_12' if n <= 12 else '13_or_more')
        diagnostics = {}
        if finite(row, 'U') and finite(row, 'B'):
            ub_reason = 'available'
        elif not finite(row, 'quality_score'):
            ub_reason = 'not_computed_complete_quality_unavailable'
            diagnostics = {'complete_quality_primary_reason': row['unavailable_primary_reason']}
        else:
            bad_roles = []
            for role, key in [('annotation', 'record_id'), ('reference', 'reference_id')]:
                oid = row[key]
                if oid not in status_cache:
                    status_cache[oid] = legacy.ring_status(geometry_lookup[oid])
                diagnostics[role] = status_cache[oid]
                if not status_cache[oid]['single_valued_recomputed']:
                    bad_roles.append(role)
            ub_reason = ('_and_'.join(bad_roles)+'_not_single_valued' if bad_roles else 'unexpected_null_needs_review')
        row['inventory_legacy_UB_availability_reason'] = ub_reason
        row['inventory_legacy_UB_diagnostics'] = diagnostics
        legacy_UB_rows.append(dict(record_id=rid, image_code=row['image_code'], reference_id=row['reference_id'],
                                   U_available=finite(row,'U'), B_available=finite(row,'B'), Q_available=finite(row,'quality_score'),
                                   reason=ub_reason, evidence=diagnostics,
                                   interpretation='Same frozen legacy ring_status sampled-azimuth test, not a new gate for Q. Not-computed and undefined are distinct.'))
        joined.append(row)

    def summarise(axis, category, rows):
        q = [r for r in rows if finite(r, 'quality_score')]
        images = {r['image_code'] for r in rows}; good_images = {r['image_code'] for r in q}
        buildings = {r['building'] for r in rows}; good_buildings = {r['building'] for r in q}
        x = dict(grouping_axis=axis, category=category, records_all=len(rows), images_all=len(images), buildings_all=len(buildings),
                 Q_available=len(q), Q_unavailable=len(rows)-len(q), images_with_Q=len(good_images), images_without_Q=len(images-good_images),
                 buildings_with_Q=len(good_buildings), buildings_without_Q=len(buildings-good_buildings),
                 band_ge95=sum(r['quality_band']=='高' for r in rows), band_85_to95=sum(r['quality_band']=='较好' for r in rows),
                 band_50_to85=sum(r['quality_band']=='一般' for r in rows), band_lt50=sum(r['quality_band']=='较差' for r in rows),
                 band_unavailable=sum(r['quality_band']=='不可评价' for r in rows),
                 annotation_2d_valid=sum(r['annotation_valid_2d']=='True' for r in rows),
                 annotation_3d_valid=sum(r['annotation_valid_3d']=='True' for r in rows),
                 iou2d_available=sum(finite(r,'iou_2d') for r in rows),
                 iou3d_corner_mean_available=sum(finite(r,'iou_3d_corner_mean') for r in rows),
                 iou3d_perimeter_mean_available=sum(finite(r,'iou_3d_perimeter_mean') for r in rows),
                 boundary_U_available=sum(finite(r,'U') for r in rows), boundary_B_available=sum(finite(r,'B') for r in rows),
                 S_top_available=sum(finite(r,'S_top_deg') for r in rows), S_bottom_available=sum(finite(r,'S_bottom_deg') for r in rows),
                 Hlocal_available=sum(finite(r,'Hlocal') for r in rows),
                 unavailable_primary_counts=dict(collections.Counter(r['unavailable_primary_reason'] for r in rows if not finite(r,'quality_score'))),
                 observed_record_Q_median=statistics.median(float(r['quality_score']) for r in q) if q else None,
                 not_population_quality_or_difficulty=True, independent_blind_test=False)
        assert x['Q_available'] + x['Q_unavailable'] == x['records_all']
        assert sum(x[k] for k in ['band_ge95','band_85_to95','band_50_to85','band_lt50','band_unavailable']) == len(rows)
        return x
    groups = [summarise('overall', 'all_records', joined)]
    axes = [
        ('parameter_selection_group', 'inventory_parameter_group'),
        ('building_role', 'inventory_building_group_role'),
        ('documented_historical_geometry_presence', 'inventory_historical_geometry_result_found'),
        ('room_binding_known', 'inventory_room_known'),
        ('source_OOS_status_not_used_for_Q', 'scene_oos_status'),
        ('source_doorway_status_not_used_for_Q', 'scene_doorway_status'),
        ('later_scene_label_not_used_for_Q', 'later_scene_description'),
        ('historical_difficulty_label_not_used_for_Q', 'historical_difficulty_not_used_for_Q'),
        ('existing_final_pair_count', 'inventory_pair_count_category'),
        ('source_ring_human_confirmed', 'ring_human_confirmed'),
        ('original36_membership', 'old36_record'),
        ('fixed_reference_version', 'reference_version'),
    ]
    for axis, key in axes:
        categories = collections.defaultdict(list)
        for r in joined: categories[str(r[key])].append(r)
        partial = [summarise(axis, c, rows) for c,rows in sorted(categories.items())]
        assert sum(r['records_all'] for r in partial) == len(joined)
        groups.extend(partial)
    new = [r for r in joined if r['inventory_parameter_group'] != 'current_v1_v11_development_image']
    groups.append(summarise('validation_scope', 'all_253_additional_images', new))
    newb = [r for r in joined if r['inventory_building_group_role'] == 'fixed_parameter_validation_building']
    groups.append(summarise('validation_scope', '16_whole_new_buildings', newb))
    devnew = [r for r in joined if r['inventory_parameter_group'] == 'current_v1_v11_development_image' and r['old36_record'] != 'True']
    groups.append(summarise('validation_scope', '113_additional_records_in_six_development_images', devnew))
    by_image = [summarise('image', code, [r for r in joined if r['image_code']==code]) for code in sorted(image_groups)]
    by_building = [summarise('building', code, [r for r in joined if r['building']==code]) for code in sorted({r['building'] for r in joined})]
    noQ = [dict(row, building=image_groups[row['category']]['building'], room=image_groups[row['category']]['room'],
                parameter_group=image_groups[row['category']]['current_parameter_group']) for row in by_image if row['Q_available']==0]
    metric_rows = []
    for field in ['quality_score','iou_2d','iou_3d_corner_mean','iou_3d_perimeter_mean','C','U','B','T','F','S_top_deg','S_bottom_deg','Hmean','Hlocal','Hstar','flat','dir']:
        available = [r for r in joined if finite(r,field)]
        metric_rows.append(dict(metric=field, records_available=len(available), records_unavailable=len(joined)-len(available),
                                images_with_metric=len({r['image_code'] for r in available}), buildings_with_metric=len({r['building'] for r in available})))
    score_lookup = {r['record_id']:r for r in joined}
    repeated_array_checks = []
    for group in read_csv(inv / 'same_image_identical_final_array_groups.csv'):
        rids = json.loads(group['record_ids']); members = [score_lookup[rid] for rid in rids]
        values = [float(r['quality_score']) for r in members if finite(r,'quality_score')]
        repeated_array_checks.append(dict(image_code=group['image_code'], record_ids=rids,
                                           records=len(rids), Q_available=len(values),
                                           reference_ids=sorted({r['reference_id'] for r in members}),
                                           statuses=sorted({r['score_status'] for r in members}),
                                           Q_max_difference=max(values)-min(values) if values else None,
                                           arrays_identical_not_independent_geometry_evidence=True))
    summary = dict(schema='expanded_v11_coverage_results_inventory_audit_v1',
                   score_file=str(scores_path), score_file_sha256=hashlib.sha256(scores_path.read_bytes()).hexdigest(),
                   joined_records=len(joined), record_ids_exactly_match_inventory=True, old36_membership_matches=True,
                   metrics=metric_rows, aggregate_groups=groups, no_Q_images=noQ,
                   additional_image_scope=groups[-3], new_building_scope=groups[-2],
                   additional_records_in_development_images=groups[-1],
                   repeated_final_array_groups_checked=len(repeated_array_checks),
                   repeated_array_max_Q_difference=max((r['Q_max_difference'] for r in repeated_array_checks if r['Q_max_difference'] is not None), default=None),
                   repeated_arrays_with_different_Q=[r for r in repeated_array_checks if r['Q_max_difference'] is not None and r['Q_max_difference']>1e-9],
                   legacy_UB_availability_reasons=dict(collections.Counter(r['reason'] for r in legacy_UB_rows)),
                   interpretation=['Only finite, already produced fixed-parameter metrics count as available; no missing value is changed to zero.',
                                   'Labels for OOS, doorway, difficulty, order and historical gates are descriptive strata and were not added to Q.',
                                   'At least one available annotation defines image_with_Q; this does not imply every annotation in the image is available or good.',
                                   'Record medians/band proportions describe this archive mixture, not image population quality, difficulty, worker quality or random-sample prevalence.',
                                   'Image/building counts in record-level strata such as pair count can overlap. images_without_Q means no available Q within that stratum, not necessarily no Q for the entire image.',
                                   'The 16 new buildings were not used for current v1/v1.1 parameter selection, but remain historical programme material, not a blind test.'])
    write_csv(inv / 'joined_newscore_inventory.csv', joined)
    write_csv(inv / 'coverage_results_audit.csv', groups)
    write_csv(inv / 'coverage_results_by_image.csv', by_image)
    write_csv(inv / 'coverage_results_by_building.csv', by_building)
    write_csv(inv / 'images_without_evaluable_Q.csv', noQ)
    write_csv(inv / 'independent_metric_availability_counts.csv', metric_rows)
    write_csv(inv / 'identical_array_score_consistency.csv', repeated_array_checks)
    write_csv(inv / 'legacy_UB_availability_reasons.csv', legacy_UB_rows)
    (inv / 'coverage_results_audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:summary[k] for k in ['additional_image_scope','new_building_scope','additional_records_in_development_images','metrics','no_Q_images']}, ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
