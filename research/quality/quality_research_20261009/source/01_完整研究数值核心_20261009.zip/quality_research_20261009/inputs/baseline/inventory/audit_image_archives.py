"""Audit and extract original image archives without editing image bytes.

The three archives contain identically named README.txt files.  They are preserved
separately in inventory/archive_readmes; only images/... entries are extracted to
the common original_images directory. This is packaging, not geometry repair.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile
from PIL import Image


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path, rows):
    with Path(path).open('w', encoding='utf-8-sig', newline='') as f:
        keys = list(dict.fromkeys(k for row in rows for k in row))
        writer = csv.DictWriter(f, keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument('--previous-photos', type=Path, default=Path('source/oct8-pro-quality-handoff/inputs/original_photos'))
    args = ap.parse_args()
    root = args.root.resolve()
    inv = root / 'inventory'
    inv.mkdir(parents=True, exist_ok=True)
    (inv / 'archive_readmes').mkdir(exist_ok=True)
    destination = root / 'original_images'
    destination.mkdir(exist_ok=True)
    manifest = json.loads((root / 'data_snapshot/image_manifest.json').read_text())
    expected = {(m['image_zip'], m['internal_path']): m for m in manifest}
    summaries, rows, issues, seen_paths = [], [], [], {}
    archives = sorted((root / 'raw_archives/3d全景图').glob('pro_quality_original_images_*.zip'))
    for archive in archives:
        summary = dict(archive=archive.name, actual_bytes=archive.stat().st_size,
                       archive_sha256=sha256_file(archive), entries=0, decoded_images=0,
                       entry_read_failures=0, decoding_failures=0, access_status='read_success')
        with zipfile.ZipFile(archive) as z:
            infos = z.infolist()
            summary['entries'] = len(infos)
            summary['duplicate_names_within_archive'] = [k for k, v in collections.Counter(x.filename for x in infos).items() if v > 1]
            for entry in infos:
                path = PurePosixPath(entry.filename)
                if path.is_absolute() or '..' in path.parts or '\\' in entry.filename:
                    raise ValueError(f'Unsafe path: {archive.name}:{entry.filename}')
                if entry.is_dir():
                    continue
                try:
                    data = z.read(entry)  # zipfile verifies CRC for each entire read.
                except Exception as e:
                    summary['entry_read_failures'] += 1
                    issues.append(dict(archive=archive.name, path=entry.filename, category='archive_read_failure', error=repr(e)))
                    continue
                if entry.filename == 'README.txt':
                    (inv / 'archive_readmes' / (archive.stem + '_README.txt')).write_bytes(data)
                    continue
                if not entry.filename.startswith('images/'):
                    issues.append(dict(archive=archive.name, path=entry.filename, category='unexpected_nonimage_entry'))
                    continue
                m = expected.get((archive.name, entry.filename))
                if m is None:
                    issues.append(dict(archive=archive.name, path=entry.filename, category='actual_image_without_manifest'))
                    m = {}
                digest = hashlib.sha256(data).hexdigest()
                if entry.filename in seen_paths:
                    issues.append(dict(archive=archive.name, path=entry.filename, category='duplicate_image_internal_path', first_archive=seen_paths[entry.filename]))
                    # Do not silently overwrite a repeated original.
                    continue
                seen_paths[entry.filename] = archive.name
                out = destination / entry.filename
                out.parent.mkdir(parents=True, exist_ok=True)
                if out.exists() and out.read_bytes() != data:
                    raise ValueError(f'Existing extraction differs; refusing overwrite: {out}')
                if not out.exists():
                    out.write_bytes(data)
                row = dict(image_code=m.get('image_code', ''), image_id=m.get('image_id', ''),
                           building=m.get('building', ''), room=m.get('room', ''),
                           population=m.get('population', ''), archive=archive.name,
                           internal_path=entry.filename, extracted_path=str(out),
                           image_bytes=len(data), image_sha256=digest, crc32=f'{entry.CRC:08x}',
                           crc_read='passed', manifest_bytes=m.get('bytes'),
                           bytes_match_manifest=(len(data) == m.get('bytes')), status='not_decoded')
                try:
                    with Image.open(io.BytesIO(data)) as im:
                        fmt = im.format
                        im.load()
                        row.update(width=im.width, height=im.height, mode=im.mode, format=fmt,
                                   pixels_rgb_sha256=hashlib.sha256(im.convert('RGB').tobytes()).hexdigest(),
                                   dimensions_match_manifest=(im.width == m.get('original_width') and im.height == m.get('original_height')),
                                   status='decoded')
                    summary['decoded_images'] += 1
                except Exception as e:
                    row.update(status='decoding_failure', error=repr(e))
                    summary['decoding_failures'] += 1
                    issues.append(dict(archive=archive.name, path=entry.filename, category='decoding_failure', error=repr(e)))
                prior = args.previous_photos / (m.get('image_code', '') + '.png')
                if prior.is_file():
                    old_bytes = prior.read_bytes()
                    with Image.open(io.BytesIO(old_bytes)) as im:
                        im.load()
                        old_pixel_sha = hashlib.sha256(im.convert('RGB').tobytes()).hexdigest()
                    row.update(previous_photo_path=str(prior.resolve()), previous_byte_sha256=hashlib.sha256(old_bytes).hexdigest(),
                               previous_byte_identical=(old_bytes == data),
                               previous_pixels_identical=(old_pixel_sha == row.get('pixels_rgb_sha256')))
                rows.append(row)
        summary['research_images'] = sum(r['archive'] == archive.name and r['population'] == 'research_annotation_image' for r in rows)
        summary['reference_only_images'] = sum(r['archive'] == archive.name and r['population'] != 'research_annotation_image' for r in rows)
        summaries.append(summary)
        print(f"{archive.name}: {summary['decoded_images']} images decoded, read failures {summary['entry_read_failures']}, decode failures {summary['decoding_failures']}", flush=True)
    actual = {(r['archive'], r['internal_path']) for r in rows}
    missing = [dict(image_code=m['image_code'], archive=m['image_zip'], internal_path=m['internal_path'],
                    category='expected_image_not_read_from_archive') for k, m in expected.items() if k not in actual]
    issues.extend(missing)
    duplicates = {}
    for key in ['image_code', 'image_id', 'image_sha256', 'pixels_rgb_sha256']:
        groups = collections.defaultdict(list)
        for row in rows:
            if row.get(key):
                groups[row[key]].append(row['image_code'])
        duplicates[key] = {k: v for k, v in groups.items() if len(v) > 1}
    summary = dict(schema='expanded_v11_image_archive_audit_v1', archives=summaries,
                   expected_manifest_images=len(manifest), actual_images=len(rows), decoded_images=sum(r['status'] == 'decoded' for r in rows),
                   research_images=sum(r['population'] == 'research_annotation_image' for r in rows),
                   reference_only_images=sum(r['population'] != 'research_annotation_image' for r in rows),
                   dimensions=dict(collections.Counter(f"{r.get('width')}x{r.get('height')}" for r in rows)),
                   bytes_mismatching_manifest=sum(not r['bytes_match_manifest'] for r in rows),
                   dimensions_mismatching_manifest=sum(not r.get('dimensions_match_manifest', False) for r in rows),
                   duplicate_groups=duplicates, missing_expected_images=len(missing), issues=issues,
                   prior_six_photos_checked=sum('previous_byte_identical' in r for r in rows),
                   prior_six_byte_identical=sum(r.get('previous_byte_identical', False) for r in rows),
                   prior_six_pixel_identical=sum(r.get('previous_pixels_identical', False) for r in rows),
                   interpretation='Actual ZIP bytes were fully CRC-read, decoded, SHA256 hashed and extracted unchanged. Decode is not visual semantic inspection. Archive README files are preserved separately to avoid name collisions.')
    write_csv(inv / 'image_code_to_path.csv', rows)
    write_csv(inv / 'image_archive_issues.csv', issues)
    (inv / 'image_archive_audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['archives','duplicate_groups','issues']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
