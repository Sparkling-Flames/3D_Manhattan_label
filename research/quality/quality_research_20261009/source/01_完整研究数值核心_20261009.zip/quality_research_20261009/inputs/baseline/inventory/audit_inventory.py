"""Read-only inventory, identity, grouping and historical-exposure audit.

This script does not evaluate Q, reinterpret eligibility, edit points or infer
that an image is blind/unseen merely because no prior result was found.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import re


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def write_csv(path, rows):
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def counter(rows, key):
    return dict(collections.Counter(str(x.get(key)) for x in rows))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument('--prior-frozen', type=Path, default=Path('source/oct8-pro-quality-handoff/inputs/frozen_geometry.json'))
    args = ap.parse_args()
    root = args.root.resolve()
    base = root / 'data_snapshot'
    out = root / 'inventory'
    out.mkdir(parents=True, exist_ok=True)
    def read(rel):
        return json.loads((base / rel).read_text())

    manifest = read('image_manifest.json')
    panel = read('current/panel.json')['images']
    records = read('current/records.json')['objects']
    image_rows = read('current/image_inventory.json')['images']
    room_groups = read('current/room_registry.json')['groups']
    duplicates = read('current/duplicate_versions.json')
    ids = read('current/identity_binding.json')['records']
    source_inv = read('source_inventory.json')['files']
    privacy_paths = {x['path'] for x in read('privacy_projection.json')['private_path_redactions']}
    annotations = [r for r in records if r['object_kind'] == 'annotation']
    references = [r for r in records if r['object_kind'] != 'annotation']
    research = [i for i in image_rows if i['population'] == 'research_annotation_image']
    all_records = {r['id']: r for r in records}
    image_by_code = {i['image_code']: i for i in image_rows}
    image_by_id = {i['image_id']: i for i in image_rows}
    same_array_groups = collections.defaultdict(list)
    for r in annotations:
        if r['points_1024x512'] is not None:
            signature = json.dumps(r['points_1024x512'], separators=(',', ':'), allow_nan=False)
            same_array_groups[(r['image_code'], signature)].append(r['id'])
    same_array_rows = []
    for (code, signature), record_ids in sorted(same_array_groups.items()):
        if len(record_ids) > 1:
            same_array_rows.append(dict(image_code=code, record_ids=record_ids, records=len(record_ids),
                                        excess_if_one_per_array=len(record_ids)-1,
                                        serialized_final_array_sha256=hashlib.sha256(signature.encode()).hexdigest(),
                                        interpretation='Distinct record identities with byte-identical serialized final point arrays within one image; not deleted, not a claim about behaviour or source independence.'))
    manifest_by_code = {i['image_code']: i for i in manifest}
    room_by_code = {r['review_code']: r for r in room_groups}
    issues = []
    checks = collections.Counter()
    file_rows = []
    source_paths = {x['package_path'] for x in source_inv}
    for row in source_inv:
        path = base / row['package_path']
        actual_size = path.stat().st_size if path.is_file() else None
        item = dict(path=row['package_path'], present=path.is_file(), manifest_bytes=row['bytes'], actual_bytes=actual_size,
                    size_matches=actual_size == row['bytes'], source_worktree_state=row.get('worktree_state'),
                    privacy_processing_declared=row['package_path'] in privacy_paths)
        file_rows.append(item)
        if not item['present']:
            issues.append(dict(category='package_core_or_source_file_missing', path=row['package_path']))
        elif not item['size_matches']:
            issues.append(dict(category='source_inventory_byte_count_differs', path=row['package_path'],
                               privacy_processing_declared=item['privacy_processing_declared'],
                               note='Source-size inventory is not a SHA certificate; no original source bytes available for independent before/after attribution.'))
    actual_files = sorted(p for p in base.rglob('*') if p.is_file())
    json_errors, csv_errors = [], []
    for path in actual_files:
        rel = str(path.relative_to(base))
        if path.suffix == '.json':
            try:
                json.loads(path.read_text()); checks['json_files_parsed'] += 1
            except Exception as e:
                json_errors.append(dict(path=rel, error=repr(e)))
        elif path.suffix == '.csv':
            try:
                with path.open(encoding='utf-8-sig', newline='') as f:
                    rows = list(csv.DictReader(f))
                checks['csv_files_parsed'] += 1
                checks['csv_data_rows_parsed'] += len(rows)
            except Exception as e:
                csv_errors.append(dict(path=rel, error=repr(e)))
    id_duplicates = {}
    for name, rows, key in [('record_id', records, 'id'), ('canonical_object_id', records, 'canonical_object_id'),
                            ('manifest_image_id', manifest, 'image_id'), ('manifest_image_code', manifest, 'image_code'),
                            ('manifest_internal_path', manifest, 'internal_path')]:
        id_duplicates[name] = {k: v for k, v in collections.Counter(r[key] for r in rows).items() if v > 1}
    identity_lookup = {r['id']: r['canonical_object_id'] for r in ids}
    for record in records:
        rid = record['id']; im = image_by_code.get(record['image_code'])
        for key in ['image_id', 'building', 'room']:
            if im is None or im[key] != record[key]:
                issues.append(dict(category='record_image_identity_mismatch', id=rid, field=key))
        if identity_lookup.get(rid) != record['canonical_object_id']:
            issues.append(dict(category='canonical_identity_mismatch', id=rid))
        checks['record_identity_bindings_checked'] += 1
    panel_ids = []
    for im in panel:
        inv = image_by_code.get(im['code'])
        m = manifest_by_code.get(im['code'])
        if inv is None or m is None:
            issues.append(dict(category='panel_image_without_inventory_or_manifest', image_code=im['code'])); continue
        if inv['annotation_n'] != len(im['annotations']):
            issues.append(dict(category='annotation_count_mismatch', image_code=im['code']))
        for key in ['building', 'room', 'population']:
            if not (im[key] == inv[key] == m[key]):
                issues.append(dict(category='image_metadata_mismatch', image_code=im['code'], field=key))
        refs = inv['references']
        for p in im['annotations'] + im['references']:
            panel_ids.append(p['id'])
            r = all_records.get(p['id'])
            if r is None:
                issues.append(dict(category='panel_record_missing', id=p['id'])); continue
            if p['points'] != r['points_1024x512']:
                issues.append(dict(category='panel_record_point_view_differs', id=p['id']))
            if im['code'] != r['image_code']:
                issues.append(dict(category='panel_record_image_differs', id=p['id']))
            checks['panel_to_record_point_views_checked'] += 1
        expected_ref_kinds = sorted('gt_original' if p['version'] == 'original' else 'gt_manual_revision' for p in im['references'])
        if expected_ref_kinds != sorted(m['GT_versions']) or expected_ref_kinds != sorted(refs):
            issues.append(dict(category='reference_version_manifest_mismatch', image_code=im['code']))
        for kind, rid in refs.items():
            r = all_records.get(rid)
            if r is None or r['object_kind'] != kind or r['image_code'] != im['code']:
                issues.append(dict(category='reference_identity_mismatch', image_code=im['code'], reference=rid))
    missing_from_panel = sorted(set(all_records) - set(panel_ids))
    duplicate_panel_ids = {k: v for k, v in collections.Counter(panel_ids).items() if v > 1}

    # Validate the documented source/final index views only.  Do not repair or
    # derive a different ring when a view is unavailable.
    coordinate_rows = []
    for r in records:
        final = r['points_1024x512']; pre = r['preprocessed_points']
        row = dict(id=r['id'], image_code=r['image_code'], object_kind=r['object_kind'],
                   preprocessing_status=r['preprocessing_status'], final_points_present=final is not None,
                   final_point_count=len(final) if final is not None else None,
                   ring_confirmed=r['ring_confirmed'], source_geometry_status=r['geometry']['status'])
        if final is not None:
            sp = r['ordered_source_point_indices']
            try:
                source_mapped = [pre[k] for k in sp]
                row['final_equals_source_index_view'] = source_mapped == final
                row['final_pair_indices_match'] = r['matterport_links_zero_based'] == [[i, i+1] for i in range(0, len(final), 2)]
                row['final_even_points'] = len(final) % 2 == 0
                n = len(final) // 2
                ec = r['existing_ring_connections']
                row['existing_ring_matches_final_order'] = (ec['top_edges'] == [[2*i, 2*((i+1) % n)] for i in range(n)]
                                                            and ec['bottom_edges'] == [[2*i+1, 2*((i+1) % n)+1] for i in range(n)]
                                                            and ec['paired_edges'] == [[2*i, 2*i+1] for i in range(n)])
            except Exception as e:
                row['index_audit_error'] = repr(e)
            for key in ['final_equals_source_index_view', 'final_pair_indices_match', 'final_even_points', 'existing_ring_matches_final_order']:
                if row.get(key) is not True:
                    issues.append(dict(category='source_or_ring_index_mismatch', id=r['id'], field=key))
        coordinate_rows.append(row)

    # Preserve upstream room identifiers, including declared subgroups and merges.
    room_rows = []
    for im in research:
        name = im['room']; row = dict(image_code=im['image_code'], building=im['building'], room=name, known=bool(name))
        if name:
            g = room_by_code.get(name.split('-')[0])
            members = set(g['image_ids']) if g else set()
            merge = g.get('interpretation', {}).get('merge', []) if g else []
            for number in merge:
                mg = room_by_code.get(f'G{number:03d}', {})
                members.update(mg.get('image_ids', []))
            row.update(parent_registry_code=g['review_code'] if g else None,
                       registry_explicit_merge=merge, registry_subgroup=name.split('-')[1:] or None,
                       membership_supported=im['image_id'] in members,
                       physical_same=g.get('raw_current', {}).get('physical_same') if g else None)
            if not row['membership_supported']:
                issues.append(dict(category='room_registry_membership_unresolved', image_code=im['image_code'], room=name))
        room_rows.append(row)

    prior = json.loads(args.prior_frozen.read_text())['images']
    development = {i['code'] for i in prior}
    development_buildings = {i['building'] for i in prior}
    old_index = {obj['id']: (im['code'], obj) for im in prior for obj in im['annotations'] + im['groundtruths']}
    old_annotation_ids = {obj['id'] for im in prior for obj in im['annotations']}
    prior_delta = []
    for rid, (code, obj) in old_index.items():
        cur = all_records.get(rid)
        prior_delta.append(dict(id=rid, image_code=code, object_kind=cur.get('object_kind') if cur else None,
                                present_in_snapshot=cur is not None,
                                old_points_equal_snapshot=(cur is not None and obj.get('points') == cur.get('points_1024x512')),
                                old_point_count=len(obj.get('points') or []), snapshot_point_count=len(cur.get('points_1024x512') or []) if cur else None,
                                policy='Current thread confirmed frozen objects take precedence; this audit never changes either source.'))

    # Historical identities: exact code/image_id matches, never person labels.
    all_codes = set(image_by_code)
    lookup = {**{c: c for c in all_codes}, **{i: x['image_code'] for i,x in image_by_id.items()}}
    def extract(node):
        found = set()
        if isinstance(node, str):
            if node in lookup: found.add(lookup[node])
        elif isinstance(node, dict):
            for k, v in node.items():
                if k in lookup: found.add(lookup[k])
                found.update(extract(v))
        elif isinstance(node, list):
            for v in node: found.update(extract(v))
        return found
    exposure_entries = []
    definite = collections.defaultdict(set)
    def register(rel, selector, node, level, note):
        codes = sorted(extract(node))
        exposure_entries.append(dict(path=rel, selector=selector, evidence_level=level, image_count=len(codes),
                                     image_codes=codes, note=note))
        if level == 'historical_geometry_input_or_result':
            for code in codes: definite[code].add(rel + '#' + selector)
    probes = [
        ('analysis_results/layout_algorithm_exploration_20260926/real/real_case_probe.json', ['selected_cases', 'screenshot_representation_probe']),
        ('analysis_results/layout_metric_response_20261001/results.json', ['real']),
        ('analysis_results/layout_3d_quality_probe_20261002/results.json', ['objects', 'real']),
        ('analysis_results/worker_profiles_20261003/input.json', ['images']),
        ('analysis_results/point_route_panel_20261005/candidates.json', ['images']),
        ('analysis_results/adaptive_point_20261007/inputs.json', ['images']),
        ('analysis_results/adaptive_point_20261007/candidates.json', ['states']),
        ('analysis_results/adaptive_point_20261007/expanded/inputs.json', ['images']),
        ('analysis_results/adaptive_point_20261007/expanded/candidates.json', ['states']),
    ]
    for rel, selectors in probes:
        data = read(rel)
        for selector in selectors:
            register(rel, selector, data[selector], 'historical_geometry_input_or_result',
                     'At least this image had geometry present in an already completed study; not independent blind material for the broader programme.')
    hist_file_rows = []
    hist_mentions = collections.defaultdict(set)
    for path in sorted((base / 'analysis_results').rglob('*')):
        if not path.is_file() or path.suffix not in ['.json', '.csv', '.md', '.txt']: continue
        rel = str(path.relative_to(base))
        text = path.read_text(encoding='utf-8-sig')
        if path.suffix == '.json':
            codes = extract(json.loads(text))
        elif path.suffix == '.csv':
            codes = extract(list(csv.DictReader(text.splitlines())))
        else:
            # Prose can reference an image without having used it; kept separate.
            codes = {c for c in all_codes if re.search(r'(?<![A-Za-z0-9])' + re.escape(c) + r'(?![0-9])', text)}
        level = 'identity_mentioned_not_proof_of_geometry_evaluation'
        if codes:
            for code in codes: hist_mentions[code].add(rel)
        hist_file_rows.append(dict(path=rel, image_count=len(codes), image_codes=sorted(codes), evidence_level=level))
    image_groups = []
    for im in research:
        code = im['image_code']; building = im['building']
        if code in development: split = 'current_v1_v11_development_image'
        elif building in development_buildings: split = 'new_image_in_development_building'
        else: split = 'new_building_not_used_for_current_v1_v11_parameter_selection'
        image_groups.append(dict(image_code=code, image_id=im['image_id'], building=building, room=im['room'],
                                 annotation_n=im['annotation_n'], current_parameter_group=split,
                                 building_group_role='development_building' if building in development_buildings else 'fixed_parameter_validation_building',
                                 historical_geometry_result_found=code in definite,
                                 historical_geometry_sources=sorted(definite.get(code, [])),
                                 historical_identity_mentioned=code in hist_mentions,
                                 historical_identity_sources=sorted(hist_mentions.get(code, [])),
                                 historical_exposure='historical_geometry_used' if code in definite else 'broader_history_not_fully_certified',
                                 independent_blind_test=False,
                                 current_bundle_oos_status=im['current_bundle_oos_status'],
                                 current_bundle_doorway_status=im['current_bundle_doorway_status'],
                                 later_scene_description=im['later_scene_description'], difficulty=im['difficulty']))
    building_rows = []
    for building in sorted({i['building'] for i in research}):
        group = [i for i in image_groups if i['building'] == building]
        building_rows.append(dict(building=building, research_images=len(group), annotations=sum(i['annotation_n'] for i in group),
                                  building_group_role=group[0]['building_group_role'],
                                  previous_six_images=sum(i['image_code'] in development for i in group),
                                  additional_images=sum(i['image_code'] not in development for i in group),
                                  known_room_images=sum(bool(i['room']) for i in group),
                                  known_room_groups=len({i['room'] for i in group if i['room']}),
                                  historical_geometry_images=sum(i['historical_geometry_result_found'] for i in group)))
    image_group_lookup = {r['image_code']: r for r in image_groups}
    duplicate_group_lookup = {rid: n for n, group in enumerate(duplicates, 1) for rid in group['object_ids']}
    record_group_rows = []
    source_unavailable = []
    for r in annotations:
        g = image_group_lookup[r['image_code']]
        record_group_rows.append(dict(id=r['id'], canonical_object_id=r['canonical_object_id'],
                                      image_code=r['image_code'], building=r['building'], room=r['room'],
                                      current_parameter_group=g['current_parameter_group'], building_group_role=g['building_group_role'],
                                      old_selected36=r['id'] in old_annotation_ids,
                                      duplicate_version_group=duplicate_group_lookup.get(r['id']),
                                      final_point_count=len(r['points_1024x512']) if r['points_1024x512'] is not None else None,
                                      historical_quality_gate=r['worker_quality_gate'], source_pairing_basis=r['pairing_basis']))
        if r['points_1024x512'] is None:
            source_unavailable.append(dict(id=r['id'], image_code=r['image_code'], building=r['building'],
                                           source_pairing_basis=r['pairing_basis'],
                                           raw_array_present=r['original_export_points'] is not None,
                                           raw_point_count=len(r['original_export_points']) if r['original_export_points'] is not None else None,
                                           before_preprocessing_present=r['before_preprocessing_points'] is not None,
                                           preprocessed_points_present=r['preprocessed_points'] is not None,
                                           links_present=r['links_zero_based'] is not None,
                                           source_geometry_status=r['geometry']['status'],
                                           source_pointer='data_snapshot/current/records.json#objects[id=' + r['id'] + ']',
                                           category='prepared_pairing_and_final_geometry_absent',
                                           interpretation='This is a missing prepared source view, not a new claim that its raw geometry is invalid; do not guess or repair pairs.'))
    duplicate_rows = []
    for index, group in enumerate(duplicates, 1):
        for rid in group['object_ids']:
            r = all_records.get(rid)
            duplicate_rows.append(dict(version_group=index, id=rid, present=r is not None,
                                       image_code=r['image_code'] if r else None,
                                       current_object_id=group['current_object_id'], is_current=rid == group['current_object_id'],
                                       same_unit_supported=r is not None and r['canonical_unit'] == group['unit']))
    ref_audit = read('reference_audit.json')
    missing_refs = []
    for rel in ref_audit['core_references']:
        missing_refs.append(dict(reference=rel, category='package_core_entry', exists=(base / rel).is_file(),
                                 interpretation='Core replay dependency' if (base / rel).is_file() else 'Missing core file'))
    for x in ref_audit['omitted_contextual_repository_links']:
        target = (base / x['document']).parent / x['contextual_link']
        missing_refs.append(dict(document=x['document'], reference=x['contextual_link'],
                                 category='declared_contextual_repository_link', exists=target.exists(),
                                 interpretation='Historical/background link omitted from snapshot; not an absent current annotation or source image.'))
    summary = dict(schema='expanded_v11_inventory_audit_v1',
                   actual_files=len(actual_files), source_inventory_files=len(source_inv),
                   package_files_not_listed_as_copied_sources=[str(p.relative_to(base)) for p in actual_files if str(p.relative_to(base)) not in source_paths],
                   missing_source_inventory_files=sum(not x['present'] for x in file_rows),
                   source_byte_count_differences=[x for x in file_rows if not x['size_matches']],
                   parsing_checks=dict(checks), json_errors=json_errors, csv_errors=csv_errors,
                   image_manifest_rows=len(manifest), panel_image_rows=len(panel), research_images=len(research), reference_only_images=len(image_rows)-len(research),
                   buildings=len(building_rows), object_counts=counter(records, 'object_kind'),
                   duplicate_ids=id_duplicates, panel_duplicate_record_ids=duplicate_panel_ids, missing_records_from_panel=missing_from_panel,
                   current_identity_bindings=len(ids), current_objects=len(records), source_coordinate_objects_available=sum(r['points_1024x512'] is not None for r in records),
                   source_annotation_final_points_available=sum(r['points_1024x512'] is not None for r in annotations),
                   source_annotation_pairing_unavailable=sum(r['preprocessing_status'] == 'unavailable' for r in annotations),
                   source_unavailable_pairing_basis=counter(source_unavailable, 'source_pairing_basis'),
                   source_unavailable_with_nonempty_raw_points=sum(bool(r['raw_point_count']) for r in source_unavailable),
                   old_selected_annotations=len(old_annotation_ids),
                   other_annotations_in_development_images=sum(r['image_code'] in development and r['id'] not in old_annotation_ids for r in annotations),
                   historical_quality_gate_counts=counter(annotations, 'worker_quality_gate'),
                   historical_cleaning_counts=counter(annotations, 'cleaning_disposition'),
                   source_geometry_counts=dict(collections.Counter(r['geometry']['status'] for r in annotations)),
                   historical_geometry_issues=dict(collections.Counter(x for r in annotations for x in r['geometry']['issues'])),
                   source_order_status_counts=counter(annotations, 'order_status'),
                   source_pair_count_distribution=dict(sorted(collections.Counter(len(r['points_1024x512'])//2 for r in annotations if r['points_1024x512'] is not None).items())),
                   historical_oos_status_images=counter(research, 'current_bundle_oos_status'),
                   historical_doorway_status_images=counter(research, 'current_bundle_doorway_status'),
                   later_scene_description_images=counter(research, 'later_scene_description'), difficulty_images=counter(research, 'difficulty'),
                   known_room_images=sum(bool(i['room']) for i in research), unknown_room_images=sum(not i['room'] for i in research),
                   known_room_identifiers=len({(i['building'], i['room']) for i in research if i['room']}),
                   room_registry_groups=len(room_groups),
                   duplicate_version_groups=len(duplicates), duplicate_version_records=len(duplicate_rows),
                   duplicate_version_excess_records=sum(len(g['object_ids'])-1 for g in duplicates),
                   same_image_identical_final_array_groups=len(same_array_rows),
                   same_image_identical_final_array_records=sum(r['records'] for r in same_array_rows),
                   same_image_identical_final_array_excess_records=sum(r['excess_if_one_per_array'] for r in same_array_rows),
                   same_image_identical_final_array_images=len({r['image_code'] for r in same_array_rows}),
                   distinct_person_image_condition_units=len({tuple(r['canonical_unit']) for r in annotations}),
                   current_development_images=sorted(development), current_development_buildings=sorted(development_buildings),
                   current_parameter_group_counts=counter(image_groups, 'current_parameter_group'),
                   annotations_by_parameter_group=dict(collections.Counter({g: sum(i['annotation_n'] for i in image_groups if i['current_parameter_group']==g) for g in {i['current_parameter_group'] for i in image_groups}})),
                   historical_geometry_images_in_selected_completed_studies=sum(i['historical_geometry_result_found'] for i in image_groups),
                   historical_identity_mentioned_images=sum(i['historical_identity_mentioned'] for i in image_groups),
                   prior_frozen_object_count=len(prior_delta), prior_frozen_point_differences=[r for r in prior_delta if not r['old_points_equal_snapshot']],
                   core_reference_count=len(ref_audit['core_references']), missing_core_references=[r for r in missing_refs if r['category']=='package_core_entry' and not r['exists']],
                   declared_omitted_contextual_links=len(ref_audit['omitted_contextual_repository_links']),
                   issues=issues,
                   interpretation=['Inventory/geometry/eligibility/exposure are separate; no legacy gate was used to exclude rows.',
                                   'New images in old buildings are reported separately. Only 16 whole new buildings can be described as held out from current v1/v1.1 parameter selection; no historical material is called a blind test.',
                                   'Historical geometry exposure is a documented minimum from explicit input/result subsets. Absence is unknown broader history, not proof of never-seen.',
                                   'Unknown room IDs do not imply independent rooms. Building group isolation avoids cross-view leakage even where room bindings are missing.',
                                   'Pairing unavailable means a prepared source coordinate/pair view is absent. Raw exported points may still exist; no fresh pairing or geometry repair is performed.'])
    write_csv(out / 'source_file_inventory_audit.csv', file_rows)
    write_csv(out / 'coordinate_identity_audit.csv', coordinate_rows)
    write_csv(out / 'room_binding_audit.csv', room_rows)
    write_csv(out / 'image_group_registry.csv', image_groups)
    write_csv(out / 'building_group_registry.csv', building_rows)
    write_csv(out / 'record_group_registry.csv', record_group_rows)
    write_csv(out / 'source_preparation_unavailable.csv', source_unavailable)
    write_csv(out / 'duplicate_version_records.csv', duplicate_rows)
    write_csv(out / 'same_image_identical_final_array_groups.csv', same_array_rows)
    write_csv(out / 'historical_geometry_exposure.csv', exposure_entries)
    write_csv(out / 'historical_file_identity_mentions.csv', hist_file_rows)
    write_csv(out / 'prior_frozen_vs_snapshot_objects.csv', prior_delta)
    write_csv(out / 'reference_file_availability.csv', missing_refs)
    write_csv(out / 'inventory_issues.csv', issues)
    dump(out / 'inventory_audit.json', summary)
    print(json.dumps({k: v for k, v in summary.items() if k in ['research_images', 'reference_only_images', 'buildings', 'object_counts', 'source_annotation_final_points_available', 'known_room_images', 'unknown_room_images', 'known_room_identifiers', 'current_parameter_group_counts', 'annotations_by_parameter_group', 'historical_geometry_images_in_selected_completed_studies', 'historical_identity_mentioned_images', 'prior_frozen_point_differences', 'duplicate_version_groups', 'duplicate_version_records', 'duplicate_version_excess_records', 'distinct_person_image_condition_units', 'issues']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
