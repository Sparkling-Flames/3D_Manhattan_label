#!/usr/bin/env python3
"""Maintainer export of EXISTING selected controls, not a new control generator.

The portable reproduction entry point does not execute this script and does
not need the historical workspace. This exporter records how its frozen
inputs and geometry-only old36 baseline were obtained.
"""
from __future__ import annotations

import argparse
import ast
import copy
import csv
import hashlib
import json
import shutil
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False) + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--workspace", required=True, type=Path)
    ap.add_argument("--expanded", required=True, type=Path)
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    args = ap.parse_args()
    ws, expanded, out = args.workspace.resolve(), args.expanded.resolve(), args.out.resolve()
    source_script = expanded / "validation/prepare_contract_and_controls.py"
    module = ast.parse(source_script.read_text())
    control_fn = next(n for n in module.body if isinstance(n, ast.FunctionDef)
                      and n.name == "control_replay")
    selected_node = next(n.value for n in control_fn.body if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == "selected"
                                 for t in n.targets))
    selected = ast.literal_eval(selected_node)
    source_paths = [
        ws / "output/layout_quality_research_v1_repro/results/geometry/control_geometries.json",
        ws / "work/research_v1_1/height_revision/results_4096/new_height_control_geometries.json",
        ws / "work/research_v1_1/new_independent_audit/layout_quality_v1_independent_audit/numeric/independent_counterexample_geometries.json",
    ]
    fixtures = {}
    source_manifest = []
    for path in source_paths:
        rel = str(path.relative_to(ws))
        source_manifest.append({"historical_path": rel, "sha256": sha(path),
                                "bytes": path.stat().st_size})
        for raw in read(path):
            cid = raw.get("case_id", raw.get("case"))
            fixtures[cid] = {"raw": raw, "source": rel,
                             "source_sha256": sha(path), "base_case_id": cid,
                             "derivation": None}
    missing = [cid for cid in selected if cid not in fixtures]
    if missing:
        raise KeyError("Selected existing fixture absent: " + repr(missing))

    # Execute only the already-existing exact-subdivision for-loop, unchanged.
    # It uses the same bases, interpolation fractions, and ring insertion order
    # as the audited selection script. No data cleaning or repair is involved.
    split_node = next(n for n in control_fn.body if isinstance(n, ast.For)
                      and isinstance(n.target, ast.Name) and n.target.id == "base")
    portable_fixtures = {
        cid: {**copy.deepcopy(item["raw"]), "case_id": cid,
              "geometry_source": item["source"]}
        for cid, item in fixtures.items()
    }
    env = {"copy": copy, "fixtures": portable_fixtures, "selected": selected}
    split_module = ast.fix_missing_locations(ast.Module(body=[split_node], type_ignores=[]))
    exec(compile(split_module, str(source_script), "exec"), env)
    selected = env["selected"]

    expected_path = expanded / "validation/focused_control_replay_full.json"
    expected = read(expected_path)
    if selected != [row["case_id"] for row in expected] or len(selected) != 38:
        raise AssertionError("Exported selection/order differs from existing 38-control replay")
    expected_map = {row["case_id"]: row for row in expected}
    flat_path = expanded / "validation/focused_control_replay.csv"
    with flat_path.open(encoding="utf-8-sig", newline="") as f:
        expected_flat = {row["case_id"]: row for row in csv.DictReader(f)}
    cases = []
    for cid in selected:
        fixture = portable_fixtures[cid]
        base_id = fixture.get("compare_with", cid)
        origin = fixtures[base_id]
        derivation = None if cid == base_id else {
            "kind": "existing_exact_collinear_one_edge_subdivision",
            "base_case_id": base_id,
            "existing_script_block": ast.get_source_segment(source_script.read_text(), split_node),
            "not_new_geometry_repair": True,
        }
        cases.append({"case_id": cid, "family": fixture.get("family", "audit_original_counterexample"),
                      "source": origin["source"], "source_sha256": origin["source_sha256"],
                      "base_case_id": base_id, "derivation": derivation,
                      "annotation": fixture["annotation"], "reference": fixture["reference"],
                      "other_original_fixture_fields": {k: v for k, v in fixture.items()
                            if k not in {"annotation", "reference"}},
                      "expected_result": expected_map[cid]["result"],
                      "expected_flat_row": expected_flat[cid]})
    dump(out / "controls38_frozen.json", {
        "schema": "existing_frozen_v11_controls38_portable_v1",
        "selection_script": "validation/prepare_contract_and_controls.py",
        "selection_script_sha256": sha(source_script),
        "sources": source_manifest,
        "expected_result_source": "validation/focused_control_replay_full.json",
        "expected_result_source_sha256": sha(expected_path),
        "expected_csv_source_sha256": sha(flat_path),
        "selection_count_original": len(ast.literal_eval(selected_node)),
        "existing_derived_count": sum(c["derivation"] is not None for c in cases),
        "human_ratings_read": False, "cases": cases,
    })

    # Preserve original36 rating-reference identity without reading ratings.
    old_root = ws / "work/research_v1_1/results"
    old_full_path = old_root / "reference_specific_results48.json"
    old_full = [r for r in read(old_full_path) if r["is_rating_reference"]]
    if len(old_full) != 36 or len({r["record_id"] for r in old_full}) != 36:
        raise AssertionError("Expected exactly 36 existing rating-reference geometries")
    # These are already geometry-only outputs, not subjective grades.
    dump(out / "baseline_old36_full.json", old_full)
    shutil.copy2(old_root / "scores36_geometry_only.csv", out / "baseline_old36_geometry_only.csv")
    dump(out / "baseline_old36_provenance.json", {
        "full_source": str(old_full_path.relative_to(ws)), "full_source_sha256": sha(old_full_path),
        "selection": "is_rating_reference == true; 36 unique record IDs",
        "csv_source": str((old_root / "scores36_geometry_only.csv").relative_to(ws)),
        "csv_source_sha256": sha(old_root / "scores36_geometry_only.csv"),
        "source_scores_are_geometric": True, "subjective_scores_read": False,
    })

    license_source = ws / "work/research_v1_1/traditional/vendor/LICENSE"
    license_out = out / "vendor_license/HoHoNet_LICENSE"
    license_out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(license_source, license_out)
    dump(out / "vendor_license/provenance.json", {
        "license_source": str(license_source.relative_to(ws)),
        "license_sha256": sha(license_source),
        "copy_is_byte_identical": sha(license_source) == sha(license_out),
        "applies_to_bundled_vendor_files": ["frozen_engine/traditional/vendor/eval_layout.py",
                                             "frozen_engine/traditional/vendor/post_proc.py"],
        "runtime_note": "Main replay uses the frozen conditional-prism adapter. Vendored official code is retained for reference and prior independent arithmetic verification; its complete depth pipeline is not run.",
    })
    print(json.dumps({"exported_controls": len(cases), "old36": len(old_full),
                      "out": str(out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
