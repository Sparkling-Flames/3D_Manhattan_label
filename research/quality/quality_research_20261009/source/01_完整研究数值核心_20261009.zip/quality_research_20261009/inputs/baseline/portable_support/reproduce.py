#!/usr/bin/env python3
"""Portable 3152-record + 38-control fixed-v1.1 replay and complete comparison.

All score computations come from the unchanged bundled frozen_engine. No
historical workspace, original photograph, external service, fitting, GT
selection, input repair, or subjective score is required.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import platform
import re
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False) + "\n", encoding="utf-8")


class Compare:
    """Recursive full-value comparison: exact NA/type/status/reasons, numeric tolerance."""

    def __init__(self, name, atol, rtol):
        self.name, self.atol, self.rtol = name, atol, rtol
        self.counts = Counter()
        self.mismatch_count = 0
        self.examples = []
        self.max_abs = 0.0
        self.max_path = None

    def mismatch(self, path, expected, actual, kind):
        self.mismatch_count += 1
        if len(self.examples) < 500:
            self.examples.append({"path": path, "kind": kind,
                                  "expected": expected, "actual": actual})

    def check(self, expected, actual, path="root"):
        if expected is None or actual is None:
            self.counts["null_cells"] += 1
            if expected is not None or actual is not None:
                self.mismatch(path, expected, actual, "null_or_availability_mismatch")
        elif isinstance(expected, bool) or isinstance(actual, bool):
            self.counts["boolean_cells"] += 1
            if type(expected) is not type(actual) or expected != actual:
                self.mismatch(path, expected, actual, "boolean_mismatch")
        elif isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
            self.counts["numeric_cells"] += 1
            if not math.isfinite(expected) or not math.isfinite(actual):
                self.mismatch(path, expected, actual, "unexpected_nonfinite_number")
                return
            delta = abs(expected-actual)
            if delta > self.max_abs:
                self.max_abs, self.max_path = float(delta), path
            if not math.isclose(expected, actual, rel_tol=self.rtol, abs_tol=self.atol):
                self.mismatch(path, expected, actual, "numeric_mismatch")
        elif isinstance(expected, dict) and isinstance(actual, dict):
            self.counts["dicts"] += 1
            missing, extra = sorted(set(expected)-set(actual)), sorted(set(actual)-set(expected))
            if missing or extra:
                self.mismatch(path, missing, extra, "missing_expected_or_extra_actual_keys")
            for key in expected.keys() & actual.keys():
                self.check(expected[key], actual[key], path + "." + str(key))
        elif isinstance(expected, list) and isinstance(actual, list):
            self.counts["lists"] += 1
            if len(expected) != len(actual):
                self.mismatch(path, len(expected), len(actual), "list_length_mismatch")
            for i, (a, b) in enumerate(zip(expected, actual)):
                self.check(a, b, f"{path}[{i}]")
        else:
            self.counts["string_or_other_cells"] += 1
            if type(expected) is not type(actual) or expected != actual:
                self.mismatch(path, expected, actual, "exact_value_mismatch")

    def report(self):
        return {"comparison": self.name, "passed": self.mismatch_count == 0,
                "absolute_tolerance": self.atol, "relative_tolerance": self.rtol,
                "counts": dict(self.counts), "mismatches": self.mismatch_count,
                "maximum_numeric_absolute_delta": self.max_abs,
                "maximum_delta_path": self.max_path,
                "mismatch_examples_first500": self.examples}


def keyed(rows, key):
    mapped = {r[key]: r for r in rows}
    if len(mapped) != len(rows):
        raise AssertionError("Duplicate row identity in " + key)
    return mapped


def parse_csv_cell(value):
    if value == "":
        return None
    if value in ("True", "False"):
        return value == "True"
    if value[:1] in ("[", "{"):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            pass
    if NUMBER.fullmatch(value):
        return float(value)
    return value


def csv_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return [{k: parse_csv_cell(v) for k, v in r.items()} for r in csv.DictReader(f)]


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compare_record_outputs(bundle, out, atol, rtol):
    expected = keyed(read(bundle / "results_fixed/all_records_results.json"), "record_id")
    replay = keyed(read(out / "scores/all_records_results.json"), "record_id")
    full = Compare("3152_full_JSON_all_fields", atol, rtol)
    full.check(expected, replay)
    dump(out / "checks/full_json_comparison.json", full.report())
    expected_csv = keyed(csv_rows(bundle / "results_fixed/all_records_scores.csv"), "record_id")
    replay_csv = keyed(csv_rows(out / "scores/all_records_scores.csv"), "record_id")
    flat = Compare("3152_CSV_all_columns", atol, rtol)
    flat.check(expected_csv, replay_csv)
    dump(out / "checks/full_csv_comparison.json", flat.report())

    old = keyed(read(bundle / "portable_support/baseline_old36_full.json"), "record_id")
    engine_keys = ["algorithm_version", "status", "quality_score", "reason_codes", "failure_classes",
                   "annotation_geometry_sha256", "reference_geometry_sha256", "target_applicability",
                   "annotation_validity", "reference_validity", "metrics", "metric_availability",
                   "parameters", "numerical_settings", "geometry_digest_status", "traditional_issues",
                   "height_diagnostics", "auxiliary_issues", "issues"]
    identity_keys = ["review_id", "record_id", "image_code", "reference_id", "reference_version"]
    old_full = Compare("old36_original_geometry_full_JSON", atol, rtol)
    schema_additions = []
    for rid, prior in old.items():
        actual_payload = copy.deepcopy({k: replay.get(rid, {}).get(k) for k in identity_keys + engine_keys})
        # The saved old36 full JSON predates two diagnostic-only fields already
        # present in the current frozen validator. Compare every old field;
        # list only these explicitly known additions instead of suppressing
        # arbitrary structural differences. The complete3152 comparison above
        # still compares these new fields strictly to the current baseline.
        for role in ("annotation", "reference"):
            old_diag = prior[role + "_validity"]["diagnostics"]
            new_diag = actual_payload[role + "_validity"]["diagnostics"]
            for field in ("actual_top_xz_projection_available", "actual_top_xz_projection_checked"):
                if field not in old_diag and field in new_diag:
                    value = new_diag.pop(field)
                    schema_additions.append({"record_id": rid, "role": role, "field": field,
                                             "actual_value": value,
                                             "old_field_absent": True,
                                             "current3152_baseline_strictly_compared": True})
        old_full.check({k: prior[k] for k in identity_keys + engine_keys},
                       actual_payload, rid)
    dump(out / "checks/old36_known_diagnostic_schema_additions.json", schema_additions)
    dump(out / "checks/old36_full_json_comparison.json", old_full.report())
    old_csv = Compare("old36_original_geometry_CSV", atol, rtol)
    old_csv_rows = keyed(csv_rows(bundle / "portable_support/baseline_old36_geometry_only.csv"), "record_id")
    # Only metadata that necessarily changed with expansion is excluded.
    # All old numeric/NA/status/reason columns and reference identities remain.
    excluded = {"geometry_source", "evaluation_group", "is_rating_reference"}
    for rid, prior in old_csv_rows.items():
        old_csv.check({k: v for k, v in prior.items() if k not in excluded},
                      {k: replay_csv.get(rid, {}).get(k) for k in prior if k not in excluded}, rid)
    old_report = old_csv.report()
    old_report["explicit_metadata_only_exclusions"] = sorted(excluded)
    dump(out / "checks/old36_csv_comparison.json", old_report)

    aggregate_reports = []
    for name, key in [("by_image.csv", "image_code"), ("by_building.csv", "building"),
                      ("metric_availability_counts.csv", "metric"),
                      ("failure_primary_counts.csv", "unavailable_primary_reason")]:
        baseline_path = bundle / "results_fixed" / name
        if baseline_path.exists():
            cmp = Compare(name, atol, rtol)
            cmp.check(keyed(csv_rows(baseline_path), key),
                      keyed(csv_rows(out / "scores" / name), key))
            aggregate_reports.append(cmp.report())
    dump(out / "checks/aggregate_comparisons.json", aggregate_reports)
    return {"records": len(replay), "old36_records": len(old),
            "available_Q": sum(r["status"] == "available" for r in replay.values()),
            "unavailable_Q": sum(r["status"] != "available" for r in replay.values()),
            "available_images_Q": len({r["image_code"] for r in replay.values() if r["status"] == "available"}),
            "images": len({r["image_code"] for r in replay.values()}),
            "buildings": len({r["building"] for r in replay.values()}),
            "full_JSON": full.report(), "all_CSV": flat.report(),
            "old36_full_JSON": old_full.report(), "old36_CSV": old_report,
            "aggregate_reports": aggregate_reports,
            "all_passed": all(r["passed"] for r in [full.report(), flat.report(), old_full.report(),
                            old_report, *aggregate_reports])}


def replay_controls(bundle, out, atol, rtol):
    sys.path.insert(0, str(bundle / "frozen_engine/core"))
    from quality_v11 import load_parameters, score_geometry
    from run_replay import csv as write_csv, flatten
    actual_kernel_path = Path(score_geometry.__code__.co_filename).resolve()
    if actual_kernel_path != (bundle / "frozen_engine/core/quality_v11.py").resolve():
        raise RuntimeError("Imported scoring kernel is not the bundled frozen file")
    path = bundle / "portable_support/controls38_frozen.json"
    before = sha(path)
    data = read(path)
    parameters = load_parameters(bundle / "frozen_engine/frozen_parameters.json")
    bands = read(bundle / "frozen_engine/frozen_bands.json")
    results, flat, by_id = [], [], {}
    comparison = Compare("38_existing_controls_full_results", atol, rtol)
    historical = {r["case_id"]: r for r in read(bundle / "validation/focused_control_replay_full.json")}
    assertions = []

    def check(name, passed, detail=None):
        assertions.append({"check": name, "passed": bool(passed), "detail": detail})

    for case in data["cases"]:
        cid = case["case_id"]
        result = score_geometry(case["annotation"], case["reference"], parameters)
        comparison.check(case["expected_result"], result, cid)
        comparison.check(historical[cid]["result"], result, cid + ".independent_packaged_baseline")
        results.append({"case_id": cid, "source": case["source"], "result": result})
        flat.append(flatten(result, {"case_id": cid, "family": case["family"]}, bands))
        by_id[cid] = result
        if result["status"] == "available":
            q, m = result["quality_score"], result["metrics"]
            check(cid + ":range_cap", -1e-10 <= q <= 100*m["iou"]+1e-10)
            check(cid + ":height_max", abs(m["Hstar"]-max(m["Hmean"], m["Hlocal"])) <= 1e-12)
            check(cid + ":mean_only_cap", q <= m["mean_height_only_score_same_parameters"]+1e-10)
            check(cid + ":accounting_sum", abs(100-q-sum(m[k] for k in ["range_deduction_points",
                  "boundary_deduction_points", "height_deduction_points", "intrinsic_deduction_points"])) <= 1e-8)
    for base in ["rectangle_scale_1", "nonflat_copy_k1", "nonflat_inverse_k64"]:
        delta = by_id[base + "_uneven_exact_subdivision"]["quality_score"] - by_id[base]["quality_score"]
        check(base + ":exact_collinear_split", abs(delta) <= 1e-8, delta)
    for family, levels in [("translation", ["0", "0.005", "0.01", "0.05", "0.2", "0.8"]),
                           ("top_shift", ["0.005", "0.02", "0.1", "0.4", "0.8"]),
                           ("local_top", ["0.005", "0.02", "0.2", "0.8"])]:
        values = [by_id[f"rectangle_{family}_{level}"]["quality_score"] for level in levels]
        check(family + ":existing_path_monotone", all(a >= b-1e-9 for a, b in zip(values, values[1:])), values)
    for cid in ["overlapping_backtrack_edges", "nonadjacent_vertex_touches_edge"]:
        check(cid + ":unavailable_not_zero", by_id[cid]["status"] == "unavailable"
              and by_id[cid]["quality_score"] is None, by_id[cid]["reason_codes"])
    check("far_alternating_height_not_near_perfect", by_id["alternating_height_xz_scale_32"]["quality_score"] < 80)
    check("nonflat_reference_copy_height_error_zero", by_id["nonflat_copy_k64"]["metrics"]["Hstar"] <= 1e-12)
    for wrong in ["nonflat_flatten_k64", "nonflat_inverse_k64"]:
        check("nonflat_copy_above_" + wrong,
              by_id["nonflat_copy_k64"]["quality_score"] > by_id[wrong]["quality_score"])
    check("portable_frozen_controls_input_unchanged", sha(path) == before)
    dump(out / "controls/focused_control_replay_full.json", results)
    write_csv(out / "controls/focused_control_replay.csv", flat)
    dump(out / "controls/control_numeric_comparison.json", comparison.report())
    dump(out / "controls/targeted_property_assertions.json", assertions)
    summary = {"control_records": len(results),
               "available": sum(r["result"]["status"] == "available" for r in results),
               "unavailable": sum(r["result"]["status"] != "available" for r in results),
               "all_numeric_NA_and_reasons": comparison.report(),
               "property_checks": len(assertions), "property_failures": sum(not r["passed"] for r in assertions),
               "imported_frozen_score_kernel": str(actual_kernel_path),
               "all_passed": comparison.mismatch_count == 0 and all(r["passed"] for r in assertions),
               "original_historical_225_check_archive": "validation/focused_control_assertions.json; preserved, not relabeled as newly executed checks"}
    dump(out / "controls/summary.json", summary)
    return summary


def verify_manifest(bundle):
    manifest = read(bundle / "portable_support/bundle_numeric_contract.json")
    rows = []
    for rel, expected in manifest["sha256"].items():
        path = bundle / rel
        actual = sha(path) if path.is_file() else None
        rows.append({"path": rel, "expected_sha256": expected, "actual_sha256": actual,
                     "passed": actual == expected})
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent.parent)
    ap.add_argument("--out", type=Path, help="New empty output folder; baseline files are never overwritten")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--atol", type=float, default=1e-8)
    ap.add_argument("--rtol", type=float, default=1e-10)
    args = ap.parse_args()
    bundle = args.bundle.resolve()
    out = (args.out or bundle / ("reproduction_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"))).resolve()
    if args.jobs < 1:
        ap.error("--jobs must be positive")
    for protected in [bundle / p for p in ("prepared", "results_fixed", "validation", "frozen_engine", "portable_support")]:
        if out == protected or protected in out.parents:
            ap.error("--out must not be inside a protected input/code/baseline directory")
    if out.exists() and any(out.iterdir()):
        ap.error("--out must be a new or empty folder; refusing to overwrite prior results")
    out.mkdir(parents=True, exist_ok=True)
    started, t0 = datetime.now(timezone.utc).isoformat(), time.perf_counter()
    manifest_before = verify_manifest(bundle)
    dump(out / "checks/input_contract_before.json", manifest_before)
    if not all(r["passed"] for r in manifest_before):
        raise RuntimeError("Bundled frozen input/code hash mismatch; see checks/input_contract_before.json")
    version_info = {name: importlib.metadata.version(name) for name in ("numpy", "scipy", "pandas")}
    command = [sys.executable, "-I", str(bundle / "run_expanded.py"),
               "--geometry", str(bundle / "prepared/frozen_expanded_geometry.json"),
               "--out", str(out / "scores"), "--jobs", str(args.jobs)]
    print("Replaying 3152 unchanged frozen records...", flush=True)
    with (out / "run_expanded.log").open("w", encoding="utf-8") as log:
        proc = subprocess.Popen(command, cwd=bundle, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in proc.stdout:
            log.write(line)
            log.flush()
            print(line.rstrip(), flush=True)
        if proc.wait() != 0:
            raise RuntimeError("Frozen runner failed; see run_expanded.log")
    print("Comparing every CSV and full-JSON value, including NA and reasons...", flush=True)
    comparisons = compare_record_outputs(bundle, out, args.atol, args.rtol)
    print("Replaying the 38 existing controls...", flush=True)
    controls = replay_controls(bundle, out, args.atol, args.rtol)
    print("Checking only current ERP dtype interface and all original source projections...", flush=True)
    dtype_module = load_module("portable_dtype_checks", bundle / "portable_support/test_adapter_dtype.py")
    dtype_report = dtype_module.run_checks(bundle, out / "adapter")
    manifest_after = verify_manifest(bundle)
    dump(out / "checks/input_contract_after.json", manifest_after)
    hashes_unchanged = manifest_before == manifest_after and all(r["passed"] for r in manifest_after)
    summary = {
        "reproduction_version": "portable_fixed_v11_3152_plus38_v1",
        "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.perf_counter()-t0, "python": sys.version,
        "platform": platform.platform(), "dependency_versions": version_info,
        "runner_command": command, "bundle": str(bundle), "out": str(out),
        "all_passed": comparisons["all_passed"] and controls["all_passed"]
                      and dtype_report["all_passed"] and hashes_unchanged,
        "frozen_input_and_code_hashes_unchanged": hashes_unchanged,
        "records": comparisons["records"], "old36_records": comparisons["old36_records"],
        "images": comparisons["images"], "buildings": comparisons["buildings"],
        "available_Q": comparisons["available_Q"], "unavailable_Q": comparisons["unavailable_Q"],
        "all3152_full_JSON_comparison": comparisons["full_JSON"],
        "all3152_CSV_comparison": comparisons["all_CSV"],
        "old36_full_JSON_comparison": comparisons["old36_full_JSON"],
        "old36_CSV_comparison": comparisons["old36_CSV"],
        "aggregate_comparisons": comparisons["aggregate_reports"],
        "control_summary": controls,
        "adapter_summary": {k: v for k, v in dtype_report.items() if k != "dtype_probes"},
        "legacy_optional_old36_path_exists": (bundle.parents[1] / "work/research_v1_1/results/scores36_geometry_only.csv").exists(),
        "portable_old36_baseline_used": True,
        "original_images_required_for_numeric_replay": False,
        "historical_source_directories_required": False,
        "source_geometry_or_GT_changed": False, "parameters_fitted": False,
        "subjective_scores_consumed": False,
    }
    dump(out / "reproduction_summary.json", summary)
    print(json.dumps({k: summary[k] for k in ["all_passed", "records", "images", "buildings",
          "available_Q", "unavailable_Q", "frozen_input_and_code_hashes_unchanged", "elapsed_seconds"]},
          ensure_ascii=False, indent=2), flush=True)
    print("Detailed report: " + str(out / "reproduction_summary.json"), flush=True)
    if not summary["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
