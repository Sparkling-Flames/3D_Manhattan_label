#!/usr/bin/env python3
"""Targeted current adapter scalar-type checks and unchanged real projection.

This does not run, replace, or modify the frozen geometry validator. It tests
the new ERP interface only, and never executes prepare_expanded.main().
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np


def dump(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False) + "\n", encoding="utf-8")


def stable_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    default=lambda x: {"type": type(x).__name__, "repr": repr(x)})
                          .encode()).hexdigest()


def run_checks(bundle, out):
    bundle, out = Path(bundle).resolve(), Path(out).resolve()
    path = bundle / "prepare_expanded.py"
    spec = importlib.util.spec_from_file_location("portable_current_erp_adapter", path)
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    geometry_path = bundle / "prepared/frozen_expanded_geometry.json"
    geometry = json.loads(geometry_path.read_text(encoding="utf-8-sig"))
    objects = [obj for im in geometry["images"] for obj in im["annotations"] + im["groundtruths"]]
    by_id = {obj["id"]: obj for obj in objects}
    base = by_id["R02075"]["source_record"]
    original_base_digest = stable_digest(base)
    probes = []

    def probe(name, transform):
        record = copy.deepcopy(base)
        record["points_1024x512"] = transform(record["points_1024x512"])
        before = stable_digest(record)
        projected = adapter.project_existing(record)
        codes = [x["code"] for x in projected["adapter_issues"]]
        passed = (codes == ["erp_coordinate_type_invalid"] and
                  projected["top3d"] is None and projected["bottom3d"] is None and
                  stable_digest(record) == before)
        probes.append({"check": name, "base_record_id": "R02075",
                       "expected": "reject before numeric promotion; preserve input",
                       "reason_codes": codes,
                       "input_preserved": stable_digest(record) == before, "passed": passed})

    def mixed(points, replacement):
        points[0][0] = replacement(points[0][0])
        return points

    probe("all_string_coordinates", lambda p: [[str(v) for v in row] for row in p])
    probe("mixed_single_string", lambda p: mixed(p, str))
    probe("all_boolean_coordinates", lambda p: [[bool(v) for v in row] for row in p])
    probe("mixed_single_python_boolean", lambda p: mixed(p, lambda v: True))
    probe("mixed_single_numpy_boolean", lambda p: mixed(p, lambda v: np.bool_(True)))
    probe("all_complex_coordinates", lambda p: [[complex(v, 0) for v in row] for row in p])
    probe("mixed_single_complex", lambda p: mixed(p, lambda v: complex(v, 0.1)))

    projection_rows = []
    maximum_override_delta = 0.0
    source_input_mutations = []
    non_numeric_real_input_ids = []
    for frozen in objects:
        source = frozen["source_record"]
        before = stable_digest(source)
        projected = adapter.project_existing(source)
        if stable_digest(source) != before:
            source_input_mutations.append(frozen["id"])
        raw = source.get("points_1024x512")
        original_numeric = raw is None or all(type(v) in (int, float) for row in raw for v in row)
        if not original_numeric:
            non_numeric_real_input_ids.append(frozen["id"])
        array_errors, exact = [], True
        max_delta = 0.0
        is_override = frozen.get("geometry_version_source") == "latest_thread_v1_1_frozen_geometry"
        for key in ("top3d", "bottom3d"):
            actual, expected = projected[key], frozen[key]
            if actual is None or expected is None:
                if actual != expected:
                    array_errors.append(key + ":null_mismatch")
                continue
            a, b = np.asarray(actual), np.asarray(expected)
            if a.shape != b.shape:
                array_errors.append(key + ":shape_mismatch")
                continue
            d = float(np.max(np.abs(a-b))) if a.size else 0.0
            max_delta = max(max_delta, d)
            exact = exact and np.array_equal(a, b)
            if d > (2e-12 if is_override else 0.0):
                array_errors.append(key + ":unexpected_coordinate_change")
        if is_override:
            maximum_override_delta = max(maximum_override_delta, max_delta)
        equal_fields = ["points", "sourcePointIndices", "sourcePairIndices",
                        "sourceExistingRingConnections", "adapter_issues"]
        field_errors = [key for key in equal_fields if projected.get(key) != frozen.get(key)]
        projection_rows.append({"record_id": frozen["id"], "object_kind": source["object_kind"],
            "latest_thread_geometry_override": is_override,
            "original_scalar_types_are_real_numbers": original_numeric,
            "projection_exactly_equal_to_packaged_geometry": exact and not array_errors,
            "maximum_absolute_projection_delta_h": max_delta,
            "errors": array_errors + field_errors,
            "passed": not array_errors and not field_errors and original_numeric})

    report = {
        "scope": "New ERP scalar-type interface only; no broad old suite and no frozen-kernel modifications.",
        "adapter_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "geometry_sha256": hashlib.sha256(geometry_path.read_bytes()).hexdigest(),
        "dtype_probes": probes, "dtype_probes_count": len(probes),
        "dtype_probes_failed": sum(not p["passed"] for p in probes),
        "real_objects_checked": len(objects),
        "real_annotations_checked": sum(r["object_kind"] == "annotation" for r in projection_rows),
        "latest_thread_override_objects": sum(r["latest_thread_geometry_override"] for r in projection_rows),
        "non_override_objects_exact": sum(not r["latest_thread_geometry_override"] and
                                           r["projection_exactly_equal_to_packaged_geometry"] for r in projection_rows),
        "latest_thread_override_maximum_delta_h": maximum_override_delta,
        "override_comparison_policy": "Known44 retain byte-for-byte earlier frozen 3D; re-projecting the identical original ERP can differ by prior last-bit arithmetic. The existing 2e-12 h audit tolerance applies only to these 44. All other objects require exact equality.",
        "real_projection_failures": sum(not r["passed"] for r in projection_rows),
        "source_input_mutation_ids": source_input_mutations,
        "non_numeric_real_input_ids": non_numeric_real_input_ids,
        "original_probe_base_unchanged": original_base_digest == stable_digest(base),
        "all_passed": all(p["passed"] for p in probes) and all(r["passed"] for r in projection_rows)
                      and not source_input_mutations and original_base_digest == stable_digest(base),
    }
    dump(out / "adapter_dtype_check.json", report)
    dump(out / "adapter_real_projection_checks3441.json", projection_rows)
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent.parent)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    report = run_checks(args.bundle, args.out)
    print(json.dumps({k: v for k, v in report.items() if k != "dtype_probes"}, ensure_ascii=False, indent=2))
    if not report["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
