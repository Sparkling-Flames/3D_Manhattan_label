#!/usr/bin/env python3
"""Adapt existing final ERP rings to unchanged v1.1; never re-pair or re-order.

Coordinates are continuous C-domain 1024x512. Source arrays, all provenance,
failed inputs, old gates and reference versions remain in the export.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, math
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def dump(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def issue(code,category,message,**extra):return dict(code=code,category=category,message=message,**extra)

def project_existing(record):
    """Read final pair/ring arrays once; do not reuse source indices to reorder."""
    r={'id':record['id'],'version':record.get('version'),
       'points':copy.deepcopy(record.get('points_1024x512')),
       'preprocessing':record.get('preprocessing'),
       'sourcePointIndices':record.get('ordered_source_point_indices'),
       'sourcePairIndices':record.get('ordered_source_pair_indices'),
       'sourceExistingRingConnections':record.get('existing_ring_connections'),
       'top3d':None,'bottom3d':None,'adapter_issues':[],
       'source_record':record}
    a=r['points']
    if a is None:
        basis=record.get('pairing_basis')
        if basis=='no_effective_points':
            cat='annotation_points_unavailable';msg='No effective final point/pair array in supplied snapshot; raw points are preserved when present.'
        else:
            cat='pairing_unresolved';msg='No existing usable paired final ring; source points exist but this run does not infer pairs or connections.'
        r['adapter_issues'].append(issue('final_paired_ring_unavailable',cat,msg,pairing_basis=basis))
        return r
    try:
        # Inspect original scalar types before numpy can promote mixed bool/float
        # or string/float input. JSON numbers are ints/floats, never booleans.
        original_values=np.asarray(a,dtype=object)
        if any(isinstance(v,(bool,np.bool_)) or not isinstance(v,(int,float,np.integer,np.floating))
               for v in original_values.flat):
            raise ValueError('Only original real numeric coordinate scalars are accepted')
        typed=np.asarray(a)
        if typed.dtype.kind not in 'iuf':
            raise ValueError('Only original real numeric coordinates are accepted')
        a=typed.astype(float,copy=False)
    except (ValueError,TypeError):
        r['adapter_issues'].append(issue('erp_coordinate_type_invalid','annotation_input_invalid','Final ERP coordinates are not a numeric array.'));return r
    if a.ndim!=2 or a.shape[1]!=2 or len(a)%2 or not np.isfinite(a).all():
        r['adapter_issues'].append(issue('erp_array_shape_or_number_invalid','annotation_input_invalid','Finite even-length Nx2 final array required.'));return r
    n=len(a)//2
    expected_pairs=[[2*i,2*i+1] for i in range(n)]
    expected={'top_edges':[[2*i,2*((i+1)%n)] for i in range(n)],
              'bottom_edges':[[2*i+1,2*((i+1)%n)+1] for i in range(n)],
              'paired_edges':expected_pairs}
    links=record.get('matterport_links_zero_based')
    con=record.get('existing_ring_connections') or {}
    if links!=expected_pairs or any(con.get(k)!=v for k,v in expected.items()):
        r['adapter_issues'].append(issue('existing_pair_or_ring_contract_mismatch','data_binding_conflict','Final array and explicitly supplied pair/edge indices disagree; no alternative ring selected.'));return r
    for component,inds in [('top',np.arange(0,len(a),2)),('bottom',np.arange(1,len(a),2))]:
        bad=inds[(a[inds,0]<0)|(a[inds,0]>1024)|(a[inds,1]<0)|(a[inds,1]>512)]
        if len(bad):r['adapter_issues'].append(issue('erp_coordinates_out_of_domain','annotation_input_invalid','ERP coordinate lies outside declared 1024x512 C domain; no trigonometric wrapping or clipping.',component=component,final_point_indices=bad.tolist(),coordinates=a[bad].tolist()))
    if any(x.get('component')=='bottom' for x in r['adapter_issues']):return r
    bt=a[1::2];tp=a[::2]
    bad=np.flatnonzero((bt[:,1]<=256)|(bt[:,1]>=512))
    if len(bad):
        r['adapter_issues'].append(issue('floor_ray_has_no_finite_paired_wall_projection','model_not_applicable','The floor ray must point below the horizon and away from the nadir degeneracy under the common floor y=-1 model.',pair_indices=bad.tolist()));return r
    phi_b=(.5-bt[:,1]/512)*np.pi
    radius=-1/np.tan(phi_b)
    theta_b=bt[:,0]/1024*2*np.pi
    bottom=np.column_stack((-radius*np.sin(theta_b),-np.ones(n),radius*np.cos(theta_b)))
    r['bottom3d']=bottom.tolist()
    if any(x.get('component')=='top' for x in r['adapter_issues']):return r
    bad=np.flatnonzero((tp[:,1]<=0)|(tp[:,1]>=512))
    if len(bad):
        r['adapter_issues'].append(issue('ceiling_ray_pole_has_no_finite_height','model_not_applicable','At an ERP pole no finite wall height at nonzero floor radius exists.',pair_indices=bad.tolist()));return r
    phi_t=(.5-tp[:,1]/512)*np.pi
    theta_t=tp[:,0]/1024*2*np.pi
    top=np.column_stack((-radius*np.sin(theta_t),radius*np.tan(phi_t),radius*np.cos(theta_t)))
    # Unshared x, if present, is preserved; strict vertical-pair validation rejects it.
    r['top3d']=top.tolist()
    return r

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--snapshot',default=str(ROOT/'data_snapshot'))
    ap.add_argument('--old-source',default=str(ROOT.parents[1]/'source/oct8-pro-quality-handoff'))
    ap.add_argument('--out',default=str(ROOT/'prepared'));args=ap.parse_args()
    source=Path(args.snapshot);old=Path(args.old_source);out=Path(args.out)
    records=read(source/'current/records.json')['objects'];rmap={x['id']:x for x in records}
    assert len(rmap)==len(records),'Duplicate object IDs'
    panel=read(source/'current/panel.json');inv={x['image_code']:x for x in read(source/'current/image_inventory.json')['images']}
    manifest={x['image_code']:x for x in read(source/'image_manifest.json')}
    oldf=read(old/'inputs/frozen_geometry.json');oldratings=read(old/'inputs/review36_user_20261008.json')['ratings']
    oldmap={x['id']:x for im in oldf['images'] for x in im['annotations']+im['groundtruths']}
    oldim={im['code']:im for im in oldf['images']}
    binding36={(x['imageCode'],x['recordId']):(x['referenceId'],x['referenceVersion']) for x in oldratings}
    reviewids={x['recordId']:x['reviewId'] for x in oldratings}
    config=read(ROOT/'frozen_engine/frozen_parameters.json');dev=set(config['development_buildings'])
    converted={};parity=[];conflicts=[]
    for r in records:
        g=project_existing(r)
        if r['id'] in oldmap:
            prior=oldmap[r['id']]
            same_points=g['points']==prior['points']
            same_pairs=g['sourcePairIndices']==prior['sourcePairIndices']
            same_indices=g['sourcePointIndices']==prior['sourcePointIndices']
            same_connections=g['sourceExistingRingConnections']==prior['sourceExistingRingConnections']
            delta=max(float(np.max(np.abs(np.asarray(g[k])-np.asarray(prior[k])))) for k in ['top3d','bottom3d']) if same_points else None
            parity.append({'record_id':r['id'],'image_code':r['image_code'],'points_identical':same_points,'source_pairs_identical':same_pairs,'source_points_identical':same_indices,'connections_identical':same_connections,'reprojection_max_abs_h':delta})
            if not (same_points and same_pairs and same_indices and same_connections):
                conflicts.append({'record_id':r['id'],'image_code':r['image_code'],'policy':'latest_thread_geometry_preserved','snapshot':g,'latest_thread':prior})
            # Keep current thread geometry/provenance exactly; historical snapshot is retained.
            for k in ['points','top3d','bottom3d','sourcePointIndices','sourcePairIndices','sourceExistingRingConnections','preprocessing']:
                g[k]=copy.deepcopy(prior.get(k))
            g['geometry_version_source']='latest_thread_v1_1_frozen_geometry'
            g['latest_thread_original']=prior
        else:g['geometry_version_source']='archive_current_final_ring_projection_v1'
        if r['id'] in reviewids:g['reviewId']=reviewids[r['id']]
        converted[r['id']]=g
    images=[];bindrows=[];grouprows=[];policies=[]
    for im in panel['images']:
        code=im['code'];ii=inv[code];mm=manifest[code]
        for part in ['annotations','references']:
            for obj in im[part]:
                assert obj['points']==rmap[obj['id']]['points_1024x512'],(code,obj['id'],'panel-record conflict')
        refs=[converted[x['id']] for x in im['references']]
        revised=[x for x in refs if x['version']=='manual_revision'];original=[x for x in refs if x['version']=='original']
        assert len(revised)<=1 and len(original)<=1,(code,'multiple same-version GT')
        chosen=(revised or original or [None])[0]
        if code in oldim:
            binding_values={v for k,v in binding36.items() if k[0]==code}
            assert len(binding_values)==1
            chosen=next(x for x in refs if (x['id'],x['version'])==next(iter(binding_values)))
        group=('historical_development_image' if code in oldim else 'additional_image_in_development_building' if im['building'] in dev else 'additional_image_in_new_building')
        policy='conditional_geometry';reason=None;reason_kind=None
        evidence=(ii.get('review') or {}).get('gt_evidence') or []
        if (ii.get('review') or {}).get('gt_substantive_error_mark'):
            assert chosen and chosen['version']=='original','Conflicting error evidence and manual revision requires explicit version audit'
            policy='reference_not_applicable';reason_kind='reference_adjudicated_error'
            reason='已有明确GT实质错误裁决且没有获确认替代参考；不把相对此GT的距离当实际质量。'
        if code in {'jtcxE69GiFV-11','pRbA3pwrgk9-16'}:
            policy='reference_not_applicable';reason_kind='historical_explicit_analysis_hold'
            reason='已有结构化用户暂缓全部分析裁决；当前保留原始输入和可计算几何诊断，不自动撤销暂缓。'
        if chosen is None:
            policy='data_missing';reason_kind='reference_data_missing';reason='No fixed reference object in supplied snapshot.'
        annotations=[]
        for obj in im['annotations']:
            a=converted[obj['id']]
            b=binding36.get((code,a['id']),(chosen['id'],chosen['version']) if chosen else (None,None))
            a['referenceId'],a['referenceVersion']=b
            a['binding_policy']='original36_recorded_reference' if (code,a['id']) in binding36 else 'fixed_per_image_manual_revision_where_available_else_original'
            annotations.append(a)
            bindrows.append({'image_code':code,'record_id':a['id'],'reference_id':b[0],'reference_version':b[1],'binding_policy':a['binding_policy'],'target_policy':policy,'target_reason_kind':reason_kind})
        imagepath=str((ROOT/'original_images'/mm['internal_path']).resolve())
        images.append({'code':code,'imageId':mm['image_id'],'building':im['building'],'room':im.get('room') or None,'population':im['population'],'imagePath':imagepath,'imageInternalPath':mm['internal_path'],'imageSize':[2048,1024],'canvas':[1024,512],'evaluation_group':group,'historical_exposure':'known_historical_archive_not_blind','historical_development_image':code in oldim,'source_image_inventory':ii,'source_scene':im.get('scene'),'defaultReferenceId':chosen['id'] if chosen else None,'defaultReferenceVersion':chosen['version'] if chosen else None,'targetApplicability':policy,'targetInapplicabilityReason':reason,'target_reason_kind':reason_kind,'target_evidence':evidence,'annotations':annotations,'groundtruths':refs})
        grouprows.append({'image_code':code,'building':im['building'],'room':im.get('room') or None,'population':im['population'],'evaluation_group':group,'records':len(annotations),'not_used_for_current_parameters':code not in oldim,'building_held_out_from_current_parameters':im['building'] not in dev,'blind_test_claimed':False})
        policies.append({'image_code':code,'reference_id':chosen['id'] if chosen else None,'reference_version':chosen['version'] if chosen else None,'reference_policy':'recorded_old36_target_or_manual_revision_where_available_else_original','target_applicability':policy,'target_reason_kind':reason_kind,'evidence':evidence})
    dump(out/'frozen_expanded_geometry.json',{'schema':'expanded_geometry_adapter_v1.0','created_utc':datetime.now(timezone.utc).isoformat(),'images':images})
    pd.DataFrame(bindrows).to_csv(out/'reference_bindings_before_scores.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(grouprows).to_csv(out/'image_groups_before_scores.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(parity).to_csv(out/'known44_input_parity.csv',index=False,encoding='utf-8-sig')
    dump(out/'reference_policies_before_scores.json',policies)
    dump(out/'latest_thread_vs_snapshot_conflicts.json',conflicts)
    contract={'created_utc':datetime.now(timezone.utc).isoformat(),'score_version':config['algorithm_version'],'parameter_definition_frozen_at':config['frozen_at_utc'],'parameters_sha256':digest(ROOT/'frozen_engine/frozen_parameters.json'),'bands_sha256':digest(ROOT/'frozen_engine/frozen_bands.json'),'adapter_sha256':digest(__file__),'input_geometry_sha256':digest(out/'frozen_expanded_geometry.json'),'source_hashes':{str(p.relative_to(source)):digest(p) for p in [source/'current/records.json',source/'current/panel.json',source/'current/image_inventory.json',source/'image_manifest.json']},'all_records_retained':True,'GT_selection_uses_scores':False,'human_grades_consumed':False,'conditional_reference_policy':'manual revision with existing ring confirmation where present, otherwise original; original36 recorded IDs override; latest thread geometry preserved; this does not certify every manual GT as physical truth','historical_repair_policy':'Use supplied final current arrays. Two explicit raw reinitialization notes (R00904,R01424) differ from historical applied-repair metadata; log both without applying or undoing edits. R01424 is outside ERP domain.','scene_policy':'No OOS, doorway, difficulty, point-count, prior cleaning or worker gate is used as an automatic mathematical validity exclusion. Explicit target error/hold evidence is retained separately.','post_validation_change_policy':'No parameter or GT changes after fixed-score results. Any necessary bug fix gets an explicit log and a replay.'}
    dump(out/'evaluation_contract_before_scores.json',contract)
    print(json.dumps({'images':len(images),'research_images':sum(bool(im['annotations']) for im in images),'records':len(bindrows),'known44_parity':len(parity),'thread_snapshot_conflicts':len(conflicts),'adapter_issue_records':sum(bool(g['adapter_issues']) for g in converted.values()),'reference_policy_holds':sum(x['target_applicability']!='conditional_geometry' for x in policies)},ensure_ascii=False))

if __name__=='__main__':main()
