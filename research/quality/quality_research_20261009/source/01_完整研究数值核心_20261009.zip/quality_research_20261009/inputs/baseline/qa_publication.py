#!/usr/bin/env python3
"""Render every delivered PDF page; audit layout and evidence coverage."""
from pathlib import Path
import json,re,hashlib
import fitz
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output/layout_quality_v1_1_expanded_20261009'
QA=ROOT/'publication_qa';QA.mkdir(exist_ok=True)
summaries=[]
for path in sorted(OUT.glob('*.pdf')):
    doc=fitz.open(path);name=path.name[:2];folder=QA/name;folder.mkdir(exist_ok=True)
    pages=[];text=[];bounds=[];imcounts=[]
    for i,page in enumerate(doc):
        words=page.get_text('words');text.append(page.get_text());imcounts.append(len(page.get_images()))
        for word in words:
            x0,y0,x1,y1,*_=word
            if x0 < 28 or y0 < 6 or x1 > page.rect.width-25 or y1 > page.rect.height-8:
                bounds.append({'page':i+1,'text':word[4],'box':[x0,y0,x1,y1]})
        pix=page.get_pixmap(matrix=fitz.Matrix(1.1,1.1),alpha=False)
        p=folder/f'page_{i+1:03d}.jpg';pix.pil_save(p,format='JPEG',quality=87);pages.append(p)
    for k in range(0,len(pages),12):
        part=pages[k:k+12];cols=3;rows=(len(part)+cols-1)//cols;tw=360;th=510
        sheet=Image.new('RGB',(cols*tw,rows*(th+24)),(219,228,234));draw=ImageDraw.Draw(sheet)
        for j,p in enumerate(part):
            im=Image.open(p);im.thumbnail((tw-8,th-8));x=(j%cols)*tw+(tw-im.width)//2;y=(j//cols)*(th+24)+24;sheet.paste(im,(x,y));draw.text(((j%cols)*tw+8,y-19),f'{name} / page {k+j+1}',fill=(23,51,75))
        sheet.save(folder/f'contact_{k//12+1:02d}.jpg',quality=92)
    full='\n'.join(text);ids=re.findall(r'R\d{5}',full)
    summaries.append({'file':path.name,'pages':len(doc),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'text_box_boundary_issues':bounds,'image_counts_per_page':imcounts,'record_ids_in_text':sorted(set(ids)),'all_pages_rendered':True,'visually_inspected':False})
    (folder/'extracted_text.txt').write_text(full)
(QA/'automated_checks.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k not in ['image_counts_per_page','record_ids_in_text','text_box_boundary_issues']} | {'boundary_issues':len(x['text_box_boundary_issues']),'unique_R_ids':len(x['record_ids_in_text'])} for x in summaries],ensure_ascii=False))
