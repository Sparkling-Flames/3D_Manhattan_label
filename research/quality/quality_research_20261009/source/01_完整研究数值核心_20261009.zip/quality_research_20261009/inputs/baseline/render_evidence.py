#!/usr/bin/env python3
"""Photo + original geometry evidence; no human scores or invented edges."""
from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import patheffects
from matplotlib.lines import Line2D
from matplotlib.patches import Polygon
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd
from PIL import Image

ROOT=Path(__file__).resolve().parent
CYAN='#00a9c8';ORANGE='#ee9400';INK='#182b3c'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def finite_ring(r,k):
    p=r.get(k)
    if p is None:return None
    a=np.asarray(p,float)
    return a if a.ndim==2 and a.shape[1]==3 and len(a)>0 and np.isfinite(a).all() else None
def bounds(records):
    p=[a for r in records for k in ['top3d','bottom3d'] if (a:=finite_ring(r,k)) is not None]
    p=np.concatenate(p+[np.zeros((1,3))]);lo=p.min(0);hi=p.max(0);span=np.maximum(hi-lo,.1)
    return lo-.09*span,hi+.09*span
def close(p):return np.vstack((p,p[0]))
def sphere_erp(p):
    r=np.linalg.norm(p,axis=1);theta=np.mod(np.arctan2(-p[:,0],p[:,2]),2*np.pi)
    phi=np.arctan2(p[:,1],np.hypot(p[:,0],p[:,2]))
    return np.column_stack((theta/(2*np.pi)*1024,(.5-phi/np.pi)*512))
def project_segment(a,b,n=257):
    na=np.linalg.norm(a);nb=np.linalg.norm(b)
    if min(na,nb)<=0:return []
    u=a/na;v=b/nb;angle=math.atan2(float(np.linalg.norm(np.cross(u,v))),float(np.dot(u,v)))
    t=np.linspace(0,1,n)
    if angle<1e-10:p=u[None,:]*(1-t[:,None])+v[None,:]*t[:,None]
    elif math.pi-angle<1e-9:return []
    else:p=(np.sin((1-t)*angle)[:,None]*u+np.sin(t*angle)[:,None]*v)/math.sin(angle)
    q=sphere_erp(p);cuts=np.flatnonzero(np.abs(np.diff(q[:,0]))>512)+1
    return [part for part in np.split(q,cuts) if len(part)>1]
def projected_paths(record):
    result=[]
    for key in ['top3d','bottom3d']:
        p=finite_ring(record,key)
        if p is None:continue
        for a,b in zip(p,np.roll(p,-1,axis=0)):result.extend(project_segment(a,b))
    t=finite_ring(record,'top3d');b=finite_ring(record,'bottom3d')
    if t is not None and b is not None:
        for a,c in zip(t,b):result.extend(project_segment(a,c,33))
    return result
def style2(ax):
    ax.set_facecolor('#fbfcfd');ax.grid(alpha=.28,color='#a9b7c5',lw=.6)
    for s in ax.spines.values():s.set_color('#cbd5df')
    ax.tick_params(labelsize=8,colors='#536574');ax.xaxis.set_major_locator(MaxNLocator(5));ax.yaxis.set_major_locator(MaxNLocator(5))
def draw_bev(ax,a,g,lim,valid=True):
    style2(ax)
    for r,c,ls in [(g,ORANGE,'--'),(a,CYAN,'-')]:
        p=finite_ring(r,'bottom3d')
        if p is None:continue
        p=p[:,[0,2]];q=close(p);ax.plot(q[:,0],q[:,1],c=c,ls=ls,lw=1.65)
        ax.scatter(p[:,0],p[:,1],s=10,c=c,zorder=5)
        if len(p)>=3 and (r is g or valid):ax.add_patch(Polygon(p,closed=True,color=c,alpha=.045))
    lo,hi=lim;mid=(lo+hi)/2;s=max(hi[0]-lo[0],hi[2]-lo[2]);ax.set(xlim=(mid[0]-s/2,mid[0]+s/2),ylim=(mid[2]-s/2,mid[2]+s/2),aspect='equal',xlabel='X / h',ylabel='Z / h')
    ax.scatter([0],[0],s=20,c=INK,marker='+',zorder=9)
    if finite_ring(a,'bottom3d') is None:ax.text(.5,.92,'Annotation BEV unavailable',transform=ax.transAxes,ha='center',fontsize=9,c='#a63d37',bbox=dict(facecolor='white',edgecolor='none',alpha=.8))
    ax.set_title('BEV / equal X-Z scale',fontsize=11,c=INK)
def draw_3d(ax,a,g,lim,valid=True):
    for r,c,ls in [(g,ORANGE,'--'),(a,CYAN,'-')]:
        t=finite_ring(r,'top3d');b=finite_ring(r,'bottom3d')
        for p in [t,b]:
            if p is None:continue
            p=close(p);ax.plot(p[:,0],p[:,2],p[:,1],c=c,ls=ls,lw=1.4)
        if t is not None and b is not None:
            for p,q in zip(t,b):ax.plot([p[0],q[0]],[p[2],q[2]],[p[1],q[1]],c=c,ls=ls,lw=.8,alpha=.8)
    lo,hi=lim;span=hi-lo;ax.set(xlim=(lo[0],hi[0]),ylim=(lo[2],hi[2]),zlim=(lo[1],hi[1]),xlabel='X / h',ylabel='Z / h',zlabel='Y / h');ax.set_box_aspect([span[0],span[2],span[1]])
    ax.set_proj_type('ortho');ax.view_init(elev=24,azim=-57)
    for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
        axis.set_major_locator(MaxNLocator(4));axis.pane.fill=False;axis.label.set_fontsize(8);axis._axinfo['grid'].update(color='#d5dce2',linewidth=.5)
    ax.tick_params(labelsize=7,pad=0);ax.scatter([0],[0],[0],c=INK,s=10,depthshade=False)
    if finite_ring(a,'top3d') is None:ax.text2D(.5,.94,'Annotation 3D unavailable',transform=ax.transAxes,ha='center',fontsize=9,c='#a63d37')
    elif not valid:ax.text2D(.5,.94,'Invalid input / wireframe only',transform=ax.transAxes,ha='center',fontsize=9,c='#a63d37')
    ax.set_title('Conditional 3D / true axis proportions',fontsize=10,c=INK)
    if span[1]/max(span[0],span[2])<.08:
        ax.set_zticks([]);ax.set_zlabel('');ax.text2D(.5,.04,f'Y: {lo[1]:.2f} to {hi[1]:.2f} h',transform=ax.transAxes,ha='center',fontsize=8)
def render(job):
    im,a,g,meta,out,dpi,lim=job
    fig=plt.figure(figsize=(18,6.5),facecolor='white')
    gs=fig.add_gridspec(1,3,width_ratios=[2.18,1,1.15],left=.018,right=.956,bottom=.18,top=.81,wspace=.17)
    fig.text(.022,.963,f"{a['id']}    {im['code']}    GT {g['id']} ({g['version']})",fontsize=15.5,c=INK,weight='bold',va='top')
    status=meta.get('unavailable_primary_reason','available')
    desc=('CONTROL / exact reference copy; not a submitted annotation' if a['id'].startswith('GT_COPY_')
          else 'Original submitted final ring; no repair or individual alignment' if status=='available'
          else 'Review status: '+status)
    fig.text(.022,.903,desc,fontsize=10.5,c='#536574',va='top')
    ax=fig.add_subplot(gs[0,0]);photo=Image.open(im['imagePath']);photo.load();ax.imshow(photo,extent=(0,1024,512,0));photo.close()
    count=0
    for r,c,ls in [(g,ORANGE,'--'),(a,CYAN,'-')]:
        for segment in projected_paths(r):
            line,=ax.plot(segment[:,0],segment[:,1],c=c,ls=ls,lw=1.25 if ls=='--' else 1.1)
            line.set_path_effects([patheffects.Stroke(linewidth=1.9,foreground='white',alpha=.5),patheffects.Normal()]);count+=1
    raw_mode=a.get('points') is None
    p=a.get('points') if not raw_mode else a.get('source_record',{}).get('original_export_points')
    if p is not None and len(p):
        p=np.asarray(p,float);ok=np.isfinite(p).all(1)&(p[:,0]>=0)&(p[:,0]<=1024)&(p[:,1]>=0)&(p[:,1]<=512)
        ax.scatter(p[ok,0],p[ok,1],s=11,c=CYAN,edgecolor='white',linewidths=.3,zorder=10)
        if raw_mode:
            for i,(x,y) in enumerate(p):
                if ok[i]:ax.text(x+3,y-3,str(i+1),c='white',fontsize=6.5,path_effects=[patheffects.withStroke(linewidth=1.5,foreground='#154354')])
        if not ok.all():ax.text(.01,.02,'Out-of-domain source point retained in JSON; not clipped into image',transform=ax.transAxes,fontsize=8,c='white',bbox=dict(facecolor='#912a2a',alpha=.85,pad=3))
    if raw_mode:ax.text(.01,.02,'Raw points only: no verified pairs / no invented connections',transform=ax.transAxes,fontsize=8,c='white',bbox=dict(facecolor='#263747',alpha=.85,pad=3))
    ax.set(xlim=(0,1024),ylim=(512,0));ax.axis('off');ax.set_title('Original panorama / seam-split exact-curve projection',fontsize=11,c=INK)
    draw_bev(fig.add_subplot(gs[0,1]),a,g,lim,meta.get('annotation_valid_3d',True));draw_3d(fig.add_subplot(gs[0,2],projection='3d'),a,g,lim,meta.get('annotation_valid_3d',True))
    fig.legend(handles=[Line2D([0],[0],c=CYAN,lw=2,label='Annotation (raw points when final ring unavailable)'),Line2D([0],[0],c=ORANGE,ls='--',lw=2,label='Fixed reference GT')],loc='lower left',bbox_to_anchor=(.018,.020),frameon=False,ncol=2,fontsize=10)
    fig.text(.985,.055,'h = common camera-to-floor unit; not metres',ha='right',fontsize=9,c='#536574')
    fig.text(.985,.014,'Old subjective ratings hidden. Axes shared within shown comparison.',ha='right',fontsize=9,c='#536574')
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True);fig.savefig(out,dpi=dpi,facecolor='white',pil_kwargs={'quality':93,'subsampling':0,'optimize':True});plt.close(fig)
    return {'record_id':a['id'],'image_code':im['code'],'reference_id':g['id'],'reference_version':g['version'],'file':out.name,'axes_low_xyz':lim[0].tolist(),'axes_high_xyz':lim[1].tolist(),'old_subjective_score_shown':False,'raw_points_only':raw_mode,'projected_segments':count,'photo_sha256':hashlib.sha256(Path(im['imagePath']).read_bytes()).hexdigest(),'card_sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--only',help='Comma-separated IDs for targeted inspection');ap.add_argument('--jobs',type=int,default=4);ap.add_argument('--images-dir',type=Path,help='Extracted original-photo root containing images/<building>/...');args=ap.parse_args()
    geom=read(ROOT/'prepared/frozen_expanded_geometry.json');f=pd.read_csv(ROOT/'results_fixed/all_records_scores.csv').set_index('record_id');selection=pd.read_csv(ROOT/'visuals/atlas_selection.csv')
    if args.images_dir:
        for im in geom['images']:
            im['imagePath']=str(args.images_dir / im['imageInternalPath'])
    lookup={a['id']:(im,a) for im in geom['images'] for a in im['annotations']}
    ids=set(args.only.split(',')) if args.only else set(selection.record_id)|set(f[f.score_status!='available'].index)
    tasks=[]
    for rid in sorted(ids):
        if rid.startswith('GT_COPY_'):
            im,g=next((im,g) for im in geom['images'] for g in im['groundtruths'] if g['id']==rid[len('GT_COPY_'):]);a=dict(g);a['id']=rid
            tasks.append((im,a,g,{'unavailable_primary_reason':'available','annotation_valid_3d':True},str(ROOT/'visuals/cards'/f'{rid}.jpg'),180,bounds([a,g])))
            continue
        im,a=lookup[rid];g=next(g for g in im['groundtruths'] if (g['id'],g['version'])==(a['referenceId'],a['referenceVersion']));meta=f.loc[rid].to_dict()
        tasks.append((im,a,g,meta,str(ROOT/'visuals/cards'/f'{rid}.jpg'),180 if rid in set(selection.record_id) else 120,bounds([a,g])))
    # Reference-copy controls inspect the own-geometry prior; they are never annotation records.
    if not args.only:
        for code in ['wc2JMjhGNzB-14','x8F5xyUWy9e-09']:
            im=next(im for im in geom['images'] if im['code']==code);g=next(g for g in im['groundtruths'] if g['id']==im['defaultReferenceId']);a=dict(g);a['id']='GT_COPY_'+g['id']
            tasks.append((im,a,g,{'unavailable_primary_reason':'available','annotation_valid_3d':True},str(ROOT/'visuals/cards'/f"GT_COPY_{g['id']}.jpg"),180,bounds([a,g])))
    results=[]
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for k,v in enumerate(pool.map(render,tasks,chunksize=2),1):
            results.append(v)
            if k%30==0:print('rendered',k,'/',len(tasks),flush=True)
    manifest=ROOT/'visuals'/('cards_manifest_partial.json' if args.only else 'cards_manifest.json')
    manifest.write_text(json.dumps(results,ensure_ascii=False,indent=2))
    # Review contact sheets retain full originals as separate files.
    shown=[r for r in results if r['record_id'] in set(selection.record_id) or r['record_id'].startswith('GT_COPY')]
    for page in range(0,len(shown),4):
        imgs=[]
        for r in shown[page:page+4]:
            im=Image.open(ROOT/'visuals/cards'/r['file']);imgs.append(im.resize((1620,585),Image.Resampling.LANCZOS).convert('RGB'));im.close()
        sheet=Image.new('RGB',(1620,585*len(imgs)+14*(len(imgs)-1)),(223,231,237));y=0
        for im in imgs:sheet.paste(im,(0,y));y+=599
        sheet.save(ROOT/'visuals'/f'contact_{page//4+1:02d}.jpg',quality=92)
    print(json.dumps({'cards':len(results),'selected_real':len(selection),'unavailable_real':int((f.score_status!='available').sum()),'no_subjective_ratings_drawn':True},ensure_ascii=False))
if __name__=='__main__':main()
