#!/usr/bin/env python3
"""Convenience entry for the unchanged portable verification runner."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).resolve().parent / "portable_support/reproduce.py"), run_name="__main__")
