#!/usr/bin/env python3
"""Full fixed-parameter replay with original rows and explicit failure taxonomy."""
from __future__ import annotations
import argparse, hashlib, json, os, sys, time
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor
import pandas as pd

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'frozen_engine/core'))
from quality_v11 import score_geometry, load_parameters
from run_replay import flatten, dump, csv

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def do_job(job):
    ann,gt,identity,policy,reason,params,bands=job
    result=score_geometry(ann,gt,params,target_applicability=policy,target_inapplicability_reason=reason)
    row=flatten(result,identity,bands)
    adapter=ann.get('adapter_issues',[])+gt.get('adapter_issues',[])
    row['adapter_reason_codes']='|'.join(x['code'] for x in adapter)
    row['adapter_failure_classes']='|'.join(dict.fromkeys(x['category'] for x in adapter))
    row['input_issue_evidence']=json.dumps(adapter,ensure_ascii=False)
    row['geometry_issue_evidence']=json.dumps(result['issues'],ensure_ascii=False)
    if result['status']=='available':primary='available'
    elif any(x['category']=='annotation_points_unavailable' for x in adapter):primary='annotation_points_unavailable'
    elif any(x['category']=='pairing_unresolved' for x in adapter):primary='existing_pairing_unresolved'
    elif any(x['category']=='annotation_input_invalid' for x in adapter):primary='annotation_input_domain_invalid'
    elif any(x['category']=='data_binding_conflict' for x in adapter):primary='data_binding_conflict'
    elif adapter:primary='projection_model_not_applicable'
    elif not result['annotation_validity']['valid_3d']:primary='annotation_geometry_invalid'
    elif identity.get('target_reason_kind'):primary=identity['target_reason_kind']
    elif not result['reference_validity']['valid_3d']:primary='reference_geometry_invalid'
    elif 'metric_domain_not_applicable' in result['failure_classes']:primary='required_metric_domain_not_applicable'
    else:primary='required_numerical_computation_failed'
    row['unavailable_primary_reason']=primary
    row['all_failure_evidence_categories']='|'.join(dict.fromkeys([*result['failure_classes'],*[x['category'] for x in adapter],*([identity['target_reason_kind']] if identity.get('target_reason_kind') else [])]))
    row['pair_count']=len(ann['points'])//2 if ann.get('points') is not None else None
    row['original_point_count']=len(ann['source_record'].get('original_export_points') or [])
    row['traditional_reference_interpretation']=('relative_to_fixed_reference_conditional_geometry' if policy=='conditional_geometry' else 'diagnostic_only_reference_not_approved_for_actual_quality')
    full={**identity,**result,'adapter_issues':adapter,'unavailable_primary_reason':primary}
    return row,full

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--geometry',default=str(ROOT/'prepared/frozen_expanded_geometry.json'));ap.add_argument('--out',default=str(ROOT/'results_fixed'));ap.add_argument('--jobs',type=int,default=4);args=ap.parse_args()
    path=Path(args.geometry);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    geom=read(path);params=load_parameters(ROOT/'frozen_engine/frozen_parameters.json');bands=read(ROOT/'frozen_engine/frozen_bands.json')
    jobs=[]
    for im in geom['images']:
        refs={(g['id'],g['version']):g for g in im['groundtruths']}
        ii=im['source_image_inventory']
        for ann in im['annotations']:
            source=ann['source_record'];gt=refs.get((ann['referenceId'],ann['referenceVersion']))
            if gt is None:raise RuntimeError('Missing pre-bound reference: '+ann['id'])
            ident={'review_id':ann.get('reviewId',ann['id']),'record_id':ann['id'],'canonical_object_id':source['canonical_object_id'],'image_code':im['code'],'image_id':im['imageId'],'building':im['building'],'room':im.get('room'),'evaluation_group':im['evaluation_group'],'historical_exposure':im['historical_exposure'],'old36_record':bool(ann.get('reviewId')),'reference_id':gt['id'],'reference_version':gt['version'],'reference_binding_policy':ann['binding_policy'],'target_applicability':im['targetApplicability'],'target_reason_kind':im.get('target_reason_kind'),'preprocessing_version':ann.get('preprocessing'),'geometry_version_source':ann.get('geometry_version_source'),'ring_order_status':source['order_status'],'ring_human_confirmed':source['ring_confirmed'],'pairing_basis':source.get('pairing_basis'),'snapshot_geometry_status':source.get('geometry',{}).get('status'),'snapshot_geometry_issues':'|'.join(source.get('geometry',{}).get('issues',[])),'snapshot_quality_gate':source.get('worker_quality_gate'),'snapshot_cleaning_disposition':source.get('cleaning_disposition'),'snapshot_independent_vote':source.get('independent_vote_eligible'),'snapshot_independence_reasons':'|'.join(source.get('independent_vote_reasons') or []),'condition_preserved_not_used_for_Q':source.get('condition'),'scene_oos_status':source.get('scene_oos_status'),'scene_doorway_status':source.get('scene_doorway_status'),'scene_category':source.get('scene_category'),'later_scene_description':ii.get('later_scene_description'),'historical_difficulty_not_used_for_Q':ii.get('difficulty'),'scope_evidence_flag':bool(ii.get('review',{}).get('scope_explicit_tag') or ii.get('review',{}).get('scope_existing_ledger')),'detail_evidence_flag':bool(ii.get('review',{}).get('detail_explicit_tag') or ii.get('review',{}).get('detail_existing_ledger')),'reference_detail_omission_flag':bool(ii.get('review',{}).get('gt_detail_omission_mark')),'reference_uncertain_flag':bool(ii.get('review',{}).get('gt_uncertainty_explicit_tag')),'historical_coordinate_version_note':'|'.join(source.get('initialization_notes') or []),'image_internal_path':im['imageInternalPath'],'geometry_source':'prepared/frozen_expanded_geometry.json','old_subjective_score_used':False}
            jobs.append((ann,gt,ident,im['targetApplicability'],im.get('targetInapplicabilityReason'),params,bands))
    started=datetime.now(timezone.utc).isoformat();t0=time.perf_counter()
    dump(out/'run_start_before_scores.json',{'started_utc':started,'geometry_sha256':sha(path),'parameters_sha256':sha(ROOT/'frozen_engine/frozen_parameters.json'),'bands_sha256':sha(ROOT/'frozen_engine/frozen_bands.json'),'runner_sha256':sha(__file__),'jobs':len(jobs),'parameter_selection_performed':False,'group_and_target_contract':'prepared/evaluation_contract_before_scores.json'})
    rows=[];full=[]
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for k,(row,res) in enumerate(pool.map(do_job,jobs,chunksize=10),1):
            rows.append(row);full.append(res)
            if k%200==0:print('scored',k,'of',len(jobs),'elapsed',round(time.perf_counter()-t0,1),flush=True)
    f=csv(out/'all_records_scores.csv',rows)
    dump(out/'all_records_results.json',full)
    unavailable=f[f.score_status!='available']
    csv(out/'unavailable_manual_review.csv',unavailable)
    metric_cols=['quality_score','iou_2d','iou_3d_corner_mean','iou_3d_perimeter_mean','C','S_top_deg','S_bottom_deg','Hmean','Hlocal','Hstar','dir','flat','U','B','T','F']
    availability=[]
    for c in metric_cols:
        availability.append({'metric':c,'valid_records':int(f[c].notna().sum()) if c in f else 0,'unavailable_records':int(f[c].isna().sum()) if c in f else len(f),'denominator_all_records':len(f),'valid_images':int(f.loc[f[c].notna(),'image_code'].nunique()) if c in f else 0})
    csv(out/'metric_availability_counts.csv',availability)
    csv(out/'failure_primary_counts.csv',unavailable.groupby('unavailable_primary_reason',dropna=False).size().rename('records').reset_index())
    csv(out/'band_counts_by_group.csv',f.groupby(['evaluation_group','quality_band'],dropna=False).size().rename('records').reset_index())
    for key in ['image_code','building']:
        summary=[]
        for code,g in f.groupby(key,sort=True):
            valid=g[g.score_status=='available'];r={key:code,'records_all':len(g),'images':g.image_code.nunique(),'building':g.building.iloc[0],'room':g.room.iloc[0] if key=='image_code' else None,'available_Q':len(valid),'unavailable_Q':len(g)-len(valid),'records_with_2d_IoU':int(g.iou_2d.notna().sum()),'records_with_corner_3d_IoU':int(g.iou_3d_corner_mean.notna().sum()),'records_with_perimeter_3d_IoU':int(g.iou_3d_perimeter_mean.notna().sum()),'Q_mean_observed_records_only':valid.quality_score.mean(),'Q_median_observed_records_only':valid.quality_score.median(),'Q_min':valid.quality_score.min(),'Q_max':valid.quality_score.max(),'evaluation_groups':'|'.join(sorted(g.evaluation_group.unique())),'not_population_quality_or_difficulty':True}
            for lab in ['高','较好','一般','较差']:r['band_'+lab]=int((valid.quality_band==lab).sum())
            for metric in ['iou_2d','iou_3d_corner_mean','iou_3d_perimeter_mean','Hstar','boundary_rms_deg']:r[metric+'_median_available']=g[metric].median()
            summary.append(r)
        csv(out/('by_image.csv' if key=='image_code' else 'by_building.csv'),summary)
    known=pd.read_csv(ROOT.parents[1]/'work/research_v1_1/results/scores36_geometry_only.csv') if (ROOT.parents[1]/'work/research_v1_1/results/scores36_geometry_only.csv').exists() else None
    parity=None
    if known is not None:
        merged=f[f.old36_record].merge(known[['record_id','reference_id','reference_version','quality_score']],on='record_id',suffixes=('_expanded','_prior'))
        merged['delta_Q']=merged.quality_score_expanded-merged.quality_score_prior
        merged['same_reference']=(merged.reference_id_expanded==merged.reference_id_prior)&(merged.reference_version_expanded==merged.reference_version_prior)
        csv(out/'old36_frozen_replay_parity.csv',merged)
        parity={'records':len(merged),'all_reference_ids_same':bool(merged.same_reference.all()),'max_abs_Q_delta':float(merged.delta_Q.abs().max())}
    summary={'score_version':'geom_quality_research_v1.1.0','records_all':len(f),'images_research':f.image_code.nunique(),'buildings_research':f.building.nunique(),'available_Q':int((f.score_status=='available').sum()),'unavailable_Q':int((f.score_status!='available').sum()),'bands':f.quality_band.value_counts().to_dict(),'primary_unavailable':unavailable.unavailable_primary_reason.value_counts().to_dict(),'available_annotation_3D_geometry':int(f.annotation_valid_3d.sum()),'available_images_Q':f.loc[f.score_status=='available','image_code'].nunique(),'all_buildings_with_Q':f.loc[f.score_status=='available','building'].nunique(),'old36_parity':parity,'parameters_changed':False,'independent_blind_claimed':False,'elapsed_seconds':time.perf_counter()-t0,'geometry_unchanged':sha(path)==read(out/'run_start_before_scores.json')['geometry_sha256'],'finished_utc':datetime.now(timezone.utc).isoformat()}
    dump(out/'summary.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
