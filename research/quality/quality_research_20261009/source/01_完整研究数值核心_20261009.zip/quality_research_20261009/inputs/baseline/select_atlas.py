#!/usr/bin/env python3
"""Deterministic fixed-score case selection; no old human grades read."""
from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parent
f=pd.read_csv(ROOT/'results_fixed/all_records_scores.csv');g=f[f.score_status=='available'].copy()
rows=[];selected=set()
def add(row,section,reason,anchor=None):
    d=row.to_dict();d.update(atlas_section=section,selection_reason=reason,selection_anchor=anchor)
    rows.append(d);selected.add(row.record_id)
for lab,anchor in [('高',98.),('较好',90.),('一般',70.),('较差',25.)]:
    s=g[(g.quality_band==lab)&(~g.old36_record)].copy();s['anchor_gap']=(s.quality_score-anchor).abs()
    used_b=set();n=0
    for require_new in [True,True,False]:
        cand=s[(~s.building.isin(used_b))&(~s.record_id.isin(selected))]
        if require_new:cand=cand[cand.evaluation_group=='additional_image_in_new_building']
        if cand.empty:continue
        r=cand.sort_values(['anchor_gap','image_code','record_id']).iloc[0]
        add(r,'representative_'+lab,'Closest to fixed within-band anchor; distinct buildings; first two from buildings held out of current parameter choice.',anchor)
        used_b.add(r.building);n+=1
for t in [95,85,50]:
    for side in ['below','above']:
        s=g[(g.quality_score<t) if side=='below' else (g.quality_score>=t)].copy()
        s['boundary_gap']=(s.quality_score-t).abs();used_b=set()
        for _ in range(2):
            cand=s[(~s.building.isin(used_b))&(~s.record_id.isin(selected))]
            r=cand.sort_values(['boundary_gap','image_code','record_id']).iloc[0]
            add(r,f'boundary_{t}_{side}','Closest score on specified side; distinct buildings; no human rating used.',t)
            used_b.add(r.building)
special={
 'R00421':'largest_real_height_revision',
 'R00384':'height_revision_and_reference_detail_limit',
 'R01114':'high_BEV_large_top_boundary_difference_OOS',
 'R01672':'high_BEV_wrong_height_or_top_boundary',
 'R01360':'same_image_boundary_error',
 'R02187':'same_image_high_quality_comparison',
 'R02141':'regular_geometry_low_extent_agreement',
 'R00086':'regular_geometry_scope_difference_new_building',
 'R00768':'high_score_reference_detail_omission_warning',
 'R01613':'high_score_complex_reference',
 'R02854':'top_below_camera_still_evaluable',
 'R00904':'documented_historical_repair_vs_current_reinitialization',
 'R00186':'severe_extent_missing_but_regular',
 'R02075':'nonorthogonal_reference_prior_limit',
 'R00328':'irregular_reference_model_warning',
 'R00474':'high_Q_on_OOS_new_building',
 'R03398':'doorway_annotation_local_height_error',
 'R03168':'band_scale_sensitivity_example',
}
for rid,why in special.items():
    r=f[f.record_id==rid].iloc[0]
    add(r,'diagnostic_'+why,why)
out=ROOT/'visuals';out.mkdir(exist_ok=True)
pd.DataFrame(rows).to_csv(out/'atlas_selection.csv',index=False,encoding='utf-8-sig')
(out/'selection_policy.json').write_text(json.dumps({'old_human_scores_read':False,'representative_fixed_Q_anchors':{'高':98,'较好':90,'一般':70,'较差':25},'representatives_per_band':3,'boundaries':{'values':[95,85,50],'each_side_distinct_buildings':2},'diagnostic_cases':special,'all_unavailable_records_will_get_evidence_cards':True,'selected_rows':len(rows),'unique_records':len(selected)},ensure_ascii=False,indent=2))
print(pd.DataFrame(rows)[['atlas_section','record_id','image_code','quality_score']].to_string(index=False))
