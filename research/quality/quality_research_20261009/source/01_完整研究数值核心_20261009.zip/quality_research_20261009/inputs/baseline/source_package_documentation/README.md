# Pro扩图质量研究资料包

本包只整理已有输入、结果与真实原图。研究目标与方法选择见用户另发prompt；这里不规定下一轮指标组合、权重或实验路线。

现行只读入口由 `load_current_bundle()` → `project_bundle()` 导出。来源HEAD为 `fd62c786aa1869361c03d08b3eda6a63d24f175b`，同时包含清单注明的已完成工作区快照，不能把全部内容称为该提交的冻结结果。

总体核对：259张研究图、22栋建筑、3152份人员记录、27名人员；259份原GT、30份人工修订GT，另2张仅GT参考图。204研究图有room绑定，55图未知，不据此强造独立房间。实际原图261/261找到，其中259张研究图无缺失。逐张解码的来源尺寸均为2048×1024；当前C标注域1024×512，显示比例2×2，原件未转码、缩图、旋转或改接缝。

上传/解压：上传数据ZIP及3个原图ZIP，在同一目录解压。每张原图的ZIP、内部路径、image_id、building/room、尺寸、坐标域与GT绑定见 `image_manifest.csv/json`。原图仅出现一次，不依赖本地盘符或网络链接。

- `current/panel.json`：现行匿名全图投影，3152份人员记录及全部参考，保留缺失、排除和历史版本。
- `current/records.json`：原导出/预处理前/预处理后/最终环四种坐标视图、上下配对、来源点/对索引、现存环连接、人审确认、清洗、质量/共识资格、借用关系和失败原因。
- `current/image_inventory.csv/json`：全图建筑/房间、现行场景与后续难度来源、GT适用性证据及原有可计算字段。后续标签单列，不反写资格。
- `current/task_initialization.json`：3152份记录的既有任务字段；2501份有vis_3d初始化payload，651份无该payload。prediction可能只是引用，未内嵌就记缺失。任务字段不能认证实际屏幕曝光或历史模型phase，manual中的payload不证明模型辅助。
- `current/identity_binding.json`、`duplicate_versions.json`、`room_registry.json`：匿名代号/canonical复现ID、版本/独立性、同房证据。没有实名、联系方式或凭证。
- `evidence/relevant_comments.json`：1181条相关历史原话/线索，保留出现来源和绑定。现行裁决由records中的gate/结构化证据承接；评论不自动升级为裁决。同目标局部判断不认证完整layout。
- `analysis_results/`：下表所列历史实际结果、输入、字段定义、失败状态与已完成上下候选；`tools/`包含指标及本地源码依赖。
- `source_inventory.json`：每个复制文件的来源、用途、大小与工作区状态；`privacy_projection.json`记录本机用户目录前缀及无关个人评语的摘录处理。几何、资格和数值未被隐私处理修改。

|既有研究|包内实际材料与分母|
|---|---|
|layout_algorithm_exploration_20260926|geometry/geometry_results.json含13个几何控制的坐标、高度及历史加权结果；real/real_case_probe.json含真实候选原/共享x变体、GT、来源和条件可计算性；当时4图4份真实候选、终审确认0，另有截图两种连接对照。|
|layout_metric_response_20261001|完整results.json含74个控制的a/b及指标、固定真实小面板和缺失参考；real/synthetic CSV、报告、字段定义、计划与图表。|
|layout_3d_quality_probe_20261002|12图195记录、390个参考版本比较，117个参考缺失；objects/real/orders存实际输入、已有自身/参考方向轴、高度与模型体积定义；metrics/order_comparisons/results全带。|
|worker_profiles_20261003|共同24×10/8建筑的input、block、source_binding、answer_metrics、IoU/面积质心矩阵、weight_sensitivity、summary及原有组合产物。旧Q构成校准用纯IoU，加权仅历史敏感性；4图修订+6图原GT政策不叫10图修订真值。|
|point_route_panel_20261005 / adaptive_point_20261007|已完成上下候选及真实失败；九图与137图扩展分开，保留输入/参考、状态、局部人审及报告。探索候选不认证完整方法，未夹带其他正在推进的未完成实验。|

历史指标实现与复算入口见 `REPLAY_MATERIALS.md`。历史公式、P/C解释、默认环处理和分母继续按当时材料解释；当前全库输入另列，不能拿当前状态追改历史结果。历史报告里的待办/路线只代表当时文本。

必要字段语义见 `field_contract.json`：2030个candidate_pending_geometry仅是候选，未认证质量合格或全库上下/3D成功率。不同点对数仍是不同表达，保留近180节点；近似同空间与质量分别解释。Lee候选仅BEV范围基线，主点候选保留top/bottom/配对/连接。OOS、门洞、可标性及GT适用性不混为一类；凸出壁炉/装饰语义保留已有局部人审，GT接近不是唯一合理目标。

打开原图必须实际解码/查看，不能凭清单路径声称看过。旧研究涉及的图片是已使用材料，不能仅因这次换包称为从未见盲测。部分评论是历史线索，部分是已有明确裁决，按来源和绑定强度阅读。

本次仅验证包结构、JSON/CSV、源码入口导入、核心引用、ZIP路径和原图可解码尺寸；未重新运行研究指标、全量实验、pytest或全文件SHA认证。旧VALIDATION/acceptance只说明旧运行。本次检查见 `VERIFICATION.json`。

未把完整原始私有评论库/界面元数据或全量运行时导出放入可上传包；历史结果已包含指标所需的序列化坐标。原始生成器从仓库真源重建/重新核验原导出的整流程依赖不等同于摘录包的指标复算入口。源文档中的额外仓库链接不保证全部在包内，已列于 `reference_audit.json`；核心资料入口全部在包内。

所有原件与仓库保持原样；新文件仅在仓库外输出目录。没有向Pro/GitHub发布，没有创建额外任务。Library尚未上传：当前Windows不支持该流程必需的元数据步骤。用户可直接从本地上传这4个ZIP。
