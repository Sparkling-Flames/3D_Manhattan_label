# 既有指标的实际复算材料

源码、序列化输入与历史结果一起交付；本次没有执行下列研究复算，也不规定Pro下一轮方案。使用新输出目录，勿覆盖历史工件。

1. 9/26几何：`geometry/geometry_results.json`各case含points_a/points_b、height_a/height_b；`layout_metric_probe_20260926.polygon_metrics(a,b,height_a,height_b)`就是已有核。历史网格 `[0,.25,.5,1,2]` 与 `Eλ=(1−IoU)+λ·dc/√areaG` 在该实现/JSON定义中，dc为区域面积质心距离。
2. 9/26真实：`real/real_case_probe.json`的selected_cases[].variants包含实际上下pairs、raw/shared_x两阶段以及条件地面几何；references含raw_points、来源环依据和bev_order_available。`layout_real_case_probe_20260926.inspect_pairs`、`compare_footprints`及该模块原函数给出指标实现。无参考连接证据者保留不可算，不能调用当前环替代历史未定环。screenshot_representation_probe单列两种用户指定连接。
3. 10/1：results.json的synthetic/real每行均保存a/b；`layout_metric_response_20261001.measure(a,b,synthetic=True)`计算控制，真实用synthetic=False。缺失b的行沿已存缺失状态，不能删除或补GT；8192采样对照单独保留在boundary_dense_check。
4. 10/2：results.json的real每行保存该实验实际使用的a/b（包括当时默认环处理结果），`layout_3d_quality_probe_20261002.compare(a,b)`复用已有高度/自身轴/参考轴定义。不要再次prepare_record排序当前全库；历史orders是当时连接敏感性对照，非本次改环许可。objects已保存逐边方向、墙高及状态。
5. 10/3共同画像：完整固定input.json/block.json、area_metrics、source_binding及rosters均在包内。原消费者支持 `python -B -m tools.thesis_main.analysis.worker_profiles_20261003 --input analysis_results/worker_profiles_20261003/input.json --out <新目录>`。该命令包含原有组合枚举，属于研究复算，本次未运行。旧Q用纯IoU；weight_sensitivity的加权只是历史排名诊断。

上述路径以数据ZIP解压根目录为工作目录；tools使用Python namespace结构，依赖列于code_dependencies.json。原图另3包解压同一根目录；任何需要显示原图的代码按image_manifest的内部路径定位，不能依赖旧机器路径。

提供的本地源码依赖由imports递归获得并经入口导入检查；只做入口导入检查，不宣称整流程跑通。源码是清单注明的当前工作区快照，部分文件未提交；没有把当前代码假称为历史逐字冻结。数值/输入历史原件与当前全库摘录各自保存。

整流程旧生成器可能读取未上传的运行时导出、私有评论库、原review JSON或任务URL；这些不是已经完成的指标复算的必要几何输入，不用新材料冒充旧原件。需要重新核验原始采集/历史完整生成器时，应回仓库真源，不称本包覆盖该流程。当前load_current_bundle源码仅供来源解释；Pro读取current/panel.json与records.json，不在摘录包重建bundle。
