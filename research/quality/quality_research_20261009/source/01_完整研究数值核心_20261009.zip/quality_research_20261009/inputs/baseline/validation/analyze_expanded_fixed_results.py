#!/usr/bin/env python3
"""Audit frozen v1.1 score tables without accessing human grades.

Sensitivity alternatives are reports, never a parameter-selection procedure.
All outputs are written beside this script. The input score table is unchanged.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys
from datetime import datetime, timezone

import numpy as np

HERE = Path(__file__).resolve().parent
OUTPUT = HERE
WORKSPACE = HERE.parents[2]
V11 = WORKSPACE / "work/research_v1_1"
DEVELOPMENT_IMAGES = {"wc2JMjhGNzB-15", "7y3sRwLe3Va-04", "rPc6DW4iMge-06",
                      "UwV83HsGsw3-09", "yqstnuAEVhm-31", "uNb9QFRL6hY-26"}
CORE_FEATURES = ["iou", "S_top_deg", "S_bottom_deg", "dir", "flat", "Hmean", "Hlocal", "Hstar"]
NUMERIC_FIELDS = [
    "quality_score", *CORE_FEATURES, "omission", "extension", "C", "U", "B", "T", "F",
    "iou_2d", "iou_3d_corner_mean", "iou_3d_perimeter_mean", "hohonet_iou3d_vertex_mean",
    "conditional_iou3d_perimeter_mean", "boundary_rms_deg", "intrinsic_factor",
    "mean_height_only_score_same_parameters", "score_v1_recomputed", "pair_count",
    "range_deduction_points", "boundary_deduction_points", "height_deduction_points",
    "intrinsic_deduction_points", "annotation_height_min_h", "annotation_height_max_h",
    "annotation_height_mean_h", "reference_height_mean_h", "annotation_height_std_h",
    "reference_height_std_h", "nearest_AG_tied_height_fraction", "nearest_GA_tied_height_fraction",
    "nearest_AG_tied_height_range_h", "nearest_GA_tied_height_range_h", "bottom_horizon_margin_deg",
    "max_depth_sensitivity_h_per_Cpx",
]
META_FIELDS = ["record_id", "review_id", "image_code", "building", "room", "evaluation_group",
               "historical_exposure", "reference_id", "reference_version", "score_status", "status",
               "quality_band", "reason_codes", "failure_classes", "annotation_valid_2d",
               "annotation_valid_3d", "reference_valid_2d", "reference_valid_3d",
               "availability_iou_2d", "availability_iou_3d_corner_mean", "availability_iou_3d_perimeter_mean",
               "availability_complete_quality", "annotation_warning_codes", "reference_warning_codes",
               "traditional_issues", "auxiliary_issues", "preprocessing_version", "source_image_class",
               "oos", "is_oos", "scene_category", "geometry_source", "scene_oos_status", "scene_doorway_status",
               "adapter_reason_codes", "adapter_failure_classes", "unavailable_primary_reason", "all_failure_evidence_categories"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def number(value):
    try:
        f = float(value)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def write_json(name, obj):
    (OUTPUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def write_csv(name, rows):
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with (OUTPUT / name).open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def band(q, shift=0.):
    if q is None:
        return "unavailable"
    return "high" if q >= 95+shift else "good" if q >= 85+shift else "fair" if q >= 50+shift else "poor"


def independent_formula(row, s=4., h=.5):
    i, st, sb, dr, fl, he = (row[k] for k in ["iou", "S_top_deg", "S_bottom_deg", "dir", "flat", "Hstar"])
    sphere = math.hypot(st, sb) / math.sqrt(2)
    bterm = (sphere/s)**2
    hterm = (he/h)**2
    intrinsic = 1 - .075*(dr*dr/(dr*dr+25.) + fl*fl/(fl*fl+4.))
    return 100*i*intrinsic/(1+bterm+hterm)


def summary_stats(values):
    a = np.asarray([x for x in values if x is not None and np.isfinite(x)], dtype=float)
    if not len(a):
        return {"n": 0}
    return {"n": int(len(a)), "min": float(a.min()), "q10": float(np.quantile(a,.1)),
            "median": float(np.median(a)), "q90": float(np.quantile(a,.9)), "max": float(a.max()),
            "mean_descriptive_records_only": float(a.mean())}


def main():
    global OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--scores", type=Path, required=True)
    parser.add_argument("--geometry", type=Path)
    parser.add_argument("--out", type=Path, default=HERE)
    parser.add_argument("--old-frozen-geometry", type=Path,
                        default=WORKSPACE / "source/oct8-pro-quality-handoff/inputs/frozen_geometry.json")
    args = parser.parse_args()
    OUTPUT = args.out.resolve()
    if not OUTPUT.is_relative_to(HERE):
        raise ValueError("This independent task may write only inside its validation directory")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    contract = json.loads((HERE/"analysis_contract_frozen_before_expanded_scores.json").read_text())
    for relative, expected in contract["source_sha256"].items():
        if sha(V11/relative) != expected:
            raise RuntimeError("Source changed after audit contract: "+relative)
    # Load only named geometry and provenance columns; never consume score/rating notes.
    with args.scores.open(encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        headers = list(reader.fieldnames)
        rows = [{k: raw.get(k, "") for k in [*META_FIELDS, *NUMERIC_FIELDS] if k in raw} for raw in reader]
    for r in rows:
        for k in NUMERIC_FIELDS:
            r[k] = number(r.get(k))
        r["score_status"] = r.get("score_status") or r.get("status") or ("available" if r["quality_score"] is not None else "unavailable")
    old_images = set(DEVELOPMENT_IMAGES)
    if args.old_frozen_geometry.exists():
        old_images = {im["code"] for im in json.loads(args.old_frozen_geometry.read_text())["images"]}
    development = set(contract["development_buildings"])
    for r in rows:
        if r.get("image_code") in old_images:
            group = "historical_six_image_replay"
        elif r.get("building") in development:
            group = "new_image_in_development_building"
        elif r.get("building"):
            group = "expanded_building_fixed_parameter_validation"
        else:
            group = "building_metadata_missing"
        r["audit_exposure_group"] = group
        r["frozen_band"] = band(r["quality_score"])
    available = [r for r in rows if r["score_status"] == "available" and r["quality_score"] is not None]
    defects = []
    def defect(row, code, actual=None):
        defects.append({"image_code": row.get("image_code"), "record_id": row.get("record_id"), "code": code, "actual": actual})
    errors = []
    ceiling_max = -math.inf
    oldscore_max = -math.inf
    for r in rows:
        if r["score_status"] != "available":
            if r["quality_score"] is not None:
                defect(r, "unavailable_has_numeric_quality", r["quality_score"])
            continue
        missing = [k for k in CORE_FEATURES if r[k] is None]
        if missing:
            defect(r, "available_missing_required_features", "|".join(missing))
            continue
        q = r["quality_score"]
        qr = independent_formula(r)
        errors.append(abs(q-qr))
        if abs(q-qr)>1e-6:
            defect(r, "score_formula_mismatch", q-qr)
        capdiff = q-100*r["iou"]
        ceiling_max = max(ceiling_max, capdiff)
        if q < -1e-8 or capdiff > 1e-7:
            defect(r, "score_ceiling_or_sign", capdiff)
        if abs(r["Hstar"]-max(r["Hmean"], r["Hlocal"]))>1e-8:
            defect(r, "height_max_mismatch", r["Hstar"]-max(r["Hmean"],r["Hlocal"]))
        if r["mean_height_only_score_same_parameters"] is not None:
            d=q-r["mean_height_only_score_same_parameters"]
            oldscore_max=max(oldscore_max,d)
            if d > 1e-7:
                defect(r,"new_score_exceeds_mean_only_cap",d)
        if r["intrinsic_factor"] is not None and not .85-1e-9 <= r["intrinsic_factor"] <= 1+1e-9:
            defect(r,"intrinsic_factor_outside_frozen_bounds",r["intrinsic_factor"])
    write_csv("expanded_arithmetic_defects.csv", defects)

    metric_counts = []
    for group in ["ALL", *sorted({r["audit_exposure_group"] for r in rows})]:
        rr = rows if group == "ALL" else [r for r in rows if r["audit_exposure_group"]==group]
        for metric in ["quality_score", "iou_2d", "iou_3d_corner_mean", "iou_3d_perimeter_mean", "U", "B", "T", "F", "S_top_deg", "S_bottom_deg", "Hmean", "Hlocal", "Hstar", "dir", "flat"]:
            metric_counts.append({"audit_exposure_group":group,"metric":metric,"all_records":len(rr),
                                  "finite_count":sum(r.get(metric) is not None for r in rr),
                                  "missing_count":sum(r.get(metric) is None for r in rr)})
    write_csv("expanded_metric_availability_counts.csv",metric_counts)
    group_summaries=[]
    for group in ["ALL", *sorted({r["audit_exposure_group"] for r in rows})]:
        rr=rows if group=="ALL" else [r for r in rows if r["audit_exposure_group"]==group]
        n=sum(r["quality_score"] is not None for r in rr)
        counts=collections.Counter(r["frozen_band"] for r in rr)
        group_summaries.append({"audit_exposure_group":group,"record_count":len(rr),"evaluable_count":n,
          "image_count":len({r.get("image_code") for r in rr}),
          "building_count_known":len({r.get("building") for r in rr if r.get("building")}),
          **{k+"_count":counts[k] for k in ["high","good","fair","poor","unavailable"]},
          **{"Q_"+k:v for k,v in summary_stats([r["quality_score"] for r in rr]).items()}})
    write_csv("expanded_independent_group_summary.csv",group_summaries)

    # Diagnostics of overlapping components. This is not a new score candidate.
    comp=[]
    for r in available:
        if any(r[k] is None for k in CORE_FEATURES):continue
        s=math.hypot(r["S_top_deg"],r["S_bottom_deg"])/math.sqrt(2)
        b=(s/4)**2; h=(r["Hstar"]/.5)**2
        intrinsic=1-.075*(r["dir"]**2/(r["dir"]**2+25)+r["flat"]**2/(r["flat"]**2+4))
        n=100*r["iou"]*intrinsic
        refq=n/(1+b+h)
        productq=n/((1+b)*(1+h))
        comp.append({**{k:r.get(k) for k in ["record_id","image_code","building","audit_exposure_group","quality_score","iou","Hmean","Hlocal","Hstar","dir","flat"]},
            "S_rms_deg":s,"boundary_denominator_term":b,"height_denominator_term":h,
            "denominator_boundary_fraction":b/(1+b+h),"denominator_height_fraction":h/(1+b+h),
            "Q_if_product_of_two_losses_diagnostic_only":productq,
            "frozen_advantage_over_product_diagnostic_points":refq-productq,
            "score_gain_if_boundary_ignored_diagnostic_only":n/(1+h)-refq,
            "score_gain_if_height_ignored_diagnostic_only":n/(1+b)-refq,
            "score_gain_if_intrinsic_prior_ignored_diagnostic_only":100*r["iou"]/(1+b+h)-refq,
            "local_height_revision_deduction_points":None if r["mean_height_only_score_same_parameters"] is None else r["mean_height_only_score_same_parameters"]-r["quality_score"]})
    write_csv("expanded_component_overlap_diagnostics.csv",comp)

    # The complete predeclared grid is reported; defaults are not replaced.
    candidates=list(itertools.product([3.5,4.,4.5],[.4,.5,.6]))
    sensitivity=[]; sensitive=[]; variants_by_id={}
    for r in available:
        if any(r[k] is None for k in CORE_FEATURES):continue
        qs=[independent_formula(r,s,h) for s,h in candidates]
        bs=[band(q) for q in qs]
        variants_by_id[(r.get("image_code"),r.get("record_id"))]=qs
        sensitive.append({**{k:r.get(k) for k in ["record_id","image_code","building","audit_exposure_group","quality_score","frozen_band"]},
            "Q_min_over_predeclared_grid":min(qs),"Q_max_over_predeclared_grid":max(qs),
            "Q_grid_range_points":max(qs)-min(qs),"same_band_all_nine":len(set(bs))==1,
            "bands_in_grid":"|".join(dict.fromkeys(bs)),"number_of_alternatives_changing_default_band":sum(b!=r["frozen_band"] for b in bs)})
        for (s,h),q,b in zip(candidates,qs,bs):
            sensitivity.append({**{k:r.get(k) for k in ["record_id","image_code","building","audit_exposure_group"]},
                "boundary_half_deg":s,"height_relative_half":h,"default_Q":r["quality_score"],"candidate_Q":q,
                "delta_Q_points":q-r["quality_score"],"default_band":r["frozen_band"],"candidate_band":b,
                "same_band":b==r["frozen_band"],"default_unchanged":s==4 and h==.5})
    write_csv("expanded_sensitivity_all_records_nine_candidates.csv",sensitivity)
    write_csv("expanded_sensitivity_record_summary.csv",sensitive)
    sens_summ=[]
    for group in ["ALL",*sorted({r["audit_exposure_group"] for r in available})]:
        sr=sensitive if group=="ALL" else [r for r in sensitive if r["audit_exposure_group"]==group]
        sens_summ.append({"audit_exposure_group":group,"n":len(sr),
            "same_band_all_nine":sum(r["same_band_all_nine"] for r in sr),
            "changed_band_in_grid":sum(not r["same_band_all_nine"] for r in sr),
            **{"Q_range_"+k:v for k,v in summary_stats([r["Q_grid_range_points"] for r in sr]).items()}})
    write_csv("expanded_sensitivity_group_summary.csv",sens_summ)
    # Ranking sensitivity is limited to within-image pairs. It is descriptive,
    # not a demand that all real pairs retain their order.
    flips=[]; pair_counts=collections.Counter()
    by_image=collections.defaultdict(list)
    for r in available:
        if (r.get("image_code"),r.get("record_id")) in variants_by_id:by_image[r.get("image_code")].append(r)
    for image,rr in by_image.items():
        for a,b in itertools.combinations(rr,2):
            d=a["quality_score"]-b["quality_score"]
            if abs(d)<=1e-8:continue
            pair_counts[a["audit_exposure_group"]]+=1
            qa=variants_by_id[(image,a["record_id"])];qb=variants_by_id[(image,b["record_id"])]
            reversed_candidates=[f"S={s:g};H={h:g}" for (s,h),x,y in zip(candidates,qa,qb)
                                 if (d>1e-8 and x-y < -1e-8) or (d < -1e-8 and x-y > 1e-8)]
            if reversed_candidates:
                flips.append({"image_code":image,"building":a.get("building"),"audit_exposure_group":a["audit_exposure_group"],
                    "record_a":a["record_id"],"record_b":b["record_id"],"default_Q_a":a["quality_score"],"default_Q_b":b["quality_score"],
                    "default_absolute_gap":abs(d),"reversing_candidates":"|".join(reversed_candidates)})
    write_csv("expanded_sensitivity_within_image_pair_reversals.csv",flips)
    threshold=[]
    for r in available:
        for shift in [-3.,0.,3.]:
            b=band(r["quality_score"],shift)
            threshold.append({**{k:r.get(k) for k in ["record_id","image_code","building","audit_exposure_group","quality_score","frozen_band"]},
                "all_thresholds_shift_points":shift,"shifted_band":b,"band_changes":b!=r["frozen_band"]})
    write_csv("expanded_threshold_sensitivity.csv",threshold)

    nominations=[]
    def nominate(r,reason,diagnostic=None):
        nominations.append({**{k:r.get(k) for k in ["record_id","image_code","building","room","audit_exposure_group","reference_id","reference_version","quality_score","frozen_band","iou","omission","extension","Hmean","Hlocal","Hstar","S_top_deg","S_bottom_deg","dir","flat","pair_count"]},
                            "nomination_reason":reason,"diagnostic_value":diagnostic,
                            "not_a_verified_visual_error":True})
    c_by={(x.get("image_code"),x.get("record_id")):x for x in comp}
    for r in available:
        cp=c_by.get((r.get("image_code"),r.get("record_id")),{})
        deduction=cp.get("local_height_revision_deduction_points")
        if deduction is not None and deduction>=3 and r["Hlocal"]>=.05 and r["Hlocal"]>=2*r["Hmean"]:
            nominate(r,"mean_cancellation_repaired_at_least_3_points",deduction)
        if r["quality_score"]>=95 and max(r["omission"] or 0,r["extension"] or 0)>=.03:
            nominate(r,"high_Q_with_3pct_scope_difference",max(r["omission"] or 0,r["extension"] or 0))
        if r["iou_3d_corner_mean"] is not None and r["iou_3d_perimeter_mean"] is not None:
            diff=abs(r["iou_3d_corner_mean"]-r["iou_3d_perimeter_mean"])
            if diff>=.05:nominate(r,"corner_vs_perimeter_3D_IoU_gap_at_least_0p05",diff)
        if max(r.get("nearest_AG_tied_height_fraction") or 0,r.get("nearest_GA_tied_height_fraction") or 0)>0:
            nominate(r,"height_nearest_ties_with_distinct_heights",max(r.get("nearest_AG_tied_height_fraction") or 0,r.get("nearest_GA_tied_height_fraction") or 0))

    gt_self=[]
    if args.geometry:
        geometries=json.loads(args.geometry.read_text())
        images=geometries["images"] if isinstance(geometries,dict) else geometries
        gi={im["code"]:im for im in images}
        sys.path.insert(0,str(V11/"core"))
        from quality_v11 import own_metrics, validate_record
        seen_refs=set()
        for r in available:
            im=gi.get(r.get("image_code"))
            if not im:continue
            aa={str(x.get("id")):x for x in im.get("annotations",[])}
            gg={str(x.get("id")):x for x in im.get("groundtruths",[])}
            a=aa.get(str(r.get("record_id")));g=gg.get(str(r.get("reference_id")))
            if not a or not g:continue
            ah=np.asarray(a["top3d"],float)[:,1]-np.asarray(a["bottom3d"],float)[:,1]
            gh=np.asarray(g["top3d"],float)[:,1]-np.asarray(g["bottom3d"],float)[:,1]
            gm=r["reference_height_mean_h"]
            if gm and gm>0:
                ext=max(0.,float(gh.min()-ah.min()),float(ah.max()-gh.max()))/gm
                if r["quality_score"]>=95 and ext>=.4:nominate(r,"high_Q_height_outside_GT_envelope_at_least_0p4",ext)
            rk=(r.get("image_code"),r.get("reference_id"))
            if rk in seen_refs:continue
            seen_refs.add(rk)
            val=validate_record(g,role="reference")
            if not val["available"]:continue
            own=own_metrics(g)
            dr,fl=own["dir"],own["flat"]
            prior=1-.075*(dr*dr/(dr*dr+25)+fl*fl/(fl*fl+4))
            gt_self.append({"image_code":r.get("image_code"),"building":r.get("building"),"audit_exposure_group":r["audit_exposure_group"],
                "reference_id":r.get("reference_id"),"reference_version":r.get("reference_version"),"dir_deg":dr,"flat_deg":fl,
                "exact_copy_Q_from_intrinsic_prior":100*prior,"copy_band":band(100*prior),
                "interpretation":"Analytic exact-copy score: I=1,S=0,H=0; this tests the weak prior, not GT truth."})
    write_csv("expanded_counterexample_nominations_geometry_only.csv",nominations)
    write_csv("expanded_reference_copy_prior_check.csv",gt_self)

    boundary=[]
    for t in [95.,85.,50.]:
        for side in ["at_or_above","below"]:
            rr=[r for r in available if (r["quality_score"]>=t)==(side=="at_or_above")]
            rr=sorted(rr,key=lambda r:abs(r["quality_score"]-t))
            selected=[];used_images=set()
            for r in rr:
                if r.get("image_code") in used_images:continue
                used_images.add(r.get("image_code"));selected.append(r)
                if len(selected)==6:break
            for r in selected:
                boundary.append({**{k:r.get(k) for k in ["record_id","image_code","building","audit_exposure_group","reference_id","reference_version","quality_score","frozen_band","iou","S_top_deg","S_bottom_deg","Hstar","dir","flat"]},
                    "threshold":t,"side":side,"distance_points":abs(r["quality_score"]-t)})
    write_csv("expanded_boundary_case_nominations.csv",boundary)
    fail_counts=collections.Counter()
    for r in rows:
        if r["score_status"]=="available":continue
        primary=r.get("unavailable_primary_reason")
        if primary:
            fail_counts[(r["audit_exposure_group"],"adapter_primary_exclusive",primary)]+=1
        for reason in (r.get("reason_codes") or "unspecified").split("|"):
            fail_counts[(r["audit_exposure_group"],"core_component_symptom_nonexclusive",reason)]+=1
    write_csv("expanded_failure_reason_counts.csv",[{"audit_exposure_group":g,"reason_layer":layer,"reason_code":k,"record_count":v} for (g,layer,k),v in sorted(fail_counts.items())])
    summary={
      "audit_time_utc":datetime.now(timezone.utc).isoformat(),"input_score_table":str(args.scores),"input_score_sha256":sha(args.scores),
      "source_sha256_matches_preanalysis_contract":True,"all_records":len(rows),"available_records":len(available),
      "unique_image_count":len({r.get("image_code") for r in rows}),"known_building_count":len({r.get("building") for r in rows if r.get("building")}),
      "duplicate_image_record_reference_rows":len(rows)-len({(r.get("image_code"),r.get("record_id"),r.get("reference_id")) for r in rows}),
      "arithmetic_defect_count":len(defects),"max_Q_independent_formula_error":max(errors,default=None),
      "max_Q_minus_100IoU":None if not math.isfinite(ceiling_max) else ceiling_max,
      "max_Q_minus_mean_height_only_score":None if not math.isfinite(oldscore_max) else oldscore_max,
      "same_band_all_nine_candidates":sum(x["same_band_all_nine"] for x in sensitive),"sensitivity_evaluable_n":len(sensitive),
      "within_image_unequal_default_pairs":sum(pair_counts.values()),"within_image_pairs_reversed_by_any_candidate":len(flips),
      "max_default_gap_in_reversed_within_image_pairs":max([r["default_absolute_gap"] for r in flips],default=0),
      "threshold_shift_minus3_changed":sum(r["band_changes"] for r in threshold if r["all_thresholds_shift_points"]==-3),
      "threshold_shift_plus3_changed":sum(r["band_changes"] for r in threshold if r["all_thresholds_shift_points"]==3),
      "reference_copies_checked":len(gt_self),"reference_copies_below95":sum(r["exact_copy_Q_from_intrinsic_prior"]<95 for r in gt_self),
      "counterexample_nominations_not_verified_errors":len(nominations),
      "component_overlap_interpretation":"Boundary and height share 1+b+h, omitting product cross-term bh. Hstar uses max(mean,local), not sum. IoU and boundary can respond to one positional/scope error; penalties are deliberate related views, not independent evidence. Attribution is order-dependent.",
      "band_necessary_bounds_if_all_other_errors_zero":[{"Q_at_least":q,"IoU_at_least":q/100,"S_at_most_deg":4*math.sqrt(100/q-1),"Hstar_at_most":.5*math.sqrt(100/q-1)} for q in [95,85,50]],
      "parameters_changed":False,"human_scores_loaded_as_features":False,"grouping_contract":contract["grouping_policy"],
      "claim_limit":"Descriptive archive validation under fixed reference policy; no image population quality/difficulty estimate, human calibration, or independent-blind-test claim."}
    write_json("expanded_independent_audit_summary.json",summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    if defects:raise AssertionError("Expanded arithmetic/availability defects found; inspect complete table")


if __name__=="__main__":main()
