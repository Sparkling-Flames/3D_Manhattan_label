#!/usr/bin/env python3
"""Compact findings and visual-review nominations after the fixed full run.

Selection is explicit, based on geometry and cross-image coverage, with old
human grades hidden. It does not change scoring, thresholds, or GT bindings.
"""
from __future__ import annotations
import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]


def read(path):
    with path.open(encoding="utf-8-sig") as f:return list(csv.DictReader(f))


def num(row,key):
    try:return float(row[key])
    except (KeyError,ValueError,TypeError):return None


def band(q):
    return "high" if q>=95 else "good" if q>=85 else "fair" if q>=50 else "poor"


def save_csv(path,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--scores",type=Path,required=True)
    args=parser.parse_args()
    raw=read(args.scores)
    rows=[r for r in raw if r["score_status"]=="available"]
    byid={r["record_id"]:r for r in rows}
    sensitive={r["record_id"]:r for r in read(HERE/"expanded_sensitivity_record_summary.csv")}
    nom=[
      ("R00421","A","局部高度均值抵消","Hmean 几乎为零而 Hlocal=.22254；本库修复额外扣分最大。看同一墙线的局部高低与位置误差。"),
      ("R00384","A","局部高度与 GT 细节限制","修复额外扣 3.67 分；历史材料有 GT 省略细节记录。需区分真实细节与实际错位，不能把该记录当已确认算法错误。"),
      ("R01114","A","2D IoU 高但上边界严重不同","IoU=.95881、Q=6.3377；上边界差 20.98°，底边界仅 .516°。确认预测/GT 所描上边界是否为同一目标。"),
      ("R01672","A","普通场景下的明显上边界误差","IoU=.95855、Q=40.687；上边界 6.079°。用于区别 OOS 标签和真实几何误差。"),
      ("R01360","A","同图 IoU 高仍有顶部误差","IoU=.98190、Q=52.0836；S_top=4.774°，两种 3D IoU 差 .05746。与同图 R02187 配对查看。"),
      ("R02187","A","同张 OOS 图的高分对照","Q=97.8399，边界、高度都贴近固定 GT。与 R01360 比较可排除场景标签直接扣分。"),
      ("R00186","A","严重范围缺失且自身近规整","IoU=.11661、D=1.134°、F=.381°，仍只有 Q=1.1304。请看是否实际仅描了局部范围。"),
      ("R02075","A","真实非正交的弱先验限制","IoU=.99011、Q=91.6138；GT 精确复制也仅 93.6837。历史类别为稳定非正交，应展示实际斜墙与先验成本。"),
      ("R00328","A","参考自身规整性告警","wc2JMjhGNzB-14 固定修订 GT 的复制分仅 87.5534，F≈9.993°。这是 GT/模型/先验适用性告警，不能由 Q 直接判哪个几何是真的。"),
      ("R01042","B","95 分边界上侧的小范围差","Q=95.0735、IoU=.96402；范围差约 3.28%，整体仍高分。适合判断高档边界是否直观。"),
      ("R00286","B","另一建筑的高分小范围差","Q=96.0834、IoU=.96648；约 3.08% 范围差。与上一例不同图片、建筑，不把小误差误称严重遗漏。"),
      ("R01401","B","门洞难例仍可得高分","Q=95.3613、Hlocal=.01985（本库高档中最大，但仅约 2%）；显示门洞类别并未被排除。"),
      ("R01613","B","高分与 GT 内容表达限制","Q=97.8464；历史标记门洞可标且 GT 省略细节。高分表示对固定 GT 的几何吻合，不保证所有图像真实细节都表达。"),
      ("R03168","B","50 分边界的尺度敏感性","默认 Q=55.2652；预先列出的九设置范围 48.8132–60.6685。上边界 4.623°，适合查看一般/较差档差异而不据此选参。"),
      ("R00474","B","新增建筑的 OOS 高分例","q9vSo1VnCiC-09 / R00474 Q=96.1511、IoU=.99059，可与低分 OOS 例对照，避免把场景类别当质量标签。"),
      ("R03398","B","可标门洞与局部高度的中档例","Q=54.9534，Hlocal=.11020、Hmean=.05087，修复额外扣 1.64 分；这是新建筑的范围/局部高度混合案例。"),
    ]
    selection=[]
    fields=["record_id","image_code","building","room","reference_id","reference_version","evaluation_group",
            "historical_exposure","quality_score","quality_band","iou","iou_3d_corner_mean","iou_3d_perimeter_mean",
            "omission","extension","S_top_deg","S_bottom_deg","Hmean","Hlocal","Hstar","dir","flat",
            "scene_category","scene_oos_status","scene_doorway_status","scope_evidence_flag","detail_evidence_flag",
            "reference_detail_omission_flag","image_internal_path","mean_height_only_score_same_parameters"]
    for record,priority,theme,note in nom:
        r=byid[record]
        old=num(r,"mean_height_only_score_same_parameters");q=num(r,"quality_score")
        sr=sensitive[record]
        selection.append({"priority":priority,"theme_zh":theme,**{k:r.get(k) for k in fields},
            "height_revision_deduction_points":old-q,
            "Q_min_over_predeclared_grid":sr["Q_min_over_predeclared_grid"],
            "Q_max_over_predeclared_grid":sr["Q_max_over_predeclared_grid"],
            "review_note_zh":note,"visual_error_verified":False,"old_human_scores_hidden":True})
    save_csv(HERE/"精选16例_几何原因与看图目的.csv",selection)
    (HERE/"精选16例_先看图再判断.txt").write_text("\n".join(
       f"{i:02d}. [{r['priority']}] {r['image_code']} / {r['record_id']} / Q={float(r['quality_score']):.4f} / {r['theme_zh']}\n    {r['review_note_zh']}"
       for i,r in enumerate(selection,1))+"\n")
    deltas=np.array([num(r,"mean_height_only_score_same_parameters")-num(r,"quality_score") for r in rows])
    affected=[r for r,d in zip(rows,deltas) if d>1]
    hsummary={"n":len(rows),"median_extra_deduction":float(np.median(deltas)),
        "p90_extra_deduction":float(np.quantile(deltas,.9)),"p99_extra_deduction":float(np.quantile(deltas,.99)),
        "max_extra_deduction":float(max(deltas)),"extra_deduction_gt1_count":int(sum(deltas>1)),
        "extra_deduction_gt3_count":int(sum(deltas>3)),"images_with_extra_deduction_gt1":len({r['image_code'] for r in affected}),
        "buildings_with_extra_deduction_gt1":len({r['building'] for r in affected}),
        "changed_frozen_band_vs_mean_height_only":sum(band(num(r,"mean_height_only_score_same_parameters"))!=band(num(r,"quality_score")) for r in rows)}
    high=[r for r in rows if num(r,"quality_score")>=95]
    hsummary["high_band_observed"]={"n":len(high),"IoU_min":min(num(r,"iou") for r in high),
        "Hstar_max":max(num(r,"Hstar") for r in high),"S_rms_max_deg":max(num(r,"boundary_rms_deg") for r in high)}
    hsummary["low_IoU_under0p5_and_D_under2_F_under0p5_count"]=sum(num(r,"iou")<.5 and num(r,"dir")<2 and num(r,"flat")<.5 for r in rows)
    hsummary["score_unavailability_primary_counts"]=dict(Counter(r['unavailable_primary_reason'] for r in raw if r['score_status']!='available'))
    hsummary["case_selection_count"]=len(selection)
    hsummary["case_selection_images"]=len({r['image_code'] for r in selection})
    hsummary["case_selection_buildings"]=len({r['building'] for r in selection})
    (HERE/"expanded_height_revision_and_selection_summary.json").write_text(json.dumps(hsummary,ensure_ascii=False,indent=2)+"\n")
    building=[]
    for code in sorted({r['building'] for r in raw}):
        rr=[r for r in raw if r['building']==code];aa=[r for r in rr if r['score_status']=='available']
        bb=Counter(band(num(r,'quality_score')) for r in aa)
        stable=sum(sensitive[r['record_id']]['same_band_all_nine']=='True' for r in aa)
        building.append({'building':code,'all_records':len(rr),'available_records':len(aa),
            'images_all':len({r['image_code'] for r in rr}),'images_with_available_Q':len({r['image_code'] for r in aa}),
            'Q_median_descriptive_archive_records_only':float(np.median([num(r,'quality_score') for r in aa])) if aa else None,
            'IoU_median_descriptive_archive_records_only':float(np.median([num(r,'iou') for r in aa])) if aa else None,
            **{b+'_count':bb[b] for b in ['high','good','fair','poor']},
            'unavailable_count':len(rr)-len(aa),'same_band_all_nine':stable,'same_band_all_nine_fraction':stable/len(aa) if aa else None,
            'population_quality_or_difficulty_inference':False})
    save_csv(HERE/'expanded_building_stability_descriptive.csv',building)
    grid=read(HERE/'expanded_sensitivity_all_records_nine_candidates.csv');grid_summary=[]
    for s in [3.5,4.,4.5]:
        for h in [.4,.5,.6]:
            rr=[r for r in grid if float(r['boundary_half_deg'])==s and float(r['height_relative_half'])==h]
            ds=np.array([float(r['delta_Q_points']) for r in rr])
            grid_summary.append({'boundary_half_deg':s,'height_relative_half':h,'n':len(rr),
               'changed_band_vs_frozen_default':sum(r['same_band']=='False' for r in rr),'median_delta_Q':float(np.median(ds)),
               'max_absolute_delta_Q':float(np.max(np.abs(ds))),'selected_as_new_default':False})
    save_csv(HERE/'expanded_nine_candidates_compact_summary.csv',grid_summary)
    (HERE/'独立审查结论_固定参数.txt').write_text(
      '当前建议：先保留冻结 v1.1 参数，供本轮研究性几何比较及粗分档；没有从旧评分、人数分布或难图均值重新选参。是否把非正交布局也称为“高档”，需结合本文指出的弱先验局限解释。\n\n'
      '全量 3152 份中 2979 份可评价，259 张图、22 个建筑均保留。算术检查无封顶或 H*=max 违规；完整 Q 独立复算最大差约 1.40e-10（CSV 舍入量级）。不可评价原因使用适配层的原始证据分类，不把 pairing 未决笼统称为坐标丢失。\n\n'
      '高档 112 份的最小 IoU=.96402，最大 H*=.01985，最大 S=.54148°；未发现严重范围缺失仅凭规整性获得高档的实际例。另有 25 份 IoU<.5 且 D<2°、F<.5° 的局部规整标注仍低分。此为对固定参考的几何事实，不能证明 GT 未省略真实细节。\n\n'
      '局部高度修复的额外扣分中位数 .0444、P90=.4046、P99=1.1697、最大 4.1834。52 份额外扣分>1，分布在 26 图、10 建筑；15 份跨过一个既定档位。R00421 显示均值几乎正确却有大局部高度误差，支持保留修复；并未对全部标注产生大的额外扣分。\n\n'
      '九组尺度下 2621/2979（约 88.0%）始终同档，新建筑组为 963/1106（约 87.1%）。所有组合的分数极差中位数约 5.21、最大 11.86 分。边界尺度 3.5→4.5 的影响明显高于高度尺度 .4→.6；固定 S=4 时高度两侧只令 22 或 10 份改档。阈值同时 -3/+3 导致 281/236 份改档，说明档位边界不能解释为经过标定的合格线。\n\n'
      '同图 24518 对默认分数不等的记录中，488 对在至少一个候选设置下反序，最大默认分差 3.562；不要求这些几何排序全部保持，也不据此选参。建筑内数据保持在同一暴露组；所有扩展数据均为历史研究库存，不能称独立盲测。\n\n'
      '重复惩罚的结构检查：边界与高度使用 1+b+h，未乘入额外 b*h 项；Hmean 与 Hlocal 取 max 不相加；自身规整折扣最多 15%。IoU 与边界都会响应同一位置或范围错误，因此是相关的几何视角，不能说各分项是独立证据。逐项扣分是固定顺序的会计分解，不能当独立因果贡献。\n\n'
      '两项应明示的限制：x8F5xyUWy9e-09 的稳定非正交 GT 精确复制理论 Q=93.684，无法进入≥95，这与弱曼哈顿先验直接有关；wc2JMjhGNzB-14 的修订 GT 自身 D/F 较大，复制理论 Q=87.553，须结合原图判断参考/模型。均未自动改 GT 或参数。\n\n'
      '控制实验仍有窄深凹口遗漏 Q=98.571、极短墙段大幅高度脉冲 Q=99.931 的高分盲点；本库预设的“高 Q 且高度超过 GT 高度包络 40%”告警未触发，不能据此证明这些情况不存在。Q 不裁决语义墙对应、GT 范围真实性、真实遗漏细节，也不保证最坏局部误差。\n\n'
      '精选图像核查 16 例覆盖 15 图、12 建筑，附原始记录/固定 GT ID、客观数值和查看目的，旧人工分隐藏。这些是解释性选例，不用于估计全库反例发生率。\n')
    print(json.dumps(hsummary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
