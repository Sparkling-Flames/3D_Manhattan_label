#!/usr/bin/env python3
"""Independent frozen-v1.1 checks, written before inspecting expanded scores.

Only this task's validation folder is written. Existing geometry and scoring
modules are read without edits. Human grades are never loaded.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
V11 = WORKSPACE / "work/research_v1_1"
sys.path.insert(0, str(V11 / "core"))
from quality_v11 import load_parameters, score_geometry, scalar_score


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def write_csv(path, rows):
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def precontract():
    source_files = [
        "frozen_parameters.json", "frozen_bands.json", "core/quality_v11.py",
        "height_revision/height_revision.py", "validity/strict_geometry.py",
        "traditional/traditional_metrics.py", "legacy_geometry/audit_geometry.py",
        "legacy_geometry/geometric_components.py",
    ]
    cfg = json.loads((V11 / source_files[0]).read_text())
    bands = json.loads((V11 / source_files[1]).read_text())
    result = {
        "contract_version": "expanded_fixed_v11_independent_audit_20261009",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "expanded_scores_seen_when_written": False,
        "quality_version": cfg["algorithm_version"],
        "parameters": cfg["parameters"],
        "numerical_settings": cfg["numerical_settings"],
        "bands": bands["thresholds"],
        "frozen_definition_time": cfg["frozen_at_utc"],
        "source_sha256": {f: sha(V11 / f) for f in source_files},
        "development_buildings": cfg["development_buildings"],
        "data_scope_expected_not_verified": {"research_images": 259, "annotations": 3152,
                                              "photo_files": 261, "gt_only_images": 2},
        "grouping_policy": {
            "unit": "building; rooms and views remain within building",
            "historical_six_images": "historical_development_replay",
            "other_images_in_six_buildings": "new_image_same_development_building",
            "other_buildings": "expanded_building_fixed_parameter_validation",
            "unknown_building": "group_metadata_missing; never claim held-out building",
            "historical_exposure": "record separately from current tuning exposure; archive provenance is not proof of blindness",
            "training_or_parameter_selection": "none in this fixed-parameter run",
        },
        "reference_policy": "Use latest confirmed per-record/per-image fixed reference with explicit provenance; never select by resulting score. Archive conflicts remain documented.",
        "data_integrity": "Original coordinates, ring order, pairing, images, GT and human grades must not be rewritten. Input access failure is distinct from data absence and geometric unavailability.",
        "failure_policy": "Retain all annotation records; unavailable score is null and excluded from four quality bands, with 2D retained when computable and separate per-metric denominators.",
        "default_analysis": [
            "Range guarantee Q <= 100*IoU; nonnegative Q; complete-score/component consistency",
            "Hstar >= Hmean and Hlocal; new score never exceeds mean-height-only score at identical parameters",
            "Band counts by current exposure group, image and building with evaluable denominators",
            "Missingness and failure reasons including valid 2D with invalid 3D; OOS and doorway classes descriptive only",
            "Threshold-boundary and geographically diverse case nominations without loading old grades",
            "Component overlap and score decomposition: descriptive, not independent causal contributions",
            "Narrow omissions and localized height tails as known average-error blind spots; geometric candidates require image interpretation",
        ],
        "sensitivity_only_candidates": {
            "boundary_half_deg": [3.5, 4.0, 4.5],
            "height_relative_half": [0.4, 0.5, 0.6],
            "other_parameters": "frozen defaults",
            "candidate_count_cartesian": 9,
            "selection": "No alternative is selected by old grades, score distribution, difficult-image mean, or the sensitivity table.",
            "threshold_shift_points_all_three_together": [-3.0, 0.0, 3.0],
            "grouped_reporting": "Report all held-out buildings descriptively. Any later parameter change must be logged and changes this pool's validation status.",
        },
        "counterexample_nominations_before_scores": [
            "Available Q>=95 with localized height extrema outside reference height envelope by >=0.4 reference mean height",
            "Available Q>=95 with omission or extension close to its score ceiling; inspect actual omitted detail and GT scope",
            "Large height-revision deduction relative to mean-only v1, especially low Hmean/high Hlocal",
            "Large weak-intrinsic prior deduction on reference copies, especially valid nonorthogonal/nonflat GT",
            "Major 3D corner-mean versus perimeter-mean IoU discrepancy linked to uneven vertex segmentation",
            "Nearest-height ties with distinct target heights; correspondence is geometric, not semantic",
        ],
        "inference_limits": [
            "No whole-image population quality or difficulty estimate from mixed targeted/random annotation selection",
            "No sampling p-values treating multiple annotations per image as independent",
            "No subjective calibration claim and no attempt to reproduce all old rankings",
            "Conditional floor/camera model does not provide measured 3D truth or resolve scope beyond GT",
            "Selected figures do not establish prevalence; publish complete numerators and denominators",
        ],
    }
    path = HERE / "analysis_contract_frozen_before_expanded_scores.json"
    if path.exists():
        existing = json.loads(path.read_text())
        if existing["source_sha256"] != result["source_sha256"]:
            raise RuntimeError("Frozen source changed after analysis contract; preserve old contract and investigate")
        return existing
    write_json(path, result)
    (HERE / "分析合同_冻结参数.txt").write_text(
        "本轮先回放 geom_quality_research_v1.1.0；参数 4°、5°、2°、0.15、0.5 和分档 95/85/50 均不选择、不改写。\n"
        "六个开发建筑名单取当前 frozen_parameters.json。同一建筑的房间和视角不拆入开发与验证两侧。六张已用图、开发建筑内新增图、新建筑分别列出；此前是否看过另列。\n"
        "九组尺度组合只作敏感性描述，不以旧评分、各档人数或难图均分选择版本。阈值整体 ±3 分只描述边界稳定性。\n"
        "访问失败、数据缺失、GT冲突/缺失、标注几何失败及模型不适用分开记录。不可评价为缺失分数，不归最低档，也不改分量权重。\n"
        "先检验 Q≤100IoU、H*=max(Hmean,Hlocal)、原曲线共线分段不变、微误差温和和局部高度均值抵消修复。\n"
        "对局部窄凹口遗漏、稀疏高度脉冲和几何近邻错配只提具体反例候选，不将几何告警当作图像事实。\n"
        "全量汇总的均值只描述收到的标注记录；不当作图片总体质量、建筑质量或难度，不宣称独立盲测或主观标定成功。\n"
        "扣分表按先范围、再边界、再高度、再规整的固定顺序分解；这只是会计分解，不能解释为各因素独立造成的损害。\n"
    )
    return result


def control_replay():
    source_paths = [
        WORKSPACE / "output/layout_quality_research_v1_repro/results/geometry/control_geometries.json",
        V11 / "height_revision/results_4096/new_height_control_geometries.json",
        V11 / "new_independent_audit/layout_quality_v1_independent_audit/numeric/independent_counterexample_geometries.json",
    ]
    fixtures = {}
    for path in source_paths:
        for raw in json.loads(path.read_text()):
            case = raw.get("case_id", raw.get("case"))
            fixtures[case] = {**raw, "case_id": case, "geometry_source": str(path.relative_to(WORKSPACE))}
    selected = [
        "rectangle_scale_1", "rectangle_scale_0.99", "rectangle_scale_0.5", "rectangle_scale_0.25",
        "rectangle_translation_0", "rectangle_translation_0.005", "rectangle_translation_0.01",
        "rectangle_translation_0.05", "rectangle_translation_0.2", "rectangle_translation_0.8",
        "rectangle_top_shift_0.005", "rectangle_top_shift_0.02", "rectangle_top_shift_0.1",
        "rectangle_top_shift_0.4", "rectangle_top_shift_0.8",
        "rectangle_local_top_0.005", "rectangle_local_top_0.02", "rectangle_local_top_0.2",
        "rectangle_local_top_0.8", "rectangle_subdivision_1", "rectangle_subdivision_2",
        "rectangle_subdivision_3", "rectangle_subdivision_4", "rectangle_subdivision_8",
        "alternating_height_xz_scale_1", "alternating_height_xz_scale_8", "alternating_height_xz_scale_32",
        "nonflat_copy_k1", "nonflat_copy_k64", "nonflat_inverse_k64", "nonflat_flatten_k64",
        "local_cancel_k64_halfwidth0.01", "filled_notch_width_0.01",
        "overlapping_backtrack_edges", "nonadjacent_vertex_touches_edge",
    ]
    missing = [case for case in selected if case not in fixtures]
    if missing:
        raise KeyError(f"Control IDs absent: {missing}")
    # Add an uneven split of only one original edge. Interpolation preserves
    # the exact 3D line; no geometry repair is involved.
    for base in ["rectangle_scale_1", "nonflat_copy_k1", "nonflat_inverse_k64"]:
        fixture = copy.deepcopy(fixtures[base])
        rec = fixture["annotation"]
        for key in ["top3d", "bottom3d"]:
            ring = rec[key]
            p, q = ring[0], ring[1]
            added = [[(1-u)*a+u*b for a,b in zip(p,q)] for u in [0.125, 0.25, 0.5, 0.625, 0.75, 0.875]]
            rec[key] = [p, *added, *ring[1:]]
        case = base + "_uneven_exact_subdivision"
        fixture.update(case_id=case, family="independent_exact_collinear_edge_split", compare_with=base)
        fixtures[case] = fixture
        selected.append(case)
    previous = {x["case_id"]: x for x in json.loads((V11 / "results/control_replay_full.json").read_text())}
    parameters = load_parameters(V11 / "frozen_parameters.json")
    before = {str(p.relative_to(WORKSPACE)): sha(p) for p in source_paths}
    output = []
    assertions = []
    full = []
    by_id = {}
    def check(name, condition, detail=None):
        assertions.append({"check": name, "passed": bool(condition), "detail": detail})
    for case in selected:
        fixture = fixtures[case]
        result = score_geometry(fixture["annotation"], fixture["reference"], parameters)
        m = result["metrics"]
        row = {"case_id": case, "family": fixture.get("family", "audit_original_counterexample"),
               "status": result["status"], "reason_codes": "|".join(result["reason_codes"]),
               "quality_score": result["quality_score"],
               **{k: m.get(k) for k in ["iou", "omission", "extension", "S_top_deg", "S_bottom_deg",
                   "boundary_rms_deg", "Hmean", "Hlocal", "Hstar", "dir", "flat",
                   "intrinsic_factor", "range_deduction_points", "boundary_deduction_points",
                   "height_deduction_points", "intrinsic_deduction_points", "mean_height_only_score_same_parameters"]}}
        if case in previous:
            prev = previous[case]
            check(case+":prior_status", result["status"] == prev["status"])
            if result["quality_score"] is not None and prev["quality_score"] is not None:
                row["previous_frozen_quality_score"] = prev["quality_score"]
                row["replay_difference_points"] = result["quality_score"] - prev["quality_score"]
                check(case+":prior_Q", abs(row["replay_difference_points"]) <= 1e-8)
        if result["status"] == "available":
            q = result["quality_score"]
            check(case+":range_ceiling", -1e-10 <= q <= 100*m["iou"]+1e-10)
            check(case+":height_max", abs(m["Hstar"] - max(m["Hmean"], m["Hlocal"])) <= 1e-12)
            check(case+":old_mean_cap", q <= m["mean_height_only_score_same_parameters"]+1e-10)
            check(case+":accounting_sum", abs(100-q-sum(m[k] for k in ["range_deduction_points", "boundary_deduction_points", "height_deduction_points", "intrinsic_deduction_points"])) <= 1e-8)
        output.append(row)
        full.append({"case_id": case, "source": fixture["geometry_source"], "result": result})
        by_id[case] = row
    for base in ["rectangle_scale_1", "nonflat_copy_k1", "nonflat_inverse_k64"]:
        diff = by_id[base+"_uneven_exact_subdivision"]["quality_score"] - by_id[base]["quality_score"]
        check(base+":uneven_collinear_score_invariance", abs(diff) <= 1e-8, diff)
    for prefix, ids in [
        ("translation", ["0", "0.005", "0.01", "0.05", "0.2", "0.8"]),
        ("top_shift", ["0.005", "0.02", "0.1", "0.4", "0.8"]),
        ("local_top", ["0.005", "0.02", "0.2", "0.8"]),
    ]:
        vals = [by_id[f"rectangle_{prefix}_{v}"]["quality_score"] for v in ids]
        check(prefix+":monotone_on_tested_path", all(a >= b-1e-9 for a,b in zip(vals, vals[1:])), vals)
    for case in ["overlapping_backtrack_edges", "nonadjacent_vertex_touches_edge"]:
        check(case+":reject_not_zero", by_id[case]["status"] == "unavailable" and by_id[case]["quality_score"] is None)
    check("alternating_height_far_no_near_perfect", by_id["alternating_height_xz_scale_32"]["quality_score"] < 80)
    check("nonflat_GT_copy_height_zero", by_id["nonflat_copy_k64"]["Hstar"] <= 1e-12)
    check("nonflat_GT_copy_above_wrong_flatten", by_id["nonflat_copy_k64"]["quality_score"] > by_id["nonflat_flatten_k64"]["quality_score"])
    check("nonflat_GT_copy_above_wrong_inverse", by_id["nonflat_copy_k64"]["quality_score"] > by_id["nonflat_inverse_k64"]["quality_score"])
    after = {str(p.relative_to(WORKSPACE)): sha(p) for p in source_paths}
    check("original_fixture_hashes_unchanged", before == after)
    write_csv(HERE / "focused_control_replay.csv", output)
    write_json(HERE / "focused_control_replay_full.json", full)
    write_json(HERE / "focused_control_assertions.json", assertions)
    summary = {"control_records": len(output), "available": sum(x["status"]=="available" for x in output),
               "assertions": len(assertions), "failed": sum(not x["passed"] for x in assertions),
               "max_previous_frozen_score_difference_points": max(abs(x.get("replay_difference_points", 0)) for x in output),
               "input_sha256_before": before, "input_sha256_after": after,
               "known_remaining_blind_spots": [
                   {"case_id": "filled_notch_width_0.01", "quality_score": by_id["filled_notch_width_0.01"]["quality_score"],
                    "interpretation": "Narrow deep omitted concavity can occupy little area and averaged angular boundary length; high Q does not guarantee every wall detail."},
                   {"case_id": "local_cancel_k64_halfwidth0.01", "quality_score": by_id["local_cancel_k64_halfwidth0.01"]["quality_score"],
                    "interpretation": "Large signed height pulses over very short perimeter can remain high under mean/RMS losses; local-height repair does not provide a worst-point guarantee."},
               ]}
    write_json(HERE / "focused_control_summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if summary["failed"]:
        raise AssertionError("Focused frozen controls failed")


if __name__ == "__main__":
    HERE.mkdir(parents=True, exist_ok=True)
    precontract()
    if "--contract-only" not in sys.argv:
        control_replay()
