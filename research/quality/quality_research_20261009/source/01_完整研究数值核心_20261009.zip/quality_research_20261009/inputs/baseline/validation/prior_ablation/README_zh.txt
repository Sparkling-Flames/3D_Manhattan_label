本目录为事后机制诊断，默认版本未修改。

便携运行（Python 3.10 或以上，依赖见资料包 portable_support/requirements.txt）：
python /bundle/path/validation/prior_ablation/run_prior_ablation.py --root /bundle/path --out /new/path

--root 是解压后资料包根目录，与脚本所在目录或当前工作目录无关。--out 必须是不存在或为空的新目录；脚本拒绝覆盖现有结果。输出不会写回默认结果、旧评分、原标注、GT 或本目录的原始分析声明。

根目录需要下列输入：
  frozen_engine/core/quality_v11.py 及 frozen_engine 中配套模块
  frozen_engine/frozen_parameters.json
  frozen_engine/frozen_bands.json
  results_fixed/all_records_results.json
  validation/prior_ablation/analysis_record_before_prior_ablation.json
  validation/expanded_reference_copy_prior_check.csv
  validation/real_visual_review.json
  validation/expanded_nine_candidates_compact_summary.csv
  validation/focused_control_replay_full.json
最后一项可以由 portable_support/controls38_frozen.json 替代。替代读取仅提取其中既有 expected_result 高精度分项，并重建、校验原 38 控制结果的 SHA256；不会重新生成几何或改变控制预期。本诊断直接使用已算分项，因此不读取 prepared 中的几何或原图；全量几何回放请用包根目录的主复现入口。

脚本从本包 frozen_engine 加载评分内核，按原始 analysis_record_before_prior_ablation.json 校验全部输入 SHA256。该声明中的历史路径仅作为来源记录，便携入口会映射到上述位置，不访问旧 work/research_v1_1。原事后声明及其时间戳不随复跑重写。新运行自己的 created_at_utc 会更新，并单列原默认参数冻结时间，不据此声称新候选事前冻结。

全量表包含 3,152 份记录，173 份不可评价仍为 null/空分数。只把 intrinsic_max_discount 从 0.15 改为 0；其余几何、分项、S/H 尺度、适用性及 GT 绑定均保持原样。这个诊断已经看过默认全量结果及少量原图，属于事后机制诊断，不是新独立验证或选参成功；本目录仍保留默认版本，不自动选择本候选。

关键交付：all_records_default_vs_no_prior.csv（逐条）、group_summary_default_vs_no_prior.csv（分组）、band_transitions.csv、within_image_order_reversals.csv、fixed_reference_exact_copy_comparison.csv、existing_controls38_default_vs_no_prior.csv、comparison_with_existing_S_H_grid.csv、prior_ablation_summary.json、prior_ablation_conclusion_zh.txt。

配置 diagnostic_parameters_no_intrinsic_prior.json 为明确标记的诊断配置，不能覆盖原 frozen_parameters.json。非正交和多层顶界的视觉证据见上级 real_visual_review.json；该文件没有把所有分数提升判为真实质量改善。

便携验证：portable_reproduction_verification.json 记录两次重跑核对。一次使用完整根目录，一次在复制后的最小资料包中从另一工作目录启动，并刻意省略 focused_control_replay_full.json，以验证 portable_support 替代读取。全部 10 个 CSV 与首版逐字节一致；4 个结果 JSON 除运行生成时间外完全一致。新增 portable_input_provenance.json 记录实际读取位置、输入 SHA256、内核路径和脚本 SHA256。

run_prior_ablation_before_portable.py 是首版脚本的只读历史副本，不是推荐运行入口；其 SHA256 和修改前时间记录在 portable_refactor_original_script_sha256.json。该副本可保留旧路径以忠实记录历史实现。当前可运行入口是带 --root/--out 的 run_prior_ablation.py。
