#!/usr/bin/env python3
"""Post hoc removal of the intrinsic prior, using frozen full-precision inputs.

The default is never changed. The diagnostic has no fitting step and accepts
no human ratings. Existing I/S/H, validity and fixed GT bindings are reused.
"""
from __future__ import annotations
import csv
import itertools
import json
import math
import hashlib
from collections import Counter, defaultdict
from pathlib import Path
from datetime import datetime, timezone
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
VALIDATION=HERE.parent
TASK=VALIDATION.parent
WORKSPACE=TASK.parents[1]
V11=WORKSPACE/'work/research_v1_1'
sys.path.insert(0,str(V11/'core'))
from quality_v11 import scalar_score, Parameters


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_csv(path):
    with path.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))


def json_out(name,data):
    (HERE/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def csv_out(name,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (HERE/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)


def band(q):
    if q is None:return 'unavailable'
    return 'high' if q>=95 else 'good' if q>=85 else 'fair' if q>=50 else 'poor'


def quantiles(a):
    a=np.array(a,float)
    if not len(a):return {'n':0}
    return {'n':int(len(a)),'min':float(a.min()),'median':float(np.median(a)),
            'p90':float(np.quantile(a,.9)),'p99':float(np.quantile(a,.99)),
            'max':float(a.max()),'mean_descriptive_only':float(a.mean())}


def calculate(m,discount):
    b=(m['S_top_deg']**2+m['S_bottom_deg']**2)/32.
    h=(m['Hstar']/.5)**2
    d=m['dir']**2/(m['dir']**2+25.)
    f=m['flat']**2/(m['flat']**2+4.)
    return 100*m['iou']/(1+b+h)*(1-discount*(d+f)/2)


def main():
    declaration=json.loads((HERE/'analysis_record_before_prior_ablation.json').read_text())
    for info in declaration['source_files'].values():
        if sha(WORKSPACE/info['path'])!=info['sha256']:
            raise RuntimeError('Input changed since post hoc diagnostic declaration: '+info['path'])
    inputs=json.loads((TASK/'results_fixed/all_records_results.json').read_text())
    config=json.loads((V11/'frozen_parameters.json').read_text())
    old=json.loads((WORKSPACE/'source/oct8-pro-quality-handoff/inputs/frozen_geometry.json').read_text())
    old_images={im['code'] for im in old['images']}
    dev_buildings=set(config['development_buildings'])
    diag_config={'diagnostic_candidate_id':'posthoc_intrinsic_prior_removed',
        'algorithm_version':'diagnostic_only__geom_quality_research_v1.1.0__intrinsic_discount_0',
        'source_algorithm_version':config['algorithm_version'],
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'default_definition_frozen_at_utc':config['frozen_at_utc'],
        'parameters':{**config['parameters'],'intrinsic_max_discount':0.},
        'inactive_scales_retained_for_interface_only':['direction_half_deg','flatness_half_deg'],
        'numerical_settings':config['numerical_settings'],
        'default_parameters_replaced':False,'validation_nature':'post hoc mechanism diagnostic; default full data and selected images already seen',
        'new_independent_validation':False}
    json_out('diagnostic_parameters_no_intrinsic_prior.json',diag_config)
    parameter_zero=Parameters(intrinsic_max_discount=0.)
    assertions=[]
    def check(name,ok,detail=None):assertions.append({'check':name,'passed':bool(ok),'detail':detail})
    rows=[]; precise={};max_api_difference=0.;max_default_difference=0.
    for r in inputs:
        image=r['image_code']
        group=('historical_six_images' if image in old_images else 'other_images_in_development_buildings'
               if r['building'] in dev_buildings else 'images_in_additional_buildings')
        row={k:r.get(k) for k in ['record_id','image_code','building','room','evaluation_group','historical_exposure',
                  'reference_id','reference_version','reference_binding_policy','status','reason_codes','failure_classes',
                  'unavailable_primary_reason','scene_category','scene_oos_status','scene_doorway_status']}
        row['audit_group']=group
        for k in ['reason_codes','failure_classes']:
            if isinstance(row[k],list):row[k]='|'.join(row[k])
        m=r['metrics']
        q=r['quality_score'];q0=None;delta=None
        if r['status']=='available':
            q0=calculate(m,0.)
            q15=calculate(m,.15)
            defaultdiff=abs(q15-q);max_default_difference=max(max_default_difference,defaultdiff)
            api=scalar_score(m['iou'],m['S_top_deg'],m['S_bottom_deg'],m['dir'],m['flat'],m['Hstar'],parameter_zero)['quality_score']
            apidiff=abs(q0-api);max_api_difference=max(max_api_difference,apidiff)
            delta=q0-q
            check(r['record_id']+':default_reconstruction',defaultdiff<=1e-10,defaultdiff)
            check(r['record_id']+':candidate_API_parity',apidiff<=1e-10,apidiff)
            check(r['record_id']+':IoU_ceiling',-1e-10<=q0<=100*m['iou']+1e-10)
            check(r['record_id']+':nonnegative_bounded_boost',-1e-10<=delta<=15+1e-10)
            check(r['record_id']+':boost_equals_removed_intrinsic_deduction',abs(delta-m['intrinsic_deduction_points'])<=1e-10)
            precise[r['record_id']]={'source':r,'q0':q0,'group':group}
        else:
            check(r['record_id']+':unavailable_preserved',q is None and q0 is None)
        row.update({'default_Q':q,'Q_no_intrinsic_prior':q0,'boost_points':delta,
            'default_band':band(q),'no_prior_band':band(q0),'band_changed':band(q)!=band(q0),
            **{k:m.get(k) for k in ['iou','S_top_deg','S_bottom_deg','Hmean','Hlocal','Hstar','dir','flat','intrinsic_factor',
                                  'intrinsic_deduction_points','iou_3d_corner_mean','iou_3d_perimeter_mean']},
            'default_intrinsic_max_discount':.15,'diagnostic_intrinsic_max_discount':0.,
            'not_selected_as_default':True})
        rows.append(row)
    csv_out('all_records_default_vs_no_prior.csv',rows)
    available=[r for r in rows if r['status']=='available']
    group_summary=[];by_group={}
    for g in ['ALL','historical_six_images','other_images_in_development_buildings','images_in_additional_buildings']:
        rr=rows if g=='ALL' else [r for r in rows if r['audit_group']==g]
        aa=[r for r in rr if r['status']=='available']
        default_counts=Counter(r['default_band'] for r in rr)
        zero_counts=Counter(r['no_prior_band'] for r in rr)
        item={'audit_group':g,'all_records':len(rr),'available_records':len(aa),
             'images_all':len({r['image_code'] for r in rr}),
             'images_with_available_Q':len({r['image_code'] for r in aa}),
             'buildings_all':len({r['building'] for r in rr}),
             'band_changed_count':sum(r['band_changed'] for r in aa),
             'band_changed_fraction':sum(r['band_changed'] for r in aa)/len(aa) if aa else None,
             **{'boost_'+k:v for k,v in quantiles([r['boost_points'] for r in aa]).items()},
             **{'default_'+b+'_count':default_counts[b] for b in ['high','good','fair','poor','unavailable']},
             **{'no_prior_'+b+'_count':zero_counts[b] for b in ['high','good','fair','poor','unavailable']}}
        by_group[g]=item;group_summary.append(item)
    csv_out('group_summary_default_vs_no_prior.csv',group_summary)
    transitions=Counter((r['audit_group'],r['default_band'],r['no_prior_band']) for r in rows)
    csv_out('band_transitions.csv',[{'audit_group':g,'default_band':a,'no_prior_band':b,'record_count':n}
          for (g,a,b),n in sorted(transitions.items())])
    # Pair orders are descriptive. Default ties are reported separately;
    # no ranking constraint is used to select the diagnostic or default.
    by_image=defaultdict(list)
    for r in available:by_image[r['image_code']].append(r)
    pair_counts=Counter();reversals=[];ties=[]
    for image,rr in by_image.items():
        for a,b in itertools.combinations(rr,2):
            d=a['default_Q']-b['default_Q'];e=a['Q_no_intrinsic_prior']-b['Q_no_intrinsic_prior'];g=a['audit_group']
            pair_counts[(g,'all_pairs')]+=1
            if abs(d)<=1e-8:
                pair_counts[(g,'default_ties')]+=1
                if abs(e)>1e-8:pair_counts[(g,'default_ties_separated')]+=1
                continue
            pair_counts[(g,'unequal_default_pairs')]+=1
            if abs(e)<=1e-8:
                pair_counts[(g,'new_candidate_ties')]+=1
                ties.append({'image_code':image,'record_a':a['record_id'],'record_b':b['record_id'],'default_gap':d,'candidate_gap':e})
            if (d>1e-8 and e < -1e-8) or (d < -1e-8 and e > 1e-8):
                pair_counts[(g,'strict_reversals')]+=1
                reversals.append({'image_code':image,'building':a['building'],'audit_group':g,
                    'record_a':a['record_id'],'record_b':b['record_id'],'default_Q_a':a['default_Q'],'default_Q_b':b['default_Q'],
                    'no_prior_Q_a':a['Q_no_intrinsic_prior'],'no_prior_Q_b':b['Q_no_intrinsic_prior'],
                    'absolute_default_gap':abs(d),'absolute_candidate_gap':abs(e),
                    'not_an_error_rate_or_human_accuracy_test':True})
    csv_out('within_image_order_reversals.csv',reversals)
    csv_out('within_image_new_ties.csv',ties)
    pair_summary=[]
    for g in ['ALL','historical_six_images','other_images_in_development_buildings','images_in_additional_buildings']:
        item={'audit_group':g}
        for typ in ['all_pairs','default_ties','default_ties_separated','unequal_default_pairs','new_candidate_ties','strict_reversals']:
            item[typ]=sum(v for (group,k),v in pair_counts.items() if k==typ and (g=='ALL' or group==g))
        rr=reversals if g=='ALL' else [r for r in reversals if r['audit_group']==g]
        item['max_default_gap_among_reversals']=max([r['absolute_default_gap'] for r in rr],default=0.)
        pair_summary.append(item)
    csv_out('within_image_order_summary.csv',pair_summary)
    # Reference-copy components are prior full-precision Python CSV values.
    copies=read_csv(VALIDATION/'expanded_reference_copy_prior_check.csv')
    for r in copies:
        d=float(r['dir_deg']);f=float(r['flat_deg'])
        q=100*(1-.075*(d*d/(d*d+25)+f*f/(f*f+4)))
        r.update({'default_copy_Q':q,'no_prior_copy_Q':100.,'boost_points':100-q,
                  'default_copy_band':band(q),'no_prior_copy_band':'high','band_changed':band(q)!='high',
                  'scope_limit':'Exact fixed GT copy, not a measured-truth or target-applicability judgment.'})
    csv_out('fixed_reference_exact_copy_comparison.csv',copies)

    # Reuse precisely the 38 existing controls; do not invent new geometry.
    controls=json.loads((VALIDATION/'focused_control_replay_full.json').read_text())
    control_rows=[];control_checks=[]
    def ccheck(name,condition,detail=None):control_checks.append({'check':name,'passed':bool(condition),'detail':detail})
    for x in controls:
        r=x['result'];m=r['metrics'];q0=calculate(m,0.) if r['status']=='available' else None
        out={'case_id':x['case_id'],'status_unchanged':r['status'],'default_Q':r['quality_score'],
             'Q_no_prior':q0,'boost_points':None if q0 is None else q0-r['quality_score'],
             **{k:m.get(k) for k in ['iou','S_top_deg','S_bottom_deg','Hmean','Hlocal','Hstar','dir','flat']},
             'reason_codes':'|'.join(r['reason_codes'])}
        control_rows.append(out)
        if q0 is None:
            ccheck(x['case_id']+':unavailable_not_zero',r['quality_score'] is None)
        else:
            ccheck(x['case_id']+':range_ceiling',-1e-10<=q0<=100*m['iou']+1e-10)
            ccheck(x['case_id']+':only_removed_prior',abs(q0-r['quality_score']-m['intrinsic_deduction_points'])<=1e-10)
            ccheck(x['case_id']+':height_repair_preserved',abs(m['Hstar']-max(m['Hmean'],m['Hlocal']))<=1e-12)
    cb={r['case_id']:r for r in control_rows}
    for base in ['rectangle_scale_1','nonflat_copy_k1','nonflat_inverse_k64']:
        diff=cb[base+'_uneven_exact_subdivision']['Q_no_prior']-cb[base]['Q_no_prior']
        ccheck(base+':exact_collinear_subdivision_unchanged',abs(diff)<=1e-8,diff)
    for prefix,ids in [('translation',['0','.005','.01','.05','.2','.8']),
                       ('top_shift',['.005','.02','.1','.4','.8']),('local_top',['.005','.02','.2','.8'])]:
        vals=[cb['rectangle_'+prefix+'_'+('0'+s if s.startswith('.') else s)]['Q_no_prior'] for s in ids]
        ccheck(prefix+':monotone_along_existing_test_path',all(a>=b-1e-9 for a,b in zip(vals,vals[1:])),vals)
    ccheck('severe_scope_loss_not_rewarded',cb['rectangle_scale_0.25']['Q_no_prior']<=6.25+1e-10)
    ccheck('nonflat_exact_copy_reaches100',abs(cb['nonflat_copy_k1']['Q_no_prior']-100)<=1e-8)
    ccheck('nonflat_exact_copy_beats_wrong_flatten',cb['nonflat_copy_k64']['Q_no_prior']>cb['nonflat_flatten_k64']['Q_no_prior'])
    ccheck('nonflat_exact_copy_beats_wrong_inverse',cb['nonflat_copy_k64']['Q_no_prior']>cb['nonflat_inverse_k64']['Q_no_prior'])
    ccheck('far_alternating_height_not_near100',cb['alternating_height_xz_scale_32']['Q_no_prior']<80)
    csv_out('existing_controls38_default_vs_no_prior.csv',control_rows)
    json_out('control_assertions.json',control_checks)

    # Mechanism examples: previously visually inspected cases, followed by a
    # few largest boosts in other images. These are not selected successes.
    reviewed=['R02075','R00328','R01114','R01672','R01360','R02187','R00186','R00474','R00421']
    selected=[];seen=set();image_seen=set()
    for record in reviewed:
        item=next(r for r in rows if r['record_id']==record)
        selected.append({**item,'selection_basis':'previously_inspected_or_previously_identified_case',
                         'visual_gain_is_proven':False})
        seen.add(record);image_seen.add(item['image_code'])
    for r in sorted(available,key=lambda r:r['boost_points'],reverse=True):
        if r['image_code'] in image_seen:continue
        selected.append({**r,'selection_basis':'largest_arithmetic_boost_in_another_image_not_newly_visually_verified',
                         'visual_gain_is_proven':False})
        seen.add(r['record_id']);image_seen.add(r['image_code'])
        if len(selected)>=14:break
    csv_out('mechanism_examples_not_selected_winners.csv',selected)
    # Put the diagnostic beside the existing S/H results without cross-product.
    sh_grid=read_csv(VALIDATION/'expanded_nine_candidates_compact_summary.csv')
    side=[]
    for r in sh_grid:
        side.append({'experiment_type':'predeclared_S_H_scale_sensitivity',
            'boundary_half_deg':float(r['boundary_half_deg']),'height_relative_half':float(r['height_relative_half']),
            'intrinsic_max_discount':.15,'changed_band_vs_default':int(r['changed_band_vs_frozen_default']),
            'median_delta_Q':float(r['median_delta_Q']),'max_absolute_delta_Q':float(r['max_absolute_delta_Q']),
            'new_independent_validation':False,'new_default_selected_in_this_diagnostic':False,
            'is_existing_frozen_default':float(r['boundary_half_deg'])==4 and float(r['height_relative_half'])==.5})
    side.append({'experiment_type':'posthoc_remove_intrinsic_prior',
        'boundary_half_deg':4.,'height_relative_half':.5,'intrinsic_max_discount':0.,
        'changed_band_vs_default':by_group['ALL']['band_changed_count'],
        'median_delta_Q':by_group['ALL']['boost_median'],'max_absolute_delta_Q':by_group['ALL']['boost_max'],
        'new_independent_validation':False,'new_default_selected_in_this_diagnostic':False,
        'is_existing_frozen_default':False})
    csv_out('comparison_with_existing_S_H_grid.csv',side)
    for info in declaration['source_files'].values():
        check('source_unchanged:'+info['path'],sha(WORKSPACE/info['path'])==info['sha256'])
    json_out('arithmetic_assertions.json',assertions)
    maxrow=max(available,key=lambda r:r['boost_points'])
    summary={
       'created_at_utc':datetime.now(timezone.utc).isoformat(),
       'status':'post hoc mechanism diagnostic; default not replaced',
       'default_full_results_seen_before_diagnostic':True,'new_independent_validation':False,
       'all_records':len(rows),'available_records':len(available),'unavailable_records':len(rows)-len(available),
       'changed_parameter_only':'intrinsic_max_discount 0.15 -> 0',
       'frozen_other_scales':[4.,5.,2.,.5],'bands_unchanged':[95.,85.,50.],
       'max_default_formula_reconstruction_difference':max_default_difference,
       'max_candidate_API_difference':max_api_difference,
       'max_boost_case':{k:maxrow[k] for k in ['record_id','image_code','default_Q','Q_no_intrinsic_prior','boost_points','default_band','no_prior_band','dir','flat','iou']},
       'group_summary':group_summary,'within_image_order_summary':pair_summary,
       'reference_copies_checked':len(copies),'reference_copy_band_changes':sum(r['band_changed'] for r in copies),
       'arithmetic_assertions':len(assertions),'arithmetic_failed':sum(not x['passed'] for x in assertions),
       'controls_reused':len(control_rows),'control_assertions':len(control_checks),'control_failed':sum(not x['passed'] for x in control_checks),
       'geometric_guarantees_zh':[
          'Q0=100I/[1+(S/4)^2+(Hstar/.5)^2] <= 100I；严重范围差异仍受相同上限约束。',
          '固定 I、S、Hstar 后移除D/F没有额外独立惩罚；这既能避免真实非正交/非平顶被先验压分，也放弃对D/F反映的错误规整性的独立控制。',
          '同一 I 下，S/Hstar增大仍单调降分；原几何严格有效性和局部高度修复完全保留。',
          '没有新增点数项或参考选择；原曲线精确共线分段的不变性保留。',
          '提升Q是取消扣分的代数必然，最大绝对提升不超过15分；不是经人工真值验证的质量改善。',
       ],
       'candidate_selection':'No winner selected; no fitting, human-grade objective, difficulty penalty or distribution target.',
       'real_target_issue_zh':'去掉弱先验不能解决坡顶/吊顶边界或淋浴间/整间浴室目标与GT不一致；主要S/H/I差异依然保留。',
    }
    json_out('prior_ablation_summary.json',summary)
    if summary['arithmetic_failed'] or summary['control_failed']:
        raise AssertionError('Diagnostic arithmetic/control failure; inspect assertions')
    print(json.dumps({k:summary[k] for k in ['all_records','available_records','max_default_formula_reconstruction_difference',
        'max_candidate_API_difference','max_boost_case','arithmetic_assertions','arithmetic_failed','control_assertions','control_failed']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
