#!/usr/bin/env python3
"""Package the six-case manual visual review with exact source provenance.

Observations below were made after actually viewing all six complete cards
and all five unmarked source panoramas with view_image. This script does not
infer visual content automatically, score new geometry, or change inputs.
"""
from pathlib import Path
import csv
import hashlib
import json
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
TASK=HERE.parent


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    geo_path=TASK/'prepared/frozen_expanded_geometry.json'
    score_path=TASK/'results_fixed/all_records_scores.csv'
    geometry=json.loads(geo_path.read_text())
    images={im['code']:im for im in geometry['images']}
    with score_path.open(encoding='utf-8-sig') as f:
        score={r['record_id']:r for r in csv.DictReader(f)}
    reviews=[
      {
        'record_id':'R01114',
        'visible_facts_zh':[
          '原图为明显坡屋顶房间：两侧是较低矮墙，矮墙上方斜面收向中部顶面，后墙窗上方的墙顶位置高于两侧矮墙顶。',
          '青色上边界大体接近两侧矮墙与斜顶的较低交界；在后墙部分也保持较低高度，不能完整表达后墙较高上界。',
          '橙色 GT 在后墙较高上界附近取线，并以近乎均高的闭环在侧面坡顶区域延拓；它同样没有表示完整的多面坡屋顶。',
          '底边界和 BEV 的两种轮廓很接近；3D 主要差异是上下高度，而不是底面严重缺失。',
        ],
        'numerically_verified_facts_zh':[
          'IoU=.9588108，Q=6.337738，S_top=20.97956°，S_bottom=.51631°。',
          '预测各顶点墙高约 .8949–.9368 h，固定 GT 约 1.2318–1.2319 h；两者都近乎均高。',
        ],
        'gt_target_ambiguity':'high',
        'interpretation_zh':'20.98° 是与固定高位代理顶界的真实角度差，不能等同整屋随机标错。可见矮墙顶、坡面与后墙顶存在不同结构目标，预测也不是完整坡顶的精确答案。',
        'possible_quality_bias_zh':'若目标是实际逐段墙顶/坡面交界，当前高位均高 GT 可能低估接近矮墙交界的部分；若目标明确规定统一高位房间包络，则该差异应受罚。仅凭本图无法裁决唯一整体质量分。',
        'freeze_implication_zh':'保留数值和条件几何可计算状态，附“坡顶目标/参考简化未裁决”说明；不把它当成已验证的严重位置错误样本，不自动按 OOS 排除，也不据此放宽边界尺度。',
        'judgment_confidence':'high_for_structure_and_geometric_difference; limited_for_absolute_quality',
      },
      {
        'record_id':'R01672',
        'visible_facts_zh':[
          '原图有高处主顶板、裸露梁/设备、较低玻璃隔断上缘和隔断上方白色墙带，不是只有一条无歧义顶界。',
          '青色线在右侧玻璃隔断一带贴近较低的隔断/框梁上缘，橙色线整体较高；其他方位上边界的落差不完全相同。',
          '底边界与 BEV 很接近；条件 3D 显示预测上界向一侧降低，而固定 GT 几乎均高。',
        ],
        'numerically_verified_facts_zh':[
          'IoU=.9585490，Q=40.68714，S_top=6.07872°，S_bottom=.48008°。',
          '预测四顶点墙高约 1.5738–1.8750 h；GT 约 1.9691 h。',
        ],
        'gt_target_ambiguity':'moderate',
        'interpretation_zh':'上界确实有明显低取和不一致，若评价固定的房间墙体外包络，方向上应扣分；但其中包含把较低隔断/梁边当作顶界的结构选择，不能把它全部描述为同一条墙顶线上的随机点位偏差。',
        'possible_quality_bias_zh':'40.69 是否符合实际缺陷程度仍未主观校准；图像支持上界不一致，但不足以证明当前扣分幅度恰好正确。不要将“ordinary”元数据当成顶界无歧义的证据。',
        'freeze_implication_zh':'作为同一 BEV、不同顶界选择的解释例保留；不单独用它证明 4° 过严或过宽。若明确外包络目标，上界低取应受罚；本轮不改 GT/参数。',
        'judgment_confidence':'high_for_lower_and_nonuniform_top; moderate_for_target_interpretation',
      },
      {
        'record_id':'R01360',
        'visible_facts_zh':[
          '原图有凸柱、靠右画作上方的较低吊顶/梁底，以及主顶面；这些结构的可见交界并非单一均高四面顶。',
          '青色上界在靠近镜头的凸柱与右侧画作上方较低墙顶/吊顶转折附近取线；前后部分和固定 GT 接近，但右侧转折显著较低。',
          'R01360 与 R02187 的底面轮廓都紧贴同一个 GT，均表达了凸柱造成的 BEV 小折角；两者差异主要集中在上界。',
        ],
        'numerically_verified_facts_zh':[
          'IoU=.9818991，Q=52.08360，S_top=4.77353°，S_bottom=.38578°。',
          '预测墙高前段约 2.09 h，凸柱/右侧段约 1.59–1.72 h；GT 各段约 2.0774 h。',
        ],
        'gt_target_ambiguity':'high',
        'interpretation_zh':'低分上界存在贴近可见较低结构交界的依据，不能仅因其不均高就判为坏答案。GT 采用均高高位包络，R01360 更接近部分实际低位转折；两者属于不同上界表达的候选。',
        'possible_quality_bias_zh':'若研究目标是可见逐段墙顶，R01360 存在被低估的具体图像依据；若目标是主顶高位外包络，R02187 与 GT 的高吻合更符合约定。当前不能把 52.08 对 97.84 直接解释为等比例实际质量差。',
        'freeze_implication_zh':'与 R02187 成对列为目标表达差异案例；当前证据不支持通过调大边界/高度容差解决，因为这样也会放过控制中的真正同目标误差。',
        'paired_comparison_record':'R02187',
        'judgment_confidence':'high_for_visible_level_change; moderate_for_exact_trace_correspondence; limited_for_absolute_ranking',
      },
      {
        'record_id':'R02187',
        'visible_facts_zh':[
          '青橙线在原图叠加、BEV 和条件 3D 中几乎重合，说明它高度吻合固定 GT。',
          '与 R01360 比较，凸柱和右侧区域的青色上界升到 GT 的高位均高包络；并未因此表示所有可见吊顶底面和真实局部高度变化。',
          '原图可见家具/植物遮挡部分底界，两个版本共同使用的底界在遮挡区仍包含推断，不能称实测三维真值。',
        ],
        'numerically_verified_facts_zh':[
          'IoU=.9822565，Q=97.83990，S_top=.14381°，S_bottom=.12127°，Hstar=.00859。',
          '预测墙高约 2.080–2.119 h，GT 约 2.0774 h。',
        ],
        'gt_target_ambiguity':'high',
        'interpretation_zh':'这是固定参考与条件几何意义上的明确高吻合例，也能证明 OOS 标签没有机械扣分；它不能单独证明 R01360 的可见较低结构边界一定错误。',
        'possible_quality_bias_zh':'若使用者将高 Q 理解为已经正确表达所有实际吊顶/柱顶高度，该例可能被过度肯定。相对于约定高位包络的高分本身是可复现事实。',
        'freeze_implication_zh':'保留高档，并把“参考吻合很好，但上界目标仍需解释”写进图册；不要只展示此例作为复杂图真实质量无条件正确的证据。',
        'paired_comparison_record':'R01360',
        'judgment_confidence':'high_for_reference_match; limited_for_absolute_completeness',
      },
      {
        'record_id':'R00186',
        'visible_facts_zh':[
          '相机位于有玻璃门的淋浴隔间内；玻璃外清楚可见更大浴室、浴缸、洗手台和外侧墙面。',
          '青色闭环主要沿淋浴隔间的墙面与玻璃门前缘封闭，形成小而较规整的底面。',
          '橙色 GT 从淋浴区继续向玻璃外的整间浴室延伸；BEV 包含大得多的范围。',
        ],
        'numerically_verified_facts_zh':[
          'IoU=.1166098，Q=1.130422，D=1.13384°、F=.38063°。',
        ],
        'gt_target_ambiguity':'scope_policy_dependent',
        'interpretation_zh':'这是范围定义差异的清楚实例，不是几何乱画。若任务固定整间浴室范围，预测确实遗漏大部分目标范围，低分与封顶机制方向一致。',
        'possible_quality_bias_zh':'若任务允许把封闭淋浴隔间当作当前房间目标，则实际范围政策与 GT 不一致，不能称其近乎零质量；这需要范围约定，不能由规整性、IoU 或照片自动决定。',
        'freeze_implication_zh':'可用于验证“相对固定整体目标的严重范围缺失不能靠规整性补分”，但图册必须写明整体浴室目标条件，避免把“范围不同”直接替换成无条件“遗漏”。',
        'judgment_confidence':'high_for_enclosure_and_scope_difference; target_scope_requires_policy',
      },
      {
        'record_id':'R00474',
        'visible_facts_zh':[
          '原图为完整可见的起居空间，有木梁/拱形顶、局部较低白色顶面、壁龛和多处门洞。',
          '青橙上界、下界和大致四边形 BEV 几乎重合；主房间范围未出现如 R00186 那样的大面积缺失。',
          '这份四边形条件几何未表示木梁、顶面多层结构、壁龛与门洞深处细节；固定 GT 同样采用主包络简化。',
        ],
        'numerically_verified_facts_zh':[
          'IoU=.9905910，Q=96.15109，S_top=.13780°，S_bottom=.09820°，Hstar=.00595。',
        ],
        'gt_target_ambiguity':'moderate_due_to_simplified_main_envelope',
        'interpretation_zh':'可作为 OOS 场景中主包络几何吻合的高档例。高分在固定主包络目标下直观合理，但不是已验证的完整室内三维重建。',
        'possible_quality_bias_zh':'若“实际质量”要求完整表示所有顶面与壁龛细节，当前高分会高估完整性；若研究明确只评主房间包络，这些细节并不自动构成应扣分项。',
        'freeze_implication_zh':'保留高档并注明简化包络口径；不要以 OOS 标签排除，也不要为显示更多细节自动改变 GT 或增加复杂模型。',
        'judgment_confidence':'high_for_reference_match_and_visible_unmodeled_structures; target_detail_scope_requires_policy',
      },
    ]
    metric_keys=['quality_score','iou','S_top_deg','S_bottom_deg','Hmean','Hlocal','Hstar','dir','flat','iou_3d_corner_mean','iou_3d_perimeter_mean']
    for r in reviews:
        row=score[r['record_id']];im=images[row['image_code']]
        card=TASK/'visuals/cards'/f"{r['record_id']}.jpg";photo=Path(im['imagePath'])
        r.update({'image_code':row['image_code'],'building':row['building'],'reference_id':row['reference_id'],
          'reference_version':row['reference_version'],'card_path':str(card),'card_sha256':digest(card),
          'original_image_path':str(photo),'original_image_sha256':digest(photo),
          'card_actually_viewed':True,'original_image_actually_viewed':True,
          'original_scores_hidden':True,'Q_before_and_after_visual_review_unchanged':float(row['quality_score']),
          'score_status_preserved':row['score_status'],'numerical_metrics':{k:float(row[k]) if row.get(k) else None for k in metric_keys}})
    result={
      'review_version':'six_case_visual_scope_audit_20261009',
      'created_at_utc':datetime.now(timezone.utc).isoformat(),
      'method':'Actually viewed six full original-overlay/BEV/3D cards and all five unmarked 2048x1024 original panoramas with view_image. These are manual observations, not automatic visual labels.',
      'score_table_sha256':digest(score_path),'prepared_geometry_sha256':digest(geo_path),
      'records_reviewed':6,'unique_images_reviewed':5,'unique_buildings_reviewed':5,
      'old_human_ratings_used':False,'parameters_changed':False,'GT_changed':False,'annotation_changed':False,
      'reviews':reviews,
      'overall_findings_zh':[
        '几何差异的数值是真实、可复现的；其实际质量含义取决于是否比较同一种上界与同一房间范围。',
        '至少两张不同建筑的图（坡顶 S9hNv5qa7GM-07 与吊顶/凸柱 uNb9QFRL6hY-52）出现清楚的“较低真实结构边/高位均高包络”差异；这支持收窄实际质量解释，而非立即调整损失尺度。',
        'R00186 的低分是对固定整间浴室目标的覆盖不足；淋浴隔间本身画得较规整。它验证封顶机制，但不自动裁决范围政策。',
        'R02187 与 R00474 的高分可靠地表示固定简化包络吻合；不能据此宣称所有真实顶面、壁龛和墙线完整。',
      ],
      'freeze_recommendation_zh':'冻结 v1.1 作为“固定 GT/固定目标约定下的条件几何质量分”是可行的；不宣称已完成无条件实际质量尺度。保留分数、可计算状态和旧分，在图册另附上界/范围目标歧义。无需因这六例增加参数模型，也不按 OOS 一刀切排除。',
      'parameter_selection_implication_zh':'这些图像证据指向目标/参考表达差异，不构成 4° 或 .5 尺度系统性错误的干净证据。放宽尺度会同时减轻真正同目标错误，不能解决语义目标不一致。本轮没有新的参数候选被选中。',
      'minimum_optional_human_question_if_future_absolute_quality_claim_requires_it_zh':'只需明确：对坡顶/吊顶图，上边界目标是实际逐段墙顶交界，还是统一高位的房间包络？范围如淋浴隔间是否允许独立成目标？这属于标注对象约定，不要求重评六图或改写旧分；当前条件几何主线可继续。',
      'status_policy':'Visual target ambiguity is a review flag, not an automatic invalid-3D finding. No record status or score was overwritten.',
    }
    out=HERE/'real_visual_review.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'saved':str(out),'records':len(reviews),'images':5,'parameters_changed':False,'GT_changed':False},ensure_ascii=False))


if __name__=='__main__':main()
