#!/usr/bin/env python3
"""Read-only audit. Never edits geometry, scores, policies or source snapshots."""
import argparse,collections,csv,hashlib,importlib.util,json,sys
from pathlib import Path
import numpy as np
ap=argparse.ArgumentParser();ap.add_argument('--bundle',type=Path,required=True);ap.add_argument('--snapshot',type=Path,required=True);ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);args=ap.parse_args();B,S,O=args.bundle,args.snapshot,args.out;O.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def count(x):return len(x) if x is not None else None
def write(name,rs):
 if not rs:return
 with (O/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def loadmod(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
geom=read(B/'prepared/frozen_expanded_geometry.json');results={r['record_id']:r for r in read(B/'results_fixed/all_records_results.json')};snapshot={r['id']:r for r in read(S/'current/records.json')['objects']};comments=read(S/'evidence/relevant_comments.json')['comments'];contract=read(B/'prepared/evaluation_contract_before_scores.json'); cm=collections.defaultdict(list)
for c in comments:
 if c['record_id']:cm[c['record_id']].append(c)
shachecks=[{'path':p,'expected_sha256':v,'actual_sha256':sha(S/p),'matches':v==sha(S/p)} for p,v in contract['source_hashes'].items()];assert all(x['matches'] for x in shachecks)
write('source_hash_verification.csv',shachecks)
adapter=loadmod('audited_prepare_expanded',B/'prepare_expanded.py');sys.path.insert(0,str(B/'frozen_engine/core'));from quality_v11 import score_geometry,load_parameters
params=load_parameters(B/'frozen_engine/frozen_parameters.json')
rows=[];checks=[];replay=[];point_rows=[];comment_rows=[]
reasons_cn={'existing_pairing_unresolved':'现行最终上下配对或环数组未形成','annotation_points_unavailable':'现行有效点数组缺失','reference_adjudicated_error':'已裁决GT实质错误且无确认替代','historical_explicit_analysis_hold':'历史明确暂缓全部分析','annotation_input_domain_invalid':'现行点坐标超出ERP范围','annotation_geometry_invalid':'现行两对点不能形成有效闭合布局','available':'Q可计算'}
for im in geom['images']:
 refs={(g['id'],g['version']):g for g in im['groundtruths']}
 for a in im['annotations']+im['groundtruths']:
  s=a['source_record']; ar=adapter.project_existing(s)
  ck={'record_id':a['id'],'image_code':im['code'],'kind':s['object_kind'],'snapshot_record_exact_match':s==snapshot[a['id']],'adapter_points_exact_match':a['points']==ar['points'],'adapter_issues_exact_match':a['adapter_issues']==ar['adapter_issues'],'projection_same_within_1e_12':True,'source_identity_contract':True,'source_identity_error':''}
  for k in ['top3d','bottom3d']:
   if a[k] is None or ar[k] is None:ck['projection_same_within_1e_12'] &= a[k] is None and ar[k] is None
   else:ck['projection_same_within_1e_12'] &= bool(np.allclose(a[k],ar[k],atol=1e-12,rtol=0))
  errs=[]
  if s['preprocessing_status']=='ready':
   pp=s['preprocessed_points'];before=s['before_preprocessing_points'];inds=s['ordered_source_point_indices'];links=s['links_zero_based'];n=len(pp)
   if len(before)!=n:errs.append('before_preprocessing_count')
   if sorted(i for q in links for i in q)!=list(range(n)):errs.append('source_pairs_not_bijection')
   if sorted(inds)!=list(range(n)):errs.append('source_indices_not_bijection')
   if s['points_1024x512']!=[pp[i] for i in inds]:errs.append('final_identity_mismatch')
   if s['ordered_source_point_labels']!=[s['point_labels'][i] for i in inds]:errs.append('point_labels_mismatch')
   if s['matterport_links_zero_based']!=[[i,i+1] for i in range(0,n,2)]:errs.append('final_pairs_mismatch')
   for up,dn in links:
    mid=(before[up][0]+((before[dn][0]-before[up][0]+512)%1024-512)/2)%1024
    if abs(pp[up][0]-mid)>1e-8 or abs(pp[dn][0]-mid)>1e-8 or pp[up][1]!=before[up][1] or pp[dn][1]!=before[dn][1]:errs.append('sharedx_or_y_changed')
   if s['ring_confirmed'] and s['order_record']['order']!=s['ordered_source_pair_indices']:errs.append('confirmed_ring_mismatch')
  elif any(s[k] is not None for k in ['preprocessed_points','points_1024x512']):errs.append('unavailable_not_null')
  ck['source_identity_contract']=not errs;ck['source_identity_error']='|'.join(errs);checks.append(ck)
  if s['object_kind']!='annotation':continue
  r=results[a['id']];raw=count(s['original_export_points']);final=count(a['points']);na=r['quality_score'] is None; hist=s['review']['historical_exclusion_reason']; excluded=s['cleaning_disposition'] in ('excluded_by_review','historical_not_accepted')
  texts=list(dict.fromkeys(c['text'] for c in cm[a['id']]))
  if r['unavailable_primary_reason']=='existing_pairing_unresolved':
   if s['pairing_basis']=='user_explicit_oos_uncalculable':detail='用户已明确此OOS无法配对就视为无法计算；保留原点不代表已获配对'
   elif s['cleaning_disposition']=='historical_not_accepted':detail='历史不纳入记录保留原点，但源最终配对为空；历史原因='+hist+'；不能据此说用户没有标点或数学上永远不可算'
   else:detail='已人工排除记录的现行配对为空；不能从点数直接补成环'
  elif r['unavailable_primary_reason']=='annotation_points_unavailable':
   detail=('原始点为空' if raw==0 else '原始点仍在，但现行有效点为空')+'；历史原因='+hist
  elif a['id']=='R01424':detail='原p8/final索引3的y=3897.2824060150374越界；修复证据曾改为389.7282406015037，初始化备注又恢复原始值，属于来源版本冲突待核'
  elif a['id']=='R01879':detail='原始及最终4点=2对；旧裁决invalid/只有4点，几何核不能形成有效闭合面'
  elif na:detail=reasons_cn[r['unavailable_primary_reason']]
  elif excluded:detail='计算可行，但旧资格已排除；只能作为全库存诊断，不能默认列入筛后主分析'
  else:detail='现行Q可计算；资格仍须按使用目的另看'
  row=dict(record_id=a['id'],image_code=im['code'],worker=s['worker'],condition=s['condition'],canonical_object_id=s['canonical_object_id'],original_point_count=raw,before_preprocessing_point_count=count(s['before_preprocessing_points']),preprocessed_point_count=count(s['preprocessed_points']),final_point_count=final,final_pair_count=final//2 if final is not None else None,raw_points_present=bool(raw),raw_positive_less_than_8=bool(raw and raw<8),raw_at_least_8=raw is not None and raw>=8,final_positive_less_than_8=bool(final and final<8),point_count_changed=bool(final is not None and raw!=final),pairing_basis=s['pairing_basis'],preprocessing_status=s['preprocessing_status'],ring_order_status=s['order_status'],ring_human_confirmed=s['ring_confirmed'],cleaning_disposition=s['cleaning_disposition'],worker_quality_gate=s['worker_quality_gate'],review_verdict=s['review']['verdict'],historical_exclusion_reason=hist,main_gate_reasons=j(s['main_quality_gate']['reasons']),score_status=r['status'],quality_score=r['quality_score'],na_primary_reason=r['unavailable_primary_reason'],na_reason_chinese=reasons_cn[r['unavailable_primary_reason']],audit_explanation=detail,old_exclusion_applies=excluded,cleaning_pass_view=not excluded,strict_main_candidate_view=s['worker_quality_gate']=='candidate_pending_geometry',independent_vote_eligible=s['independent_vote_eligible'],independent_vote_reasons=j(s['independent_vote_reasons']),reference_id=a['referenceId'],reference_version=a['referenceVersion'],target_applicability=im['targetApplicability'],target_reason_kind=im['target_reason_kind'],point_labels=j(s['point_labels']),original_export_indices=j(s['original_export_indices']),ordered_source_point_indices=j(s['ordered_source_point_indices']),ordered_source_pair_indices=j(s['ordered_source_pair_indices']),deleted_previous_point_indices=j(s['deleted_previous_point_indices']),source_pair_links=j(s['links_zero_based']),final_pair_links=j(s['matterport_links_zero_based']),source_ring_connections=j(s['existing_ring_connections']),initialization_notes=j(s['initialization_notes']),repair_evidence=j(s['repair_evidence']),semantic_annotation_evidence=j(s['review'].get('semantic_annotation_evidence')),relevant_comments=j(texts),source_path=s['source'].get('selected_snapshot_path',s['source'].get('path')),source_task=s['source'].get('task'),source_annotation=s['source'].get('annotation'))
  rows.append(row)
  if na:
   gt=refs[a['referenceId'],a['referenceVersion']]; rr=score_geometry(a,gt,params,target_applicability=im['targetApplicability'],target_inapplicability_reason=im['targetInapplicabilityReason'])
   replay.append(dict(record_id=a['id'],quality_score_still_null=rr['quality_score'] is None,status_identical=rr['status']==r['status'],reason_codes_identical=rr['reason_codes']==r['reason_codes'],annotation_validity_identical=rr['annotation_validity']==r['annotation_validity'],reference_validity_identical=rr['reference_validity']==r['reference_validity'],failure_classes_identical=rr['failure_classes']==r['failure_classes']))
   for stage,key in [('original_export','original_export_points'),('before_preprocessing','before_preprocessing_points'),('preprocessed','preprocessed_points'),('final_ring','points_1024x512')]:
    for idx,xy in enumerate(s[key] or []):
     source_idx=s['ordered_source_point_indices'][idx] if stage=='final_ring' else idx if stage in ('before_preprocessing','preprocessed') else None
     label=s['point_labels'][source_idx] if source_idx is not None and source_idx<len(s['point_labels']) else None
     origin=s['original_export_indices'][source_idx] if source_idx is not None and source_idx<len(s['original_export_indices']) else idx if stage=='original_export' else None
     point_rows.append(dict(record_id=a['id'],image_code=im['code'],stage=stage,index_zero_based=idx,source_point_label=label,source_preprocessed_index_zero_based=source_idx,original_export_index_zero_based=origin,x=xy[0],y=xy[1]))
  if na or excluded or (raw is not None and raw<8):
   for c in cm[a['id']]:
    for oc in c['occurrences']:
     comment_rows.append(dict(record_id=a['id'],image_code=im['code'],comment_id=c['comment_id'],text=c['text'],occurrence_id=oc['occurrence_id'],source_file=oc['source_file'],json_pointer=oc['json_pointer'],updated_at=oc['updated_at'],recorded_verdict=oc['recorded_verdict'],recorded_status=oc['recorded_status'],binding_status=oc['binding_status']))
write('all_3152_point_gate_audit.csv',rows);write('all_3441_source_contract_checks.csv',checks);write('NA173_record_recheck.csv',[r for r in rows if r['quality_score'] is None]);write('NA173_point_coordinates.csv',point_rows);write('NA173_score_replay_checks.csv',replay);write('excluded_by_review85.csv',[r for r in rows if r['cleaning_disposition']=='excluded_by_review']);write('historical_not_accepted133.csv',[r for r in rows if r['cleaning_disposition']=='historical_not_accepted']);write('raw_lt8_71_including_empty.csv',[r for r in rows if r['original_point_count']<8]);write('final_lt8_18.csv',[r for r in rows if r['final_positive_less_than_8']]);write('point_count_changed20.csv',[r for r in rows if r['point_count_changed']]);write('historical_comment_evidence.csv',comment_rows)
views=[('full_inventory',lambda r:True,'全库存，沿用原研究分母'),('remove_excluded_by_review_only',lambda r:r['cleaning_disposition']!='excluded_by_review','只移除85份人工排除；仍保留133份历史不纳入'),('pass_old_cleaning_gate',lambda r:r['cleaning_pass_view'],'只应用既有85人工排除和133历史不纳入，未应用今日wc2-14暂搁置；不等同全部适合主质量分析'),('retained_only',lambda r:r['cleaning_disposition']=='retained','只保留retained，不纳入retained_pending'),('strict_main_quality_candidate',lambda r:r['strict_main_candidate_view'],'严格沿用旧主质量候选gate；候选仍不保证几何有效'),('diagnostic_raw_ge8_only',lambda r:r['raw_at_least_8'],'仅诊断；不建议作为恢复旧筛选，会错删已确认7→8点记录')]
vs=[]
for name,fn,note in views:
 sub=[r for r in rows if fn(r)];vs.append(dict(view=name,records=len(sub),available_Q=sum(r['quality_score'] is not None for r in sub),unavailable_Q=sum(r['quality_score'] is None for r in sub),images=len(set(r['image_code'] for r in sub)),images_with_Q=len(set(r['image_code'] for r in sub if r['quality_score'] is not None)),interpretation=note))
write('denominator_views.csv',vs)
cat=[]
for reason in sorted({r['na_primary_reason'] for r in rows if r['quality_score'] is None}):
 sub=[r for r in rows if r['na_primary_reason']==reason];cat.append(dict(na_reason=reason,chinese=reasons_cn[reason],records=len(sub),raw_empty=sum(r['original_point_count']==0 for r in sub),raw_1_to_7=sum(r['raw_positive_less_than_8'] for r in sub),raw_ge8=sum(r['raw_at_least_8'] for r in sub),raw_present=sum(r['raw_points_present'] for r in sub),old_excluded=sum(r['old_exclusion_applies'] for r in sub),images=len(set(r['image_code'] for r in sub))))
write('NA173_reason_by_point_count.csv',cat)
gates=[]
for gate in sorted({r['worker_quality_gate'] for r in rows}):
 sub=[r for r in rows if r['worker_quality_gate']==gate];gates.append(dict(gate=gate,records=len(sub),Q=sum(r['quality_score'] is not None for r in sub),NA=sum(r['quality_score'] is None for r in sub)))
write('quality_gate_score_crosscheck.csv',gates)
for name,fn,_ in views:
 if name in ('pass_old_cleaning_gate','strict_main_quality_candidate'):write(name+'_view.csv',[r for r in rows if fn(r)])
summary={'schema':'na_point_filter_recheck_v1','source_read_only':True,'original_algorithms_and_data_changed':False,'records':len(rows),'NA':len(replay),'NA_with_raw_points':sum(r['quality_score'] is None and r['raw_points_present'] for r in rows),'raw_lt8_including_empty':sum(r['original_point_count']<8 for r in rows),'final_lt8':sum(r['final_positive_less_than_8'] for r in rows),'point_count_changed':sum(r['point_count_changed'] for r in rows),'source_hashes_match':all(x['matches'] for x in shachecks),'all_source_contract_checks_pass':all(all(v for k,v in c.items() if k.endswith('_match') or k in ('projection_same_within_1e_12','source_identity_contract')) for c in checks),'NA173_replay_all_pass':all(all(v for k,v in c.items() if k!='record_id') for c in replay),'denominator_views':vs,'na_categories':cat,'no_unapproved_repair_or_repair_inference':True}
(O/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(summary,ensure_ascii=False,indent=2))

# Additional view only: the user's 2026-10-09 decision holds all five wc2-14 records.
# Preserve every original score and all frozen eligibility fields.
overlay=[]
for r in rows:
    hold=r['image_code']=='wc2JMjhGNzB-14'
    overlay.append(dict(record_id=r['record_id'],image_code=r['image_code'],worker=r['worker'],original_quality_score=r['quality_score'],original_score_status=r['score_status'],old_cleaning_disposition=r['cleaning_disposition'],old_cleaning_pass=r['cleaning_pass_view'],today_user_hold_wc2_14=hold,current_cleaning_plus_today_hold_pass=r['cleaning_pass_view'] and not hold,current_analysis_status='hold_user_20261009_both_gt_questioned' if hold else 'historically_excluded' if not r['cleaning_pass_view'] else r['score_status'],decision_date='2026-10-09' if hold else '',decision_scope='wc2JMjhGNzB-14 all five annotation records; both GT versions questioned; temporary hold' if hold else ''))
write('current_decision_overlay_all3152.csv',overlay)
write('wc2_14_today_hold_five_records.csv',[r for r in overlay if r['today_user_hold_wc2_14']])
sub=[r for r in rows if r['cleaning_pass_view'] and r['image_code']!='wc2JMjhGNzB-14']
write('current_cleaning_plus_today_hold_view.csv',sub)
vs.append(dict(view='old_cleaning_plus_today_wc2_14_hold',records=len(sub),available_Q=sum(r['quality_score'] is not None for r in sub),unavailable_Q=sum(r['quality_score'] is None for r in sub),images=len(set(r['image_code'] for r in sub)),images_with_Q=len(set(r['image_code'] for r in sub if r['quality_score'] is not None)),interpretation='既有两类清洗排除+2026-10-09 wc2-14五条暂搁置；P017原已排除，因此新增移除4条；原Q均保留在覆盖表'))
write('denominator_views.csv',vs)
summary['denominator_views']=vs
summary['current_user_decision_overlay']={'held_image':'wc2JMjhGNzB-14','records':5,'workers':['P001','P007','P017','P020','P026'],'already_excluded_before_today':1,'newly_removed_from_old_cleaning_view':4,'frozen_scores_modified':False}
(O/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
write('old_cleaning_NA32.csv',[r for r in rows if r['cleaning_pass_view'] and r['quality_score'] is None])
