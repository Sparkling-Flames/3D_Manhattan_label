from pathlib import Path
import json, hashlib
import pandas as pd

import argparse
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
ROOT=args.out.resolve();ROOT.mkdir(parents=True,exist_ok=True);SRC=args.bundle.resolve()
manifest={x['path']:x['sha256'] for x in json.load(open(SRC/'MANIFEST.json'))['files']}
def source_hash(p):
 return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else manifest[str(p.relative_to(SRC))]
s=pd.read_csv(SRC/'results_fixed/all_records_scores.csv')
a=pd.read_csv(SRC/'validation/prior_ablation/all_records_default_vs_no_prior.csv')
c=pd.read_csv(SRC/'validation/prior_ablation/fixed_reference_exact_copy_comparison.csv')
reviews=json.load(open(SRC/'validation/real_visual_review.json'))
rv={r['record_id']:r for r in reviews['reviews']}
captions=json.load(open(SRC/'visuals/case_captions_zh.json'))['captions']
visual_notes={
'R02075':('prior_mismatch_supported','照片中部转折墙面同时有上下边界与墙角支持；BEV青橙线紧贴且存在非正交墙段。顶线有轻微局部差，不能声称各点完全正确。方向偏差不应整体解释为标注错误。'),
'R01114':('ceiling_target_ambiguity','可见坡顶与矮墙；蓝线部分贴低位交界，但后墙也保持低位，不能宣称它完整正确。橙线采用较高近同高包络，侧墙并非完整真实坡顶模型。低Q可解释为参考差异，不能推成整体几乎无质量。'),
'R01360':('ceiling_target_ambiguity','前景柱及画上方存在低位顶/梁底交界；蓝线在相邻位置降低，底面接近GT。并非纯随机错线，但仅凭卡片不能认证每一段。'),
'R02187':('ceiling_target_ambiguity','高位蓝橙包络几乎重合；右侧低位结构仍可见。高参考吻合不能单独证明R01360的低位表达错。'),
'GT_COPY_R02762':('prior_identity_failure','与GT精确重合的控制；真实墙角和上下线脚支持中部斜墙。低于95来自先验，非参考误差。'),
'GT_COPY_R02739':('reference_semantics_uncertain','控制线贴柜体上缘并跨过不同开口高度，房间墙面包络与柜体边界混杂。不能将高度起伏认证为真实斜顶；去先验得100也不证明物理正确。'),
'R00768':('reference_detail_omission','简化矩形青橙线接近；照片中有柱/凸出结构。是否应包含它们取决于目标，但高Q不能认证所有真实细节完整。'),
'R00186':('scope_target_difference','蓝线围合淋浴隔间；GT延伸到玻璃门外浴室。严重范围差事实明确，但是否允许隔间作目标须有任务约定。'),
'R02173':('input_pairing_unavailable','照片上仍有12个原点，卡片无补造连接。NA表示既有配对未确定，不能凭无BEV认定原始点不存在或房间不可建模。'),
'R02082':('input_points_unavailable','卡片只有GT，没有蓝原点；与表中原始点数0一致。未补造几何。'),
'R01423':('historical_reference_error','图中标注BEV/条件3D可展示；NA源于既有GT裁决，并非本审查从图作出新的GT错误结论。'),
'R01726':('historical_hold','标注BEV/条件3D可展示；NA源于历史hold。本审查不将hold升级为GT已证实错误。'),
'R01424':('input_out_of_domain','原点图不强行将异常点画回图片内；卡片明确域外点保留JSON。看图不能决定该点应该缩小十倍。'),
'R01879':('input_insufficient_pairs','仅两对点形成线状/单墙片，不能形成闭合房间底面；卡片用线框而非虚构体积。'),
}
rows=[]
for rid,(tag,note) in visual_notes.items():
 p=SRC/'visuals/cards'/f'{rid}.jpg'
 assert p.exists() or str(p.relative_to(SRC)) in manifest
 row={'record_or_control_id':rid,'card_relative_to_source':str(p.relative_to(SRC)),'card_sha256':source_hash(p),'evidence_bytes_present_in_lightweight':p.exists(),'actually_viewed_in_this_audit':True,'view_scope':'provided overlay card: panorama, equal-scale BEV, conditional 3D; no separate unoverlaid original opened','independent_audit_tag':tag,'independent_visible_observation_zh':note,'existing_publication_caption_zh':captions.get(rid,''),'new_GT_adjudication':False}
 sr=s[s.record_id==rid]
 if not sr.empty:
  sr=sr.iloc[0]
  for k in ['image_code','reference_id','reference_version','score_status','quality_score','ring_order_status','unavailable_primary_reason','scope_evidence_flag','reference_uncertain_flag','reference_detail_omission_flag']:
   row[k]=sr[k]
  ar=a[a.record_id==rid].iloc[0]
  row['published_Q_no_intrinsic_prior']=ar['Q_no_intrinsic_prior']
 if rid in rv:
  row['existing_20261009_gt_target_ambiguity']=rv[rid].get('gt_target_ambiguity','')
  row['existing_20261009_review_source']=f'validation/real_visual_review.json#/reviews (record_id={rid})'
 rows.append(row)
pd.DataFrame(rows).to_csv(ROOT/'visual_evidence_14.csv',index=False,encoding='utf-8-sig')

# Join demonstration only. Preserve historical fields; no rewrites to the source.
join=s[['record_id','image_code','scope_evidence_flag','reference_uncertain_flag','reference_detail_omission_flag','target_applicability','quality_score']].merge(pd.DataFrame([{
'record_id':r['record_id'],'review_20261009_gt_target_ambiguity':r.get('gt_target_ambiguity'),'review_20261009_interpretation_zh':r.get('interpretation_zh'),'review_20261009_freeze_implication_zh':r.get('freeze_implication_zh'),'review_20261009_source':'validation/real_visual_review.json'} for r in reviews['reviews']]),on='record_id',how='inner',validate='one_to_one')
join.to_csv(ROOT/'existing_review_join_example.csv',index=False,encoding='utf-8-sig')

summary={
 'audit_kind':'applicability/GT/grouping/failure policy and independently viewed provided evidence cards; not full numerical replay',
 'source_unchanged':True,
 'all_records':len(s),'Q_available':int(s.quality_score.notna().sum()),'Q_unavailable':int(s.quality_score.isna().sum()),
 'ring_by_status':pd.crosstab(s.ring_order_status,s.score_status).to_dict(),
 'default_unreviewed_fraction_among_Q_available':float(((s.ring_order_status=='default_unreviewed') & s.quality_score.notna()).sum()/s.quality_score.notna().sum()),
 'NA_primary_counts':s[s.quality_score.isna()].unavailable_primary_reason.value_counts().to_dict(),
 'group_counts':s.groupby('evaluation_group').agg(records=('record_id','size'),images=('image_code','nunique'),buildings=('building','nunique'),valid_Q=('quality_score','count')).reset_index().to_dict('records'),
 'manual_revision_images':int(s[s.reference_version=='manual_revision'].image_code.nunique()),'manual_revision_records':int((s.reference_version=='manual_revision').sum()),
 'GT_copies_checked_in_published_table':len(c),'GT_copies_below95':int((c.default_copy_Q<95).sum()),'GT_copies_D_over1deg':int((c.dir_deg>1).sum()),'GT_copies_F_over1deg':int((c.flat_deg>1).sum()),
 'published_review_join_rows':len(join),'viewed_cards_in_this_audit':list(visual_notes),
 'source_hashes':{f:source_hash(SRC/f) for f in ['README_先读.txt','reports/01_中文研究报告.pdf','results_fixed/all_records_scores.csv','validation/real_visual_review.json','visuals/case_captions_zh.json','run_expanded.py']},
}
(ROOT/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
