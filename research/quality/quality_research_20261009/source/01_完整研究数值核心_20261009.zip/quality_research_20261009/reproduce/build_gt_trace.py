from pathlib import Path
import json, sys, hashlib, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager, patheffects
from matplotlib.lines import Line2D
from PIL import Image

import argparse
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--trace-inputs',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--font',type=Path);args=p.parse_args()
HERE=args.trace_inputs.resolve();ROOT=args.bundle.resolve();OUT=args.out.resolve();OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT)); import render_evidence as re
sys.path.insert(0,str(ROOT/'frozen_engine/core'))
from quality_v11 import own_metrics, scalar_score
fonts=[f.fname for f in font_manager.fontManager.ttflist if any(n in f.name for n in ['Noto Sans CJK','Source Han Sans','Microsoft YaHei','SimHei'])]
font=str(args.font) if args.font else (fonts[0] if fonts else None)
if not font:raise RuntimeError('A Chinese font is required for these figures. Install Noto Sans CJK or pass --font FONT_FILE.')
font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':11})
im=next(x for x in json.loads((ROOT/'prepared/frozen_expanded_geometry.json').read_text())['images'] if x['code']=='wc2JMjhGNzB-14')
old,new=im['groundtruths']; assert old['id']=='R02738' and new['id']=='R02739'
photo_path=HERE/'photos'/Path(im['imageInternalPath']).relative_to('images')
photo=Image.open(photo_path);photo.load();assert photo.size==(2048,1024)
COLORS=['#007EB5','#D65100']; INK='#172F45'; SUB='#52687C'; HI='#A9286A'
metrics={g['id']:own_metrics(g) for g in [old,new]}
rows=[]
for g in [old,new]:
 p=np.asarray(g['points']).reshape(-1,2,2); raw=np.asarray(g['source_record']['original_export_points'])
 for j,(t,b) in enumerate(p):
  alpha=(.5-t[1]/512)*np.pi; beta=(b[1]/512-.5)*np.pi
  rho=1/np.tan(beta); y=rho*np.tan(alpha)
  ti,bi=g['sourcePointIndices'][2*j:2*j+2]
  rows.append({'GT':g['id'],'pair':j+1,'raw_top_index_one_based':ti+1,'raw_bottom_index_one_based':bi+1,'raw_top_x':raw[ti,0],'raw_top_y':raw[ti,1],'raw_bottom_x':raw[bi,0],'raw_bottom_y':raw[bi,1],'shared_x':float(t[0]),'top_y':float(t[1]),'bottom_y':float(b[1]),'upper_elevation_deg':float(np.rad2deg(alpha)),'lower_depression_deg':float(np.rad2deg(beta)),'horizontal_radius_h':float(rho),'top_y_above_camera_h':float(y),'floor_to_top_h':float(1+y)})
with (OUT/'gt_source_coordinates.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def overlay(ax,g,c,prefix):
 ax.imshow(photo,extent=(0,1024,512,0))
 for seg in re.projected_paths(g):
  line,=ax.plot(seg[:,0],seg[:,1],color=c,lw=1.7)
  line.set_path_effects([patheffects.Stroke(linewidth=2.7,foreground='white',alpha=.75),patheffects.Normal()])
 p=np.asarray(g['points']).reshape(-1,2,2)
 for i,(t,b) in enumerate(p,1):
  ax.scatter([t[0],b[0]],[t[1],b[1]],c=c,s=34,edgecolor='white',lw=.7,zorder=6)
  for q,suf in [(t,'上'),(b,'下')]:
   ax.text(q[0]+7,q[1]-8,prefix+str(i)+suf,color='white',fontsize=12,weight='bold',path_effects=[patheffects.withStroke(linewidth=3.5,foreground=c)],zorder=8)
 ax.set(xlim=(0,1024),ylim=(512,0));ax.axis('off')

fig=plt.figure(figsize=(20,13.7),facecolor='white')
fig.text(.035,.974,'wc2JMjhGNzB-14：原始GT与当前修订GT的原图回放',fontsize=23,weight='bold',c=INK,va='top')
fig.text(.035,.932,'同一张2048×1024原图；显示坐标为1024×512。按既有点对、环序和三维边投影，不改点、不对齐、不修形。',fontsize=12,c=SUB)
gs=fig.add_gridspec(2,1,left=.025,right=.975,top=.891,bottom=.105,hspace=.14)
for ax,g,c,prefix,title in [(fig.add_subplot(gs[0]),old,COLORS[0],'O','原始 original · R02738'),(fig.add_subplot(gs[1]),new,COLORS[1],'N','当前 manual_revision · R02739')]:
 overlay(ax,g,c,prefix); ax.set_title(title,loc='left',fontsize=16,color=c,pad=9,weight='bold')
fig.text(.035,.071,'编号仅表示各版本自己的环序：O1与N1不代表同一物理墙角；本材料没有从原始GT到修订GT的逐点编辑日志。',fontsize=12,c=INK)
fig.text(.035,.044,'原始GT的矩形/平顶是数据事实，不是正确性认证；当前修订GT仍为现行唯一评分参考。本图不裁决是否误改。',fontsize=12,c=INK)
fig.text(.035,.018,'来源：复现包 prepared/frozen_expanded_geometry.json + 配套原图ZIP第3包；线条为原几何证据，非生成式重绘。',fontsize=10,c=SUB)
fig.savefig(OUT/'01_wc2原始与当前GT_原图对比.png',dpi=190,facecolor='white');plt.close(fig)

fig=plt.figure(figsize=(20,14),facecolor='white')
fig.text(.035,.973,'R02738 → R02739：可核实的坐标链条与条件几何',fontsize=23,weight='bold',c=INK,va='top')
fig.text(.035,.929,'蓝色：原始GT　橙色：当前修订GT　h＝相机到地面归一化距离；Y＝0在相机，地面Y＝−1。',fontsize=13,c=SUB)
gs=fig.add_gridspec(2,3,left=.045,right=.965,top=.865,bottom=.125,height_ratios=[1,1.03],width_ratios=[1,1.18,1.28],wspace=.30,hspace=.38)
lim=re.bounds([old,new])
ax=fig.add_subplot(gs[0,0]);re.style2(ax)
for g,c,prefix in [(old,COLORS[0],'O'),(new,COLORS[1],'N')]:
 p=np.asarray(g['bottom3d'])[:,[0,2]];q=re.close(p);ax.plot(q[:,0],q[:,1],color=c,lw=2);ax.scatter(p[:,0],p[:,1],color=c,s=30)
 for j,v in enumerate(p,1):ax.annotate(prefix+str(j),v,xytext=(5,6),textcoords='offset points',c=c,fontsize=11)
ax.scatter([0],[0],marker='+',s=80,c=INK);ax.set_aspect('equal');ax.set(xlabel='X / h',ylabel='Z / h',title='俯视：两版原形，同尺度')
ax=fig.add_subplot(gs[0,1],projection='3d')
for g,c,prefix in [(old,COLORS[0],'O'),(new,COLORS[1],'N')]:
 t=np.asarray(g['top3d']);b=np.asarray(g['bottom3d'])
 for p in [t,b]:q=re.close(p);ax.plot(q[:,0],q[:,2],q[:,1],color=c,lw=1.8)
 for j,(p,q) in enumerate(zip(t,b),1):
  ax.plot([p[0],q[0]],[p[2],q[2]],[p[1],q[1]],color=c,lw=1)
  ax.text(p[0],p[2],p[1]+.04,prefix+str(j),color=c,fontsize=10)
lo,hi=lim;span=hi-lo;ax.set(xlim=(lo[0],hi[0]),ylim=(lo[2],hi[2]),zlim=(lo[1],hi[1]),xlabel='X / h',ylabel='Z / h',zlabel='Y / h',title='条件3D：真实轴比例')
ax.set_box_aspect([span[0],span[2],span[1]]);ax.set_proj_type('ortho');ax.view_init(elev=23,azim=-58);ax.tick_params(labelsize=8)
ax=fig.add_subplot(gs[0,2]);ax.axis('off')
text='高点是否来自后续x归并？\n\n不是。第4对在修订导出里已是：\n上点 p8 = (734.1764, 99.7030)\n下点 p7 = (732.3636, 391.1075)\n\n归并后两者 x = 733.2700，y均未改。\n最终数组把 p8 放上、p7 放下。\n这不是把两个端点误交换位置。\n\n顶高 Y/h = tan(上仰角) / tan(下俯角)\n该高度公式不含x。\nN4：54.95° / 47.50° → Y = 1.306h\nN1–N3：Y = 0.483 / 0.396 / 0.509h'
ax.text(0,1,text,va='top',fontsize=12,c=INK,linespacing=1.6)
ax=fig.add_subplot(gs[1,:2]);ax.axis('off')
data=[]
for r in rows:
 data.append([('O' if r['GT']=='R02738' else 'N')+str(r['pair']),f"{r['shared_x']:.3f}",f"{r['top_y']:.3f}",f"{r['bottom_y']:.3f}",f"{r['horizontal_radius_h']:.3f}",f"{r['top_y_above_camera_h']:.3f}"])
table=ax.table(cellText=data,colLabels=['版本内点对','最终x','上点y','下点y','水平距离 / h','相机以上顶高 / h'],cellLoc='center',colLoc='center',loc='upper center',bbox=[0,.19,1,.81])
table.auto_set_font_size(False);table.set_fontsize(11)
for (r,c),cell in table.get_celld().items():
 cell.set_edgecolor('#D7E0E6');cell.set_height(.09)
 if r==0:cell.set_facecolor('#E8EFF4');cell.set_text_props(weight='bold',color=INK)
 else:cell.set_facecolor('#F2F8FC' if r<=4 else '#FFF5EF');cell.set_text_props(color=COLORS[0] if r<=4 else COLORS[1])
ax.text(0,.115,'原始O1–O4按其源环序列出；修订N1–N4按其确认环序列出。两组之间不设虚构的墙角对应。',fontsize=11,color=SUB)
ax.text(0,.045,'N4的水平距离0.916h比N1–N3更短；其较高顶高主要体现更大的上仰角，而非底点带来的远距离。',fontsize=11,color=INK)
ax=fig.add_subplot(gs[1,2]);ax.axis('off')
text='修订链条的证据边界\n\n① 原始：数据集label_cor文本 → R02738\n   源点、预处理点、最终点完全相同。\n② 修订：groudTruth.json → R02739\n   原始导出与预处理前点完全相同。\n   N2共享x：301.1643/309.1023 → 305.1333\n   N4共享x：734.1764/732.3636 → 733.2700\n   所有y保留，无新增或删除点。\n③ 环序确认：2026-09-29 07:32:42 UTC\n   该时间仅证明环序确认，不是改点时间。\n④ 10/9复现包两版source_record与\n   10/7资料包current/records逐字段一致。\n\n没有作者/逐步拖点记录，不能据此断言误改。\n几何规整性与GT语义/准确性需要分别判断。'
ax.text(0,1,text,va='top',fontsize=11.5,c=INK,linespacing=1.55)
fig.text(.035,.073,'规整性仅作描述：原始 方向残差≈0.002°、平顶残差≈0.0003°；当前 方向残差7.603°、平顶残差9.993°。',fontsize=12,c=INK)
fig.text(.035,.046,'这些差异不能证明矩形版更正确，也不能证明修订错误。未替换GT、修改评分算法或回写任何数据。',fontsize=12,c=INK)
fig.text(.035,.019,'点位单位：1024×512 ERP像素；几何单位为h，非米。所有结论来自实际源坐标与冻结投影。',fontsize=10,c=SUB)
fig.savefig(OUT/'02_wc2修订链与几何_证据图.png',dpi=180,facecolor='white');plt.close(fig)

original_txt=args.snapshot/'data/mp3d_layout/test/label_cor/wc2JMjhGNzB_1d8917d25abb4a77a0da9583dc82c17c.txt'
assert np.array_equal(np.loadtxt(original_txt),np.asarray(old['points']))
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
src=ROOT/'prepared/frozen_expanded_geometry.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=next(x['sha256'] for x in manifest['files'] if x['path']=='prepared/frozen_expanded_geometry.json')
assert sha(src)==expected
prior=args.snapshot
prior_records=json.loads((prior/'current/records.json').read_text())['objects']
assert all(g['source_record']==next(x for x in prior_records if x['id']==g['id']) for g in [old,new])
comments=[x for x in json.loads((prior/'evidence/relevant_comments.json').read_text())['comments'] if x.get('image_code')==im['code']]
out={'image_code':im['code'],'image_id':im['imageId'],'photo_sha256':sha(photo_path),'input_sha256':expected,'original_source_verified_equal':True,'prior_current_source_records_identical':True,'point_rows':rows,'intrinsic_metrics':metrics,'historical_comments':comments,'limits':['No physical-corner correspondence between versions is asserted.','No coordinate editor identity or chronological point-edit log is included.','Order confirmation time is not coordinate edit time.','Original version regularity is not ground-truth validity evidence.'],'files':[{'name':p.name,'sha256':sha(p)} for p in OUT.glob('*.png')]}
(OUT/'gt_trace_evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'outputs':[str(p) for p in OUT.iterdir()],'image_size':photo.size,'all_checks_passed':True},ensure_ascii=False))
