import sys, json, csv, pathlib, math, hashlib
import numpy as np
import argparse
p=argparse.ArgumentParser();p.add_argument('--bundle',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);args=p.parse_args()
ROOT=args.bundle.resolve();OUT=args.out.resolve();OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'frozen_engine/core'))
from quality_v11 import score_geometry
from audit_geometry import signed_area, intersection_area
images=json.load(open(ROOT/'prepared/frozen_expanded_geometry.json'))['images']
rows=list(csv.DictReader(open(ROOT/'results_fixed/all_records_scores.csv',encoding='utf-8-sig')))
lookup={r['record_id']:r for r in rows}
selected=[]
results={}
for rid in ['R00186','R01013']:
 im=next(im for im in images if any(a['id']==rid for a in im['annotations']))
 a=next(a for a in im['annotations'] if a['id']==rid)
 g=next(g for g in im['groundtruths'] if (g['id'],g['version'])==(a['referenceId'],a['referenceVersion']))
 r=score_geometry(a,g)
 (OUT/(rid+'_replay.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2))
 orig=lookup[rid]
 result={'record_id':rid,'image_code':im['code'],'image_id':im['imageId'],'groundtruths_available':[{'id':gt['id'],'version':gt['version']} for gt in im['groundtruths']],'reference_used':{'id':g['id'],'version':g['version']},'source_score':float(orig['quality_score']),'replayed_score':r['quality_score'],'score_abs_error':abs(float(orig['quality_score'])-r['quality_score']),'metrics':{k:r['metrics'].get(k) for k in ['iou','S_top_deg','S_bottom_deg','boundary_rms_deg','Hmean','Hlocal','Hstar','dir','flat','boundary_factor','reference_factor','intrinsic_factor','range_ceiling_points','range_deduction_points','boundary_deduction_points','height_deduction_points','intrinsic_deduction_points']},'annotation_pairs':len(a['bottom3d']),'gt_pairs':len(g['bottom3d']),'source_semantic_evidence':a['source_record']['review']['semantic_image_evidence'],'source_oos_status':im['source_scene']['oos_status']}
 if rid=='R01013':
  gp=np.asarray(g['bottom3d'])[:,[0,2]]
  ap=np.asarray(a['bottom3d'])[:,[0,2]]
  wing=gp[[3,4,5,6]]
  main=gp[[0,1,2,3,6,7]]
  ga,aa,wa,ma=map(lambda q:abs(signed_area(q)),[gp,ap,wing,main])
  missing=ga-intersection_area(gp,ap)
  wingmissing=wa-intersection_area(wing,ap)
  mainmissing=ma-intersection_area(main,ap)
  result['descriptive_footprint_partition']={'definition':'Original GT indices 3,4,5,6 (zero-based) define the visible left wing polygon. This is a descriptive area partition of the existing GT only; it is not a revised GT or a counterfactual score. Closing 6-to-3 is a partition seam, not a newly endorsed wall. All units are normalized by common camera-floor height h.','gt_area_h2':ga,'annotation_area_h2':aa,'gt_missing_h2':missing,'wing_area_h2':wa,'wing_missing_h2':wingmissing,'main_missing_h2':mainmissing,'wing_share_of_gt':wa/ga,'wing_share_of_missing':wingmissing/missing,'main_share_of_missing':mainmissing/missing,'partition_exact_cover_area_error_h2':abs(wa+ma-ga)}
  pa,pg=np.array(a['points']),np.array(g['points'])
  matches=[]
  for ai,gi in [(0,2),(1,7),(2,0),(3,1)]:
   dx=((pa[2*ai,0]-pg[2*gi,0]+512)%1024)-512
   matches.append({'annotation_pair_1based':ai+1,'GT_pair_1based':gi+1,'annotation_xy_top':pa[2*ai].tolist(),'GT_xy_top':pg[2*gi].tolist(),'annotation_xy_bottom':pa[2*ai+1].tolist(),'GT_xy_bottom':pg[2*gi+1].tolist(),'dx_1024px':dx,'dy_top_512px':pa[2*ai,1]-pg[2*gi,1],'dy_bottom_512px':pa[2*ai+1,1]-pg[2*gi+1,1]})
  result['descriptive_corresponding_outer_corners']=matches
  result['corner_matching_caveat']='Four corners matched by nearby azimuth to existing outer footprint corners for transparent coordinate inspection; not algorithmic scoring correspondences and not an independently certified physical truth.'
 results[rid]=result
 selected.extend(r for r in rows if r['image_code']==im['code'])
 print(rid,json.dumps(result,ensure_ascii=False),flush=True)
keys=['record_id','image_code','reference_id','reference_version','quality_score','quality_band','iou','S_top_deg','S_bottom_deg','boundary_rms_deg','Hmean','Hlocal','Hstar','dir','flat','boundary_factor','reference_factor','intrinsic_factor','range_deduction_points','boundary_deduction_points','height_deduction_points','intrinsic_deduction_points','area_h2','reference_area_h2','annotation_height_mean_h','reference_height_mean_h']
with open(OUT/'scope_case_scores.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:r[k] for k in keys} for r in selected)
results['notes']=['The four point deductions are an ORDERED algebraic decomposition (range, then boundary, then height, then intrinsic), not independent causal attribution.','No source file, GT, scoring parameter, algorithm, or release score was modified.','Small height and intrinsic errors indicate internal consistency, not accurate absolute location by themselves. User feedback plus actual image review support the submitted shower enclosure quality judgment.','No verified annotation-task target specification was found in the inspected evidence, so compliance with whole-bathroom scope cannot be inferred from the fixed reference alone.']
(OUT/'scope_case_evidence.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
