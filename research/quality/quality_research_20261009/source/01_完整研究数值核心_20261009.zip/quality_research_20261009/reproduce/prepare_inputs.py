#!/usr/bin/env python3
"""Verify and copy self-contained numerical inputs to a fresh external workspace."""
import argparse,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prepare(out):
 out=out.resolve()
 if out==ROOT or ROOT in out.parents:raise ValueError('Use an output directory outside the delivered package.')
 if out.exists() and any(out.iterdir()):raise ValueError('Work directory must be new or empty.')
 b0=ROOT/'inputs/baseline';s0=ROOT/'inputs/snapshot'
 contract=json.loads((b0/'portable_support/bundle_numeric_contract.json').read_text());checks=[]
 for rel,expected in contract['sha256'].items():
  actual=sha(b0/rel);assert actual==expected,rel
  checks.append({'path':rel,'sha256':actual,'passed':True})
 source=json.loads((b0/'prepared/evaluation_contract_before_scores.json').read_text());source_checks=[]
 for rel,expected in source['source_hashes'].items():
  actual=sha(s0/rel);assert actual==expected,rel
  source_checks.append({'path':rel,'sha256':actual,'passed':True})
 out.mkdir(parents=True,exist_ok=True);b=out/'baseline/quality_v1_1_expanded_repro_20261009';s=out/'snapshot'
 shutil.copytree(b0,b);shutil.copytree(s0,s)
 result={'delivery_kind':'lightweight_numerical_inputs','baseline':'baseline/quality_v1_1_expanded_repro_20261009','snapshot':'snapshot','numeric_contract_checks':checks,'source_contract_checks':source_checks,'large_archives_required':False}
 (out/'prepared_inputs.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');return b,s,result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--work-dir',type=Path,required=True);a=p.parse_args();_,_,r=prepare(a.work_dir);print(json.dumps(r,ensure_ascii=False,indent=2))
