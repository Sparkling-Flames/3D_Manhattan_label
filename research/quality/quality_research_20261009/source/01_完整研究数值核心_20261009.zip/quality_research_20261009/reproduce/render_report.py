#!/usr/bin/env python3
"""Render the package's Chinese TXT report to a readable PDF. No network needed."""
import argparse,re
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
from reportlab.lib.enums import TA_LEFT
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=ROOT/'当前综合审查.txt');p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
 styles={
  'title':ParagraphStyle('title',fontName='STSong-Light',fontSize=18,leading=26,spaceAfter=8,textColor='#000000'),
  'date':ParagraphStyle('date',fontName='STSong-Light',fontSize=9,leading=14,spaceAfter=15,textColor='#555555'),
  'heading':ParagraphStyle('heading',fontName='STSong-Light',fontSize=12.5,leading=19,spaceBefore=13,spaceAfter=7,keepWithNext=True,textColor='#000000'),
  'body':ParagraphStyle('body',fontName='STSong-Light',fontSize=10.5,leading=15.6,spaceAfter=7,wordWrap='CJK',alignment=TA_LEFT,textColor='#111111')}
 paras=a.input.read_text(encoding='utf8').strip().split('\n\n');story=[]
 for i,s in enumerate(paras):
  lines=s.strip().splitlines()
  if i==0:
   story.append(Paragraph(escape(lines[0]),styles['title']))
   if len(lines)>1:story.append(Paragraph('<br/>'.join(escape(x) for x in lines[1:]),styles['date']))
  else:
   heading=bool(re.match(r'^[一二三四五六七八九十]+\s',s)) and '\n' not in s
   story.append(Paragraph('<br/>'.join(escape(x) for x in lines),styles['heading' if heading else 'body']))
 def page(c,d):
  c.saveState();c.setFont('STSong-Light',8);c.setFillColorRGB(.38,.38,.38)
  c.drawString(48,26,'全景布局质量完整审计  2026年10月9日');c.drawRightString(564,26,str(d.page));c.restoreState()
 a.out.parent.mkdir(parents=True,exist_ok=True)
 doc=SimpleDocTemplate(str(a.out),pagesize=(612,792),leftMargin=48,rightMargin=48,topMargin=38,bottomMargin=39,title='全景布局质量完整审计与共同范围遗漏研究',author='dot')
 doc.build(story,onFirstPage=page,onLaterPages=page)
 print(a.out)
if __name__=='__main__':main()
