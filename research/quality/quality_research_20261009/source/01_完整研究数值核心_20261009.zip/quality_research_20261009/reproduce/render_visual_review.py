#!/usr/bin/env python3
import argparse,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--photos',type=Path,default=ROOT/'original_photos');p.add_argument('--out',type=Path,required=True);p.add_argument('--font',type=Path);p.add_argument('--images',nargs='*');p.add_argument('--overview-only',action='store_true');a=p.parse_args()
 out=a.out.resolve()
 if out==ROOT or ROOT in out.parents:raise ValueError('Visual outputs must be outside the delivered package.')
 out.mkdir(parents=True,exist_ok=True);cfg=json.loads((ROOT/'reproduce/visual_entry.json').read_text())
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','QUALITY_BUNDLE':str(a.bundle.resolve()),'QUALITY_PHOTOS':str(a.photos.resolve()),'QUALITY_VISUAL_OUT':str(out),'MPLCONFIGDIR':str(out/'matplotlib_cache')}
 if a.font:env['QUALITY_CJK_FONT']=str(a.font.resolve())
 subprocess.run([sys.executable,'-B',str(ROOT/cfg['overview_script']),*(a.images or cfg['images'])],env=env,check=True)
 if not a.overview_only:subprocess.run([sys.executable,'-B',str(ROOT/cfg['core_script'])],env=env,check=True)
if __name__=='__main__':main()
