#!/usr/bin/env python3
"""Portable orchestration only. Keeps original scoring and GT untouched."""
import argparse,csv,hashlib,json,os,subprocess,sys,time
from pathlib import Path
from prepare_inputs import prepare
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--work-dir',type=Path,required=True);p.add_argument('--jobs',type=int,default=4);p.add_argument('--skip-new-scope-scan',action='store_true',help='Development or old-audit-only replay; not the recommended final verification')
 a=p.parse_args();out=a.work_dir.resolve();b,s,_=prepare(out);py=sys.executable;env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','MPLCONFIGDIR':str(out/'matplotlib_cache')};runs=[]
 def run(name,args):
  start=time.time();log=out/(name+'.log');cmd=[py,'-B',*map(str,args)]
  with log.open('w') as f:r=subprocess.run(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT)
  runs.append({'name':name,'seconds':round(time.time()-start,3),'exit_code':r.returncode,'log':log.name})
  print(name, 'PASS' if r.returncode==0 else 'FAIL',flush=True)
  (out/'reproduction_runs.json').write_text(json.dumps(runs,ensure_ascii=False,indent=2)+'\n')
  if r.returncode:raise RuntimeError(name+' failed; see '+log.name)
 run('baseline_fixed_replay',[b/'reproduce.py','--out',out/'baseline_replay','--jobs',a.jobs])
 run('independent_numeric',[ROOT/'reproduce/independent_numeric_audit.py','--bundle',b,'--out',out/'independent_numeric'])
 run('binding',[ROOT/'reproduce/verify_bindings.py','--root',b,'--out',out/'binding'])
 run('na_qualification',[ROOT/'reproduce/audit_na_point_filters.py','--bundle',b,'--snapshot',s,'--out',out/'na_qualification'])
 run('scope_cases',[ROOT/'reproduce/check_scope_cases.py','--bundle',b,'--out',out/'scope_cases'])
 run('applicability_evidence',[ROOT/'reproduce/build_applicability_evidence.py','--bundle',b,'--out',out/'applicability'])
 if not a.skip_new_scope_scan:
  config=json.loads((ROOT/'reproduce/new_scope_entry.json').read_text())
  cmd=[ROOT/config['script'],'--source-root',b,'--audit-root',out/'na_qualification','--out-dir',out/'scope_scan']
  run('new_scope_scan',cmd)
  run('new_scope_summary',[ROOT/config['summarize_script'],'--scan-dir',out/'scope_scan'])
  run('new_scope_validation',[ROOT/config['validate_script'],'--scan-dir',out/'scope_scan','--source-root',b,'--audit-root',out/'na_qualification'])
 na=json.loads((out/'na_qualification/audit_summary.json').read_text())
 v=next(x for x in na['denominator_views'] if x['view']=='old_cleaning_plus_today_wc2_14_hold')
 assert (v['records'],v['available_Q'],v['unavailable_Q'])==(2930,2898,32)
 def read(p):return json.loads(p.read_text())
 numeric=read(out/'independent_numeric/independent_traditional_summary.json')
 sensitivity=read(out/'independent_numeric/independent_sensitivity_summary.json')
 binding=read(out/'binding/binding_audit.json')
 provenance=read(out/'independent_numeric/provenance_scope.json')
 assert not numeric['mismatches']
 assert not sensitivity['arithmetic_defects']
 assert binding['failed_check_count']==0
 assert provenance.get('manifest_all_present_passed',provenance['manifest_all_passed']) and provenance['numeric_contract_all_passed']
 assert na['source_hashes_match'] and na['all_source_contract_checks_pass'] and na['NA173_replay_all_pass']
 byte_checks=[]
 for name in ['all_records_scores.csv','all_records_results.json']:
  before=hashlib.sha256((b/'results_fixed'/name).read_bytes()).hexdigest()
  after=hashlib.sha256((out/'baseline_replay/scores'/name).read_bytes()).hexdigest()
  assert before==after
  byte_checks.append({'file':name,'sha256':before,'byte_identical':True})
 (out/'independent_replay_byte_check.json').write_text(json.dumps(byte_checks,indent=2)+'\n')
 archive_checks=[]
 for rel,expected in read(ROOT/'inputs/baseline/portable_support/bundle_numeric_contract.json')['sha256'].items():
  actual=hashlib.sha256((ROOT/'inputs/baseline'/rel).read_bytes()).hexdigest()
  assert actual==expected
  archive_checks.append({'path':rel,'sha256':actual,'unchanged':True})
 r={'all_commands_passed':True,'explicit_result_assertions_passed':True,'runs':runs,'current_view':v,'full_csv_json_byte_checks':byte_checks,'archive_checks_after_replay':archive_checks,'scope_scan_included':not a.skip_new_scope_scan,'visual_regeneration_included':False,'large_archives_required':False,'source_package_modified':False}
 (out/'REPRODUCTION_SUMMARY.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
