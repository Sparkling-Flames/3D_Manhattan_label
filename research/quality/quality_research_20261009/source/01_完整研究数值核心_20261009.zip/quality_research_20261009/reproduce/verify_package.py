#!/usr/bin/env python3
"""Verify core files and any installed optional atlas images, without changing files."""
import argparse,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path);a=p.parse_args()
 m=json.loads((ROOT/'MANIFEST_SHA256.json').read_text());atlas=json.loads((ROOT/'ATLAS_MANIFEST_SHA256.json').read_text());failed=[];optional_present=0
 for r in m['files']:
  f=ROOT/r['path']
  if not f.is_file() or f.stat().st_size!=r['bytes'] or sha(f)!=r['sha256']:failed.append(r['path'])
 for r in atlas['files']:
  f=ROOT/r['path']
  if f.exists():
   optional_present+=1
   if not f.is_file() or f.stat().st_size!=r['bytes'] or sha(f)!=r['sha256']:failed.append(r['path'])
 allowed={x['path'] for x in m['files']}|{x['path'] for x in atlas['files']}|{'MANIFEST_SHA256.json','MANIFEST_SHA256.txt'}
 extra=[str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in allowed and '__pycache__' not in p.parts]
 r={'core_files_checked':len(m['files']),'optional_atlas_files_present':optional_present,'optional_atlas_files_total':len(atlas['files']),'failed':failed,'unexpected_files':extra,'passed':not failed and not extra,'large_archives_required':False}
 if a.out:a.out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['passed'] else 1
if __name__=='__main__':sys.exit(main())
