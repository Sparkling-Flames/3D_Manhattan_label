import json,math
from pathlib import Path
import matplotlib.pyplot as plt
import render_scope_evidence as V
R=V.ROOT
CHOICES={
'pRbA3pwrgk9-02':['R00186','R00352','R02061'],
'q9vSo1VnCiC-29':['R02324','R02305','R01485'],
'uNb9QFRL6hY-67':['R02930','R02210','R03194','R02929'],
'UwV83HsGsw3-09':['R01271','R00400','R01411'],
'rPc6DW4iMge-06':['R01798','R02468','R01518','R02094'],
'zsNo4HB9uLZ-13':['R01170','R00894','R02475','R00909'],
'e9zR4mvMWw7-17':['R00626','R02128','R01013'],
'B6ByNegPMKs-11':['R00036','R01017','R01736'],
'uNb9QFRL6hY-54':['R00145','R01642','R01895'],
}
CAP={
'pRbA3pwrgk9-02':('玻璃小隔间与整浴室的范围差','6/6围合小隔间；用户已认可R00186。低分不能单独表示隔间画得极差。'),
'q9vSo1VnCiC-29':('梳妆前室与接缝相邻房间的范围差','5/5围合前室；GT翼部向全景接缝延伸。样本仅5人，GT仍是当前参考。'),
'uNb9QFRL6hY-67':('多数选择淋浴小隔间，少数选择更大范围','9/15清洗后独立工人只画小隔间；下排保留大范围对照，避免整图一概免责。'),
'UwV83HsGsw3-09':('小范围、遮挡与镜面：保留当前修订GT','多人选小区；当前GT更全且包含不可见区域。镜面/遮挡语义不可由此卡裁决。'),
'rPc6DW4iMge-06':('玻璃内外范围差，也存在自身畸变','上两排未进玻璃内；第三排覆盖GT；末排自身畸变，不能仅凭范围差称良好。'),
'zsNo4HB9uLZ-13':('3/4人围合卧室主区，小样本支持','前三排主矩形较一致；末排尝试侧翼但边界斜变。只有4名独立工人。'),
'e9zR4mvMWw7-17':('共同不画内翼，不等于每个人主区都好','保留两份相对较好主区与R01013偏差对照；不将所有低分都归因于范围。'),
'B6ByNegPMKs-11':('反例：同一走廊的深度/高度差','规整线框仍可能同空间点位偏差；未见清楚替代侧翼范围，勿机械判GT多标。'),
'uNb9QFRL6hY-54':('主区与入口短廊的范围差','6名manual均未延伸GT入口短廊；另4份semi不并入独立共识。')}
MAN=[]
for code,ids in CHOICES.items():
 im=V.G[code];g=next(x for x in im['groundtruths'] if x['id']==im['defaultReferenceId']);p=V.photo(code);aa=[next(a for a in im['annotations'] if a['id']==x) for x in ids]
 n=len(aa);fig=plt.figure(figsize=(18,3.6*n+1.35),facecolor='white');gs=fig.add_gridspec(n,3,width_ratios=[2.5,1,1.2],left=.025,right=.97,bottom=.04,top=.89,wspace=.14,hspace=.38)
 fig.text(.025,.98,f'{code}  |  {CAP[code][0]}',fontsize=17,weight='bold',va='top')
 fig.text(.025,.946,CAP[code][1],fontsize=11,va='top')
 fig.text(.025,.918,f'橙虚线：固定GT {g["id"]} ({g["version"]})；青实线：标注。全部使用冻结原坐标，无独立缩放/对齐。',fontsize=10,va='top')
 for j,a in enumerate(aa):
  ax=fig.add_subplot(gs[j,0]);V.draw_photo(ax,p,[(g,V.E.ORANGE,'--'),(a,V.COL,'-')]);ax.set_title(V.annotation_title(a),fontsize=12)
  lim=V.E.bounds([a,g]);V.E.draw_bev(fig.add_subplot(gs[j,1]),a,g,lim);V.E.draw_3d(fig.add_subplot(gs[j,2],projection='3d'),a,g,lim)
 fig.text(.025,.014,'条件3D采用真实轴比例；h为共同相机到地板的归一单位，非实测米。Q为相对固定GT的冻结研究分；规整≠人工真值。',fontsize=10)
 out=R/'evidence'/f'{code}_core_3d.jpg';fig.savefig(out,dpi=170,pil_kwargs={'quality':94});plt.close(fig)
 MAN.append({'image_code':code,'record_ids':ids,'fixed_GT':g['id'],'path':'evidence/'+out.name,'caption':CAP[code]});print(code,flush=True)
json.dump(MAN,open(R/'core_evidence_index.json','w'),ensure_ascii=False,indent=2)
