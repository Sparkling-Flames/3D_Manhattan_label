#!/usr/bin/env python3
"""Exact frozen-coordinate visual evidence. Never modifies geometry or scoring."""
import json,math,sys,zipfile,hashlib,importlib.util,os
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
ROOT=Path(os.environ['QUALITY_VISUAL_OUT']).resolve()
(ROOT/'evidence').mkdir(parents=True,exist_ok=True)
(ROOT/'review_sheets').mkdir(parents=True,exist_ok=True)
PHOTOS=Path(os.environ['QUALITY_PHOTOS']).resolve()
SRC=Path(os.environ['QUALITY_BUNDLE']).resolve()
spec=importlib.util.spec_from_file_location('evidence',SRC/'render_evidence.py'); E=importlib.util.module_from_spec(spec);spec.loader.exec_module(E)
from matplotlib import font_manager
fonts=[f.fname for f in font_manager.fontManager.ttflist if any(n in f.name for n in ['Noto Sans CJK','Source Han Sans','Microsoft YaHei','SimHei'])]
font=os.environ.get('QUALITY_CJK_FONT') or (fonts[0] if fonts else None)
if not font:raise RuntimeError('Install Noto Sans CJK or pass --font FONT_FILE through the visual wrapper.')
font_manager.fontManager.addfont(font)
plt.rcParams['font.family']=['Noto Sans CJK JP','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
G={i['code']:i for i in json.load(open(SRC/'prepared/frozen_expanded_geometry.json'))['images']}
S=pd.read_csv(SRC/'results_fixed/all_records_scores.csv').set_index('record_id')
COL=E.CYAN

def photo(code):
 p=PHOTOS/G[code]['imageInternalPath']
 if not p.is_file():raise FileNotFoundError('Case photo missing: '+str(p))
 return p

def format_q(rid):
 v=S.loc[rid,'quality_score'];return f'{v:.2f}' if pd.notna(v) else 'NA'

def draw_photo(ax,p,records):
 with Image.open(p) as im:ax.imshow(im,extent=(0,1024,512,0))
 for r,c,ls in records:
  for seg in E.projected_paths(r):ax.plot(seg[:,0],seg[:,1],c=c,ls=ls,lw=1.3)
 ax.set(xlim=(0,1024),ylim=(512,0));ax.axis('off')

def annotation_title(a):
 sr=a['source_record'];q=format_q(a['id']);return f"{a['id']} / {sr['worker']} / {sr['condition']}  Q={q}"

def render(code):
 im=G[code];p=photo(code)
 if not p:return
 g=next(g for g in im['groundtruths'] if g['id']==im['defaultReferenceId']);aa=im['annotations']
 # Inspect every retained or historically excluded record; decision population is later flagged separately.
 for start in ([] if os.environ.get("SKIP_SHEETS") else range(0,len(aa),4)):
  group=aa[start:start+4];fig=plt.figure(figsize=(18,3.35*len(group)+.65));gs=fig.add_gridspec(len(group),3,width_ratios=[2.5,1,1],left=.02,right=.98,bottom=.025,top=.90,wspace=.13,hspace=.34)
  fig.suptitle(f'{code}  原坐标全体审查 {start+1}–{start+len(group)}/{len(aa)} | 橙虚线=固定GT {g["id"]}；青实线=标注',fontsize=14)
  for j,a in enumerate(group):
   ax=fig.add_subplot(gs[j,0]);draw_photo(ax,p,[(g,E.ORANGE,'--'),(a,COL,'-')]);ax.set_title(annotation_title(a),fontsize=11)
   lim=E.bounds([a,g]);E.draw_bev(fig.add_subplot(gs[j,1]),a,g,lim)
   E.draw_3d(fig.add_subplot(gs[j,2],projection='3d'),a,g,lim)
  fig.savefig(ROOT/'review_sheets'/f'{code}_all_{start//4+1:02d}.jpg',dpi=130,pil_kwargs={'quality':90});plt.close(fig)
 # Concise picture and same-scale all-person footprint panel.
 nrows=math.ceil(len(aa)/6);fig=plt.figure(figsize=(18,5+2.6*nrows));gs=fig.add_gridspec(2+nrows,6,height_ratios=[2.4,2.4]+[2.6]*nrows,left=.03,right=.97,bottom=.04,top=.87,hspace=.5,wspace=.3)
 ax=fig.add_subplot(gs[0:2,0:4]);draw_photo(ax,p,[(g,E.ORANGE,'--')]);ax.set_title('原全景＋当前固定GT（橙虚线）',fontsize=13)
 ax=fig.add_subplot(gs[0:2,4:6]); lim=E.bounds([g]+[a for a in aa if E.finite_ring(a,'bottom3d') is not None]);E.draw_bev(ax,aa[0],g,lim);ax.clear()
 for a in aa:
  q=E.finite_ring(a,'bottom3d')
  if q is not None:q=E.close(q[:,[0,2]]);ax.plot(q[:,0],q[:,1],c=COL,alpha=.35,lw=.8)
 q=E.close(np.array(g['bottom3d'])[:,[0,2]]);ax.plot(q[:,0],q[:,1],c=E.ORANGE,ls='--',lw=2);ax.set_aspect('equal');ax.set_title('全体底面：未经对齐/缩放',fontsize=13);ax.grid(alpha=.2)
 for j,a in enumerate(aa):
  ax=fig.add_subplot(gs[2+j//6,j%6]);E.draw_bev(ax,a,g,lim);ax.set_title(annotation_title(a).replace(' / ','\n',1),fontsize=8);ax.set_xlabel('');ax.set_ylabel('')
 fig.suptitle(f'{code}  |  {len(aa)}份源标注全部展示（不是清洗后支持人数）\n橙=固定GT {g["id"]} / {g["version"]}；青=各源标注；Q为冻结v1.1分数，h为共同相机高度单位',fontsize=15)
 fig.savefig(ROOT/'evidence'/f'{code}_overview.jpg',dpi=155,pil_kwargs={'quality':92});plt.close(fig)
 print('RENDERED',code,len(aa),flush=True)

if __name__=='__main__':
 for code in sys.argv[1:]:render(code)
