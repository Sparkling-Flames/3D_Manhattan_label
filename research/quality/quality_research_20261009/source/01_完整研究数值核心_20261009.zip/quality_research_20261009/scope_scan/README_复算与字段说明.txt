多人共同未覆盖GT范围的候选检索

入口
1. 先读 中文量化报告.txt。
2. 全259图表为 all_259_images_scope_scan.csv；全3152记录审计为 all_3152_records_scope_metrics.csv。
3. candidate_images_ranked.csv 与 candidate_records.csv 含检索候选、历史基线及反例对照；通过 candidate_base / candidate_relaxed、primary_manual_oos 等列确定实际使用人群，不能把全部行计入支持人数。
4. geometry_evidence/ 下为当前绑定GT、多人工人地面多边形、512×512掩模、几何图。图中橙色为当前GT；绿色只说明通过自身规整代理，不证明标注真实准确。
5. condition_stratified_all_images.csv 分列manual、oos、semi；allconditions_ 前缀保留三条件合并的不同工人统计；shape_dedup_ 前缀只是完全相同几何只保留一份的保守敏感性。

可复算命令
python scan_shared_gt_omissions.py --source-root /path/to/quality_v1_1_expanded_repro_20261009 --audit-root /path/to/point_and_gate_audit --out-dir /path/to/new_scope_scan
python summarize_scope_scan.py --scan-dir /path/to/new_scope_scan
python validate_scope_outputs.py --scan-dir /path/to/new_scope_scan --source-root /path/to/quality_v1_1_expanded_repro_20261009 --audit-root /path/to/point_and_gate_audit

依赖
Python 3、numpy、scipy、matplotlib。仅本地读输入，不联网、不训练模型、不调用旧primary gate、不改GT/原算法/分数。默认256×256扫描，512×512核验检索候选和指定对照。运行通常为一至两分钟，取决于CPU和字体缓存。
可选设置 XDG_CACHE_HOME 与 MPLCONFIGDIR 指向可写临时目录，避免matplotlib字体缓存告警。

成功判据
scan_summary.json 中 source_images_with_annotations=259、inventory_records=3152、current_view_records=2930、current_available_Q=2898。
主分析人口manual/oos不同工人合计2368个图-人工人单位；194图有至少3位。全条件合并2884个不同工人单位。不是259张图都足以验证“多人独立一致”。
严格/基准/宽松联合检索候选分别4/16/31张。阈值是探索性检索规则，不是评分算法或已验证分类标准。
脚本输出的分数Q逐字读取原已发布CSV；GT仅按每图当前绑定reference_id/reference_version读取。scan_summary.json保存原输入SHA256。

核心字段
GT_missing_area_h2_exact = GT面积 - 交集面积；annotation_outside_area_h2_exact = 标注面积 - 交集面积。
gt_missing_fraction_exact = 未覆盖GT面积 / GT面积。
annotation_outside_fraction_exact = GT外标注面积 / 标注自身面积。此分母不是GT面积，不能与旧extension列混用。
exact 指冻结多边形计算输出，相对于网格近似而言；面积为相机地高归一化h²，并非平方米或实测真值。
shared_missing_ge2of3_gt_fraction_grid = 至少2/3当前组不同工人未覆盖的GT网格面积 / GT网格总面积。
all_missing_gt_fraction_grid = 当前组所有人都未覆盖的GT网格面积 / GT网格总面积。
pairwise_missing_jaccard_median_grid = 所有工人两两GT遗漏集合的交并比中位数，不是标注多边形IoU，不是均值。
shared_largest_component_fraction = 上述至少2/3共同遗漏掩模中，最大8连通分量占该掩模的比例。
shared_max_180deg_sector_fraction = 以相机原点分8个方位扇区，连续4扇区最多容纳的共同遗漏比例；不是标注任务真值。
shared_azimuth_circular_resultant = 共同遗漏格点方位角单位向量的平均合向量长度，0分散、1集中。
regular_base = source自身二维/三维有效且D≤5°、flat≤3°、自身高度相对RMS≤8%。不含Q、IoU、H*。
Hstar_reference_relative 单列对GT的参考高度接近程度，不是自身内部高度一致性。
scope_regular_base = regular_base且个人GT遗漏≥15%、GT外占自身≤15%；相应k/N报告仅描述这个代理同时成立。
median_Q = 当前组所有可评不同工人原Q中位数；scope_regular_base_median_Q只对上述同时支持者计算。
geometry_constructible = 原引擎对标注自身2D/3D均判有效；analysis_eligible_pre_dedup另需当前清洗通过、来源独立性未阻断及Q可用。
primary_manual_oos = 使用现行清洗视图、来源独立性标记和图-工人去重后，manual或oos条件的一次投票。semi从主支持人数分开，但未删除，全部在条件分层及allconditions_统计中。
source_geometry_sha256相同不等于重复导入，也不证明抄袭或无效；只在shape_dedup_敏感性中合并一次，正式记录与分数未删改。
scale_to_gt_area_iou_diagnostic 是绕相机等比缩放标注使面积等于GT后的网格IoU；translate_centroid_iou_diagnostic只平移到GT面积质心。二者均为排查全局缩放/位移混淆的描述性试验，不产生修订GT或替代Q。
geometric_retrieval_index = 至少2/3共同遗漏面积比例 × 两两遗漏Jaccard中位数 × (1-标注GT外比例中位数) × 基准规整人数比例。少于3人设0；仅为人工核验优先顺序，不评价标注质量。候选是否入选另由明确条件决定，且没有用Q参与该排序。

范围与限制
未证明不同工人的统计独立性；来源标记只排除已知借点/待定等问题。同工人跨条件不重复投票；完全相同几何另作敏感性。条件名称不构成随机盲测证据。
原算法认可几何可构造、自身规整、参考高度接近是三个不同命题；均不能替代图像核验。真实非正交OOS可能合理但D较高，因此保留全量与宽松对照，不旧gate一刀切删除。
高一致性也可能是同一深度误差、共同省略细节或相同初始化。多人都选小范围不说明GT错误。原GT仍是当前评分参考，规整性仍扣总分。
未采用缩放/平移诊断修改Q；未重训模型；未把探索性候选当GT真相裁决。最后案例归类应结合独立视觉核验和原任务范围说明。
