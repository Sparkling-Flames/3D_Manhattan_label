#!/usr/bin/env python3
"""Read-only scope-candidate retrieval; does not alter GT, scoring or published Q.
Requires Python 3, numpy, scipy, matplotlib. Run --help for portable source paths.
"""
import argparse, csv, json, math, hashlib, collections
from pathlib import Path
import numpy as np
from matplotlib.path import Path as MplPath
from scipy import ndimage

PROFILES={
 'strict':{'D':3.,'flat':1.5,'internal_h':.04,'missing':.20,'outside':.10,'shared':.15,'agreement':.55},
 'base':{'D':5.,'flat':3.,'internal_h':.08,'missing':.15,'outside':.15,'shared':.10,'agreement':.40},
 'relaxed':{'D':10.,'flat':4.,'internal_h':.12,'missing':.10,'outside':.20,'shared':.075,'agreement':.30},
}
BASELINE=['e9zR4mvMWw7-17','pRbA3pwrgk9-02']
CONTROLS=['yqstnuAEVhm-01','yqstnuAEVhm-32','yqstnuAEVhm-34','uNb9QFRL6hY-60','uNb9QFRL6hY-81','wc2JMjhGNzB-14','e9zR4mvMWw7-09','2t7WUuJeko7-07','7y3sRwLe3Va-17','B6ByNegPMKs-40']

def jsonclean(v):
 if isinstance(v,dict):return {k:jsonclean(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [jsonclean(x) for x in v]
 if isinstance(v,(float,np.floating)):return float(v) if np.isfinite(v) else None
 if isinstance(v,np.integer):return int(v)
 if isinstance(v,np.bool_):return bool(v)
 return v

def readcsv(p):
 with open(p,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def writecsv(p,rows):
 rows=list(rows)
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with open(p,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
  for r in rows:
   w.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(list,dict)) else v for k,v in r.items()})
def num(r,k):
 try:
  v=float(r.get(k,''));return v if math.isfinite(v) else np.nan
 except (ValueError,TypeError):return np.nan
def med(x):
 x=[v for v in x if np.isfinite(v)];return float(np.median(x)) if x else np.nan
def frac(x):return sum(x)/len(x) if x else np.nan
def coords(a):return np.asarray(a['bottom3d'],dtype=float)[:,[0,2]]
def area(p):return abs(float(np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1]))/2)
def centroid(p):
 q=np.roll(p,-1,axis=0);cross=p[:,0]*q[:,1]-q[:,0]*p[:,1];a=cross.sum()
 return ((p+q)*cross[:,None]).sum(axis=0)/(3*a) if abs(a)>1e-12 else p.mean(axis=0)
def scope_regular(r,profile):
 p=PROFILES[profile]
 return r['regular_'+profile] and r['gt_missing_fraction_exact']>=p['missing'] and r['annotation_outside_fraction_exact']<=p['outside']

def regular(r,profile):
 p=PROFILES[profile]
 return r['geometry_constructible'] and r['D_deg']<=p['D'] and r['flat_deg']<=p['flat'] and r['internal_height_relative_rms']<=p['internal_h']
def raster_info(gp,n):
 lo=gp.min(axis=0);hi=gp.max(axis=0);step=(hi-lo)/n
 xx=lo[0]+(np.arange(n)+.5)*step[0];zz=lo[1]+(np.arange(n)+.5)*step[1]
 X,Z=np.meshgrid(xx,zz);pts=np.stack([X.ravel(),Z.ravel()],axis=1)
 gt=MplPath(np.vstack([gp,gp[0]])).contains_points(pts,radius=0).reshape(n,n)
 return pts,gt,lo,hi,step

def group_stats(recs,gp,n=256,diagnostics=False,retain=False):
 if not recs:return {'n_workers':0},None
 pts,gt,lo,hi,step=raster_info(gp,n);inside_pts=pts[gt.ravel()];gcount=len(inside_pts);ga=area(gp);gc=centroid(gp)
 covers=np.array([MplPath(np.vstack([r['_poly'],r['_poly'][0]])).contains_points(inside_pts) for r in recs],dtype=bool)
 missing=~covers; nworkers=len(recs);vote=missing.mean(axis=0);common=vote>=2/3-1e-12;allmiss=vote>=1-1e-12
 pair=[]; goodpair=[]
 for i in range(nworkers):
  for j in range(i):
   den=np.count_nonzero(missing[i]|missing[j]);v=np.count_nonzero(missing[i]&missing[j])/den if den else 0.;pair.append(v)
   if recs[i]['regular_base'] and recs[j]['regular_base']:goodpair.append(v)
 grid=np.zeros(gt.shape,dtype=bool);grid[gt]=common; labels,nc=ndimage.label(grid,structure=np.ones((3,3)))
 component_counts=np.bincount(labels.ravel())[1:];largest=int(max(component_counts,default=0));cmn=int(common.sum())
 cmpts=inside_pts[common]
 if cmn:
  angles=np.arctan2(cmpts[:,1],cmpts[:,0]);sector=np.floor((angles+np.pi)/(2*np.pi)*8).astype(int).clip(0,7);sc=np.bincount(sector,minlength=8)
  maxhalf=max(sum(sc[(j+np.arange(4))%8]) for j in range(8))/cmn
  az_conc=abs(np.exp(1j*angles).mean());cc=cmpts.mean(axis=0)
 else:sc=np.zeros(8);maxhalf=az_conc=np.nan;cc=np.array([np.nan,np.nan])
 regular_rows=[r for r in recs if r['regular_base']]
 goodshared=float(np.mean(missing[[r['regular_base'] for r in recs]].mean(axis=0)>=2/3-1e-12)) if regular_rows else np.nan
 stats={
 'n_workers':nworkers,'n_manual':sum(r['condition']=='manual' for r in recs),'n_oos':sum(r['condition']=='oos' for r in recs),'n_semi':sum(r['condition']=='semi' for r in recs),
 'median_Q':med([r['Q'] for r in recs]),'q_lt50_n':sum(r['Q']<50 for r in recs),'q_lt50_fraction':frac([r['Q']<50 for r in recs]),'q_lt60_fraction':frac([r['Q']<60 for r in recs]),'q_lt40_fraction':frac([r['Q']<40 for r in recs]),
 'median_iou':med([r['IoU'] for r in recs]),'median_gt_missing_fraction':med([r['gt_missing_fraction_exact'] for r in recs]),'median_annotation_outside_fraction':med([r['annotation_outside_fraction_exact'] for r in recs]),
 'median_annotation_area_over_gt':med([r['annotation_area_over_gt'] for r in recs]),'median_D_deg':med([r['D_deg'] for r in recs]),'median_flat_deg':med([r['flat_deg'] for r in recs]),'median_internal_height_relative_rms':med([r['internal_height_relative_rms'] for r in recs]),
 'median_Hstar_reference_relative':med([r['Hstar_reference_relative'] for r in recs]),'reference_height_Hstar_le_0_1_n':sum(r['Hstar_reference_relative']<=.1 for r in recs),
 'regular_strict_n':sum(r['regular_strict'] for r in recs),'regular_base_n':len(regular_rows),'regular_relaxed_n':sum(r['regular_relaxed'] for r in recs),
 'shared_missing_ge2of3_gt_fraction_grid':cmn/gcount,'all_missing_gt_fraction_grid':allmiss.sum()/gcount,'any_missing_gt_fraction_grid':float(missing.any(axis=0).mean()),
 'group_mean_gt_coverage_grid':float(covers.mean()),'shared_missing_ge2of3_area_h2_grid':cmn*float(np.prod(step)),
 'pairwise_missing_jaccard_median_grid':med(pair),'regular_pairwise_missing_jaccard_median_grid':med(goodpair),'regular_shared_missing_gt_fraction_grid':goodshared,
 'shared_largest_component_fraction':largest/cmn if cmn else 0.,'shared_components_n':nc,'shared_max_180deg_sector_fraction':maxhalf,'shared_azimuth_circular_resultant':az_conc,
 'shared_centroid_x_h':cc[0],'shared_centroid_z_h':cc[1],'shared_missing_eight_sector_counts':sc.tolist(),'grid_nx':n,'grid_nz':n,'grid_gt_cell_count':gcount,'gt_grid_area_relative_error':gcount*np.prod(step)/ga-1,
 'record_ids':[r['record_id'] for r in recs],'worker_ids':[r['worker'] for r in recs],
 'regular_base_record_ids':[r['record_id'] for r in regular_rows],
 'scope_regular_base_n':sum(scope_regular(r,'base') for r in recs),
 'scope_regular_base_record_ids':[r['record_id'] for r in recs if scope_regular(r,'base')],
 'scope_regular_base_median_Q':med([r['Q'] for r in recs if scope_regular(r,'base')]),
 'scope_regular_base_lowQ_lt50_n':sum(scope_regular(r,'base') and r['Q']<50 for r in recs),
 'scope_regular_base_lowQ_lt60_n':sum(scope_regular(r,'base') and r['Q']<60 for r in recs),
 }
 if diagnostics:
  for r,cv in zip(recs,covers):
   ap=r['_poly'];aa=r['annotation_area_h2'];inter=float(cv.sum()*np.prod(step));ri=inter/(ga+aa-inter)
   scaled=ap*math.sqrt(ga/aa);translated=ap+(gc-centroid(ap))
   def diag_iou(pp,newarea):
    ii=float(MplPath(np.vstack([pp,pp[0]])).contains_points(inside_pts).sum()*np.prod(step));return ii/(ga+newarea-ii)
   si=diag_iou(scaled,ga);ti=diag_iou(translated,aa)
   r['diagnostics_grid_resolution']=n;r['grid_original_iou']=ri;r['grid_iou_error_vs_exact']=ri-r['IoU'];r['scale_to_gt_area_iou_diagnostic']=si;r['scale_iou_gain_diagnostic']=si-ri;r['translate_centroid_iou_diagnostic']=ti;r['translate_iou_gain_diagnostic']=ti-ri
  stats['median_scale_iou_gain_diagnostic']=med([r['scale_iou_gain_diagnostic'] for r in recs]);stats['median_translate_iou_gain_diagnostic']=med([r['translate_iou_gain_diagnostic'] for r in recs]);stats['max_abs_grid_iou_error']=max(abs(r['grid_iou_error_vs_exact']) for r in recs)
 if diagnostics:
  for r,miss in zip(recs,missing):
   r['primary_shared_omission_fraction_of_own_omission_grid']=np.count_nonzero(miss&common)/max(1,np.count_nonzero(miss))
 extras={'gt_mask':gt,'missing_vote_grid':np.where(gt,0.,np.nan),'lo':lo,'hi':hi,'step':step,'common_grid':grid,'inside_points':inside_pts,'missing':missing,'gt_polygon':gp}
 extras['missing_vote_grid'][gt]=vote
 return stats,extras if retain else None

def qualifies(s,profile,need_regular=True,lowq=True):
 p=PROFILES[profile]
 return bool(s.get('n_workers',0)>=3 and s.get('median_gt_missing_fraction',0)>=p['missing'] and s.get('median_annotation_outside_fraction',1)<=p['outside'] and s.get('shared_missing_ge2of3_gt_fraction_grid',0)>=p['shared'] and s.get('pairwise_missing_jaccard_median_grid',0)>=p['agreement'] and (not need_regular or s.get('regular_'+profile+'_n',0)>=3) and (not lowq or s.get('q_lt50_fraction',0)>=.5))

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--audit-root',type=Path,required=True);parser.add_argument('--out-dir',type=Path,required=True);parser.add_argument('--grid',type=int,default=256);parser.add_argument('--verify-grid',type=int,default=512);args=parser.parse_args()
 src=args.source_root;out=args.out_dir;out.mkdir(parents=True,exist_ok=True);(out/'geometry_evidence').mkdir(exist_ok=True)
 data=json.load(open(src/'prepared/frozen_expanded_geometry.json')); score={r['record_id']:r for r in readcsv(src/'results_fixed/all_records_scores.csv')}; audits={r['record_id']:r for r in readcsv(args.audit_root/'all_3152_point_gate_audit.csv')};current={r['record_id'] for r in readcsv(args.audit_root/'current_cleaning_plus_today_hold_view.csv')};overlay={r['record_id']:r for r in readcsv(args.audit_root/'current_decision_overlay_all3152.csv')}
 allrecords=[];imagerows=[];groups={};im_by_code={};conditionrows=[]
 for im in data['images']:
  if not im['annotations']:continue
  code=im['code'];im_by_code[code]=im;recs=[];refs={(g['id'],g['version']):g for g in im['groundtruths']}
  for a in im['annotations']:
   rid=a['id'];s=score[rid];au=audits[rid];source=a['source_record'];ga=num(s,'reference_area_h2');aa=num(s,'area_h2');ia=num(s,'intersection_area_h2');valid=s['annotation_valid_3d']=='True' and s['annotation_valid_2d']=='True'
   r={'record_id':rid,'image_code':code,'worker':au['worker'],'condition':au['condition'],'canonical_object_id':au['canonical_object_id'],'current_view_pass':rid in current,'independence_source_eligible':au['independent_vote_eligible']=='True','independence_source_reasons':au['independent_vote_reasons'],'today_hold':overlay[rid]['today_user_hold_wc2_14']=='True','old_cleaning_disposition':au['cleaning_disposition'],'source_score_status':s['score_status'],'geometry_constructible':valid,'reference_id':s['reference_id'],'reference_version':s['reference_version'],'Q':num(s,'quality_score'),'IoU':num(s,'iou'),'annotation_area_h2':aa,'GT_area_h2':ga,'intersection_area_h2':ia,'GT_missing_area_h2_exact':max(0.,ga-ia) if np.isfinite(ga+ia) else np.nan,'annotation_outside_area_h2_exact':max(0.,aa-ia) if np.isfinite(aa+ia) else np.nan,'gt_missing_fraction_exact':max(0.,1-ia/ga) if ga>0 else np.nan,'annotation_outside_fraction_exact':max(0.,1-ia/aa) if aa>0 else np.nan,'annotation_area_over_gt':aa/ga if ga>0 else np.nan,'D_deg':num(s,'dir'),'flat_deg':num(s,'flat'),'internal_height_relative_rms':num(s,'height_internal_relative_rms'),'Hstar_reference_relative':num(s,'Hstar'),'Hmean_reference_relative':num(s,'Hmean'),'Hlocal_reference_relative':num(s,'Hlocal'),'intrinsic_factor':num(s,'intrinsic_factor'),'reference_factor':num(s,'reference_factor'),'boundary_factor':num(s,'boundary_factor'),'S_top_deg':num(s,'S_top_deg'),'S_bottom_deg':num(s,'S_bottom_deg'),'boundary_rms_deg':num(s,'boundary_rms_deg'),'scene_oos_status':s['scene_oos_status'],'target_applicability':s['target_applicability'],'source_warning_codes':s['annotation_warning_codes'],'source_geometry_sha256':s['annotation_geometry_sha256'],'scope_evidence_flag':s['scope_evidence_flag'],'source_path':au['source_path'],'_poly':coords(a) if valid else None,'_annotation':a,'_ref':refs[(a['referenceId'],a['referenceVersion'])]}
   for pf in PROFILES:r['regular_'+pf]=regular(r,pf)
   for pf in PROFILES:r['scope_regular_'+pf]=scope_regular(r,pf)
   r['analysis_eligible_pre_dedup']=bool(r['current_view_pass'] and r['independence_source_eligible'] and valid and s['score_status']=='available')
   r['selected_unique_worker']=False;r['primary_manual_oos']=False;r['dedup_reason']='not_eligible' if not r['analysis_eligible_pre_dedup'] else ''
   recs.append(r);allrecords.append(r)
  # Deterministic per-worker representative uses condition priority then record id, never Q.
  eligible=sorted((r for r in recs if r['analysis_eligible_pre_dedup']),key=lambda r:({'manual':0,'oos':1,'semi':2}.get(r['condition'],3),r['record_id']))
  chosen=[];workers=set();seen_geometry={}
  for r in eligible:
   if r['worker'] in workers:r['dedup_reason']='same_worker_other_condition';continue
   workers.add(r['worker']);r['selected_unique_worker']=True;r['dedup_reason']='selected';chosen.append(r)
   seen_geometry.setdefault(r['source_geometry_sha256'],[]).append(r['worker'])
  primary=[r for r in chosen if r['condition'] in ('manual','oos')]
  for r in primary:r['primary_manual_oos']=True
  refkeys={(r['reference_id'],r['reference_version']) for r in chosen}
  if len(refkeys)>1:raise RuntimeError('Multiple bound reference versions within image '+code)
  defaultref=refs[(im['defaultReferenceId'],im['defaultReferenceVersion'])];gp=coords(defaultref)
  base,extra=group_stats(primary,gp,args.grid,diagnostics=True)
  allstat,_=group_stats(chosen,gp,args.grid)
  unique_primary=[]; shape_groups=collections.defaultdict(list)
  for r in primary:shape_groups[r['source_geometry_sha256']].append(r)
  for sha,rr in shape_groups.items():unique_primary.append(sorted(rr,key=lambda r:r['record_id'])[0])
  shape_stat,_=group_stats(unique_primary,gp,args.grid)
  row={'image_code':code,'image_id':im['imageId'],'reference_id':im['defaultReferenceId'],'reference_version':im['defaultReferenceVersion'],'source_oos_status':im['source_scene'].get('oos_status'),'target_applicability':im['targetApplicability'],'inventory_records_n':len(recs),'inventory_workers_n':len(set(r['worker'] for r in recs)),'current_view_records_n':sum(r['current_view_pass'] for r in recs),'current_available_Q_n':sum(r['current_view_pass'] and r['source_score_status']=='available' for r in recs),'current_available_geometry_independence_n':len(eligible),'dedup_selected_workers_n':len(chosen),'source_nonindependent_excluded_n':sum(r['current_view_pass'] and not r['independence_source_eligible'] for r in recs),'same_worker_dedup_removed_n':len(eligible)-len(chosen),'identical_geometry_crossworker_groups':[v for v in seen_geometry.values() if len(v)>1],'GT_pair_count':len(gp),'image_internal_path':im['imageInternalPath'],**base}
  row.update({'allconditions_'+k:v for k,v in allstat.items()})
  row.update({'shape_dedup_'+k:v for k,v in shape_stat.items()})
  row['primary_distinct_geometry_n']=len(unique_primary)
  row['primary_identical_geometry_groups']=[[{'record_id':r['record_id'],'worker':r['worker'],'condition':r['condition']} for r in rr] for rr in shape_groups.values() if len(rr)>1]
  row['widespread_Q_lt50_ge2of3']=base.get('q_lt50_fraction',0)>=2/3
  for pf in PROFILES:
   row['scope_only_'+pf]=qualifies(base,pf,need_regular=False,lowq=False)
   row['regular_scope_'+pf]=qualifies(base,pf,need_regular=True,lowq=False)
   row['candidate_'+pf]=qualifies(base,pf)
   row['shape_dedup_candidate_'+pf]=qualifies(shape_stat,pf)
   row['allconditions_candidate_'+pf]=qualifies(allstat,pf)
  row['geometric_retrieval_index']=float(base.get('shared_missing_ge2of3_gt_fraction_grid',0)*base.get('pairwise_missing_jaccard_median_grid',0)*(1-base.get('median_annotation_outside_fraction',1))*base.get('regular_base_n',0)/max(1,len(primary))) if primary else 0.
  if not np.isfinite(row['geometric_retrieval_index']) or len(primary)<3:row['geometric_retrieval_index']=0.
  row['retrieval_status']='no_three_primary_workers' if len(primary)<3 else 'base_candidate' if row['candidate_base'] else 'relaxed_candidate' if row['candidate_relaxed'] else 'scope_with_mixed_quality_or_Q' if row['scope_only_base'] else 'not_scope_candidate'
  imagerows.append(row);groups[code]=(primary,chosen,gp,recs)
  for cond in ['manual','oos','semi']:
   rr=[r for r in chosen if r['condition']==cond]
   cs,_=group_stats(rr,gp,args.grid);conditionrows.append({'image_code':code,'condition':cond,**cs,**{'candidate_'+pf:qualifies(cs,pf) for pf in PROFILES}})
  print(code,len(primary),row['retrieval_status'],round(row['geometric_retrieval_index'],4),flush=True)
 # Rank all available rows by geometric index; low Q is reported afterward and not in the index.
 imagerows.sort(key=lambda r:(-r['geometric_retrieval_index'],r['image_code']))
 for rank,r in enumerate(imagerows,1):r['geometric_rank_all']=rank
 selected=[r['image_code'] for r in imagerows if r['candidate_relaxed'] or r['candidate_base'] or r['candidate_strict']]
 supplemental=[r['image_code'] for r in imagerows if r['allconditions_candidate_base'] and not r['candidate_base']]
 evidence=list(dict.fromkeys(selected+supplemental+BASELINE+CONTROLS))
 verif=[];evidence_index=[]
 for code in evidence:
  if code not in groups:continue
  primary,chosen,gp,recs=groups[code];ir=next(r for r in imagerows if r['image_code']==code)
  if not primary:continue
  high,ex=group_stats(primary,gp,args.verify_grid,diagnostics=True,retain=True)
  vr={'image_code':code,'base_grid':args.grid,'verify_grid':args.verify_grid}
  for k in ['shared_missing_ge2of3_gt_fraction_grid','all_missing_gt_fraction_grid','pairwise_missing_jaccard_median_grid','shared_largest_component_fraction','gt_grid_area_relative_error']:
   vr[k+'_base']=ir.get(k);vr[k+'_verify']=high.get(k);vr[k+'_abs_difference']=abs(ir.get(k,np.nan)-high.get(k,np.nan))
  vr['max_abs_grid_iou_error_verify']=high.get('max_abs_grid_iou_error');verif.append(vr)
  np.savez_compressed(out/'geometry_evidence'/f'{code}_grid{args.verify_grid}.npz',gt_mask=ex['gt_mask'],missing_vote=ex['missing_vote_grid'],common_missing=ex['common_grid'],lo=ex['lo'],hi=ex['hi'],gt_polygon=gp)
  ej={'image_code':code,'reference_id':ir['reference_id'],'reference_version':ir['reference_version'],'GT_floor_polygon_xz_h':gp.tolist(),'grid':args.verify_grid,'bounds_lo_xz':ex['lo'].tolist(),'bounds_hi_xz':ex['hi'].tolist(),'grid_cell_area_h2':float(np.prod(ex['step'])),'statistics':high,'records':[{k:v for k,v in r.items() if not k.startswith('_')}|{'floor_polygon_xz_h':r['_poly'].tolist()} for r in primary]}
  (out/'geometry_evidence'/f'{code}_geometry.json').write_text(json.dumps(jsonclean(ej),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
  render(code,primary,gp,ex,{**ir,**high},out/'geometry_evidence'/f'{code}_footprint.png')
  evidence_index.append({'image_code':code,'candidate_base':ir['candidate_base'],'candidate_relaxed':ir['candidate_relaxed'],'geometric_rank':ir['geometric_rank_all'],'reason':'candidate' if code in selected else 'baseline_or_control','geometry_json':f'geometry_evidence/{code}_geometry.json','footprint_png':f'geometry_evidence/{code}_footprint.png','grid_npz':f'geometry_evidence/{code}_grid{args.verify_grid}.npz','source_image_internal_path':ir['image_internal_path']})
 # Sensitivity: isolated nearby cutoffs with all other base values fixed.
 sensitivity=[]
 for ir in imagerows:
  for axis,vals in [('missing',[.10,.15,.20]),('outside',[.10,.15,.20]),('shared',[.075,.10,.15]),('agreement',[.30,.40,.55]),('good_geometry_profile',['strict','base','relaxed']),('lowQ_cutoff',[40,50,60])]:
   for val in vals:
    p=PROFILES['base'].copy()
    if axis in p:p[axis]=val
    gpname=val if axis=='good_geometry_profile' else 'base'; low=ir.get('q_lt'+str(val if axis=='lowQ_cutoff' else 50)+'_fraction',0)
    hit=bool(ir.get('n_workers',0)>=3 and ir.get('regular_'+gpname+'_n',0)>=3 and ir.get('median_gt_missing_fraction',0)>=p['missing'] and ir.get('median_annotation_outside_fraction',1)<=p['outside'] and ir.get('shared_missing_ge2of3_gt_fraction_grid',0)>=p['shared'] and ir.get('pairwise_missing_jaccard_median_grid',0)>=p['agreement'] and low>=.5)
    sensitivity.append({'image_code':ir['image_code'],'axis':axis,'value':val,'candidate':hit})
 (out/'primary_independent_worker_ids.json').write_text(json.dumps({code:[{k:r[k] for k in ['record_id','worker','condition']} for r in vv[0]] for code,vv in groups.items()},ensure_ascii=False,indent=2),encoding='utf-8')
 writecsv(out/'all_259_images_scope_scan.csv',imagerows);writecsv(out/'all_3152_records_scope_metrics.csv',({k:v for k,v in r.items() if not k.startswith('_')} for r in allrecords));writecsv(out/'candidate_records.csv',({k:v for k,v in r.items() if not k.startswith('_')} for r in allrecords if r['image_code'] in evidence));writecsv(out/'candidate_images_ranked.csv',(r for r in imagerows if r['image_code'] in evidence));writecsv(out/'condition_stratified_all_images.csv',conditionrows);writecsv(out/'threshold_sensitivity_all259.csv',sensitivity);writecsv(out/'grid_resolution_verification.csv',verif);writecsv(out/'geometry_evidence_index.csv',evidence_index)
 summary={'source_images_with_annotations':len(imagerows),'inventory_records':len(allrecords),'current_view_records':len(current),'current_available_Q':sum(r['current_view_pass'] and r['source_score_status']=='available' for r in allrecords),'primary_workers_total':sum(r['primary_manual_oos'] for r in allrecords),'primary_images_ge3_workers':sum(r.get('n_workers',0)>=3 for r in imagerows),'selected_candidate_count':len(selected),'allconditions_base_supplemental_images':supplemental,'total_dedup_selected_workers':sum(r['selected_unique_worker'] for r in allrecords),'primary_source_nonindependent_excluded':sum(r['current_view_pass'] and not r['independence_source_eligible'] for r in allrecords),'same_worker_dedup_removed_total':sum(r['dedup_reason']=='same_worker_other_condition' for r in allrecords),'candidate_counts':{p:sum(r['candidate_'+p] for r in imagerows) for p in PROFILES},'candidate_images':{p:[r['image_code'] for r in imagerows if r['candidate_'+p]] for p in PROFILES},'profiles':PROFILES,'raster_grid':args.grid,'verify_grid':args.verify_grid,'source_sha256':{str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [src/'prepared/frozen_expanded_geometry.json',src/'results_fixed/all_records_scores.csv']},'audited_view_sha256':hashlib.sha256((args.audit_root/'current_cleaning_plus_today_hold_view.csv').read_bytes()).hexdigest(),'read_only_scoring':True,'evidence_images':evidence}
 (out/'scan_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary,ensure_ascii=False,indent=2))

def render(code,recs,gp,ex,stats,path):
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axs=plt.subplots(1,2,figsize=(12,5.5),constrained_layout=True)
 for ax in axs:ax.set_aspect('equal');ax.set_xlabel('x / camera-floor height');ax.set_ylabel('z / camera-floor height');ax.grid(alpha=.2);ax.scatter([0],[0],c='black',marker='+',s=50,zorder=10)
 for r in recs:
  p=np.vstack([r['_poly'],r['_poly'][0]]);axs[0].plot(p[:,0],p[:,1],alpha=.6,lw=1.0,color='#168c72' if r['regular_base'] else '#967bb6')
 for ax in axs:
  g=np.vstack([gp,gp[0]]);ax.plot(g[:,0],g[:,1],color='#d65d0e',lw=2.8,label='Current bound GT')
 im=axs[1].imshow(ex['missing_vote_grid'],origin='lower',extent=[ex['lo'][0],ex['hi'][0],ex['lo'][1],ex['hi'][1]],vmin=0,vmax=1,cmap='YlOrRd',interpolation='nearest');fig.colorbar(im,ax=axs[1],label='Fraction of distinct workers missing GT cells')
 axs[0].set_title(f'{code}: N={len(recs)}; regular proxy={stats.get("regular_base_n",0)}\nGreen=regular proxy; purple=other valid geometry')
 axs[1].set_title(f'Q median={stats.get("median_Q",np.nan):.2f}; GT omitted by >=2/3={stats.get("shared_missing_ge2of3_gt_fraction_grid",np.nan):.1%}\nGrid evidence, not task-scope truth')
 fig.savefig(path,dpi=170);plt.close(fig)

if __name__=='__main__':main()
