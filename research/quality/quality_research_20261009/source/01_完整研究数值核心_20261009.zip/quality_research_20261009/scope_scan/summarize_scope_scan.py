#!/usr/bin/env python3
"""Generate a Chinese summary from scanner output; preserves human visual findings as dated notes."""
import argparse,csv,json,collections,math
from pathlib import Path

def read(p):
 with open(p,encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def f(r,k):
 try:return float(r[k])
 except (KeyError,ValueError):return float('nan')
def pct(x):return f'{x:.2%}'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--scan-dir',type=Path,required=True);args=ap.parse_args();p=args.scan_dir
 rows=read(p/'all_259_images_scope_scan.csv');lookup={r['image_code']:r for r in rows};rr=read(p/'all_3152_records_scope_metrics.csv');su=json.load(open(p/'scan_summary.json'));vf=read(p/'grid_resolution_verification.csv');sens=read(p/'threshold_sensitivity_all259.csv')
 maincodes=['pRbA3pwrgk9-02','q9vSo1VnCiC-29','uNb9QFRL6hY-67','uNb9QFRL6hY-54','UwV83HsGsw3-09','rPc6DW4iMge-06','zsNo4HB9uLZ-13','e9zR4mvMWw7-17']
 lines=['多人共同未覆盖GT范围的全库检索报告','2026年10月9日','',
 '一 结论',
 '全259张有人工标注的图片均进入库存扫描，保留3152条记录。应用既有85条人工排除、133条历史不纳入和本日wc2JMjhGNzB-14暂缓后，现行视图2930条，其中2898条Q可算。本轮没有采用旧primary场景gate去删除可标OOS。',
 '几何先检索、原Q后描述及过滤：严格、基准、宽松联合条件分别得到4、16、31张探索性候选。它们不是16张已确认GT错误的图，也不是31张所有人都画好的图。独立视觉核验进一步分出强范围差异、范围与自身问题混合、相同深度误差和共同漏细节等反例。',
 '最清楚的新增/扩展示例包括pRbA3pwrgk9-02、q9vSo1VnCiC-29、uNb9QFRL6hY-67与uNb9QFRL6hY-54；UwV83HsGsw3-09、rPc6DW4iMge-06需保留遮挡、镜面或细节解释，zsNo4HB9uLZ-13只有4人。e9z-17是混合基线，不能称全部标注3D良好。',
 '保留当前GT作评分参考，原Q、算法、参数、规整扣总分均未改变。多人共同围合较小区域与范围差异相容，但任务是否要求覆盖GT全部区域仍需任务说明或用户裁决，不能由多数投票替代真值。','',
 '二 分母与所谓独立工人',
 '3152全库存 → 2930当前清洗视图（256图） → 2898 Q可算（248图） → 再去12条Q可算但来源独立资格被阻断的记录 = 2886 → 同图同工人跨条件2条去重 = 2884不同图-工人单位 → semi条件516条另列，主分析manual/oos共2368单位。',
 '2368由manual 2158和oos 210组成，覆盖230张图，其中194张至少3人。另13条当前记录来源标记不独立，其中1条本已Q不可算；不要从2898再次减13。32条现行NA仍保存在全库存表。',
 '同工人去重按manual、oos、semi优先级和record_id固定顺序，不以高分/低分择人。semi没有删掉，全部进入条件分层表与allconditions统计。本轮allconditions基准候选没有增加主分析基准名单外的图。',
 '“独立”仅是不同worker、来源independent_vote_eligible未阻断、同图同人不重复投票的操作性称呼，不是证明随机、盲测或统计独立。不同工人也可能采用共同初始化或完全相同最终几何；不能据此自动认定重复导入、抄袭或无效。shape_dedup敏感性把完全相同几何只计一次，正式记录和分数不删改。',
 '清洗后没有足够manual/oos工人的图仍在全259图表中，明确标记不足，不被静默遗忘。','',
 '三 指标与检索条件',
 '1. 几何可构造：沿用原引擎标注自身2D和3D有效状态；这是非退化/可计算条件，不是图片上的正确性认证。实际主检索另外要求原Q可算且当前资格通过。',
 '2. 自身规整代理：基准D≤5°、flat≤3°、自身高度相对RMS≤8%；严格3°/1.5°/4%；宽松10°/4°/12%。完全不把Q、IoU、H*纳入这个代理。真正非正交OOS可能D高但合理，故保留宽松和全量对照，并需要人工看图。',
 '3. 参考高度：H*、Hmean、Hlocal分别报告；它们依赖GT参考，不等同自身3D好坏。H*低也不能证明水平位置正确。',
 '4. 冻结多边形面积：GT遗漏率=(GT面积-交集)/GT面积；GT外比例=(标注面积-交集)/标注自身面积，两个分母不同。area_h2等单位是归一化相机地高h²而非平方米。所谓exact为原浮点多边形算法输出，相对网格近似而言。',
 '5. 至少2/3共同遗漏：GT中至少ceil(2N/3)名工人没有覆盖的区域。其占比的分母是GT面积。另单列所有N人均未覆盖区域，绝不混称。两两遗漏Jaccard指每对工人的GT遗漏集合交并比，最后取中位数，不是均值、不是标注IoU。',
 '6. 同侧/局部一致性：列出共同遗漏最大8连通分量占比、以相机为中心8扇区的最大180°占比和方位合向量长度。它们描述集中程度，不可排除同侧深度误差或共同漏细节。',
 '7. 缩放/定位排查：仅作诊断，分别将标注绕相机等比缩放到GT面积，或把面积质心平移到GT质心，记录网格IoU改善。未生成替代Q、未替换GT；诊断改善小也不能单独证明是范围选择。',
 '基准图级检索：N≥3；个人遗漏率中位≥15%；GT外占自身中位≤15%；至少2/3共同遗漏GT≥10%；两两遗漏Jaccard中位≥0.40；至少3人通过自身规整代理；最后加原Q<50比例≥1/2。',
 '因此基准candidate_base是宽泛待查条件：至少3人规整，不保证同3人同时范围型且低分。scope_regular_base_n单列“自身规整且个人遗漏≥15%、GT外≤15%”联合支持者，scope_regular_base_lowQ_lt50_n进一步要求其原Q<50。不得把regular_base_n直接说成“好3D且漏同区的低分人数”。',
 'Q<50取原包已有低分段，用于后置筛查“低分是否常见”，从未参与全图几何检索优先顺序。16张基准候选中14张满足更强的至少2/3人Q<50；uNb9QFRL6hY-79与yqstnuAEVhm-25仅超过一半，不能无条件称普遍。',
 '排序量=共同遗漏占比×两两遗漏Jaccard中位×(1-GT外比例中位)×基准规整人数比例。少于3人设0。这个量只决定人工核验优先级，不是新质量分数、概率、因果强度或评分阈值。','',
 '四 重点图的可核对数字',
 '以下共同遗漏均指至少2/3工人未覆盖的GT占比，J为两两遗漏Jaccard中位数。k/N为同时规整且个人范围型的数量；Q中位先列全组，括号列k人的中位。']
 brief=[]
 for code in maincodes:
  r=lookup[code]
  lines+=['',f"{code}：源记录{r['inventory_records_n']}，当前记录{r['current_view_records_n']}，manual/oos工人N={r['n_workers']}，不同最终几何{r['primary_distinct_geometry_n']}。",
   f"k/N={r['scope_regular_base_n']}/{r['n_workers']}；全部规整代理人数严格/基准/宽松={r['regular_strict_n']}/{r['regular_base_n']}/{r['regular_relaxed_n']}；Q中位{f(r,'median_Q'):.2f}（联合支持者{f(r,'scope_regular_base_median_Q'):.2f}）；联合支持者中Q<50有{r['scope_regular_base_lowQ_lt50_n']}人。",
   f"至少2/3共同遗漏{pct(f(r,'shared_missing_ge2of3_gt_fraction_grid'))}；所有人均未覆盖{pct(f(r,'all_missing_gt_fraction_grid'))}；J={f(r,'pairwise_missing_jaccard_median_grid'):.3f}；个人GT遗漏中位{pct(f(r,'median_gt_missing_fraction'))}；GT外占自身中位{pct(f(r,'median_annotation_outside_fraction'))}。",
   f"共同遗漏最大连通分量占比{pct(f(r,'shared_largest_component_fraction'))}；最大180°同侧占比{pct(f(r,'shared_max_180deg_sector_fraction'))}；H*中位{pct(f(r,'median_Hstar_reference_relative'))}。"]
  brief.append({k:r[k] for k in ['image_code','inventory_records_n','current_view_records_n','n_workers','primary_distinct_geometry_n','scope_regular_base_n','scope_regular_base_lowQ_lt50_n','scope_regular_base_median_Q','median_Q','shared_missing_ge2of3_gt_fraction_grid','all_missing_gt_fraction_grid','pairwise_missing_jaccard_median_grid','median_gt_missing_fraction','median_annotation_outside_fraction','candidate_base','candidate_relaxed']})
 lines+=['',
 '五 与逐图视觉核验合并解读',
 '独立图片与3D核验详见相邻视觉包的 逐图视觉核验表.csv、视觉核验说明.txt 及证据图。本节为2026年10月9日的观察摘要，复算脚本不会从数值自动生成空间语义判断。',
 'pRb-02：6/6围合相机处玻璃淋浴隔间，GT覆盖玻璃外浴缸/双盆区域。5/6满足基准联合代理，且这些人Q仍约1.1。用户确认的R00186是直接例证，但其余人的细节仍不自动获同等评价。',
 'q9v-29：5/5选相机处梳妆前室，GT伸向全景接缝附近相邻区域。4/5规整，3/5同时满足保守GT外比例门槛。GT扩展方向不能误说成画面另一侧的深柜间。',
 'uNb-67：9/15只围合玻璃淋浴小隔间，另2人画长条、4人画较大区域或变形。全体8/15满足联合代理不等于这8人恰好就是视觉小隔间群体；不能说所有15人漏同一整块。至少2/3共同遗漏69.11%，但15人全部不覆盖的GT仅2.60%。',
 'uNb-54：6名manual都选择主区、GT另有入口短廊，6人规整且范围型。另4份semi有的延伸短廊，必须分列；manual相同形状去重后仍保留基准候选。',
 'UwV-09：小区、不同窄条和完整L形并存，18/24规整但只有8/24满足更严格的个人范围联合代理。GT外占自身中位15.63%略超15%基准，故属于宽松候选。当前参考已经是manual_revision；历史用户认为GT较全且含大块不可见区域，不能以镜面/遮挡观察宣布GT错误。',
 'rPc-06：多人在淋浴外表面停止，GT进入玻璃内空间；同时存在细节简化和个别明显斜变，属于范围与细节混合候选。',
 'zs-13：3/4选卧室主矩形、另1人尝试侧翼但倾斜；只有4人，是小样本候选。',
 'e9z-17：6/6不深入GT翼部，但R01013主体也收缩/歪斜；严格规整仅1/6，基准3/6。3个联合支持者的Q为23.94、24.81、50.35，因此原Q<50只有2个，Q<60才有3个。之前展示例不能代表全部人，也不能把原低分全归翼部差异。','',
 '六 必须保留的反例和阴性对照',
 'B6ByNegPMKs-11：23人中22规整、19满足个人范围代理、至少2/3共同遗漏20.95%，数值很像范围候选；实际图像更像同一狭长走廊的远端深度/顶高偏差，H*中位13.95%。这是量化筛查假阳性，不能称GT多标导致免责。',
 'jtcxE69GiFV-18：3/4规整，实际同时简化凹口并整体收缩，缺少明确完整替代小空间。',
 '7y3sRwLe3Va-22：楼梯挑空、栏杆平台与跨挑空墙包络选择混合，规整长条不证明共同地板和高度假设正确。',
 'e9zR4mvMWw7-09：共同遗漏很大，但基准规整只有2/6，多人有明显斜边；不属于多人3D都好。',
 'yqstnuAEVhm-01：manual共同简化实际可见墙面折变，历史用户明确GT对。源10份中仅5名manual，清洗后另4份semi；不能当10人独立共识。',
 'yqstnuAEVhm-34：历史scope标签并不等于当前GT缺区，至少2/3共同遗漏约0.003%。yqst-32已绑定修订GT，不把旧原始范围问题直接搬到当前参考。',
 'uNb-81：入口小突出处共同遗漏约6.60%，Q中位71.65，没有普遍极低。uNb-60：共同遗漏约3.39%，规整仅5/21，低分有多种原因。x8-03为共同漏浅细节而Q中位72.07，不自动套用其他x8图的非正交OOS结论。','',
 '七 敏感性与数值核验',
 '严格/基准/宽松联合阈值同时改变时分别4/16/31图；严格4图为B6-11、pRb-02、jtcx-18、uNb-67。严格条件仍混入视觉反例，证明阈值不是任务真值分类器。',
 '只改一个条件、其他保持基准时：']
 cnt=collections.Counter((x['axis'],x['value']) for x in sens if x['candidate']=='True')
 for axis in ['missing','outside','shared','agreement','good_geometry_profile','lowQ_cutoff']:
  lines.append(axis+'：'+'；'.join(v+'→'+str(n)+'图' for (a,v),n in cnt.items() if a==axis))
 lines+=['完全相同几何只计一票后，原16个基准候选全部仍在；另有yqst-01和7y-03跨过基准边缘。这说明相同形状合并不是必定降低共同遗漏或低Q比例，不能把它当统计独立性的精确修正。',
 f"网格在每张GT的x/z轴对齐包围盒上均匀取256×256单元中心，仅使用点在GT多边形内部的单元。共享区域采用8连通；没有给GT外补点、没有改环顺序。候选与对照共{len(vf)}张升至512×512复核。边界恰好落格点的处理依赖matplotlib.Path零半径point-in-polygon，边界面积本身为零。",
 f"256→512至少2/3共同遗漏占比最大绝对变动{100*max(f(r,'shared_missing_ge2of3_gt_fraction_grid_abs_difference') for r in vf):.4f}个百分点；两两遗漏J中位最大变动{max(f(r,'pairwise_missing_jaccard_median_grid_abs_difference') for r in vf):.6f}。",
 f"512网格GT面积相对冻结多边形面积最大绝对误差{100*max(abs(f(r,'gt_grid_area_relative_error_verify')) for r in vf):.4f}%；原多边形IoU与512网格IoU最大绝对差{max(f(r,'max_abs_grid_iou_error_verify') for r in vf):.6f}。共同面积是采样近似，源个人面积/IoU是既有浮点多边形值，两者列名有区分。",
 '512复核误差远小于主要例的大块遗漏，但接近阈值的个案仍需看邻近阈值和图像，不能把小数点后多位当测量精度。','',
 '八 复算与证据入口',
 '使用README_复算与字段说明.txt中的三个命令即可重建扫描CSV、JSON、图像及本报告。输入只需原完整复现包根目录和point_and_gate_audit目录。',
 'all_259_images_scope_scan.csv：全图分母、条件、阈值命中、共同区域、形状去重对照。',
 'all_3152_records_scope_metrics.csv：全库存逐记录清洗状态、参考绑定、Q、IoU、GT内外面积、规整代理、资格与同人去重。',
 'candidate_records.csv：候选、基线和反例的全部库存记录，必须用primary_manual_oos及候选列配合确定支持人群；不把已排除/暂缓记录当支持。',
 'threshold_sensitivity_all259.csv：全图逐参数邻近敏感性；grid_resolution_verification.csv：网格误差。',
 'geometry_evidence：GT与原标注地面多边形JSON、512掩模NPZ、多人叠加PNG；不依赖重新训练。',
 '原Q与源CSV的数值一致性、源文件SHA256等见output_validation.json与scan_summary.json。没有重新裁决GT范围，没有修改当前GT、原分数或正式算法。']
 (p/'中文量化报告.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 with open(p/'重点案例摘要.csv','w',encoding='utf-8-sig',newline='') as fh:
  w=csv.DictWriter(fh,fieldnames=list(brief[0]));w.writeheader();w.writerows(brief)
 print('Wrote 中文量化报告.txt and 重点案例摘要.csv')
if __name__=='__main__':main()
