#!/usr/bin/env python3
"""Read-only regression checks for scope scanner outputs."""
import argparse,csv,json,hashlib,math
from pathlib import Path

def read(p):
 with open(p,encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def main():
 a=argparse.ArgumentParser();a.add_argument('--scan-dir',required=True,type=Path);a.add_argument('--source-root',required=True,type=Path);a.add_argument('--audit-root',required=True,type=Path);args=a.parse_args();p=args.scan_dir
 rs=read(p/'all_3152_records_scope_metrics.csv'); ims=read(p/'all_259_images_scope_scan.csv');scores={r['record_id']:r for r in read(args.source_root/'results_fixed/all_records_scores.csv')};current={r['record_id'] for r in read(args.audit_root/'current_cleaning_plus_today_hold_view.csv')}
 eligible=[r for r in rs if r['primary_manual_oos']=='True'];errors=[]
 def check(name,cond):
  if not cond:errors.append(name)
 check('inventory_count',len(rs)==3152 and len(ims)==259)
 check('current_count',len(current)==2930 and sum(r['current_view_pass']=='True' for r in rs)==2930)
 check('primary_population',len(eligible)==2368)
 check('primary_cleaning',all(r['record_id'] in current for r in eligible))
 check('primary_independence_flag',all(r['independence_source_eligible']=='True' for r in eligible))
 check('hold_absent_primary',all(r['image_code']!='wc2JMjhGNzB-14' for r in eligible))
 check('primary_unique_worker_per_image',len({(r['image_code'],r['worker']) for r in eligible})==len(eligible))
 check('primary_no_semi',all(r['condition'] in ['manual','oos'] for r in eligible))
 diffs=[abs(float(r['Q'])-float(scores[r['record_id']]['quality_score'])) for r in rs if scores[r['record_id']]['score_status']=='available']
 check('published_Q_exact_numeric_preservation',all(d==0 for d in diffs))
 check('published_reference_binding_preservation',all((r['reference_id'],r['reference_version'])==(scores[r['record_id']]['reference_id'],scores[r['record_id']]['reference_version']) for r in rs))
 ranks=[float(r['geometric_retrieval_index']) for r in ims];check('ranking_finite_monotonic',all(math.isfinite(x) for x in ranks) and all(x>=y for x,y in zip(ranks,ranks[1:])))
 malformed=[]
 for fp in (p/'geometry_evidence').glob('*.json'):
  try:json.loads(fp.read_text(),parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
  except Exception as e:malformed.append(str(fp.name)+': '+str(e))
 check('geometry_json_strict_json',not malformed)
 base=[r for r in ims if r['candidate_base']=='True'];check('candidate_counts',len(base)==16 and sum(r['candidate_strict']=='True' for r in ims)==4 and sum(r['candidate_relaxed']=='True' for r in ims)==31)
 check('all_base_survive_identical_shape_sensitivity',all(r['shape_dedup_candidate_base']=='True' for r in base))
 source=json.load(open(p/'scan_summary.json'))['source_sha256'];check('source_file_hashes_unchanged',all(hashlib.sha256((args.source_root/k).read_bytes()).hexdigest()==v for k,v in source.items()))
 result={'pass':not errors,'errors':errors,'malformed_json':malformed,'inventory_rows':len(rs),'image_rows':len(ims),'primary_image_worker_units':len(eligible),'published_Q_comparisons':len(diffs),'max_abs_Q_change':max(diffs),'base_candidates':len(base),'geometry_json_files':len(list((p/'geometry_evidence').glob('*.json'))),'source_file_hashes_unchanged':not any(x=='source_file_hashes_unchanged' for x in errors)}
 (p/'output_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
 if errors:raise SystemExit(1)
if __name__=='__main__':main()
