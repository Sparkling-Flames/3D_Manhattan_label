# HOHONET 两图范围与质量模型研究增量（2026-10-15）

先读 `REPORT_ZH.md`；查看全部28份存档作答的独立底面图及逐项说明，打开自包含的 `REVIEW.html`。

**这不是当前36份的完整收尾包。** 原图及当前LFS输入未取得；可读的是28份存档manual分析坐标、44份开发粗评、276条参考配对前缀和220个冻结融合终点。每份新范围完整WQ／3D IoU保持空值，不修改任何正式评分或资格。

## 复算

测试环境 Python 3.13.5、NumPy 2.3.5、pandas 2.2.3、SciPy 1.17.0、Shapely 2.1.2。依赖列在 `requirements.txt`；不需要模型训练或网络访问。

```bash
python reproduce.py --output ../new_replay
python plot_results.py --results ../new_replay --output ../new_figures
python -m pytest -q -p no:cacheprovider
```

输出目录必须不存在。`config.json`记录冻结合同，修改采样尺度或敏感性列表时程序拒绝悄悄忽略配置；这些不是已拟合的新参数。

`python build_review.py` 可从包内results和figures重建自包含REVIEW.html。`python extract_valid_csv.py --source inputs/extracted_text/ALL_REFERENCE_PAIRS.txt --output ../new_pairs.csv` 可重现完整行筛选；截断尾行只隔离，不补齐。

## 文件含义

- `results/two_image_floor_updates_28.csv`：28份作答×两参考的逐项结果、原账本回接、范围兼容提示、当前身份未核验状态及完整分数NA。
- `results/geometry_reproduction_parity_28.csv`：从坐标重算I/D/Sb/Hm/Hc/3D IoU/WQ与原表的差；不代表当前数组逐值核对。
- `results/human_44_rescores.csv`：44份原回执绑定、曝光、选样、分项和固定方向系数敏感性。
- `results/qualitative_order_descriptions.csv`：粗档反序等描述，不能当独立准确率。
- `results/available_pair_rescores_276.csv`：原始配对前缀，多参考不得当不同作答；最新1145资格未完整回接。
- `results/worker_*`与`ordinary_pairwise_sensitivity.csv`：条件子集，不是人员资格、最终能力档或选人政策。
- `results/fusion_*`：冻结终点的重评分；没有重选人、改票权或重新融合。
- `results/synthetic_*`、`rough_boundary_sequence.csv`及`matched_overlap_boundary_counterexample.json`：明示控制、反例和失败的双指标几何匹配。
- `results/routing_sensitivity.csv`：探索性空间分组对阈值的敏感性，非标定的空间分类器。
- `results/top_boundary_missing_locations.csv`：新底面8个顶点的ERP位置及待确认顶界，不要求重新画底面。
- `results/partial_identification_bounds.csv`：旧IoU不足以确定新IoU的保守区间，不能以区间端点作为新得分。
- `SOURCE_AVAILABILITY.json`：读取失败、原始与可读数量、存档坐标来源及材料边界。
- `tests/TEST_RESULTS.txt`、`REPRODUCTION_CHECK.json`：实际执行回执。

## 采用建议

不选新α、不修改正式默认WQ。受限工作指数保持原α=1；论文分别报告参考条件几何、D自身规整性、结构／参考资格，并保留现用均高棱柱3D IoU。新增底面只发布底面分项和完整WQ上界，不能把上界当完整分数。

## 尚缺的现成材料

`CURRENT_TWO_IMAGE_OBJECTS.json`、`TWO_IMAGE_PRIOR_LEDGER.csv`或可执行的当前LFS输入与loader；两张原图；最新1145完整资格映射。新增顶部优先核验B6的x≈805.91及其新闭合段，Uw跨缝两端x≈68.69／973.40。缺失8份作答的ID和条件尚未建立。
