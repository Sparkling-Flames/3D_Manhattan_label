"""Recover only syntactically complete rows from a tool-provided CSV text prefix.
A complete-width row count is NOT proof that the original file was fully returned.
"""
import argparse,csv,io,json
from pathlib import Path

def extract(source,output):
    if output.exists():raise ValueError('Output exists; do not overwrite evidence')
    text=source.read_text(encoding='utf-8-sig');lines=text.splitlines(keepends=True)
    header=next(i for i,line in enumerate(lines) if line.startswith('index,'))
    reader=csv.reader(io.StringIO(''.join(lines[header:])));cols=next(reader);valid=[];held=[]
    for ordinal,row in enumerate(reader,1):
        if len(row)==len(cols):valid.append(row)
        else:held.append({'row_ordinal':ordinal,'actual_columns':len(row),'expected_columns':len(cols),'raw':row})
    with output.open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f,lineterminator='\n');writer.writerow(cols);writer.writerows(valid)
    audit={'valid_rows':len(valid),'held_rows':held,'source_was_tool_text_not_raw_file':True,'original_completeness_not_established':True}
    output.with_suffix('.extraction.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    return audit
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=extract(a.source,a.output);print('Complete rows:',r['valid_rows'],'Held rows:',len(r['held_rows']))
