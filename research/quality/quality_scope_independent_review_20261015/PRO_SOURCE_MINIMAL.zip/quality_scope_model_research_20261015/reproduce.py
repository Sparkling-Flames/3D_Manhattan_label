#!/usr/bin/env python3
"""Reproduce the delivered, explicitly partial study offline. Output must be new.
No repository, GT, qualification, historical receipt, or default scoring is changed.
"""
import argparse,json,sys,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from scope import run_scope
from empirical import feedback,downstream
from controls import run_controls
from supplement import supplement

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--inputs',type=Path,default=ROOT/'inputs');a=p.parse_args()
    if a.output.exists():raise SystemExit('Output already exists; use a new directory to preserve earlier results.')
    cfg=json.loads((ROOT/'config.json').read_text())
    if cfg['direction_alpha_sensitivity'] != [1.,.75,.5,.25,0.] or cfg['spherical_boundary_samples_per_direction']!=2048 or cfg['height_samples_per_direction']!=4096:
        raise ValueError('This release reproduces a frozen measurement contract; config does not silently retune the implementation.')
    a.output.mkdir(parents=True)
    run_scope(a.inputs,a.output)
    feedback(a.inputs,a.output)
    downstream(a.inputs,a.output)
    run_controls(a.output)
    supplement(a.inputs,a.output)
    import numpy,pandas,scipy,shapely
    receipt={'status':'completed_for_available_inputs','full_current36_completed':False,'current3152_loader_executed':False,
             'new_scope_full3d_completed':False,'raw_images_reviewed':0,'latest_joint_qualification_fully_joined':False,'canonical_files_modified':False,'weights_fitted_to_human_feedback':False,
             'python':platform.python_version(),'numpy':numpy.__version__,'pandas':pandas.__version__,'scipy':scipy.__version__,'shapely':shapely.__version__,
             'phases':['floor-only archival replay','ordinary fixed direction sensitivity','ordinary selection/exposure sensitivity','doorway fixed-parameter weaker check','worker and frozen-fusion sensitivity','synthetic controls'],
             'ordinary_parameters_changed_at_doorway_stage':False}
    (a.output/'RUN_RECEIPT.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,ensure_ascii=False))
if __name__=='__main__':main()
