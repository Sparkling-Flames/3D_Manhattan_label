"""Declared synthetic geometry controls. No human record is edited.
These are mathematical counterexamples, not independent human-quality observations.
"""
import json
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from geometry import polygon,iou,direction,bottom_distance,height_components,prism_iou,angles
from model import score,floor_diagnostic

def measure(a,g,ah=None,gh=None):
    a,g=np.asarray(a,float),np.asarray(g,float)
    ah=np.full(len(a),2.) if ah is None else np.asarray(ah,float)
    gh=np.full(len(g),2.) if gh is None else np.asarray(gh,float)
    I=iou(a,g);D=direction(a);Sb=bottom_distance(a,g);Hm,Hc=height_components(a,ah,g,gh)
    return dict(I=I,D=D,Sb=Sb,Hm=Hm,Hc=Hc,WQ=score(I,Sb,D,Hm,Hc),Q_half=score(I,Sb,D,Hm,Hc,.5),
                Q_noD=score(I,Sb,D,Hm,Hc,0),IoU3D100=100*prism_iou(a,ah,g,gh),
                direction_penalty=1.5*D**2/(D**2+37.5),candidate_area=polygon(a).area,
                candidate_perimeter=polygon(a).length,reference_area=polygon(g).area)

def run_controls(out):
    g=np.array([[-2.,-2.],[2,-2],[2,2],[-2,2]])
    rows=[];geo=[]
    def add(case,a,ref=g,ah=None,gh=None,**kw):
        r=measure(a,ref,ah,gh);r.update(case=case,**kw);rows.append(r)
        geo.append(dict(case=case,candidate=np.asarray(a).tolist(),reference=np.asarray(ref).tolist(),heights=None if ah is None else np.asarray(ah).tolist()))
        return r
    add('perfect',g,group='identity',amplitude=0)
    for s in [.0001,.0005,.001,.005,.01,.025,.05,.1,.2,.5]:
        a=g@np.array([[1,0],[s,1.]])
        add('shear_'+str(s),a,group='near_correct_shear',amplitude=s)
    for th in [0,1,5,15,30,45,60,75,85,89]:
        t=np.radians(th);a=g@np.array([[np.cos(t),np.sin(t)],[-np.sin(t),np.cos(t)]])
        add('rotation_'+str(th),a,group='rigid_rotation_orthogonal',amplitude=th)
    for angle in [90,75,60,45,30,15,5,1]:
        t=np.radians(angle);a=g@np.array([[1,0],[np.cos(t),np.sin(t)]])
        add('rhombus_'+str(angle),a,group='family_collapse',amplitude=angle,
            known_corner_angle_rms=float(np.sqrt(np.mean((angles(a)-angles(g))**2))))
    for s in [.01,.05,.5]:
        a=g@np.array([[1,0],[s,1.]])
        add('nonorthogonal_self_'+str(s),a,ref=a,group='reference_identity',amplitude=s)
    # Valid concavity, not penalized as an incorrect 270-degree angle.
    l=np.array([[-2,-2],[2,-2],[2,0],[0,0],[0,2],[-2,2.]])
    add('concave_L_self',l,ref=l,group='concavity',amplitude=0)
    branch=np.array([[-2,-2],[2,-2],[2,2],[.05,2],[.05,4],[-.05,4],[-.05,2],[-2,2.]])
    add('orthogonal_branch_omitted',g,ref=branch,group='omission',amplitude=.1,
        explicit_corner_correspondence_available=False)
    # Subdivide a low-height straight wall without changing the represented 3D surface.
    ah=np.array([1.8,1.8,2.2,2.2])
    for n in [0,1,10,100]:
        extra=np.array([g[0]+k/(n+1)*(g[1]-g[0]) for k in range(1,n+1)]).reshape(-1,2)
        a=np.r_[g[:1],extra,g[1:]];hh=np.r_[ah[:1],np.full(n,ah[0]),ah[1:]]
        add('subdivide_'+str(n),a,ah=hh,group='same_surface_subdivision',amplitude=n)
    for r in [1,1.1,1.2,1.5,2,4]:
        add('height_'+str(r),g,ah=np.full(4,2*r),group='uniform_height',amplitude=r)
    # D need not converge under Hausdorff/area convergence when the boundary's slope does not.
    # Only I,D are evaluated at large n; avoid claiming quadrature convergence from undersampling.
    rough=[]
    for n in [4,16,64,256]:
        x=np.linspace(2,-2,2*n+1);amp=.1*4/(2*n)
        top=np.c_[x,2+amp*np.where(np.arange(len(x))%2,1.,0.)]
        a=np.r_[g[:2],top]
        rough.append(dict(teeth=n,amplitude=amp,I=iou(a,g),D=direction(a),max_boundary_offset=amp))
    # Same IoU does not determine D. Analytic scaling counterexample.
    s=.2;shear=g@np.array([[1,0],[s,1.]]);sr=measure(shear,g)
    scaled=g/np.sqrt(sr['I']);rr=measure(scaled,g)
    add('same_iou_shear',shear,group='equal_overlap_distinct_structure',amplitude=s)
    add('same_iou_scaled',scaled,group='equal_overlap_distinct_structure',amplitude=s)
    # Challenge stronger redundancy claim: match BOTH I and Sb with an orthogonal rectangle.
    # Geometric calibration only, no ratings, no candidate model fit.
    best=None
    for init in [[1.1,1.1,0],[1.,1.,.4],[1.2,.9,0],[.9,1.2,0]]:
        def make(x):return g*np.asarray(x[:2])+np.array([x[2],0])
        def fun(x):
            a=make(x)
            return np.array([iou(a,g)-sr['I'],(bottom_distance(a,g,512)-bottom_distance(shear,g,512))/10])
        fit=least_squares(fun,init,bounds=([.6,.6,-.7],[1.5,1.5,.7]),max_nfev=75,diff_step=1e-5,ftol=1e-11,xtol=1e-11,gtol=1e-11)
        norm=float(np.linalg.norm(fun(fit.x)))
        if best is None or norm<best[0]:best=(norm,fit.x)
    a=g*np.asarray(best[1][:2])+np.array([best[1][2],0]);br=measure(a,g)
    # Refit at final 2048 sample definition, all fitted shapes remain actual orthogonal rectangles.
    fit=least_squares(lambda x: [iou(g*x[:2]+[x[2],0],g)-sr['I'],(bottom_distance(g*x[:2]+[x[2],0],g)-sr['Sb'])/10],best[1],bounds=([.6,.6,-.7],[1.5,1.5,.7]),max_nfev=100,diff_step=1e-6,ftol=1e-12,xtol=1e-12,gtol=1e-12)
    a=g*fit.x[:2]+[fit.x[2],0];br=add('attempted_I_Sb_orthogonal_match',a,group='failed_exact_overlap_boundary_match',amplitude=s)
    matched={'target_shear':sr,'orthogonal_match':br,'parameters':fit.x.tolist(),'I_difference':br['I']-sr['I'],'Sb_difference':br['Sb']-sr['Sb'],
             'exact_match_succeeded':abs(br['I']-sr['I'])<1e-6 and abs(br['Sb']-sr['Sb'])<1e-6,
             'failure_retained':'The orthogonal rectangle search did not exactly match both I and Sb; do not cite this as an exact information-redundancy counterexample.',
             'not_human_evidence':True,'not_an_argument_that_more_D_penalty_is_better':True}
    pd.DataFrame(rows).to_csv(out/'synthetic_controls.csv',index=False)
    pd.DataFrame(rough).to_csv(out/'rough_boundary_sequence.csv',index=False)
    (out/'synthetic_geometries.json').write_text(json.dumps(geo,indent=2))
    (out/'matched_overlap_boundary_counterexample.json').write_text(json.dumps(matched,indent=2))
    return rows
