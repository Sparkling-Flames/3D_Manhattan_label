"""Frozen-input comparisons; qualitative ratings are never training targets.
All correlations / disagreement counts are descriptive, not independent trial accuracy.
"""
import json,itertools
import numpy as np
import pandas as pd
from scipy.stats import spearmanr,kendalltau
from model import score,terms,shapley_deductions
ALPHAS=[1.,.75,.5,.25,0.]
GRADES={'poor':0,'average_poor':1,'average':2,'good_average':3,'good':4}
def aname(a):return 'Q_alpha_'+str(a).replace('.','p')
def attach_scores(d):
    d=d.copy()
    for a in ALPHAS:
        d[aname(a)]=[score(r.iou_2d,r.S_bottom_deg,r['dir'],r.Hmean,r.Hcenter,a) if all(pd.notna(r[k]) for k in ['iou_2d','S_bottom_deg','dir','Hmean','Hcenter']) else np.nan for _,r in d.iterrows()]
    return d

def concordance(d,model,label='grade_numeric'):
    d=d.dropna(subset=[model,label]);sg=sl=ties=gap2bad=gap2n=0
    for a,b in itertools.combinations(d.index,2):
        dh=d.loc[a,label]-d.loc[b,label];dm=d.loc[a,model]-d.loc[b,model]
        if dh==0:continue
        if abs(dh)>=2:
            gap2n+=1;gap2bad+=dh*dm<0
        if dh*dm>0:sg+=1
        elif dh*dm<0:sl+=1
        else:ties+=1
    return dict(n=len(d),grade_order_consistent=sg,grade_order_opposite=sl,score_ties=ties,
                nonindependent_comparable_pairs=sg+sl+ties,grade_gap_at_least_two_pairs=gap2n,grade_gap_at_least_two_opposite=gap2bad,
                spearman=float(spearmanr(d[model],d[label]).statistic) if len(d)>2 else None)

def feedback(inp,out):
    provenance=pd.read_csv(inp/'selection_provenance.csv');diag=json.loads((inp/'FEEDBACK_DIAGNOSTICS.json').read_text());receipt=json.loads((inp/'human_receipt_44.json').read_text())
    entries=[]
    for r in diag['rows']:
        p=provenance[provenance.record_id==r['record_id']]
        if len(p)!=1:raise ValueError('ambiguous feedback row')
        p=p.iloc[0].to_dict();h=receipt['decisions'][r['card_id']]
        if h['bindings'][0]['object_id']!=p['object_id'] or h['bindings'][0]['reference_object_id']!=p['reference_id']:raise ValueError('feedback binding mismatch')
        p.update(card_id=r['card_id'],grade=h['grade'],grade_numeric=GRADES.get(h['grade']),comment=h['comment'],
                 score_revealed=h.get('score_revealed_at') is not None,first_reveal_grade=h.get('grade_at_first_score_reveal'),
                 grade_changed_after_reveal=bool(h.get('score_revealed_at') and h.get('grade_at_first_score_reveal') is not None and h.get('grade_at_first_score_reveal')!=h['grade']),
                 scope_revision_hold=r['card_id'] in ['N05','N28'],extra_scope_comment_sensitivity=r['card_id'] in ['N08','N20'],
                 blind_validation=False)
        losses=terms(p['iou_2d'],p['S_bottom_deg'],p['dir'],p['Hmean'],p['Hcenter'])
        p.update({'loss_'+k:v for k,v in losses.items()})
        p.update({'shapley_'+k:v for k,v in shapley_deductions(losses).items()})
        entries.append(p)
    d=attach_scores(pd.DataFrame(entries));d['direction_actual_drop']=d[aname(0.)]-d[aname(1.)]
    d.to_csv(out/'human_44_rescores.csv',index=False)
    desc=[]
    masks={'ordinary_excluding_two_scope':(d.phase=='ordinary')&~d.scope_revision_hold,
           'ordinary_excluding_four_scope_comments':(d.phase=='ordinary')&~d.scope_revision_hold&~d.extra_scope_comment_sensitivity,
           'doorway_weak_feedback':d.phase=='doorway'}
    # Selection and disclosure strata are descriptive; no subset is relabelled as blind.
    for sel in d.selection.unique():masks['ordinary_selection_'+sel]=masks['ordinary_excluding_two_scope']&(d.selection==sel)
    for exposed in [False,True]:masks['ordinary_this_page_revealed_'+str(exposed)]=masks['ordinary_excluding_two_scope']&(d.score_revealed==exposed)
    for name,mask in masks.items():
        for model in [aname(a) for a in ALPHAS]+['IoU3D100']:
            desc.append(dict(subset=name,model=model,**concordance(d[mask],model)))
    pd.DataFrame(desc).to_csv(out/'qualitative_order_descriptions.csv',index=False)
    same=[]
    for _,g in d.groupby(['image_id','reference_id','condition','phase']):
        for (_,a),(_,b) in itertools.combinations(g.iterrows(),2):
            if a.scope_revision_hold or b.scope_revision_hold:continue
            z={'a':a.card_id,'b':b.card_id,'image':a.image_code,'grade_a':a.grade,'grade_b':b.grade,'independent_validation':False}
            for model in [aname(x) for x in ALPHAS]+['IoU3D100']:z['difference_'+model]=a[model]-b[model]
            # Exact linear crossing in denominator, not a fitted parameter.
            aa=1/a.iou_2d+a.loss_bottom+a.loss_global+a.loss_local
            bb=1/b.iou_2d+b.loss_bottom+b.loss_global+b.loss_local
            z['alpha_equal_score']=(bb-aa)/(a.loss_direction-b.loss_direction) if a.loss_direction!=b.loss_direction else None
            same.append(z)
    pd.DataFrame(same).to_csv(out/'human_same_image_pairs.csv',index=False)
    return d

def numeric_pairwise(d,models):
    rows=[]
    for name,model in models.items():
        n=opp=material=identical=0
        for _,g in d.groupby(['image_id','reference_id','condition']):
            for (_,a),(_,b) in itertools.combinations(g.iterrows(),2):
                if a.worker_id==b.worker_id:continue
                x=a[aname(1.)]-b[aname(1.)];y=a[model]-b[model]
                if abs(x)<1e-10 and abs(y)<1e-10:identical+=1;continue
                n+=1;opp+=x*y<-1e-10;material+=x*y<-1e-10 and abs(x)>=5 and abs(y)>=5
        rows.append(dict(model=name,comparable_pairs=n,identical_pairs=identical,opposite=opp,both_differences_ge5_opposite=material))
    return rows

def downstream(inp,out):
    p=attach_scores(pd.read_csv(inp/'ALL_REFERENCE_PAIRS_valid.csv'))
    p['latest_joint_qualification_verified']=False
    p['numerical_comparison_only']=True
    p.to_csv(out/'available_pair_rescores_276.csv',index=False)
    ordinary=p[(p.use_layers=='["ordinary_current"]')&(p.condition=='manual')&(p.personnel_barriers=='[]')&(p.context_barriers=='[]')&(~p.original_holdout)].copy()
    ordinary=ordinary[~ordinary.image_code.isin(['B6ByNegPMKs-37','UwV83HsGsw3-10'])]
    if ordinary.duplicated(['record_id']).any():raise ValueError('multiple references cannot count as independent worker submissions')
    models={aname(a):aname(a) for a in ALPHAS};models['IoU3D100']='IoU3D100'
    pairwise=numeric_pairwise(ordinary,models);pd.DataFrame(pairwise).to_csv(out/'ordinary_pairwise_sensitivity.csv',index=False)
    ordinary['cell']=ordinary.image_id+'|'+ordinary.reference_id+'|'+ordinary.condition
    # At most one score per worker per image/reference cell; not multiple votes.
    cells=ordinary.groupby(['worker_id','cell'])[list(models)].mean().reset_index()
    for model in models:
        cells['centered_'+model]=cells[model]-cells.groupby('cell')[model].transform('mean')
    support=cells.groupby('worker_id').size();keep=support[support>=5].index
    wc=cells[cells.worker_id.isin(keep)].groupby('worker_id')[[c for c in cells if c.startswith('centered_')]].mean()
    wc['n_cells']=support.loc[wc.index]
    for model in models:wc['rank_'+model]=wc['centered_'+model].rank(ascending=False,method='average')
    wc.to_csv(out/'worker_centered_partial_panel.csv')
    # Common-panel sensitivity uses exactly the same cells for all retained workers.
    cw=cells[cells.worker_id.isin(keep)];counts=cw.groupby('cell').worker_id.nunique();common=counts[counts==len(keep)].index
    cm=cw[cw.cell.isin(common)].groupby('worker_id')[list(models)].mean()
    cm.to_csv(out/'worker_common_partial_panel.csv')
    summary=[]
    for model in models:
        a=wc['centered_'+aname(1.)];b=wc['centered_'+model]
        summary.append({'model':model,'workers':len(wc),'spearman_centered':float(spearmanr(a,b).statistic) if len(wc)>2 else None,
            'max_rank_shift':float((wc['rank_'+model]-wc['rank_'+aname(1.)]).abs().max()) if len(wc) else None,
            'common_cells':len(common),'common_panel_rho':float(spearmanr(cm[aname(1.)],cm[model]).statistic) if len(common) and len(cm)>2 else None})
    pd.DataFrame(summary).to_csv(out/'worker_partial_sensitivity_summary.csv',index=False)
    f=attach_scores(pd.read_csv(inp/'FUSION_220_SCORES_valid.csv'));f.to_csv(out/'fusion_220_rescores.csv',index=False)
    fsum=[];fpair=[]
    # Frozen endpoints are rescored, not newly fused or reweighted.
    for name,mask in {'all_numerically_complete':f.status=='complete',
                      'ordinary_no_recorded_member_or_holdout_barriers':(f.status=='complete')&(f.stage=='ordinary')&(f.member_restrictions=='[]')&(f.holdout_members=='[]')&~f.image_code.isin(['B6ByNegPMKs-37','UwV83HsGsw3-10'])}.items():
        q=f[mask]
        for model in models:
            fsum.append(dict(subset=name,model=model,n=len(q),mean=q[model].mean(),median=q[model].median(),spearman_to_WQ=float(spearmanr(q[aname(1.)],q[model]).statistic)))
        for (im,ref),g in q.groupby(['image_id','reference_id']):
            if set(g.version)!={'automatic','assisted'} or len(g)!=2:continue
            a=g[g.version=='assisted'].iloc[0];b=g[g.version=='automatic'].iloc[0]
            z=dict(subset=name,image_id=im,image_code=a.image_code,reference_id=ref,n_assisted=a.n,n_automatic=b.n,comparison='fixed assisted minus automatic; no causal interpretation')
            for model in models:z[model]=a[model]-b[model]
            fpair.append(z)
    pd.DataFrame(fsum).to_csv(out/'fusion_sensitivity_summary.csv',index=False)
    pd.DataFrame(fpair).to_csv(out/'fusion_matched_version_differences.csv',index=False)
    coverage={'available_reference_pairs':len(p),'unique_submissions_in_pairs':int(p.record_id.nunique()),'multi_reference_submissions':int((p.groupby('record_id').size()>1).sum()),'ordinary_current_binding_rows':int((p.use_layers=='["ordinary_current"]').sum()),
        'ordinary_worker_comparison_rows':len(ordinary),'ordinary_worker_cells':int(cells.cell.nunique()),'ordinary_buildings':int(ordinary.building_id.nunique()),'worker_support_min_cells':5,'workers_retained':len(keep),'common_cells':len(common),
        'fusion_entries':len(f),'fusion_complete':int((f.status=='complete').sum()),'fusion_unchanged_not_recomputed':True,'original_full1145_not_recovered':True,'sample_selection':'readable extraction prefix; not representative random sample','formal_eligibility_changed':False,'latest1145_target_hold_flags_fully_joined':False,'worker_result_not_formal_admission_or_ability_ranking':True}
    (out/'empirical_coverage.json').write_text(json.dumps(coverage,indent=2))
    return p,f
