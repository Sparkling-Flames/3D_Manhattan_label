"""Read-only geometric measurements on explicit, already ordered layout rings.
Projection: continuous ERP coordinates, no half pixel shift. Camera height = 1.
S_bottom follows the archived native minor-arc implementation, not chord samples.
D is independently minimized over all quadratic wrap intervals.
"""
from __future__ import annotations
import math
import numpy as np
from shapely.geometry import Polygon,Point

def polygon(x):
    x=np.asarray(x,float)
    if x.ndim!=2 or x.shape[1]!=2 or len(x)<3 or not np.isfinite(x).all():raise ValueError('finite >=3 xz vertices required')
    p=Polygon(x)
    if not p.is_valid or p.area<=1e-12:raise ValueError('invalid or degenerate polygon')
    if np.any(np.linalg.norm(np.roll(x,-1,axis=0)-x,axis=1)<1e-12):raise ValueError('zero edge')
    return p

def project(triples):
    q=np.asarray(triples,float)
    if q.ndim!=2 or q.shape[1]!=3 or not np.isfinite(q).all():raise ValueError('x,top_y,bottom_y triples required')
    u=(q[:,0]/1024-.5)*2*np.pi; v=(q[:,2]/512-.5)*np.pi
    if np.any((v<=0)|(v>=np.pi/2)):raise ValueError('floor must be below horizon and above nadir')
    rho=1/np.tan(v)
    xz=np.c_[rho*np.sin(u),-rho*np.cos(u)]
    h=1-rho*np.tan((q[:,1]/512-.5)*np.pi)
    polygon(xz)
    if np.any(h<=0):raise ValueError('nonpositive wall height')
    return xz,h

def erp_triples(points):
    q=np.asarray(points,float).reshape(-1,2,2)
    if not np.allclose(q[:,0,0],q[:,1,0],atol=1e-9):raise ValueError('unpaired longitude')
    return np.c_[q[:,0,0],q[:,0,1],q[:,1,1]]

def direction(xz):
    polygon(xz);x=np.asarray(xz,float);e=np.roll(x,-1,axis=0)-x
    length=np.linalg.norm(e,axis=1);th=np.degrees(np.arctan2(e[:,1],e[:,0]))
    breaks=np.unique(np.r_[0.,90.,(th+45)%90]); vals=[]
    def f(phi):return float(np.average(((th-phi+45)%90-45)**2,weights=length))
    for lo,hi in zip(breaks[:-1],breaks[1:]):
        mid=(lo+hi)/2; rr=(th-mid+45)%90-45
        optimum=np.clip(mid+np.average(rr,weights=length),lo,hi)
        vals.extend((f(lo),f(hi),f(optimum)))
    return math.sqrt(max(0,min(vals)))

def iou(a,g):
    a,g=polygon(a),polygon(g);return a.intersection(g).area/a.union(g).area

def unit(v):
    v=np.asarray(v,float);n=np.linalg.norm(v,axis=-1,keepdims=True)
    if np.any(n<1e-12):raise ValueError('origin in spherical projection')
    return v/n

def arc_basis(ring):
    a=unit(ring);b=np.roll(a,-1,axis=0);c=np.cross(a,b)
    s=np.linalg.norm(c,axis=1);co=np.sum(a*b,axis=1);theta=np.arctan2(s,co)
    if np.any(theta<1e-12) or np.any(np.pi-theta<1e-10):raise ValueError('degenerate spherical arc')
    normal=c/s[:,None];tangent=np.cross(normal,a)
    return a,b,tangent,normal,theta

def arc_samples(ring,n):
    a,b,tangent,normal,length=arc_basis(ring);cum=np.r_[0,np.cumsum(length)]
    s=(np.arange(n)+.5)*cum[-1]/n;ix=np.searchsorted(cum,s,side='right')-1;alpha=s-cum[ix]
    return a[ix]*np.cos(alpha)[:,None]+tangent[ix]*np.sin(alpha)[:,None]

def points_to_arcs(points,target):
    p=unit(points);a,b,tangent,normal,length=arc_basis(target)
    x=p@a.T;y=p@tangent.T;phase=np.arctan2(y,x)
    inside=(phase>=-1e-12)&(phase<=length[None,:]+1e-12)
    d=np.arctan2(np.abs(p@normal.T),np.hypot(x,y))
    da=np.arctan2(np.linalg.norm(np.cross(p[:,None,:],a[None,:,:]),axis=-1),x)
    db=np.arctan2(np.linalg.norm(np.cross(p[:,None,:],b[None,:,:]),axis=-1),p@b.T)
    return np.where(inside,d,np.minimum(da,db)).min(axis=1)

def bottom_distance(a,g,n=2048):
    polygon(a);polygon(g)
    a=np.c_[np.asarray(a)[:,0],-np.ones(len(a)),np.asarray(a)[:,1]]
    g=np.c_[np.asarray(g)[:,0],-np.ones(len(g)),np.asarray(g)[:,1]]
    return math.degrees((points_to_arcs(arc_samples(a,n),g).mean()+points_to_arcs(arc_samples(g,n),a).mean())/2)

def height_mean(x,h):
    x=np.asarray(x,float);h=np.asarray(h,float);l=np.linalg.norm(np.roll(x,-1,axis=0)-x,axis=1)
    return float(np.average((h+np.roll(h,-1))/2,weights=l))

def height_samples(x,h,n):
    x=np.asarray(x,float);h=np.asarray(h,float);e=np.roll(x,-1,axis=0)-x;l=np.linalg.norm(e,axis=1)
    cum=np.r_[0,np.cumsum(l)];s=(np.arange(n)+.5)*cum[-1]/n;k=np.searchsorted(cum,s,side='right')-1
    u=(s-cum[k])/l[k]
    return x[k]+u[:,None]*e[k],h[k]+u*(np.roll(h,-1)[k]-h[k])

def nearest_height_mse(a,ah,g,gh,n):
    # Same conservative largest vertical residual at genuine nearest-footprint ties.
    origin=np.asarray(a)[0];a=np.asarray(a)-origin;g=np.asarray(g)-origin
    x,h=height_samples(a,ah,n);e=np.roll(g,-1,axis=0)-g;e2=np.sum(e*e,axis=1)
    v=x[:,None,:]-g[None,:,:];u=np.clip(np.sum(v*e[None,:,:],axis=2)/e2[None,:],0,1)
    d2=np.sum((v-u[:,:,None]*e[None,:,:])**2,axis=2)
    eps=64*np.finfo(float).eps*max(1,float(np.abs(x).max())**2,float(np.abs(g).max())**2)
    tied=d2<=d2.min(axis=1)[:,None]+eps
    mh=np.asarray(gh)[None,:]+u*(np.roll(gh,-1)-gh)[None,:]
    r2=(h[:,None]-mh)**2
    return float(np.max(np.where(tied,r2,-np.inf),axis=1).mean())

def height_components(a,ah,g,gh,n=4096):
    ma,mg=height_mean(a,ah),height_mean(g,gh)
    ac=np.asarray(ah)+(mg-ma)
    hc=math.sqrt((nearest_height_mse(a,ac,g,gh,n)+nearest_height_mse(g,gh,a,ac,n))/2)/mg
    return abs(ma-mg)/mg,hc

def prism_iou(a,ah,g,gh):
    a,g=polygon(a),polygon(g);ha,hg=np.mean(ah),np.mean(gh)
    inter=a.intersection(g).area*min(ha,hg)
    return inter/(a.area*ha+g.area*hg-inter)

def angles(xz):
    polygon(xz);x=np.asarray(xz,float);e=np.roll(x,-1,axis=0)-x;p=np.roll(e,1,axis=0)
    area2=np.sum(x[:,0]*np.roll(x[:,1],-1)-x[:,1]*np.roll(x[:,0],-1))
    turn=np.arctan2(p[:,0]*e[:,1]-p[:,1]*e[:,0],np.sum(p*e,axis=1))*np.sign(area2)
    return 180-np.degrees(turn)
