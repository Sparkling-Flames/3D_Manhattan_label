"""WQ-LS08 exact algebra and fixed direction sensitivity checks. No learned weights."""
from __future__ import annotations
from itertools import permutations
import numpy as np

def terms(I,Sb,D,Hm,Hc):
    x=np.array([I,Sb,D,Hm,Hc],float)
    if not np.isfinite(x).all() or not 0<=I<=1 or min(x[1:])<0:raise ValueError('required finite nonnegative components; I in [0,1]')
    return {'overlap':1/I-1 if I>0 else np.inf,'bottom':Sb**2/32,
            'direction':1.5*D**2/(D**2+37.5),'global':(Hm/.8)**2,'local':(Hc/.25)**2}

def score(I,Sb,D,Hm,Hc,alpha=1.):
    if not np.isfinite(alpha) or alpha<0:raise ValueError('negative/nonfinite direction coefficient')
    p=terms(I,Sb,D,Hm,Hc)
    return float(100*I/(1+I*(p['bottom']+alpha*p['direction']+p['global']+p['local'])))

def floor_diagnostic(I,Sb,D):
    # This is an explicitly incomplete floor diagnostic / upper bound, NOT an imputed full quality.
    if not np.isfinite([I,Sb,D]).all() or not 0<=I<=1 or min(Sb,D)<0:raise ValueError('floor inputs invalid')
    k=Sb**2/32+1.5*D**2/(D**2+37.5)
    return float(100*I/(1+I*k))

def shapley_deductions(p):
    if not all(np.isfinite(list(p.values()))):raise ValueError('finite terms required')
    out=dict.fromkeys(p,0.);orders=list(permutations(p))
    for order in orders:
        s=0.;q=100.
        for k in order:
            s+=p[k];nq=100/(1+s);out[k]+=q-nq;q=nq
    return {k:v/len(orders) for k,v in out.items()}

def nested_new_iou_bounds(old_iou,relative_area):
    """Exact partial-identification bounds for N subset G; no routing is inferred."""
    t,r=float(old_iou),float(relative_area)
    if not 0<=t<=1 or not 0<r<=1:raise ValueError('I in [0,1], area ratio in (0,1] required')
    return max(0.,t+r-1), min(1.,t/r,r/t) if t>0 else 0.
