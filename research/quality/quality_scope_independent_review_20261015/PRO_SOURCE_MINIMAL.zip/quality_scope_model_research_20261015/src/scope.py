"""Floor-only two-reference audit. Routing uses distinguishing boundary, NEVER final Q.
Uncertain routing, archival input status and ceiling missingness are retained.
"""
import json
import numpy as np
import pandas as pd
from shapely.geometry import Point
from geometry import project,erp_triples,polygon,iou,direction,bottom_distance,height_components,prism_iou,angles
from model import floor_diagnostic,score

def routing(a,old,new,image):
    A,G,N=polygon(a),polygon(old),polygon(new)
    cap=G.difference(N);coverage=A.intersection(cap).area/cap.area
    common=G.intersection(N)
    out={'distinguishing_old_only_coverage':coverage,
         'common_floor_recall':A.intersection(common).area/common.area,
         'outside_both_area_fraction':A.difference(G.union(N)).area/A.area}
    if image.startswith('B6'):
        # The old footprint has a side extension; all recovered rings have four corners.
        out.update(route='new_corridor_family' if coverage<.25 and len(a)==4 else 'unresolved_family',
                   route_basis='side-extension coverage and absence of its two turns; not maximum Q',
                   route_boundary_margin=None,distinguishing_endpoint_z=None,
                   routing_is_visual_adjudication=False,
                   scope_caveat='Far corridor endpoint exceeds both supplied references; no third reference is approved.')
    else:
        # The old and new stopping walls cross the ERP seam. The final-to-first edge
        # is the declared same wall in these archived ordered rings, including 5/6-corner ones.
        z=np.asarray(a)[[0,-1],1];og=float(np.max(np.asarray(old)[:,1]));ng=float(np.max(np.asarray(new)[:,1]))
        t=(z-ng)/(og-ng);lo,hi=min(t),max(t)
        route='old_far_stop_family' if lo>.5 else ('new_near_stop_family' if hi<.5 else 'mixed_stop_unresolved')
        margin=min(abs(t-.5)) if route!='mixed_stop_unresolved' else 0.
        out.update(route=route,route_basis='both seam-edge endpoint distances to the two frozen stop planes; not maximum Q',
                   route_boundary_margin=float(margin),distinguishing_endpoint_z=json.dumps(z.tolist()),
                   routing_is_visual_adjudication=False,scope_caveat='Family compatibility is not a finding that other walls or the stop are correct.')
    return out

def run_scope(inp,out):
    coords=json.loads((inp/'archival_geometry_28.json').read_text())
    delta=json.loads((inp/'TWO_IMAGE_SCOPE_DELTA.json').read_text())['records']
    old=pd.read_csv(inp/'ALL_REFERENCE_PAIRS_valid.csv')
    rows=[];parity=[];features=[]
    for rid,tr in sorted(coords.items()):
        m=old[old.record_id==rid]
        if len(m)!=1:raise ValueError('Target must have a unique prior binding: '+rid)
        m=m.iloc[0];d=next(i for i in delta if i['image_code']==m.image_code)
        g,gh=project(erp_triples(d['original_reference_points_1024x512']));new=np.asarray(d['new_floor_polygon_xz_h']);a,ah=project(tr)
        if not np.allclose(g,d['original_reference_floor_xz_h'],atol=1e-12):raise ValueError('projection convention mismatch')
        D=direction(a);I=iou(a,g);SB=bottom_distance(a,g);Hm,Hc=height_components(a,ah,g,gh)
        raw=100*prism_iou(a,ah,g,gh);WQ=score(I,SB,D,Hm,Hc);NI=iou(a,new);NSB=bottom_distance(a,new)
        r={k:m[k] for k in ['record_id','object_id','image_id','image_code','worker_id','condition','stage','reference_id','original_holdout','personnel_barriers','context_barriers','role','use_layers']}
        route=routing(a,g,new,m.image_code);which=route['route']
        candidate=d['new_floor_candidate_id'] if which.startswith('new_') else (d['original_reference_object_id'] if which.startswith('old_') else None)
        r.update(route,new_floor_reference_id=d['new_floor_candidate_id'],provisional_family_reference_id=candidate,
                 old_reference_status='retained_original_not_newly_confirmed',new_top_status='pending_no_height_transplant',
                 canonical_current_array_identity_verified=False,archival_measurement_reconciled=True,
                 candidate_contains_camera=polygon(a).covers(Point(0,0)),
                 routing_threshold_sensitivity_review_required=bool((m.image_code.startswith('B6') and route['distinguishing_old_only_coverage']>=.1) or (m.image_code.startswith('Uw') and which=='new_near_stop_family' and route['route_boundary_margin']<.4)),
                 prior_ring_confirmed=bool(m.image_code.startswith('B6')),formal_eligibility_newly_granted=False,
                 adopted_full_score=None,adopted_full_score_status='not_published_without_current_array_and_scope_validation',
                 new_WQ_full=None,new_IoU3D100=None,
                 old_IoU2D100=100*I,new_IoU2D100=100*NI,old_Sb_deg=SB,new_Sb_deg=NSB,D_deg=D,
                 prior_WQ_replayed=WQ,prior_IoU3D100_replayed=raw,
                 old_floor_diagnostic=floor_diagnostic(I,SB,D),new_floor_diagnostic=floor_diagnostic(NI,NSB,D),
                 new_full_WQ_upper_bound=floor_diagnostic(NI,NSB,D),new_full_WQ_lower_bound=0.,
                 floor_diagnostic_is_full_quality=False,old_Hm=Hm,old_Hc=Hc,
                 point_pairs=len(tr),candidate_floor_area=polygon(a).area,
                 new_floor_recall=polygon(a).intersection(polygon(new)).area/polygon(new).area,
                 new_floor_precision=polygon(a).intersection(polygon(new)).area/polygon(a).area)
        rows.append(r)
        parity.append(dict(record_id=rid,I=I-m.iou_2d,Sb=SB-m.S_bottom_deg,D=D-m['dir'],Hm=Hm-m.Hmean,Hc=Hc-m.Hcenter,WQ=WQ-m.WQ,IoU3D100=raw-m.IoU3D100))
        features.append(dict(record_id=rid,image_code=m.image_code,candidate_floor=a.tolist(),heights=ah.tolist(),interior_angles=angles(a).tolist(),old_floor=g.tolist(),new_floor=new.tolist(),original_reference_id=m.reference_id,new_floor_id=d['new_floor_candidate_id'],route=which))
    df=pd.DataFrame(rows);df.to_csv(out/'two_image_floor_updates_28.csv',index=False)
    pd.DataFrame(parity).to_csv(out/'geometry_reproduction_parity_28.csv',index=False)
    (out/'two_image_geometries.json').write_text(json.dumps(features,indent=2))
    # No zero-filled missing 8 rows. Their IDs/conditions have not been established.
    coverage={'expected_current_submissions':36,'archival_submissions_recovered':28,'current_loader_executed':False,
        'current_arrays_identity_checked':0,'all_28_previous_metrics_reproduced':bool(np.max(np.abs(pd.DataFrame(parity).drop(columns='record_id').values))<1e-9),
        'unrecovered_submissions':8,'unrecovered_record_ids':None,'unrecovered_condition':None,
        'images_available':0,'new_full_3d_scores_validated':0,'floor_comparisons':56,
        'comparisons_not_independent_submissions':True,'routing':'provisional geometry compatibility, not final image adjudication',
        'route_counts':df.groupby(['image_code','route']).size().to_dict()}
    coverage['route_counts']=[{'image_code':k[0],'route':k[1],'n':int(v)} for k,v in coverage['route_counts'].items()]
    (out/'scope_coverage.json').write_text(json.dumps(coverage,indent=2))
    return df
