import json
import numpy as np
import pandas as pd
from geometry import polygon,direction,bottom_distance
from model import nested_new_iou_bounds

def inverse_floor(x,z):
    u=np.arctan2(x,-z);v=np.arctan2(1,np.hypot(x,z))
    return float((u/(2*np.pi)+.5)*1024%1024),float((v/np.pi+.5)*512)

def supplement(inp,out):
    delta=json.loads((inp/'TWO_IMAGE_SCOPE_DELTA.json').read_text())['records']
    d=pd.read_csv(out/'two_image_floor_updates_28.csv');req=[];bounds=[];sensitivity=[]
    for s in delta:
        G,N=polygon(s['original_reference_floor_xz_h']),polygon(s['new_floor_polygon_xz_h']);n0=N.intersection(G)
        r=n0.area/G.area;eps=1-n0.area/N.area
        for i,(x,z) in enumerate(s['new_floor_polygon_xz_h']):
            xp,yp=inverse_floor(x,z)
            req.append(dict(image_code=s['image_code'],new_floor_id=s['new_floor_candidate_id'],vertex=i,x_h=x,z_h=z,erp_x=xp,erp_floor_y=yp,
                            missing_top_y=None,requires_redrawing_floor=False,
                            request='Confirm corresponding top boundary and whether the new closure shares the original main ceiling; preserve physical wall versus protocol closure. Do not infer top_y from old GT.',
                            priority='new closure endpoint' if (s['image_code'].startswith('Uw') and i in [0,1]) or (s['image_code'].startswith('B6') and i==1) else 'Confirm continued top on retained boundary; no floor redraw'))
        for _,row in d[d.image_code==s['image_code']].iterrows():
            lo,hi=nested_new_iou_bounds(row.old_IoU2D100/100,r)
            bounds.append(dict(record_id=row.record_id,image_code=s['image_code'],lower=max(0,lo-eps),upper=min(1,hi+eps),actual_new_I=row.new_IoU2D100/100,
                               near_nested_sliver_allowance=eps,not_a_point_estimate=True))
        for gap in [.1,.25,.4]:
            b=d[d.image_code==s['image_code']]
            if s['image_code'].startswith('B6'):
                sensitivity.append(dict(image_code=s['image_code'],rule='branch_coverage_below_threshold',threshold=gap,assigned_new=int((b.distinguishing_old_only_coverage<gap).sum()),unresolved=int((b.distinguishing_old_only_coverage>=gap).sum())))
            else:
                # Here gap is a safety margin away from the midpoint in normalized plane distance.
                definite=(b.route!='mixed_stop_unresolved')&(b.route_boundary_margin>=gap)
                sensitivity.append(dict(image_code=s['image_code'],rule='both_endpoint_same_side_and_margin',threshold=gap,assigned_new=int((definite&(b.route=='new_near_stop_family')).sum()),assigned_old=int((definite&(b.route=='old_far_stop_family')).sum()),unresolved=int((~definite).sum())))
    pd.DataFrame(req).to_csv(out/'top_boundary_missing_locations.csv',index=False)
    pd.DataFrame(bounds).to_csv(out/'partial_identification_bounds.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(out/'routing_sensitivity.csv',index=False)
