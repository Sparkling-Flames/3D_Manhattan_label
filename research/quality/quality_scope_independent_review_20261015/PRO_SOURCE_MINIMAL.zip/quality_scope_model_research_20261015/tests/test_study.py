"""Tests of mathematics, representation and the explicitly limited data contract."""
import sys,json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from geometry import polygon,project,erp_triples,direction,iou,bottom_distance,height_mean,height_components,prism_iou,angles
from model import terms,score,floor_diagnostic,shapley_deductions,nested_new_iou_bounds
from scope import routing
from empirical import attach_scores
G=np.array([[-2.,-2],[2,-2],[2,2],[-2,2]])

@pytest.mark.parametrize('I,expected',[(0,0),(1,100),(.5,50)])
def test_baseline_overlap(I,expected):assert score(I,0,0,0,0)==expected
@pytest.mark.parametrize('x',[(np.nan,0,0,0,0),(1,-1,0,0,0),(1.1,0,0,0,0),(1,0,np.inf,0,0),(1,0,0,np.nan,0)])
def test_invalid_components(x):
    with pytest.raises(ValueError):score(*x)
def test_negative_alpha_rejected():
    with pytest.raises(ValueError):score(.8,1,1,.1,.1,-1)
def test_equivalent_reciprocal():
    p=terms(.74,1.7,4.5,.11,.08)
    assert score(.74,1.7,4.5,.11,.08)==pytest.approx(100/(1+sum(p.values())))
def test_gradient_overlap():
    I=.7;v=[2.,5.,.2,.1];h=1e-6;p=terms(I,*v);K=sum(p[k] for k in ['bottom','direction','global','local'])
    numerical=(score(I+h,*v)-score(I-h,*v))/(2*h)
    assert numerical==pytest.approx(100/(1+I*K)**2,rel=1e-7)
def test_direction_drop_closed_form():
    I=.7;Sb=2;D=5;Hm=.2;Hc=.1;p=terms(I,Sb,D,Hm,Hc)
    a=1/I+p['bottom']+p['global']+p['local'];d=p['direction']
    assert score(I,Sb,D,Hm,Hc,0)-score(I,Sb,D,Hm,Hc)==pytest.approx(100*d/(a*(a+d)))
def test_shapley_conserves_loss():
    p=terms(.7,2,5,.2,.1)
    assert sum(shapley_deductions(p).values())==pytest.approx(100-score(.7,2,5,.2,.1))
def test_floor_is_upper_bound_not_height_imputation():
    assert score(.6,2,4,.3,.2)<floor_diagnostic(.6,2,4)
def test_fixed_components_monotonic():
    assert score(.7,2,3,.1,.05)<score(.8,2,3,.1,.05)
    assert score(.8,2,8,.1,.05)<score(.8,2,3,.1,.05)
def test_geometry_identity():
    assert iou(G,G)==pytest.approx(1);assert direction(G)<1e-10;assert bottom_distance(G,G)<1e-10
@pytest.mark.parametrize('degrees',[1,15,43,89])
def test_direction_rotation_invariant(degrees):
    t=np.radians(degrees);a=G@np.array([[np.cos(t),np.sin(t)],[-np.sin(t),np.cos(t)]])
    assert direction(a)<1e-10;assert iou(a,G)<1
@pytest.mark.parametrize('angle',[75,45,15,1])
def test_direction_family_folding(angle):
    t=np.radians(angle);a=G@np.array([[1.,0],[np.cos(t),np.sin(t)]])
    assert direction(a)==pytest.approx(min(angle,90-angle)/2,abs=1e-10)
def test_nonorthogonal_self_not100():
    a=G@np.array([[1.,0],[.05,1.]])
    assert score(1,0,direction(a),0,0)<100
    assert iou(a,a)==1

def test_valid_concavity():
    a=np.array([[-2,-2],[2,-2],[2,0],[0,0],[0,2],[-2,2]])
    assert 270 in angles(a);assert direction(a)<1e-10
    assert np.allclose(sorted(angles(a)),sorted(angles(a[::-1])))
def test_common_height_shift_only_global():
    h=np.full(4,2.);hm,hc=height_components(G,h*1.2,G,h)
    assert hm==pytest.approx(.2);assert hc<1e-12

def test_surface_subdivision_preserves_integral_not_vertex_mean():
    h=np.array([1.8,1.8,2.2,2.2]);a=np.insert(G,1,(G[0]+G[1])/2,axis=0);ah=np.insert(h,1,1.8)
    assert height_mean(a,ah)==pytest.approx(height_mean(G,h))
    assert height_components(a,ah,G,np.full(4,2))==pytest.approx(height_components(G,h,G,np.full(4,2)),abs=1e-10)
    assert prism_iou(a,ah,G,np.full(4,2))!=pytest.approx(prism_iou(G,h,G,np.full(4,2)))
def test_partial_identification_bounds_random_sets():
    rng=np.random.default_rng(1031);ground=np.arange(1000)<600;new=np.arange(1000)<350;r=new.sum()/ground.sum()
    for _ in range(300):
        a=rng.random(1000)<rng.uniform(.02,.99);old_i=(a&ground).sum()/(a|ground).sum();ni=(a&new).sum()/(a|new).sum()
        lo,hi=nested_new_iou_bounds(old_i,r);assert lo-1e-12<=ni<=hi+1e-12

def test_missing_score_stays_missing():
    a=pd.DataFrame([dict(iou_2d=.9,S_bottom_deg=1,dir=2,Hmean=np.nan,Hcenter=.1)])
    assert attach_scores(a).filter(regex='Q_alpha').isna().all().all()

def test_only_two_scope_deltas():
    d=json.loads((ROOT/'inputs/TWO_IMAGE_SCOPE_DELTA.json').read_text())['records']
    assert {x['image_code'] for x in d}=={'B6ByNegPMKs-37','UwV83HsGsw3-10'}
    for x in d:
        old,_=project(erp_triples(x['original_reference_points_1024x512']))
        assert np.allclose(old,x['original_reference_floor_xz_h'],atol=1e-12)
        assert x['top_boundary_pending'] is True;assert x['reference_ready'] is False

def test_actual_archival_parity():
    d=pd.read_csv(ROOT/'results/geometry_reproduction_parity_28.csv');assert len(d)==28
    assert d.drop(columns='record_id').abs().max().max()<1e-9

def test_new_scope_full_missing_and_unique():
    d=pd.read_csv(ROOT/'results/two_image_floor_updates_28.csv');assert len(d)==d.record_id.nunique()==28
    assert d[['new_WQ_full','new_IoU3D100','adopted_full_score']].isna().all().all()
    assert not d.canonical_current_array_identity_verified.any();assert not d.formal_eligibility_newly_granted.any()

def test_partial_bounds_contain_computed():
    d=pd.read_csv(ROOT/'results/partial_identification_bounds.csv')
    assert ((d.actual_new_I>=d.lower-1e-12)&(d.actual_new_I<=d.upper+1e-12)).all()

def test_feedback_not_blind_or_training():
    h=pd.read_csv(ROOT/'results/human_44_rescores.csv');assert len(h)==44
    assert not h.blind_validation.any();assert h.scope_revision_hold.sum()==2
    assert h[h.phase=='ordinary'].score_revealed.sum()==16
    assert h[h.phase=='ordinary'].grade_changed_after_reveal.sum()==6

def test_multiple_references_not_independent_workers():
    p=pd.read_csv(ROOT/'results/available_pair_rescores_276.csv');assert len(p)==276;assert p.record_id.nunique()==252
    assert (p.groupby('record_id').size()>1).sum()==24

def test_fusion_coverage_not_claimed_refusion():
    f=pd.read_csv(ROOT/'results/fusion_220_rescores.csv');assert len(f)==220
    assert (f.status=='complete').sum()==144;assert (f.status=='floor_only').sum()==1
    assert f.loc[f.status!='complete','Q_alpha_1p0'].isna().all()

def test_failed_matching_not_claimed_success():
    x=json.loads((ROOT/'results/matched_overlap_boundary_counterexample.json').read_text())
    assert x['exact_match_succeeded'] is False

def test_receipt_declares_limits():
    x=json.loads((ROOT/'results/RUN_RECEIPT.json').read_text())
    assert x['full_current36_completed'] is False;assert x['current3152_loader_executed'] is False
    assert x['raw_images_reviewed']==0;assert x['weights_fitted_to_human_feedback'] is False
