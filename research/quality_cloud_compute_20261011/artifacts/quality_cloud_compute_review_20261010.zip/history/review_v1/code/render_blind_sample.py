"""Render small review sample from real photo bytes; do not batch expand."""
import math,json,sys,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from common import read,save,sha
ROOT=Path(__file__).resolve().parents[1]
COLORS=['#ff6900','#0099ff']
REF='#58d05d'

def erp(xyz):
    p=np.asarray(xyz);r=np.hypot(p[:,0],p[:,2])
    x=np.mod(np.arctan2(-p[:,0],p[:,2])/(2*np.pi),1)
    y=.5-np.arctan2(p[:,1],r)/np.pi
    return np.column_stack([x,y])

def pano_lines(ax,g,color,w=1.4,floor_only=False):
    if floor_only:loops=[np.asarray(g['bottom3d'])]
    else:loops=[np.asarray(g[k]) for k in ['bottom3d','top3d']]
    for loop in loops:
        for i in range(len(loop)):
            points=loop[i]+np.linspace(0,1,161)[:,None]*(loop[(i+1)%len(loop)]-loop[i])
            uv=erp(points);breaks=np.r_[0,np.flatnonzero(abs(np.diff(uv[:,0]))>.5)+1,len(uv)]
            for start,end in zip(breaks[:-1],breaks[1:]):
                if end-start>=2:ax.plot(uv[start:end,0],uv[start:end,1],color=color,lw=w)
    if not floor_only:
        for t,b in zip(g['top3d'],g['bottom3d']):
            uv=erp([t,b]);ax.plot(uv[:,0],uv[:,1],color=color,lw=w*.8)

def bev(ax,g,color,label):
    x=np.asarray(g['bottom3d'])[:,[0,2]];x=np.vstack([x,x[0]]);ax.plot(x[:,0],x[:,1],color=color,lw=1.8,label=label);ax.scatter(x[:-1,0],x[:-1,1],s=9,color=color)

def wire(ax,g,color,floor_only=False):
    for key in ['bottom3d'] if floor_only else ['bottom3d','top3d']:
        x=np.asarray(g[key]);x=np.vstack([x,x[0]]);ax.plot(x[:,0],x[:,2],x[:,1],color=color,lw=1.3)
    if not floor_only:
        for b,t in zip(g['bottom3d'],g['top3d']):ax.plot([b[0],t[0]],[b[2],t[2]],[b[1],t[1]],color=color,lw=1)

def main():
    cases=read(ROOT/'blind_sample/answer_mapping_private.json')
    geo=read(ROOT/'inputs/current_geometry.json')['geometries']
    confirmed=read('/workspace/quality_recovered_20261010/quality_scope_review_complete_20261010/final_scope_reference_integration/inputs/normalized_confirmation_overlay.json')['records']
    registry=read('/workspace/quality_recovered_20261010/quality_scope_review_complete_20261010/final_scope_reference_integration/results/reference_registry.json')['records']
    user=ROOT/'blind_sample/user';user.mkdir(exist_ok=True)
    manifest=[]
    for c in cases:
        im=Image.open(c['photo_path']);im.load();im=np.asarray(im.convert('RGB'))
        a=geo[c['object_1']];g=geo[c['reference_object_id']]
        cross=c['case_id']=='X01'
        items=[a,geo[c['object_2']]] if not cross else [a]
        fig=plt.figure(figsize=(16,18));gs=fig.add_gridspec(4,2,height_ratios=[.8,.9,1,1.1],hspace=.4,wspace=.12)
        ax=fig.add_subplot(gs[0,:]);ax.imshow(im,extent=[0,1,1,0]);ax.set_aspect(.5);ax.set_axis_off();ax.set_title(c['case_id']+' | Historical material | Original pixels',fontsize=13)
        if cross:
            conf=next(r for r in confirmed if r['image_code']==c['image_code'])
            B={'bottom3d':[[x,-1,z] for x,z in conf['polygon']]}
            Areg=next(r for r in registry if r['image_code']==c['image_code'])
            other=B
            labels=['Annotation + A reference','Annotation + B floor (top pending)']
        else:
            other=g;labels=['Alternative 1','Alternative 2']
        points=np.vstack([np.asarray(z['bottom3d']) for z in [*items,g,other]])
        lo=points[:,[0,2]].min(axis=0);hi=points[:,[0,2]].max(axis=0);center=(lo+hi)/2;span=max(hi-lo)*1.15
        tops=[np.asarray(z.get('top3d',z['bottom3d'])) for z in [*items,g]]
        all3=np.vstack([points,*tops]);min3=all3.min(axis=0);max3=all3.max(axis=0);ctr=(min3+max3)/2;span3=max(max3-min3)*1.1
        for j in range(2):
            annotation=items[j] if not cross else a
            reference=other if cross and j==1 else g
            color=COLORS[j] if not cross else COLORS[0]
            ax=fig.add_subplot(gs[1,j]);ax.imshow(im,extent=[0,1,1,0]);ax.set_aspect(.5);pano_lines(ax,reference,REF,floor_only=cross and j==1);pano_lines(ax,annotation,color);ax.set_axis_off();ax.set_title(labels[j]+' | green: reference',fontsize=10)
            ax=fig.add_subplot(gs[2,j]);bev(ax,reference,REF,'Reference floor');bev(ax,annotation,color,'Annotation');ax.set_xlim(center[0]-span/2,center[0]+span/2);ax.set_ylim(center[1]-span/2,center[1]+span/2);ax.set_aspect('equal');ax.scatter([0],[0],marker='+',color='black');ax.grid(alpha=.2);ax.set_title('BEV | identical scale');ax.set_xlabel('x / camera height');ax.set_ylabel('z / camera height')
            ax=fig.add_subplot(gs[3,j],projection='3d');wire(ax,reference,REF,floor_only=cross and j==1);wire(ax,annotation,color);ax.set_xlim(ctr[0]-span3/2,ctr[0]+span3/2);ax.set_ylim(ctr[2]-span3/2,ctr[2]+span3/2);ax.set_zlim(ctr[1]-span3/2,ctr[1]+span3/2);ax.set_box_aspect([1,1,1]);ax.view_init(elev=24,azim=-60);ax.set_title('3D | identical scale'+(' | B floor only' if cross and j==1 else ''));ax.set_xlabel('x / h');ax.set_ylabel('z / h');ax.set_zlabel('y / h')
        fig.subplots_adjust(top=.97,bottom=.035)
        dest=user/(c['case_id']+'.jpg');fig.savefig(dest,dpi=125);plt.close(fig)
        raw=user/(c['case_id']+'_original.jpg');shutil.copyfile(c['photo_path'],raw)
        manifest.append({'case_id':c['case_id'],'rendered_path':str(dest.relative_to(ROOT/'blind_sample')),'rendered_sha256':sha(dest),'original_path':str(raw.relative_to(ROOT/'blind_sample')),'photo_sha256':sha(c['photo_path']),'photo_size':list(im.shape[:2][::-1]),'real_pixels_loaded':True,'sample_only':True,'B_top_created':False,'labels_contain_Q_worker_formula':False})
        print(c['case_id'],dest.stat().st_size,flush=True)
    shutil.copyfile(ROOT/'blind_sample/user_response_blank.csv',user/'responses.csv')
    html='<!doctype html><meta charset="utf-8"><title>盲评小样</title><style>body{font:16px sans-serif;max-width:1100px;margin:30px auto;line-height:1.6}img{max-width:100%}section{margin:40px 0}textarea{width:95%;min-height:80px}label{display:block}</style><h1>几何比较小样</h1><p>全部来自历史材料；不称未见验证。请结合真实照片、同尺度BEV和3D判断两份标注优劣。绿色为现有参考。Q、公式与人员身份隐藏；参考仍可能有语义或模型局限，无法判断时请选择不确定。</p><p>请选择：1更好 / 2更好 / 相近 / 不确定；差距：小 / 中 / 大；主要原因由您填写。填写栏为空，不预填结论。X01单列为跨空间诊断，B只有批准底面，顶界仍待定，不比较B完整3D质量。</p>'
    for m in manifest:
        html+=f'<section><h2>{m["case_id"]}</h2><a href="{m["case_id"]}_original.jpg">查看原图</a><img src="{m["case_id"]}.jpg"><label>优劣：<select><option value="">请选择</option><option>1更好</option><option>2更好</option><option>相近</option><option>不确定</option></select></label><label>差距：<select><option value="">请选择</option><option>小</option><option>中</option><option>大</option></select></label><label>主要原因及不确定性：<textarea></textarea></label></section>'
    html+='<p>本页输入不自动保存；正式回执请填写同目录responses.csv。</p>';(user/'index.html').write_text(html)
    save(ROOT/'blind_sample/render_manifest.json',manifest)
if __name__=='__main__':main()
