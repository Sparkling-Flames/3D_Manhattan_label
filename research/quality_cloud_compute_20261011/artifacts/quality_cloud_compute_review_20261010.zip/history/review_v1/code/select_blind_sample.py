from pathlib import Path
from collections import defaultdict
import csv,itertools
from common import read,save,csvwrite,digest
ROOT=Path(__file__).resolve().parents[1]
ASSETS=Path('/workspace/quality_recovered_20261010/quality_scope_review_complete_20261010/workbench_v3.4.2/dist/assets')

def main():
    rows=read(ROOT/'results/current_components.json');geo=read(ROOT/'inputs/current_geometry.json')['geometries']
    groups=[];eligible=[];holdout=[]
    for r in rows:
        room=r['building_id']+':'+(r['room_id'] or r['image_id']);held=int(digest(room)[:8],16)%5==0
        groups.append({'record_id':r['record_id'],'image_code':r['image_code'],'room_group':room,'room_id_missing':not bool(r['room_id']),'held_out_of_sample_and_future_calibration':held,'historically_unseen_claimed':False})
        if held:holdout.append(r['record_id']);continue
        if not (r['primary_included'] and r['Manhattan_applicability_group']=='ordinary_scene_supports_Manhattan'):continue
        g=geo[r['reference_object_id']];ys=[p[1] for p in g.get('top3d') or []]
        if not ys or max(ys)-min(ys)>=.01 or not (ASSETS/(r['image_code']+'.jpg')).exists():continue
        eligible.append(r)
    lookup={r['record_id']:r for r in eligible};byim=defaultdict(list)
    for r in eligible:byim[r['image_code']].append(r)
    chosen=[];usedrooms=set()
    def add(kind,a,b):
        room=a['building_id']+':'+(a['room_id'] or a['image_id'])
        if room in usedrooms:return False
        idx=len(chosen)+1;cid=f'C{idx:02d}';pair=[a,b]
        if int(digest(cid)[:8],16)%2:pair.reverse()
        chosen.append({'case_id':cid,'selection_stratum':kind,'image_code':a['image_code'],'room_group':room,'record_1':pair[0]['record_id'],'record_2':pair[1]['record_id'],'object_1':pair[0]['object_id'],'object_2':pair[1]['object_id'],'reference_object_id':a['reference_object_id'],'Q1':pair[0]['Q'],'Q2':pair[1]['Q'],'worker_1':pair[0]['worker_id'],'worker_2':pair[1]['worker_id'],'photo_path':str(ASSETS/(a['image_code']+'.jpg')),'historical_exposure':'historical_archive_or_prior_review_no_independent_blind_claim'})
        usedrooms.add(room);return True
    predicates=[('mild_geometry',lambda r:r['iou_2d']>=.8 and r['boundary_rms_deg']<=2 and r['Hstar']<=.1 and r['dir']<=3 and r['flat']<=1.2),('clear_geometry_difference',lambda r:.5<=r['iou_2d']<.85 and 2<=r['boundary_rms_deg']<6),('severe_geometry',lambda r:r['iou_2d']<=.5 or r['boundary_rms_deg']>=8 or r['dir']>=10)]
    for kind,pred in predicates:
        done=False
        for code,rs in sorted(byim.items()):
            selected=sorted([r for r in rs if pred(r)],key=lambda r:r['record_id'])
            for a,b in itertools.combinations(selected,2):
                if a['reference_object_id']==b['reference_object_id'] and add(kind,a,b):done=True;break
            if done:break
    flips=list(csv.DictReader(open(ROOT/'results/real_same_image_rank_flips.csv',encoding='utf-8-sig')))
    fs=[f for f in flips if f['family']=='constant_alpha' and f['strength']=='0.3' and f['main_Manhattan_pair']=='True']
    for f in sorted(fs,key=lambda f:(abs(float(f['crossing_strength'])-.3),f['image_code'],f['record_1'],f['record_2'])):
        if f['record_1'] in lookup and f['record_2'] in lookup and add('ranking_conflict_alpha30',lookup[f['record_1']],lookup[f['record_2']]):break
    roots=list(csv.DictReader(open(ROOT/'results/band_crossing_roots.csv',encoding='utf-8-sig')))
    rs=[r for r in roots if r['family']=='constant_alpha' and r['root_status']=='in_domain' and r['threshold'] in ['95','85','50'] and r['record_id'] in lookup]
    for root in sorted(rs,key=lambda r:(abs(float(r['root'])-.3),r['image_code'],r['record_id'])):
        a=lookup[root['record_id']]
        bs=sorted([b for b in byim[a['image_code']] if b['record_id']!=a['record_id'] and b['reference_object_id']==a['reference_object_id']],key=lambda r:r['record_id'])
        if bs and add('near_historical_boundary_root',a,bs[0]):break
    margins=read(ROOT/'results/AB_margins_all_events.json')
    weird=[r for r in margins if r['status']=='valid' and r['target_count']==2 and not any(x['restrict_primary'] for x in r['primary_reference_restrictions']) and (ASSETS/(r['image_code']+'.jpg')).exists()]
    weird.sort(key=lambda r:(r.get('mixed_geometry_evidence')!='both_exclusive_regions_intersected',-min(r['A_boundary_rms_h'],r['B_boundary_rms_h']),r['record_id']))
    if weird:
        w=weird[0];source=next(r for r in rows if r['record_id']==w['record_id'])
        chosen.append({'case_id':'X01','selection_stratum':'cross_space_diagnostic_only','image_code':w['image_code'],'record_1':w['record_id'],'object_1':w['object_id'],'reference_object_id':source['reference_object_id'],'photo_path':str(ASSETS/(w['image_code']+'.jpg')),'floor_only_B':True,'top_status':'top_pending','historical_exposure':'historical_review_image','quality_gate':source['worker_quality_gate']})
    save(ROOT/'blind_sample/answer_mapping_private.json',chosen);csvwrite(ROOT/'results/room_holdout_manifest.csv',groups)
    save(ROOT/'blind_sample/selection_audit.json',{'eligible':len(eligible),'held_out_records':len(holdout),'main_sample_cases':sum(c['case_id']!='X01' for c in chosen),'cross_space_cases':sum(c['case_id']=='X01' for c in chosen),'no_user_judgments_filled':True})
    csvwrite(ROOT/'blind_sample/user_response_blank.csv',[{'case_id':c['case_id'],'historical_exposure':'历史材料，非未见验证','judgment_1_better_2_better_similar_uncertain':'','gap_small_medium_large':'','main_reason':'','confidence':'','comments':''} for c in chosen])
    print([{k:c.get(k) for k in ['case_id','selection_stratum','image_code','record_1','record_2']} for c in chosen])
if __name__=='__main__':main()
