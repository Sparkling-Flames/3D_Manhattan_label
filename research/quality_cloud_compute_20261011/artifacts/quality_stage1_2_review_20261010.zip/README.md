# 云端质量空间与惩罚计算交付

先读reports/COMPUTE_HANDOFF_REPORT.md（返修已更新）、reports/STAGE1_2_HANDOFF.md（第一轮历史报告）。这是dot主线程审阅工件，未更改main、正式数据、GT、gate或旧分数。Pro输入已通过指定研究提交取得并核验；原stage13/24和官方IoU当前3152条完整CLI已原样重放。Library输出失败记录保留，源与输出均通过研究分支正常归档。

- inputs/current_geometry_compact.json：当前loader派生、保留既存配对和环的冻结几何。来源与资格见results/current_components.json及source_contract_final.json。
- inputs/scope/：从17分卷精确复制的429记录与35确认快照，用于离线BEV计算；没有新顶界。
- frozen/：原样v1.1、MIT许可和历史控制/审计来源；新适配只在code/。
- results/：逐条分量、A/B距离、所有事件分母、有限惩罚候选、解析临界点与翻转、核验。
- logs/：真实执行；新适配层初次失败也保留，不改冻结核以抹除失败。
- 小样用户版和答案映射分开Library附件；不在此计算包内混入用户盲评版。

RUN_COMMANDS.txt给出独立离线复算入口。数值核验通过不等于人工质量校准完成。

返修入口：python code/target_alignment.py；python code/verify_revision.py。blind_sample/内含私有映射与历史六例来源；用户版ZIP单独交付。若需重渲染，解压用户ZIP到blind_sample/user，render_blind_sample.py会使用其中原图回退，不依赖父线程路径。
