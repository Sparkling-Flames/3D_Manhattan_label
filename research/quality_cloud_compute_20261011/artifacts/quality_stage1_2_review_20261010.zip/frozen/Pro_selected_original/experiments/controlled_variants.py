#!/usr/bin/env python3
"""Finite, objective defect controls; never fit subjective labels or real scores."""
import argparse,copy,hashlib,json,math,sys
from pathlib import Path
import numpy as np
from run_quality import save,csvwrite,variant_scores
from multitarget_controls import geom

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    sys.path.insert(0,str(a.engine/'core'));sys.path.insert(0,str(a.engine/'validity'))
    from quality_v11 import score_geometry
    from replay_strict_validation import cases
    from strict_geometry import validate_record
    a.out.mkdir(parents=True,exist_ok=True);config=json.loads(a.config.read_text())
    strict=[]
    for c in cases():
        before=hashlib.sha256(json.dumps(c['record'],sort_keys=True,allow_nan=True).encode()).hexdigest()
        r=validate_record(c['record'],role=c['role'])
        ok=all(r[k]==c[e] for k,e in [('available','expected_available'),('valid_2d','expected_valid_2d'),('valid_3d','expected_valid_3d')]) and (c['expected_code'] is None or c['expected_code'] in r['reason_codes'])
        after=hashlib.sha256(json.dumps(c['record'],sort_keys=True,allow_nan=True).encode()).hexdigest()
        strict.append({'case_id':c['case'],'passed':ok and before==after,'source_unchanged':before==after,'result':r})
    save(a.out/'strict_constructed_cases.json',strict)
    xz=np.array([[-2.,-1.],[2.,-1.],[2.,1.],[-2.,1.]])
    ref=geom(xz);experiments=[]
    def add(cid,p,g=ref,family=None,severity=0):experiments.append({'case_id':cid,'family':family,'severity':severity,'annotation':p,'reference':g})
    add('perfect',ref,family='identity')
    for shift in [.01,.02,.05,.1,.25,.5,1.]:add('translation_'+str(shift),geom(xz+[shift,0]),family='position',severity=shift)
    for t in [.01,.02,.05,.1,.2,.4]:
        add('height_up_'+str(t),geom(xz,2*(1+t)),family='uniform_height_up',severity=t)
        add('height_down_'+str(t),geom(xz,2*(1-t)),family='uniform_height_down',severity=t)
    for t in [.01,.02,.05,.1,.25,.5]:add('shrink_'+str(t),geom(xz*(1-t)),family='scope_omission',severity=t)
    for degrees in [1.,2.,5.,10.,20.,30.]:
        q=xz.copy();q[:,0]+=math.tan(math.radians(degrees))*q[:,1]
        add('shear_'+str(degrees),geom(q),family='nonmanhattan_shear',severity=degrees)
    for degree in [.2,1,2,5,10,20]:
        t=math.radians(degree);mat=np.array([[math.cos(t),-math.sin(t)],[math.sin(t),math.cos(t)]])
        add('rotation_'+str(degree),geom(xz@mat.T),family='same_shape_wrong_orientation',severity=degree)
    for scale in [1,10,100]:add('cancel_near_far_'+str(scale),geom(xz*scale,[1.01,1.01,2.99,2.99]),geom(xz*scale),family='mean_height_cancellation',severity=scale)
    # Analytic same surface, different point counts. The interpolation is exact.
    base=geom(xz,[1.7,1.8,2.2,2.1])
    for n in [0,1,4,40]:
        ob=copy.deepcopy(base)
        if n:
            for key in ['top3d','bottom3d']:
                q=np.array(ob[key]);pts=[q[0]]+[q[0]+u*(q[1]-q[0]) for u in np.arange(1,n+1)/(n+1)]+list(q[1:]);ob[key]=np.array(pts).tolist()
        add('exact_collinear_'+str(n),ob,family='same_geometry_subdivision',severity=n)
    rows=[];details=[]
    for c in experiments:
        r=score_geometry(c['annotation'],c['reference'],**config['numerical_settings']);m=r['metrics']
        row={'case_id':c['case_id'],'family':c['family'],'severity':c['severity'],'score_status':r['status'],
             'I':m.get('iou_2d'),'official_height_iou':m.get('iou_3d_corner_mean'),'S':m.get('boundary_rms_deg'),
             'Hstar':m.get('Hstar'),'D':m.get('dir'),'F':m.get('flat'),**variant_scores(m,config)}
        rows.append(row);details.append({**c,'result':r})
    checks=[]
    for family in ['position','uniform_height_up','uniform_height_down','scope_omission','nonmanhattan_shear','same_shape_wrong_orientation']:
        rr=sorted([r for r in rows if r['family']==family],key=lambda x:x['severity'])
        for v in config['variants']:
            scores=[r[v['name']] for r in rr];checks.append(dict(test='monotonic_'+family,variant=v['name'],passed=all(y<=x+1e-9 for x,y in zip(scores,scores[1:]))))
    col=[r for r in rows if r['family']=='same_geometry_subdivision']
    for v in config['variants']:
        vals=[r[v['name']] for r in col];checks.append(dict(test='collinear_invariance_this_control',variant=v['name'],passed=max(vals)-min(vals)<1e-8,max_difference=max(vals)-min(vals)))
    checks.append(dict(test='coverage_upper_bound_all_controls',passed=all(r['Q_v11']<=100*r['I']+1e-8 for r in rows)))
    checks.append(dict(test='strict_domain_all_cases',passed=all(r['passed'] for r in strict),n=len(strict)))
    csvwrite(a.out/'controlled_variants.csv',rows);save(a.out/'controls_with_geometries.json',details);save(a.out/'checks.json',checks)
    print('cases',len(rows),'strict',len(strict),'checks',len(checks),'failed',sum(not c['passed'] for c in checks))
    for r in rows:
        if r['case_id'] in ['translation_0.01','translation_1.0','height_up_0.01','shrink_0.5','shear_20.0','cancel_near_far_100']:print(r)
if __name__=='__main__':main()
