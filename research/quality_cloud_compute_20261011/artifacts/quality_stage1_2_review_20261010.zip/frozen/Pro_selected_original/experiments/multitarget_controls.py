#!/usr/bin/env python3
"""Known full-3D synthetic target-policy counterexamples, not invented real GT."""
import argparse,json,sys,math
from pathlib import Path
import numpy as np
from run_quality import csvwrite,save,variant_scores

def geom(xz,height=2):
    xz=np.asarray(xz,float);h=np.broadcast_to(np.asarray(height,float),(len(xz),))
    b=np.c_[xz[:,0],np.full(len(xz),-1.),xz[:,1]];t=b.copy();t[:,1]=h-1
    return {'bottom3d':b.tolist(),'top3d':t.tolist()}
def rect(r,height=2,shift=(0,0)):
    return geom(np.asarray([[-r,-r],[r,-r],[r,r],[-r,r]])+shift,height)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    sys.path.insert(0,str(a.engine/'core'));from quality_v11 import score_geometry
    conf=json.loads(a.config.read_text());a.out.mkdir(parents=True,exist_ok=True)
    families={
      'same_height':{'large':rect(4),'small':rect(2)},
      'different_ceiling':{'large':rect(4,4),'small':rect(2,2)}
    }
    cases=[('exact_large',rect(4),'same_height','large'),
           ('exact_small_valid_task',rect(2),'same_height','small'),
           ('same_small_omitted_large_task',rect(2),'same_height','large'),
           ('small_10pct_inward',rect(1.8),'same_height','small'),
           ('small_25pct_inward',rect(1.5),'same_height','small'),
           ('small_position_error_0p5h',rect(2,shift=(.5,0)),'same_height','small'),
           ('small_position_error_1h',rect(2,shift=(1,0)),'same_height','small'),
           ('intermediate_ambiguous',rect(math.sqrt(8)),'same_height',None),
           ('large_wrong_height',rect(4,2),'different_ceiling','large'),
           ('small_wrong_height',rect(2,4),'different_ceiling','small')]
    rows=[];summ=[];full=[]
    for cid,ann,family,declared in cases:
        rr=[]
        for tid,ref in families[family].items():
            res=score_geometry(ann,ref,**conf['numerical_settings']);assert res['status']=='available'
            m=res['metrics'];row={'case_id':cid,'target_family':family,'declared_target_if_known':declared,
              'target_id':tid,'I_2d':m['iou_2d'],'precision_pred':m['intersection_area_h2']/m['area_h2'],
              'recall_target':m['intersection_area_h2']/m['reference_area_h2'],
              'coverage_of_large':m['area_h2']/64,'S_deg':m['boundary_rms_deg'],'Hstar':m['Hstar'],
              'D_deg':m['dir'],'F_deg':m['flat'],**variant_scores(m,conf)}
            rows.append(row);rr.append(row);full.append({'case_id':cid,'target_id':tid,'annotation':ann,'reference':ref,'result':res})
        gi=max(rr,key=lambda r:r['I_2d']);gq=max(rr,key=lambda r:r['Q_v11'])
        isum=sorted([r['I_2d'] for r in rr],reverse=True)
        summ.append(dict(case_id=cid,declared_target_if_known=declared,target_family=family,
          BEV_argmax_target=gi['target_id'],Q_argmax_target=gq['target_id'],max_I=gi['I_2d'],I_gap=isum[0]-isum[1],
          max_Q=gq['Q_v11'],Q_known_target=next((r['Q_v11'] for r in rr if r['target_id']==declared),None),
          retained_target_count=len(rr),argmax_is_true_intent=False))
    csvwrite(a.out/'all_candidate_target_scores.csv',rows);csvwrite(a.out/'policy_comparison.csv',summ);save(a.out/'full_control_geometries_and_results.json',full)
    A=next(r for r in summ if r['case_id']=='exact_small_valid_task');B=next(r for r in summ if r['case_id']=='same_small_omitted_large_task')
    checks={'same_geometry_same_set_same_max_score':abs(A['max_Q']-B['max_Q'])<1e-12,
      'different_task_intent_has_different_fixed_target_quality':abs(A['Q_known_target']-B['Q_known_target'])>50,
      'scores_never_recover_true_intent':True,'all_full_target_sets_synthetic_only':True,
      'new35_complete_reference_scores_computed':False,
      'at_least_one_BEV_vs_Q_argmax_disagreement':any(r['BEV_argmax_target']!=r['Q_argmax_target'] for r in summ)}
    save(a.out/'checks.json',checks);print(json.dumps(summ,ensure_ascii=False,indent=2));print(checks)
if __name__=='__main__':main()
