#!/usr/bin/env python3
"""Exact unchanged geometry evidence figures: ERP curves, BEV and same-scale3D.
No human score is loaded. Photographs are read as evidence, never generated.
"""
import argparse,json,math
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

PRED='#007c91';REF='#d2502e';FLOOR='#744daf'
def curve_pixels(g,which):
    p=np.array(g[which]);parts=[]
    for aa,bb in zip(p,np.roll(p,-1,axis=0)):
        v=aa[None,:]*(1-np.linspace(0,1,90)[:,None])+bb[None,:]*np.linspace(0,1,90)[:,None]
        u=(np.arctan2(v[:,0],-v[:,2])/(2*np.pi)+.5)*1024
        y=(-np.arctan2(v[:,1],np.linalg.norm(v[:,[0,2]],axis=1))/np.pi+.5)*512
        xy=np.c_[u,y];cuts=np.flatnonzero(abs(np.diff(u))>512)+1;parts.extend(np.split(xy,cuts))
    return parts
def plot_overlay(ax,g,color,label):
    if g.get('bottom3d') is None or g.get('top3d') is None:return
    first=True
    for which in ['bottom3d','top3d']:
        for c in curve_pixels(g,which):
            ax.plot(c[:,0],c[:,1],color=color,lw=1.5,alpha=.93,label=label if first else None);first=False
    pp=g.get('points')
    if pp:
        pp=np.array(pp);valid=(pp[:,1]>=0)&(pp[:,1]<=512)
        ax.scatter(pp[valid,0],pp[valid,1],s=8,c=color,zorder=8)
        for t,b in zip(pp[::2],pp[1::2]):
            if 0<=t[1]<=512 and 0<=b[1]<=512:ax.plot([t[0],b[0]],[t[1],b[1]],color=color,lw=.65,alpha=.5)
def draw3(ax,g,color,limits):
    if g.get('bottom3d') is not None and g.get('top3d') is not None:
        t,b=np.array(g['top3d']),np.array(g['bottom3d'])
        for p in [t,b]:
            q=np.vstack([p,p[0]]);ax.plot(q[:,0],q[:,2],q[:,1],color=color,lw=1.6)
        for tt,bb in zip(t,b):ax.plot([tt[0],bb[0]],[tt[2],bb[2]],[tt[1],bb[1]],color=color,lw=.8)
    else:ax.text2D(.2,.5,'Unavailable: retain original input',transform=ax.transAxes,fontsize=9)
    ax.set(xlim=limits[0],ylim=limits[1],zlim=limits[2],xlabel='X / h',ylabel='Z / h',zlabel='Y / h')
    sizes=[hi-lo for lo,hi in limits];ax.set_box_aspect(sizes);ax.view_init(elev=27,azim=-54)
    ax.tick_params(labelsize=7);ax.scatter([0],[0],[0],c='black',s=12)
def render(row,g,ref,photo,path,scope=None):
    fig=plt.figure(figsize=(14,9.6),layout='constrained');gs=fig.add_gridspec(2,3,height_ratios=[1.1,1])
    ax=fig.add_subplot(gs[0,:]);ax.imshow(Image.open(photo),extent=(0,1024,512,0));plot_overlay(ax,ref,REF,'Fixed selected GT');plot_overlay(ax,g,PRED,'Annotation')
    sf=None
    if scope is not None:
        q=np.array(scope['floor_xz_h']);sf={'bottom3d':np.c_[q[:,0],-np.ones(len(q)),q[:,1]].tolist()}
        first=True
        for c in curve_pixels(sf,'bottom3d'):
            ax.plot(c[:,0],c[:,1],color=FLOOR,lw=2,ls='--',label='Confirmed primary FLOOR ONLY' if first else None);first=False
    ax.set(xlim=(0,1024),ylim=(512,0),xticks=[],yticks=[]);ax.legend(loc='upper left',ncol=3 if sf else 2,fontsize=9)
    bv=fig.add_subplot(gs[1,0]);allp=[]
    for geo,col,lab in [(ref,REF,'Fixed selected GT'),(g,PRED,'Annotation')]:
        if geo.get('bottom3d') is None:continue
        p=np.array(geo['bottom3d']);q=np.vstack([p,p[0]]);bv.plot(q[:,0],q[:,2],c=col,lw=1.8,label=lab);bv.scatter(p[:,0],p[:,2],s=12,c=col)
        if geo.get('top3d') is not None:allp.extend([p,np.array(geo['top3d'])])
    if sf:
        q=np.array(sf['bottom3d']);q=np.vstack([q,q[0]]);bv.plot(q[:,0],q[:,2],c=FLOOR,lw=2,ls='--',label='New primary FLOOR ONLY');allp.append(q)
    bv.scatter([0],[0],marker='x',c='black',s=25);bv.set_aspect('equal','box');bv.grid(alpha=.2);bv.set(xlabel='X / h',ylabel='Z / h',title='BEV: same footprint coordinates')
    pp=np.concatenate(allp) if allp else np.array([[-1,-1,-1],[1,1,1]])
    limits=[]
    for k in [0,2,1]:
        lo=min(pp[:,k].min(),0);hi=max(pp[:,k].max(),0);pad=max((hi-lo)*.06,.06);limits.append((lo-pad,hi+pad))
    a3=fig.add_subplot(gs[1,1],projection='3d');b3=fig.add_subplot(gs[1,2],projection='3d');draw3(a3,g,PRED,limits);draw3(b3,ref,REF,limits)
    a3.set_title('Annotation: conditional 3D',fontsize=11);b3.set_title('Selected GT: identical 3D scale',fontsize=11)
    if sf:
        q=np.array(sf['bottom3d']);q=np.vstack([q,q[0]]);b3.plot(q[:,0],q[:,2],q[:,1],c=FLOOR,lw=2,ls='--')
        b3.set_title('Old selected GT + new floor (top pending)',fontsize=10)
    def fmt(k):v=row.get(k);return 'NA' if pd.isna(v) else f'{v:.2f}'
    fig.suptitle(f"{row['image_code']}  /  {row['record_id']}  /  GT {row['selected_gt_record_id']}\nQ v1.1={fmt('Q_v11')}    alpha45={fmt('Q_alpha45')}    stage13={fmt('Q_stage13')}    I={fmt('iou_2d')}    S={fmt('S_deg')} deg    D={fmt('D_deg')} deg    F={fmt('F_deg')} deg    H*={fmt('Hstar')}",fontsize=12)
    if sf:fig.text(.5,.005,'New primary has no approved top: full target Q is unavailable. Dashed purple is floor only.',ha='center',fontsize=10,color=FLOOR)
    fig.savefig(path,dpi=135);plt.close(fig)
def main():
    p=argparse.ArgumentParser();p.add_argument('--scores',type=Path,required=True);p.add_argument('--geometry',type=Path,required=True);p.add_argument('--photos',type=Path,required=True);p.add_argument('--ids',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--scope-registry',type=Path);a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True);d=pd.read_csv(a.scores);geo=json.loads(a.geometry.read_text());ids=a.ids.split(',');manifest=[]
    scopes={r['image_code']:r for r in json.loads(a.scope_registry.read_text())['records']} if a.scope_registry else {}
    for rid in ids:
        row=d[d.record_id.eq(rid)].iloc[0];g=geo[row.object_id]['geometry'];ref=geo[row.selected_gt_object_id]['geometry'];photo=a.photos/(row.image_code+'.jpg');path=a.out/(row.image_code+'_'+rid+'.png')
        render(row,g,ref,photo,path,scopes.get(row.image_code));manifest.append(dict(record_id=rid,image_code=row.image_code,photo=str(photo),figure=path.name,old_subjective_score_read=False,new_scope_top_pending=bool(a.scope_registry)))
    (a.out/'case_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print('rendered',len(manifest))
if __name__=='__main__':main()
