#!/usr/bin/env python3
"""Post-hoc gallery selection at existing Q boundaries; no tuning or old grades.

Uses the existing render_cases.render, unchanged source images and projected
geometries. The six added pages have a separate manifest from prior case lists.
"""
import argparse
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path

from PIL import Image
from render_cases import render


def save_csv(path, rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--scores',type=Path,required=True)
    p.add_argument('--geometry',type=Path,required=True)
    p.add_argument('--photos',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.out.exists() and any(a.out.iterdir()):raise SystemExit('Use a new empty directory; preserve existing galleries.')
    a.out.mkdir(parents=True,exist_ok=True)
    numeric=['Q_v11','Q_alpha45','Q_stage13','iou_2d','S_deg','D_deg','F_deg','Hstar',
             'S_top_deg','S_bottom_deg','Hmean','Hlocal','range_deduction','boundary_deduction',
             'height_deduction','intrinsic_deduction']
    with a.scores.open(encoding='utf-8-sig') as f:
        rows=[r for r in csv.DictReader(f)
              if r['target_aligned_quality_candidate']=='True' and r['score_status']=='available']
    if len(rows)!=1725:raise ValueError(f'Expected the frozen 1725 eligible rows, received {len(rows)}')
    for r in rows:
        for k in numeric:r[k]=float(r[k]) if r[k] else float('nan')
        if not math.isfinite(r['Q_v11']):raise ValueError('Eligible row lacks finite default Q')
    selected=[];used_images=set()
    order=0
    for threshold in [95,85,50]:
        for side in ['below','above']:
            candidates=[r for r in rows if (r['Q_v11']<threshold if side=='below' else r['Q_v11']>=threshold)]
            candidates.sort(key=lambda r:(abs(r['Q_v11']-threshold),r['image_code'],r['record_id']))
            accepted=next((r for r in candidates if r['image_code'] not in used_images),None)
            if accepted is None:raise ValueError('Insufficient different images for registered de-duplication rule')
            rank=next(i+1 for i,r in enumerate(candidates) if r['record_id']==accepted['record_id'])
            order+=1;used_images.add(accepted['image_code'])
            selected.append(dict(row=accepted,display_order=order,threshold=threshold,side=side,
                absolute_Q_gap=abs(accepted['Q_v11']-threshold),signed_Q_gap=accepted['Q_v11']-threshold,
                nearest_rank_before_image_deduplication=rank,
                closest_unrestricted_record_id=candidates[0]['record_id'],
                closest_unrestricted_Q=candidates[0]['Q_v11'],
                skipped_conflicting_record_ids=';'.join(r['record_id'] for r in candidates[:rank-1])))
    rule='事后展示；95、85、50依次处理，每阈值先下侧(Q<t)再上侧(Q>=t)；各侧按|Q-t|、image_code、record_id排序；顺序选择尚未使用的图片，遇同图取下一候选。只按默认Q选例，不读取旧人工分，不调参数。'
    design=dict(selection_purpose='posthoc_display_only',eligible_denominator=1725,
        thresholds=[95,85,50],rule_zh=rule,unique_images=len(used_images),old_subjective_scores_read=False,
        changes_parameters=False,changes_previous_14_case_manifest=False,
        scores_sha256=hashlib.sha256(a.scores.read_bytes()).hexdigest(),
        geometry_sha256=hashlib.sha256(a.geometry.read_bytes()).hexdigest(),
        selected_before_photo_render=True,
        warning='Existing Q class boundaries are provisional research categories, not validated quality cutoffs or equal-quality statements.')
    (a.out/'selection_design.json').write_text(json.dumps(design,ensure_ascii=False,indent=2)+'\n')
    geo=json.loads(a.geometry.read_text())
    detail=[];atlas=[];checks=[]
    labels={'range_deduction':'范围交并','boundary_deduction':'上下边界','height_deduction':'局部/平均高度','intrinsic_deduction':'自身规整'}
    for s in selected:
        r=s['row'];rid=r['record_id'];code=r['image_code'];t=s['threshold'];side=s['side']
        title=f"事后边界例：{t}分阈值{'下侧' if side=='below' else '上侧'}"
        deductions=sorted(labels,key=lambda k:r[k],reverse=True)
        main='、'.join(f"{labels[k]}约{r[k]:.2f}分" for k in deductions[:2])
        explanation=(f"默认Q={r['Q_v11']:.5f}，距暂定{t}分边界{s['absolute_Q_gap']:.5f}分。"
            f"固定GT为{r['selected_gt_record_id']}（{r['selected_gt_version']}）。"
            f"2D IoU={r['iou_2d']:.4f}，边界S={r['S_deg']:.3f}°，D={r['D_deg']:.3f}°，F={r['F_deg']:.3f}°，H*={r['Hstar']:.4f}。"
            f"按当前公式顺序分解，较大的两项扣分为{main}；扣分不是独立因果贡献。"
            '这只是边界两侧的事后展示，不表示阈值已经获得主观标定，也不表示邻近样本实际等质。')
        filename=f"boundary_{s['display_order']:02d}_{t}_{side}_{code}_{rid}.png"
        photo=a.photos/(code+'.jpg');fig=a.out/filename
        if not photo.is_file():raise FileNotFoundError(str(photo))
        # Encode in memory, validate complete bytes, then publish atomically.
        # This protects the gallery from an incomplete directly-written PNG.
        encoded=io.BytesIO()
        render(r,geo[r['object_id']]['geometry'],geo[r['selected_gt_object_id']]['geometry'],photo,encoded)
        payload=encoded.getvalue()
        with Image.open(io.BytesIO(payload)) as im:im.load()
        with Image.open(io.BytesIO(payload)) as im:im.verify()
        temporary=fig.with_suffix('.pending')
        with temporary.open('wb') as f:
            f.write(payload);f.flush();os.fsync(f.fileno())
        if temporary.read_bytes()!=payload:raise IOError('Rendered PNG temporary bytes differ from the complete in-memory image')
        with Image.open(temporary) as im:im.load()
        os.replace(temporary,fig)
        with Image.open(fig) as im:
            im.load();width,height=im.size;mode=im.mode
        with Image.open(fig) as im:im.verify()
        checks.append(dict(figure=filename,width=width,height=height,mode=mode,
                           complete_decode=True,sha256=hashlib.sha256(fig.read_bytes()).hexdigest()))
        meta_keys=['object_id','image_id','selected_gt_object_id','selected_gt_record_id','selected_gt_version',
                   'selected_gt_coordinates_sha256','target_aligned_quality_candidate','conservative_fixed_gt_quality_candidate',
                   'score_status','main_quality_gate','worker_quality_gate','reference_research_status',
                   'reference_policy_reasons','quality_use','group_split','historical_exposure','building_id','room_id']
        detail.append({**{k:v for k,v in s.items() if k!='row'},'record_id':rid,'image_code':code,
            **{k:r[k] for k in meta_keys},**{k:r[k] for k in numeric},
            'figure':filename,'title_zh':title,'explanation_zh':explanation,'selection_rule_zh':rule,
            'posthoc_display_only':True,'old_subjective_score_read':False,'source_photo':str(photo)})
        atlas.append(dict(figure=filename,record_id=rid,image_code=code,title_zh=title,explanation_zh=explanation))
        print(json.dumps({'rendered':s['display_order'],'record_id':rid,'figure':filename}),flush=True)
    save_csv(a.out/'boundary_selection_detail.csv',detail)
    save_csv(a.out/'png_decode_checks.csv',checks)
    (a.out/'boundary_cases_for_atlas.json').write_text(json.dumps(atlas,ensure_ascii=False,indent=2)+'\n')
    (a.out/'README_边界例.txt').write_text('本目录为本轮默认Q的事后分档边界展示，不用于参数选择。\n'+rule+'\n'+
        '完整准入分母为1725份。本目录独立于此前14图案例清单；旧人工评分未读取。\n'+
        '所有图片复用未修改的原图、当前投影几何、固定GT和已有render函数，均完成PNG完整解码及结构校验。\n'+
        '图中保留既有render函数显示的默认Q与两个候选分值，但选例仅使用默认Q；候选分值不参与去重或选择。\n'+
        '这六张是同一固定数据上的事后选例，不能称为盲测，也不能把95/85/50当作已验证合格线。\n')
    print(json.dumps({'selected':len(selected),'unique_images':len(used_images),'eligible':len(rows),
                      'fully_decoded_pngs':len(checks),'image_deduplication_replacements':sum(s['nearest_rank_before_image_deduplication']>1 for s in selected)},indent=2))


if __name__=='__main__':main()
