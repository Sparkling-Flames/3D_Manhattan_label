#!/usr/bin/env python3
"""Add precise upstream failure labels without modifying frozen raw results.

Legacy validator data_missing after a rejected projection means it received
no rings; it must not be reported as an absent/access-failed source file.
"""
import argparse,json
from pathlib import Path
import pandas as pd

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scores',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    d=pd.read_csv(a.scores);rows=[]
    for _,r in d.iterrows():
        p=json.loads(r.annotation_projection_reasons)
        if 'coordinates_outside_image' in p:c='invalid_canvas_coordinates';why='原始坐标超出1024×512画布，拒绝投影，不自动更正'
        elif 'invalid_paired_canvas_array' in p:c='insufficient_or_invalid_paired_array';why='当前正式点对数组不足以形成合法闭环或格式无效'
        elif 'approved_paired_coordinates_unavailable' in p:c='pairing_preprocessing_unavailable';why='原始作答已读取，但当前正式配对/预处理未形成可用几何'
        elif r.score_status=='available':c='available';why='固定输入几何及全部分量可计算'
        else:c='geometric_or_metric_failure';why=str(r.reason_codes)
        rows.append((c,why))
    d['computation_status_category']=[r[0] for r in rows];d['computation_status_reason_zh']=[r[1] for r in rows]
    d['source_access_status']='success'
    d['reference_policy_status']=d.reference_research_status
    d['formal_qualification_preserved']=True
    def band(q):
        if pd.isna(q):return '不可评价'
        if q>=95:return '高匹配_95及以上'
        if q>=85:return '较高匹配_85至95以下'
        if q>=50:return '中间档_50至85以下'
        return '低匹配_50以下'
    # Historical research bands only; no new empirical pass/fail calibration.
    d['band_v11_diagnostic']=d.Q_v11.map(band)
    d['band_v11_primary']=[band(q) if eligible else '不纳入主比较' for q,eligible in zip(d.Q_v11,d.conservative_fixed_gt_quality_candidate)]
    d['Q_target_aligned_v11']=d.Q_v11.where(d.target_aligned_quality_candidate)
    d['band_v11_target_aligned']=[band(q) if eligible else '不纳入目标一致比较' for q,eligible in zip(d.Q_v11,d.target_aligned_quality_candidate)]
    a.out.mkdir(parents=True,exist_ok=True);d.to_csv(a.out/'逐份质量结果_3152.csv',index=False,encoding='utf-8-sig')
    fail=d[d.score_status!='available'];fail.to_csv(a.out/'几何不可计算复审_131.csv',index=False,encoding='utf-8-sig')
    fail.groupby('computation_status_category').agg(records=('record_id','size'),images=('image_code','nunique')).reset_index().to_csv(a.out/'计算失败原因.csv',index=False,encoding='utf-8-sig')
    print(d.computation_status_category.value_counts().to_string())
if __name__=='__main__':main()
