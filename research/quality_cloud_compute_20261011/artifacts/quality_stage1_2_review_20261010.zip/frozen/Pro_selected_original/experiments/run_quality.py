#!/usr/bin/env python3
"""Read-only current-input replay. No repair, target choice, fitting or gate edits.

All Q columns are mathematical diagnostics unless a corresponding admission
column explicitly permits use. Q_primary_* additionally applies conservative
fixed-reference quality admission. Worker eligibility is stricter and separate.
"""
from __future__ import annotations
import argparse, collections, concurrent.futures, csv, datetime, hashlib, json, math, os, platform, sys, time
from pathlib import Path
import numpy as np


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def plain(x):
    if isinstance(x,dict): return {k:plain(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [plain(v) for v in x]
    if isinstance(x,np.ndarray): return plain(x.tolist())
    if isinstance(x,np.generic): return plain(x.item())
    if isinstance(x,float) and not math.isfinite(x): return None
    return x
def save(p,x):
    Path(p).parent.mkdir(parents=True,exist_ok=True)
    Path(p).write_text(json.dumps(plain(x),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csvwrite(p,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,keys);w.writeheader()
        for r in rows:
            w.writerow({k:json.dumps(v,ensure_ascii=False,allow_nan=False) if isinstance(v,(list,dict)) else v for k,v in plain(r).items()})
def istrue(v): return v is True or str(v).lower()=='true'


def project_object(o):
    """Existing continuous-canvas ray convention, exact stored pair/ring order.

    No wrap, clipping, sorting, snapping, deletion or reconstruction from an
    unreviewed alternate source. Out-of-domain canvas input is rejected before
    trigonometry; top-only domain failure retains a valid floor if possible.
    """
    g={'id':o['object_id'],'points':o.get('points_1024x512'),
       'sourcePointIndices':o.get('ordered_source_point_indices'),
       'sourcePairIndices':o.get('ordered_source_pair_indices'),
       'bottom3d':None,'top3d':None}
    meta={'projection_version':'current_continuous_canvas_h1_no_repair_v1',
          'projection_status':'unavailable','projection_reasons':[],
          'source_preprocessing_status':o.get('preprocessing_status'),
          'source_geometry_status':o.get('geometry',{}).get('status'),
          'source_geometry_issues':o.get('geometry',{}).get('issues',[])}
    reasons=meta['projection_reasons']
    if o.get('points_1024x512') is None:
        reasons.append('approved_paired_coordinates_unavailable');return g,meta
    p=np.asarray(o['points_1024x512'],dtype=float)
    if p.ndim!=2 or p.shape[1]!=2 or len(p)<6 or len(p)%2:
        reasons.append('invalid_paired_canvas_array');return g,meta
    if not np.isfinite(p).all(): reasons.append('nonfinite_canvas_coordinate');return g,meta
    if not np.array_equal(p[::2,0],p[1::2,0]):
        reasons.append('shared_x_pairing_not_satisfied');return g,meta
    floor,top=p[1::2],p[::2]
    bad=np.argwhere((p<np.array([0.,0.]))|(p>np.array([1024.,512.])))
    if len(bad):
        reasons.append('coordinates_outside_image');meta['outside_canvas_indices']=bad.tolist()
        # Any bad floor coordinate makes the footprint undefined in this frame.
        if np.any((floor<np.array([0.,0.]))|(floor>np.array([1024.,512.]))):return g,meta
    if np.any((floor[:,1]<=256)|(floor[:,1]>=512)):
        reasons.append('floor_ray_does_not_identify_finite_positive_depth');return g,meta
    u=(floor[:,0]/1024-.5)*2*np.pi;v=(floor[:,1]/512-.5)*np.pi
    radius=1/np.tan(v);x=radius*np.sin(u);z=-radius*np.cos(u)
    g['bottom3d']=np.c_[x,-np.ones_like(x),z].tolist()
    if reasons:return g,meta
    if np.any((top[:,1]<=0)|(top[:,1]>=512)):
        reasons.append('top_ray_at_or_beyond_pole');return g,meta
    y=-radius*np.tan((top[:,1]/512-.5)*np.pi)
    g['top3d']=np.c_[x,y,z].tolist();meta['projection_status']='available'
    return g,meta


def variant_scores(m,config):
    if any(m.get(k) is None for k in ['iou','S_top_deg','S_bottom_deg','dir','flat','Hstar']):return {}
    p=config['base_parameters'];s=math.hypot(m['S_top_deg'],m['S_bottom_deg'])/math.sqrt(2)
    qpre=100*m['iou']/(1+(s/p['boundary_half_deg'])**2+(m['Hstar']/p['height_relative_half'])**2)
    ud=m['dir']/p['direction_half_deg'];uf=m['flat']/p['flatness_half_deg']
    ld=ud*ud/(1+ud*ud);lf=uf*uf/(1+uf*uf);out={'q_before_intrinsic':qpre}
    for v in config['variants']:
        if v['type']=='constant_intrinsic':ad=af=v['alpha']
        else:
            def alpha(u):return v['alpha_min']+(v['alpha_max']-v['alpha_min'])*np.clip((u-v['start_loss_units'])/(v['end_loss_units']-v['start_loss_units']),0,1)
            ad,af=alpha(ud),alpha(uf)
        out[v['name']]=qpre*(1-(ad*ld+af*lf)/2)
    return plain(out)


GLOBALS={}
def init_worker(engine,official_dir,vendor,config):
    if vendor:sys.path.insert(0,vendor)
    sys.path.insert(0,str(Path(engine)/'core'));sys.path.insert(0,official_dir)
    from quality_v11 import score_geometry,Parameters
    from traditional_metrics import frozen_to_hohonet_pixels
    from audit_official_controls import load_official_iou_branch,run_compatibility
    from shapely.geometry import Polygon
    fn,post,meta=load_official_iou_branch(Polygon)
    GLOBALS.update(score=score_geometry,params=Parameters(**config['base_parameters']),config=config,
        pixels=frozen_to_hohonet_pixels,official=fn,compat=run_compatibility)


def job(item):
    identity,a,g,am,gm=item;conf=GLOBALS['config']
    res=GLOBALS['score'](a,g,GLOBALS['params'],**conf['numerical_settings'])
    m=res['metrics'];v=variant_scores(m,conf) if res['status']=='available' else {}
    if v and abs(v['Q_v11']-res['quality_score'])>1e-10:raise AssertionError('frozen_scalar_adapter_mismatch')
    # Research comparison uses strictly valid geometry, never official zero-on-error.
    official={'official_branch_status':'not_run_strict_geometry_or_projection_unavailable',
              'official_iou2d_raw':None,'official_iou3d_raw':None}
    if res['annotation_validity']['valid_3d'] and res['reference_validity']['valid_3d']:
        official=GLOBALS['compat'](GLOBALS['official'],GLOBALS['pixels'](a),GLOBALS['pixels'](g))
    qpol=istrue(identity.get('conservative_fixed_gt_quality_candidate',identity.get('conservative_fixed_gt_primary_candidate',False)))
    row={**identity,'score_status':res['status'],
      'quality_use':'eligible_fixed_reference_geometry' if qpol and res['status']=='available' else 'diagnostic_only_or_unavailable',
      'annotation_projection_status':am['projection_status'],'reference_projection_status':gm['projection_status'],
      'annotation_projection_reasons':am['projection_reasons'],'reference_projection_reasons':gm['projection_reasons'],
      'annotation_valid_2d':res['annotation_validity']['valid_2d'],'annotation_valid_3d':res['annotation_validity']['valid_3d'],
      'reference_valid_2d':res['reference_validity']['valid_2d'],'reference_valid_3d':res['reference_validity']['valid_3d'],
      'failure_classes':res['failure_classes'],'reason_codes':res['reason_codes'],
      'annotation_reason_codes':res['annotation_validity']['reason_codes'],
      'reference_reason_codes':res['reference_validity']['reason_codes'],
      'traditional_reason_codes':res.get('traditional_issues',[]),
      'iou_2d':m.get('iou_2d'),'iou_3d_corner_mean':m.get('iou_3d_corner_mean'),
      'iou_3d_perimeter_mean':m.get('iou_3d_perimeter_mean'),
      'official_iou3d_same_geometry_vertex_mean':official.get('official_iou3d_raw'),
      'official_iou2d_same_geometry':official.get('official_iou2d_raw'),
      'official_iou_branch_status':official['official_branch_status'],
      'official_iou3d_adapter_delta':m['iou_3d_corner_mean']-official['official_iou3d_raw'] if m.get('iou_3d_corner_mean') is not None and official.get('official_iou3d_raw') is not None else None,
      'S_deg':m.get('boundary_rms_deg'),'D_deg':m.get('dir'),'F_deg':m.get('flat'),
      'S_top_deg':m.get('S_top_deg'),'S_bottom_deg':m.get('S_bottom_deg'),
      'Hstar':m.get('Hstar'),'Hlocal':m.get('Hlocal'),'Hmean':m.get('Hmean'),
      'C':m.get('C'),'omission':m.get('omission'),'extension':m.get('extension'),
      'area_h2':m.get('area_h2'),'reference_area_h2':m.get('reference_area_h2'),
      'intersection_area_h2':m.get('intersection_area_h2'),
      'height_vertex_mean_h':m.get('height_vertex_mean_h'),'reference_height_vertex_mean_h':m.get('reference_height_vertex_mean_h'),
      'height_perimeter_mean_h':m.get('height_perimeter_mean_h'),'reference_height_perimeter_mean_h':m.get('reference_height_perimeter_mean_h'),
      'range_deduction':m.get('range_deduction_points'),'boundary_deduction':m.get('boundary_deduction_points'),
      'height_deduction':m.get('height_deduction_points'),'intrinsic_deduction':m.get('intrinsic_deduction_points'),
      'source_point_count':len(a['points']) if a.get('points') else None,
      'annotation_geometry_sha256':res['annotation_geometry_sha256'],'reference_geometry_sha256':res['reference_geometry_sha256'],
      **{v['name']:None for v in conf['variants']},**v}
    for cand in conf['variants']:row['Q_primary_'+cand['name'][2:]]=row[cand['name']] if qpol else None
    row['annotation_projected_vertex_count']=len(a['bottom3d']) if a.get('bottom3d') else None
    return row,{'identity':identity,'annotation':a,'reference_id':g['id'],'annotation_projection':am,
       'reference_projection':gm,'result':res,'variants':v,'official_iou_branch':official}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--current-data',type=Path,required=True)
    ap.add_argument('--admission',type=Path,required=True);ap.add_argument('--engine',type=Path,required=True)
    ap.add_argument('--official-dir',type=Path,required=True);ap.add_argument('--vendor',type=Path)
    ap.add_argument('--config',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--processes',type=int,default=4);args=ap.parse_args()
    out=args.out.resolve()
    if out.exists() and any(out.iterdir()):raise FileExistsError('results_must_be_new')
    out.mkdir(parents=True,exist_ok=True)
    conf=read(args.config);data=read(args.current_data)
    if 'data' in data:data=data['data']
    objects={o['object_id']:o for o in data['objects']}
    with args.admission.open(encoding='utf-8-sig') as f:admission=list(csv.DictReader(f))
    assert len(admission)==3152 and len({r['object_id'] for r in admission})==3152
    reference_key=next(k for k in ['selected_gt_object_id','selected_reference_id','reference_object_id'] if k in admission[0])
    projected={oid:project_object(o) for oid,o in objects.items()}
    inputs_before={str(p):sha(p) for p in [args.current_data,args.admission,args.config]}
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    manifest={'started_utc':start,'current_data_sha256':sha(args.current_data),'admission_sha256':sha(args.admission),
      'configuration_sha256':sha(args.config),'configuration':conf,'records_expected':3152,
      'code_sha256':sha(__file__),'input_hashes_before':inputs_before,'no_point_or_reference_mutation':True,
      'official_full_model_or_depth_pipeline_run':False,'official_branch':'pinned original IoU statements, same 3D rays re-expressed in official pixel centers',
      'new_35_scope_targets_used_for_complete_Q':False,'quality_use_rule':'apply admission flags; raw Q is diagnostic when excluded',
      'runtime':{'python':platform.python_version(),'numpy':np.__version__,'platform':platform.platform()}}
    save(out/'run_contract_before_scoring.json',manifest)
    csvwrite(out/'projection_inventory_3441.csv',[{'object_id':oid,'object_kind':objects[oid]['object_kind'],'image_code':objects[oid]['image_code'],**m} for oid,(g,m) in projected.items()])
    save(out/'projected_objects_3441.json',{oid:{'geometry':g,'projection':m} for oid,(g,m) in projected.items()})
    jobs=[]
    for r in admission:
        a,am=projected[r['object_id']];g,gm=projected[r[reference_key]]
        jobs.append((r,a,g,am,gm))
    initargs=(str(args.engine),str(args.official_dir),str(args.vendor) if args.vendor else None,conf)
    rows=[]
    with (out/'full_results_3152.jsonl').open('w',encoding='utf-8') as f,concurrent.futures.ProcessPoolExecutor(max_workers=args.processes,initializer=init_worker,initargs=initargs) as pool:
        for i,(row,full) in enumerate(pool.map(job,jobs,chunksize=4),1):
            rows.append(row);f.write(json.dumps(plain(full),ensure_ascii=False,allow_nan=False)+'\n')
            if i%100==0: print('computed',i,'/',len(jobs),flush=True)
    csvwrite(out/'score_rows_3152.csv',rows)
    # Recompute reference self-scores to expose unsupported intrinsic constraints.
    ref_ids=sorted({r[reference_key] for r in admission});selfrows=[]
    init_worker(*initargs)
    for oid in ref_ids:
        g,gm=projected[oid];o=objects[oid]
        ident={'record_id':'SELF:'+oid,'object_id':oid,'image_code':o['image_code'],'selected_gt_object_id':oid}
        row,res=job((ident,g,g,gm,gm));selfrows.append(row)
    csvwrite(out/'selected_reference_self_scores.csv',selfrows)
    finite=[r['official_iou3d_adapter_delta'] for r in rows if r['official_iou3d_adapter_delta'] is not None]
    status=collections.Counter(r['score_status'] for r in rows)
    manifest.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=len(rows),images=len({r['image_code'] for r in rows}),
      score_status=dict(status),valid_iou2d=sum(r['iou_2d'] is not None for r in rows),
      valid_iou3d=sum(r['iou_3d_corner_mean'] is not None for r in rows),
      official_matched_geometry_comparisons=len(finite),max_abs_official_iou3d_adapter_delta=max(map(abs,finite)) if finite else None,
      source_inputs_unchanged=all(sha(p)==h for p,h in inputs_before.items()))
    if not manifest['source_inputs_unchanged']:raise AssertionError('input_modified')
    if finite and max(map(abs,finite))>1e-8:raise AssertionError('official_iou_same_geometry_mismatch')
    save(out/'run_summary.json',manifest)
    print(json.dumps({k:manifest[k] for k in ['rows','images','score_status','valid_iou2d','valid_iou3d','official_matched_geometry_comparisons','max_abs_official_iou3d_adapter_delta','source_inputs_unchanged']},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
