#!/usr/bin/env python3
"""Descriptive same-row method comparison; no parameter selection or fitting."""
import argparse,json,hashlib
from pathlib import Path
import pandas as pd

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scores',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    d=pd.read_csv(a.scores);rows=[];cor=[]
    methods=['iou_2d','official_iou3d_same_geometry_vertex_mean','iou_3d_perimeter_mean','Q_v11','Q_alpha30','Q_alpha45','Q_stage13','Q_stage24']
    for policy in ['conservative_fixed_gt_quality_candidate','target_aligned_quality_candidate']:
        base=d[d[policy]&d.score_status.eq('available')].copy()
        for split in ['development','validation','all']:
            x=base if split=='all' else base[base.group_split.eq(split)]
            assert x[methods].notna().all().all()
            for k in methods:
                rows.append(dict(policy=policy,split=split,method=k,n=len(x),images=x.image_code.nunique(),buildings=x.building_id.nunique(),mean=x[k].mean(),median=x[k].median(),p05=x[k].quantile(.05),p95=x[k].quantile(.95),units='0_to_1' if k.startswith(('iou','official')) else '0_to_100',mean_delta_vs_v11=(x[k]-x.Q_v11).mean() if k.startswith('Q_') else None))
            for k in methods[:3]:
                cor.append(dict(policy=policy,split=split,n=len(x),comparison=k,spearman_with_Q_v11=x[k].corr(x.Q_v11,method='spearman'),interpretation='descriptive_dependence_not_accuracy_or_independence'))
    a.out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(a.out/'same_sample_policy_metric_summary.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(cor).to_csv(a.out/'same_sample_IoU_Q_dependence.csv',index=False,encoding='utf-8-sig')
    (a.out/'descriptive_summary_provenance.json').write_text(json.dumps(dict(source=str(a.scores),sha256=hashlib.sha256(a.scores.read_bytes()).hexdigest(),no_formula_changes=True,no_human_score_fitting=True,generated_from_existing_frozen_rows=True),ensure_ascii=False,indent=2)+'\n')
    print(pd.DataFrame(rows).query("split=='all'")[['policy','method','n','mean','median','mean_delta_vs_v11']].to_string(index=False))
if __name__=='__main__':main()
