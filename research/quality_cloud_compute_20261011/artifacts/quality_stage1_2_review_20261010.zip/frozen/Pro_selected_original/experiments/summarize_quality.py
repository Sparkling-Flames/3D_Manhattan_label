#!/usr/bin/env python3
"""Summaries with explicit policy and image/group denominators. No optimization."""
import argparse,json,hashlib,datetime
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

V=['Q_v11','Q_alpha30','Q_alpha45','Q_stage13','Q_stage24']
POL=['formal_quality_gate_candidate','registry_minimum_quality_candidate','conservative_fixed_gt_quality_candidate',
     'conservative_fixed_gt_primary_candidate','target_aligned_quality_candidate','target_aligned_primary_candidate']
def yes(s):return s.astype(str).str.lower().eq('true')
def cv(p,d):d.to_csv(p,index=False,encoding='utf-8-sig')
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def basic(g,col):
    x=g[col].dropna();return dict(n=int(len(x)),mean=float(x.mean()) if len(x) else None,median=float(x.median()) if len(x) else None,
        p05=float(x.quantile(.05)) if len(x) else None,p95=float(x.quantile(.95)) if len(x) else None,
        images=int(g.loc[g[col].notna(),'image_code'].nunique()),buildings=int(g.loc[g[col].notna(),'building_id'].nunique()),
        groups=int(g.loc[g[col].notna(),'group_key'].nunique()))
def band(x):return np.select([x>=95,x>=85,x>=50,x.notna()],['95+','85-95','50-85','below50'],default='unavailable')

def main():
    p=argparse.ArgumentParser();p.add_argument('--scores',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True);d=pd.read_csv(a.scores,keep_default_na=True)
    for k in POL:d[k]=yes(d[k])
    d['math_available']=d.score_status.eq('available')
    dens=[]
    for pol in ['all_supplied']+POL:
        mask=pd.Series(True,index=d.index) if pol=='all_supplied' else d[pol]
        g=d[mask];valid=g[g.math_available]
        dens.append(dict(policy=pol,admitted_rows=len(g),admitted_images=g.image_code.nunique(),admitted_buildings=g.building_id.nunique(),
            complete_Q_rows=len(valid),Q_images=valid.image_code.nunique(),Q_buildings=valid.building_id.nunique(),Q_groups=valid.group_key.nunique(),
            unavailable=len(g)-len(valid),development_rows=sum(valid.group_split.eq('development')),validation_rows=sum(valid.group_split.eq('validation')),
            development_images=valid.loc[valid.group_split.eq('development'),'image_code'].nunique(),validation_images=valid.loc[valid.group_split.eq('validation'),'image_code'].nunique()))
    cv(a.out/'effective_denominators.csv',pd.DataFrame(dens))
    main=d[d.conservative_fixed_gt_quality_candidate & d.math_available].copy()
    rows=[];deltas=[];trans=[];strata=[];cross=[]
    for split in ['development','validation','all']:
        ds=main if split=='all' else main[main.group_split.eq(split)]
        for v in V:
            rows.append(dict(split=split,variant=v,**basic(ds,v)))
            delta=ds[v]-ds.Q_v11
            deltas.append(dict(split=split,variant=v,n=len(ds),mean_delta=float(delta.mean()),median_delta=float(delta.median()),
                min_delta=float(delta.min()),p05_delta=float(delta.quantile(.05)),changes_over_2=int((delta<-2).sum()),
                changes_over_5=int((delta<-5).sum()),changes_over_10=int((delta<-10).sum()),
                rank_spearman=float(spearmanr(ds.Q_v11,ds[v]).statistic)))
            for label,n in pd.Series(band(ds[v])).value_counts().items():trans.append(dict(split=split,variant=v,band=label,n=int(n)))
        for key,mask in [('all',pd.Series(True,index=ds.index)),('D>=10',ds.D_deg>=10),('F>=4',ds.F_deg>=4),('D<5 and F<2',(ds.D_deg<5)&(ds.F_deg<2)),('Q>=85',ds.Q_v11>=85),('I<0.5',ds.iou_2d<.5)]:
            g=ds[mask]
            for v in V:
                strata.append(dict(split=split,stratum=key,variant=v,**basic(g,v),mean_delta=float((g[v]-g.Q_v11).mean()) if len(g) else None))
        for v in V[1:]:
            tmp=ds[['record_id','object_id','image_code','building_id','group_key','group_split','Q_v11',v,'D_deg','F_deg','iou_2d','S_deg','Hstar']].copy()
            tmp['base_band']=band(tmp.Q_v11);tmp['variant_band']=band(tmp[v]);tmp=tmp[tmp.base_band!=tmp.variant_band]
            if split!='all':cv(a.out/f'band_changes_{split}_{v}.csv',tmp)
    cv(a.out/'variant_summaries.csv',pd.DataFrame(rows));cv(a.out/'variant_deltas.csv',pd.DataFrame(deltas));cv(a.out/'variant_bands.csv',pd.DataFrame(trans));cv(a.out/'variant_strata.csv',pd.DataFrame(strata))
    for keys,name in [(['image_code','image_id','building_id','room_id','group_key','group_split'],'by_image_259'),(['building_id','group_split'],'by_building')]:
        out=[]
        for vals,g in d.groupby(keys,dropna=False):
            if not isinstance(vals,tuple):vals=(vals,)
            r=dict(zip(keys,vals));m=g[g.conservative_fixed_gt_quality_candidate&g.math_available]
            r.update(records_supplied=len(g),math_available=int(g.math_available.sum()),primary_admitted=int(g.conservative_fixed_gt_quality_candidate.sum()),primary_Q_n=len(m),
                math_unavailable=int((~g.math_available).sum()),not_primary=int((~g.conservative_fixed_gt_quality_candidate).sum()))
            for k in ['iou_2d','iou_3d_corner_mean',*V,'D_deg','F_deg','S_deg','Hstar']:
                r[k+'_mean']=m[k].mean();r[k+'_median']=m[k].median()
            out.append(r)
        cv(a.out/(name+'.csv'),pd.DataFrame(out))
    for reason in ['annotation_projection_reasons','reference_projection_reasons','annotation_reason_codes','reference_reason_codes','reason_codes','failure_classes']:
        counts=[]
        for ix,r in d.iterrows():
            for k in json.loads(r[reason]) if isinstance(r[reason],str) else []:counts.append(dict(record_id=r.record_id,image_code=r.image_code,reason=k,primary=bool(r.conservative_fixed_gt_quality_candidate)))
        f=pd.DataFrame(counts,columns=['record_id','image_code','reason','primary'])
        q=f.groupby(['reason','primary']).agg(records=('record_id','nunique'),images=('image_code','nunique')).reset_index()
        cv(a.out/(reason+'_counts.csv'),q)
    cv(a.out/'manual_review_geometry_unavailable_131.csv',d[~d.math_available])
    cv(a.out/'not_admitted_all_records.csv',d[~d.conservative_fixed_gt_quality_candidate])
    # This is descriptive redundancy, not evidence for dropping any component.
    cols=['iou_2d','S_deg','Hstar','D_deg','F_deg','Q_v11','iou_3d_corner_mean']
    main[cols].corr(method='spearman').to_csv(a.out/'component_spearman_descriptive.csv',encoding='utf-8-sig')
    dev=main[main.group_split.eq('development')]
    cv(a.out/'development_largest_intrinsic_changes.csv',dev.assign(drop=dev.Q_v11-dev.Q_alpha45).sort_values('drop',ascending=False).head(30))
    cv(a.out/'development_highQ_largeD_orF.csv',dev[(dev.Q_v11>=85)&((dev.D_deg>=5)|(dev.F_deg>=2))].sort_values('Q_v11',ascending=False))
    save(a.out/'summary_contract.json',dict(input_sha256=hashlib.sha256(a.scores.read_bytes()).hexdigest(),
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),all_variants_same_input=True,
        no_parameter_fit=True,old_subjective_scores_read=False,record_means_are_not_image_population_estimates=True,
        historical_blind_validation_claimed=False,main_policy='conservative_fixed_gt_quality_candidate AND score_status=available'))
    print(pd.DataFrame(dens).to_string(index=False))
    print('Development variants:');print(pd.DataFrame(deltas).query('split=="development"').to_string(index=False))

if __name__=='__main__':main()
