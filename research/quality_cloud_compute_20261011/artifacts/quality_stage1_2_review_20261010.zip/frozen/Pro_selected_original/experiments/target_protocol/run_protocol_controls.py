#!/usr/bin/env python3
"""Small policy controls, with no fitting and no real-annotation target-Q run."""
from __future__ import annotations
import argparse
import copy
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path

from target_protocol import FrozenEngine, digest, evaluate, target_set_digest


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def csvwrite(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geom(xz):
    return {"bottom3d": [[x, -1.0, z] for x, z in xz],
            "top3d": [[x, 1.0, z] for x, z in xz]}


def rect(r, dx=0):
    return geom([[x+dx, z] for x, z in [[-r, -r], [r, -r], [r, r], [-r, r]]])


def target(tid, geometry, top_ready=True):
    return {"target_id": tid, "geometry": geometry, "geometry_sha256": digest(geometry),
            "top_ready": top_ready, "legal_authorized": True,
            "authority": "synthetic preapproved control, not an actual image GT"}


def packet(annotation, targets, overall, mode="fixed_declared_target", declared="small", any_auth=False):
    return {"annotation": annotation, "targets": targets, "overall_scope": overall, "mode": mode,
            "target_set_sha256": target_set_digest(targets), "declared_target_id": declared,
            "any_target_mode_authorized": any_auth}


class CountingEngine(FrozenEngine):
    def __init__(self, *args):
        super().__init__(*args)
        self.score_calls = 0

    def score(self, *args):
        self.score_calls += 1
        return super().score(*args)


def run(p, engine):
    return evaluate(p["annotation"], p["targets"], p["overall_scope"], engine, mode=p["mode"],
                    expected_target_set_sha256=p["target_set_sha256"],
                    declared_target_id=p.get("declared_target_id"),
                    any_target_mode_authorized=p.get("any_target_mode_authorized", False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", required=True, type=Path)
    ap.add_argument("--config", required=True, type=Path)
    ap.add_argument("--registry", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    (a.out / "fixtures").mkdir()
    large, small = target("large", rect(4)), target("small", rect(2))
    targets = [large, small]
    overall = {"scope_id": "fixed_total_large", "geometry": rect(4), "geometry_sha256": digest(rect(4))}
    pending = target("small_floor_pending", {"bottom3d": rect(2)["bottom3d"], "top3d": None}, False)
    invalid = geom([[-2, -2], [2, -2], [0, -2], [2, 2], [-2, 2]])
    # All fixtures are fixed and written before any score is calculated.
    fixtures = {
        "01_same_small_fixed_large": packet(rect(2), targets, overall, declared="large"),
        "02_same_small_fixed_small": packet(rect(2), targets, overall),
        "03_same_small_any_authorized": packet(rect(2), targets, overall, "any_preapproved_target", any_auth=True),
        "04_same_small_legacy": packet(rect(2), targets, overall, "unresolved_legacy"),
        "05_same_small_any_unauthorized": packet(rect(2), targets, overall, "any_preapproved_target"),
        "06_displaced_small_fixed_small": packet(rect(2, .5), targets, overall),
        "07_pending_single_fixed": packet(rect(2), [pending], overall, declared=pending["target_id"]),
        "08_pending_set_any": packet(rect(2), [large, pending], overall, "any_preapproved_target", any_auth=True),
        "09_invalid_backtracking_annotation": packet(invalid, targets, overall),
    }
    for name, p in fixtures.items():
        save(a.out / "fixtures" / (name + ".json"), p)
    registration = {"created_before_control_scoring_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                    "script_sha256": sha(Path(__file__)),
                    "protocol_sha256": sha(Path(__file__).with_name("target_protocol.py")),
                    "frozen_config_sha256": sha(a.config), "latest35_registry_sha256": sha(a.registry),
                    "fixed_fixtures_sha256": digest(fixtures),
                    "families": ["same geometry/different task", "position error", "top pending",
                                 "invalid input", "reference content binding"],
                    "new_real_annotation_target_quality_computed": False}
    save(a.out / "registration.json", registration)
    engine = CountingEngine(a.engine, a.config)
    results, rows = {}, []
    for name, p in fixtures.items():
        n = engine.score_calls
        r = run(p, engine)
        results[name] = r
        rows.append({"case_id": name, "mode": p["mode"], "declared_target": p["declared_target_id"],
                     "status": r["status"], "formal_Q": r["formal_Q"], "formal_target": r["formal_target_id"],
                     "coverage_of_fixed_total": r["coverage_relative_to_fixed_overall_scope"].get("coverage_of_target"),
                     "BEV_best": "|".join(r["geometry_preference"]["BEV_best_ids"]),
                     "BEV_gap": r["geometry_preference"]["BEV_margin"],
                     "Q_best": "|".join(r["geometry_preference"]["Q_best_ids"]),
                     "diagnostic_Q_max": r["geometry_preference"]["Q_max"],
                     "full_score_calls": engine.score_calls-n,
                     "annotation_sha256": r["annotation_sha256"], "source_modified": r["source_geometry_modified"]})
    save(a.out / "complete_control_results.json", results)
    csvwrite(a.out / "control_summary.csv", rows)
    get = lambda n: results[next(k for k in results if k.startswith(f"{n:02d}_"))]
    checks = {
        "identical_geometry_and_frozen_targets": fixtures["01_same_small_fixed_large"]["annotation"] == fixtures["02_same_small_fixed_small"]["annotation"],
        "fixed_task_changes_quality": get(2)["formal_Q"] - get(1)["formal_Q"] > 50,
        "any_authorized_retains_both_results": get(3)["formal_Q"] == get(2)["formal_Q"] and len(get(3)["candidates"]) == 2,
        "any_does_not_restore_historical_intent": not get(3)["historical_intent_inferred"],
        "small_high_quality_keeps_quarter_total_coverage": abs(get(2)["coverage_relative_to_fixed_overall_scope"]["coverage_of_target"]-.25) < 1e-10,
        "clear_legacy_preference_still_no_formal_assignment": get(4)["geometry_preference"]["BEV_margin"] > .7 and get(4)["formal_Q"] is None and get(4)["formal_target_id"] is None,
        "unauthorized_any_calls_no_full_score": rows[4]["full_score_calls"] == 0 and get(5)["formal_Q"] is None,
        "position_error_penalized_under_same_target": get(6)["formal_Q"] < get(2)["formal_Q"],
        "pending_single_no_fallback_ceiling": get(7)["status"] == "top_pending" and rows[6]["full_score_calls"] == 0,
        "pending_candidate_blocks_any_full_scoring": get(8)["status"] == "top_pending" and rows[7]["full_score_calls"] == 0,
        "invalid_input_is_unavailable_unchanged": get(9)["status"] == "unavailable_annotation" and not get(9)["source_geometry_modified"],
        "all_original_inputs_unchanged": digest(fixtures) == registration["fixed_fixtures_sha256"],
    }
    corrupt = copy.deepcopy(fixtures["02_same_small_fixed_small"])
    corrupt["targets"][1]["geometry"]["bottom3d"][0][0] -= .1
    try:
        run(corrupt, engine)
        checks["changed_frozen_target_set_rejected"] = False
    except ValueError as e:
        checks["changed_frozen_target_set_rejected"] = str(e) == "frozen_target_set_hash_mismatch"
    corrupt["target_set_sha256"] = target_set_digest(corrupt["targets"])
    bound_conflict = run(corrupt, engine)
    checks["internal_geometry_binding_conflict_blocks_declared_target"] = bound_conflict["status"] == "reference_binding_conflict" and bound_conflict["formal_Q"] is None
    save(a.out / "binding_conflict_result.json", bound_conflict)
    # A synthetic valid annotation exercises readiness guards on the actual
    # newly confirmed floor registry. No actual answer or ceiling is invented.
    registry = json.loads(a.registry.read_text())["records"]
    ready_rows, readiness_results = [], []
    for record in registry:
        floor = {"bottom3d": [[x, -1.0, z] for x, z in record["floor_xz_h"]], "top3d": None}
        t = {"target_id": record["reference_id"], "geometry": floor, "geometry_sha256": digest(floor),
             "legal_authorized": True, "authorization_scope": "confirmed_floor_only",
             "top_ready": record["reference_ready"], "source_registry_record": record}
        scope = {"scope_id": record["reference_id"], "geometry": floor, "geometry_sha256": digest(floor),
                 "coverage_scope_only": True}
        p = packet(rect(2), [t], scope, declared=t["target_id"])
        n = engine.score_calls
        r = run(p, engine)
        readiness_results.append({"image_code": record["image_code"], "synthetic_annotation_only": True,
                                  "packet": p, "result": r})
        ready_rows.append({"image_code": record["image_code"], "reference_id": record["reference_id"],
                           "is_research_image": record["in_current_formal_corpus"],
                           "n_research_annotations_metadata_only": record["n_research_annotations"],
                           "top_pending": record["top_boundary_pending"], "top_ready": record["reference_ready"],
                           "actual_annotations_scored": 0, "full_score_calls": engine.score_calls-n,
                           "status": r["status"], "formal_Q": r["formal_Q"],
                           "floor_sha256": record["floor_polygon_sha256"], "formal_eligibility_modified": False})
    save(a.out / "latest35_readiness_full.json", readiness_results)
    csvwrite(a.out / "latest35_readiness_guards.csv", ready_rows)
    checks["latest35_all_top_pending_no_full_scores"] = len(ready_rows) == 35 and all(x["status"] == "top_pending" and x["full_score_calls"] == 0 and x["formal_Q"] is None for x in ready_rows)
    checks["latest35_33_research_2_reference_only"] = sum(x["is_research_image"] for x in ready_rows) == 33
    checks["latest35_no_new_real_annotation_scores"] = all(x["actual_annotations_scored"] == 0 for x in ready_rows)
    save(a.out / "checks.json", {"checks": checks, "passed": sum(checks.values()), "total": len(checks),
                                 "registry_count": len(ready_rows), "control_count": len(rows)})
    assert all(checks.values()), checks
    print(json.dumps({"out": str(a.out), "passed": sum(checks.values()), "total": len(checks),
                      "fixed_large_Q_for_small": get(1)["formal_Q"], "fixed_small_Q": get(2)["formal_Q"],
                      "displaced_small_Q": get(6)["formal_Q"], "latest35_full_score_calls": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
