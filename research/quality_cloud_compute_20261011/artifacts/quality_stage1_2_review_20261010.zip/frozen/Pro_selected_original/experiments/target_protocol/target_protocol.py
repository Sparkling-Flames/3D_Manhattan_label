#!/usr/bin/env python3
"""Minimal explicit target protocol around the unchanged frozen v1.1 engine.

Geometry preference is never interpreted as historical task intent. A hash
proves content identity, not that targets were selected independently or that
an approval is semantically correct; those are external research obligations.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys


VERSION = "explicit_frozen_target_protocol_20261011_v1"
MODES = {"fixed_declared_target", "any_preapproved_target", "unresolved_legacy"}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def target_set_digest(targets):
    return digest(sorted(targets, key=lambda t: t["target_id"]))


class FrozenEngine:
    def __init__(self, engine_path, config_path):
        sys.path.insert(0, str(Path(engine_path) / "core"))
        import quality_v11 as frozen
        self.frozen = frozen
        config = json.loads(Path(config_path).read_text())
        self.parameters = frozen.Parameters(**config["base_parameters"])
        self.numerical = config["numerical_settings"]

    def score(self, annotation, target):
        return self.frozen.score_geometry(annotation, target, self.parameters, **self.numerical)

    def validate(self, geometry, role):
        return self.frozen.validate_record(geometry, role=role)

    def bev(self, annotation, target):
        av, tv = self.validate(annotation, "annotation"), self.validate(target, "reference")
        if not av["valid_2d"] or not tv["valid_2d"]:
            return {"status": "unavailable", "annotation_reasons": av["reason_codes"], "reference_reasons": tv["reason_codes"]}
        m = self.frozen.area_metrics(annotation, target)
        return {"status": "available", "iou_2d": m["iou"],
                "coverage_of_target": m["intersection_area_h2"] / m["reference_area_h2"],
                "prediction_inside_fraction": m["intersection_area_h2"] / m["area_h2"],
                "annotation_area_h2": m["area_h2"], "target_area_h2": m["reference_area_h2"]}


def best_ids(candidates, field):
    available = [(c["target_id"], c.get(field)) for c in candidates
                 if c.get(field) is not None and math.isfinite(c[field])]
    if not available:
        return [], None, None
    maximum = max(v for _, v in available)
    ids = sorted(k for k, v in available if abs(v - maximum) <= 1e-12)
    ordered = sorted((v for _, v in available), reverse=True)
    return ids, maximum, (ordered[0] - ordered[1] if len(ordered) > 1 else None)


def evaluate(annotation, targets, overall_scope, engine, *, mode,
             expected_target_set_sha256, declared_target_id=None,
             any_target_mode_authorized=False):
    """Return all references/results and a formal Q only under explicit rules."""
    if mode not in MODES:
        raise ValueError("unknown_target_protocol_mode")
    if not targets or len({t["target_id"] for t in targets}) != len(targets):
        raise ValueError("empty_or_duplicate_target_ids")
    if target_set_digest(targets) != expected_target_set_sha256:
        raise ValueError("frozen_target_set_hash_mismatch")
    if digest(overall_scope["geometry"]) != overall_scope["geometry_sha256"]:
        raise ValueError("overall_scope_geometry_hash_mismatch")
    before = digest({"annotation": annotation, "targets": targets, "overall_scope": overall_scope})
    av = engine.validate(annotation, "annotation")
    coverage = engine.bev(annotation, overall_scope["geometry"])
    # An accepted-set task must be authorized and fully ready before any full
    # scores are calculated in that mode. Legacy explicitly permits diagnostic
    # per-target scores, but never turns them into an official quality value.
    any_set_ready = any_target_mode_authorized is True and all(
        t.get("legal_authorized") is True and t.get("top_ready") is True
        and digest(t["geometry"]) == t["geometry_sha256"]
        and engine.validate(t["geometry"], "reference")["available"]
        for t in targets)
    candidates = []
    for target in targets:
        geometry = target["geometry"]
        item = {**target, "complete_Q": None, "iou_2d": None, "frozen_result": None}
        if digest(geometry) != target["geometry_sha256"]:
            item["status"] = "reference_binding_conflict"
        else:
            item["reference_validity"] = engine.validate(geometry, "reference")
            item["BEV"] = engine.bev(annotation, geometry)
            item["target_vs_fixed_overall_scope"] = engine.bev(geometry, overall_scope["geometry"])
            item["iou_2d"] = item["BEV"].get("iou_2d")
            if target.get("legal_authorized") is not True:
                item["status"] = "target_not_legally_authorized"
            elif target.get("top_ready") is not True:
                item["status"] = "top_pending"
            elif mode == "any_preapproved_target" and not any_set_ready:
                item["status"] = "score_not_run_any_protocol_gate"
            else:
                result = engine.score(annotation, geometry)
                item["frozen_result"] = result
                item["status"] = result["status"]
                item["complete_Q"] = result["quality_score"]
        candidates.append(item)
    by_id = {c["target_id"]: c for c in candidates}
    qi, qmax, qgap = best_ids(candidates, "complete_Q")
    ii, imax, igap = best_ids(candidates, "iou_2d")
    result = dict(protocol_version=VERSION, mode=mode,
        target_set_sha256=expected_target_set_sha256,
        annotation_sha256=digest(annotation), overall_scope=overall_scope,
        annotation_validity=av, coverage_relative_to_fixed_overall_scope=coverage,
        declared_target_id=declared_target_id,
        any_target_mode_authorized=bool(any_target_mode_authorized),
        candidates=candidates, geometry_preference=dict(BEV_best_ids=ii, BEV_max=imax, BEV_margin=igap,
            Q_best_ids=qi, Q_max=qmax, Q_margin=qgap),
        formal_Q=None, formal_target_id=None, selected_quality_reference_ids=[],
        historical_intent_inferred=False, source_geometry_modified=False)
    if not av["available"]:
        result["status"] = "unavailable_annotation"
    elif coverage["status"] != "available":
        result["status"] = "unavailable_fixed_overall_scope"
    elif mode == "unresolved_legacy":
        result["status"] = "unresolved_legacy_no_formal_assignment"
    elif mode == "fixed_declared_target":
        if declared_target_id not in by_id:
            result["status"] = "declared_target_missing_or_not_in_frozen_set"
        else:
            chosen = by_id[declared_target_id]
            result["status"] = chosen["status"]
            if chosen["status"] == "available":
                result.update(formal_Q=chosen["complete_Q"], formal_target_id=declared_target_id,
                              selected_quality_reference_ids=[declared_target_id])
    elif any_target_mode_authorized is not True:
        result["status"] = "any_target_protocol_requires_explicit_authorization"
    elif not all(c["status"] == "available" for c in candidates):
        result["status"] = ("top_pending" if any(c["status"] == "top_pending" for c in candidates)
                            else "target_set_not_fully_eligible")
    else:
        result.update(status="available", formal_Q=qmax,
                      selected_quality_reference_ids=qi,
                      formal_target_id=qi[0] if len(qi) == 1 else None)
    if before != digest({"annotation": annotation, "targets": targets, "overall_scope": overall_scope}):
        raise AssertionError("protocol_mutated_input")
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", required=True, type=Path)
    ap.add_argument("--config", required=True, type=Path)
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    if args.out.exists():
        raise FileExistsError("Use a new output file")
    packet = json.loads(args.input.read_text())
    engine = FrozenEngine(args.engine, args.config)
    result = evaluate(packet["annotation"], packet["targets"], packet["overall_scope"], engine,
        mode=packet["mode"], expected_target_set_sha256=packet["target_set_sha256"],
        declared_target_id=packet.get("declared_target_id"),
        any_target_mode_authorized=packet.get("any_target_mode_authorized", False))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+"\n")
    print(json.dumps({k: result[k] for k in ["status", "formal_Q", "formal_target_id", "historical_intent_inferred"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
