#!/usr/bin/env python3
"""Mechanism controls: physical length dilution versus representation changes.

No candidate weights are chosen. The current frozen default Q is replayed.
The anomaly is an outward triangle with two fixed 45-degree edges. Increasing
the rectangle length adds physical correct walls; subdivision does not.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import numpy as np

from audit_official_controls import geometry, subdivide, load_module, write_csv, write_json


def build_cases():
    cases = []
    for L in [2., 8., 32., 128.]:
        a = .25
        gt = geometry([[-L,-1.],[L,-1.],[L,1.],[-L,1.]])
        pred = geometry([[-L,-1.],[L,-1.],[L,1.],[a,1.],[0.,1.+a],[-a,1.],[-L,1.]])
        cases.append(dict(case_id=f'physical_L{L:g}_fixed_triangle', family='physical_correct_length_added',
            half_length_h=L, triangle_half_width_h=a, triangle_height_h=a, annotation=pred, reference=gt))
        cases.append(dict(case_id=f'physical_L{L:g}_perfect_reference', family='perfect_reference_self',
            half_length_h=L, annotation=gt, reference=gt))
    base = cases[0]
    for label, a in [('add40_good_edge',subdivide(base['annotation'],0,40)),
                      ('add40_bad_edge',subdivide(base['annotation'],3,40))]:
        cases.append(dict(case_id='representation_'+label, family='same_geometry_subdivision',
            representation_reference_case=base['case_id'], annotation=a, reference=base['reference']))
    for offset in [1,3]:
        a = {k: np.roll(np.asarray(base['annotation'][k]),-offset,axis=0).tolist()
             for k in ['top3d','bottom3d']}
        cases.append(dict(case_id=f'representation_cyclic{offset}', family='same_geometry_sampling_origin',
            representation_reference_case=base['case_id'], annotation=a, reference=base['reference']))
    a = {k: np.asarray(base['annotation'][k])[::-1].tolist() for k in ['top3d','bottom3d']}
    cases.append(dict(case_id='representation_reverse', family='same_geometry_sampling_origin',
        representation_reference_case=base['case_id'], annotation=a, reference=base['reference']))
    return cases


def diagnostics(record, own_axis_deg, reference_axis_deg):
    b = np.asarray(record['bottom3d'])[:,[0,2]]
    edge = np.roll(b,-1,axis=0)-b
    length = np.linalg.norm(edge,axis=1)
    theta = np.rad2deg(np.arctan2(edge[:,1],edge[:,0]))
    out = {'floor_perimeter_h':float(length.sum())}
    local = []
    for label,axis in [('own',own_axis_deg),('reference',reference_axis_deg)]:
        residual = np.abs((theta-axis+45)%90-45)
        out[label+'_max_direction_residual_deg']=float(residual.max())
        out[label+'_length_weighted_direction_rms_deg']=float(np.sqrt(np.dot(length,residual**2)/length.sum()))
        out[label+'_bounded_loss_after_rms']=out[label+'_length_weighted_direction_rms_deg']**2 / (out[label+'_length_weighted_direction_rms_deg']**2+25.)
        out[label+'_length_mean_local_bounded_loss']=float(np.dot(length,residual**2/(residual**2+25.))/length.sum())
        for threshold in [5.,10.,20.]:
            bad = residual > threshold
            out[f'{label}_length_above_{threshold:g}deg_h']=float(length[bad].sum())
            out[f'{label}_fraction_above_{threshold:g}deg']=float(length[bad].sum()/length.sum())
        if label=='own':
            for i in range(len(length)):
                local.append(dict(segment_index=i, length_h=float(length[i]), angle_deg=float(theta[i]),
                                  residual_to_own_axis_deg=float(residual[i])))
    return out,local


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise SystemExit('Use a new output directory; old results are retained.')
    args.out.mkdir(parents=True,exist_ok=True)
    q=load_module(args.engine/'core/quality_v11.py','_q_direction_dilution_control')
    cases=build_cases()
    write_json(args.out/'preregistered_geometry_cases.json',cases)
    write_json(args.out/'experiment_design.json',dict(
        frozen_before_scores=True, direction_perturbation='two fixed 45 degree triangle edges',
        triangle_half_width_h=.25,triangle_height_h=.25, rectangle_half_lengths_h=[2,8,32,128],
        added_good_edge_points=40,added_bad_edge_points=40,
        case_count=len(cases), weights_selected=False,
        interpretation='Physical added wall length changes extent weighting. Exact collinear subdivision does not. Threshold fractions are diagnostics, not accepted quality thresholds.'))
    rows=[]; detail=[]; segment_rows=[]
    for case in cases:
        result=q.score_geometry(case['annotation'],case['reference'])
        own=q.own_metrics(case['annotation']); ref=q.own_metrics(case['reference'])
        d,segments=diagnostics(case['annotation'],own['axis_deg'],ref['axis_deg'])
        row={k:v for k,v in case.items() if k not in ['annotation','reference']}
        row.update(d, status=result['status'],Q_v11=result['quality_score'],
            reason_codes=';'.join(result['reason_codes']),vertex_count=len(case['annotation']['bottom3d']))
        for key in ['iou','S_top_deg','S_bottom_deg','boundary_rms_deg','dir','flat','Hstar',
                    'range_deduction_points','boundary_deduction_points','height_deduction_points',
                    'intrinsic_deduction_points','intrinsic_factor','reference_factor']:
            row[key]=result['metrics'].get(key)
        if case['family']=='physical_correct_length_added':
            L=case['half_length_h'];a=case['triangle_half_width_h']
            fraction=2*a*math.sqrt(2)/(4*L+4+2*a*(math.sqrt(2)-1))
            row['analytic_bad_diagonal_length_fraction']=fraction
            row['analytic_own_D_deg']=45*math.sqrt(fraction*(1-fraction))
            row['analytic_D_abs_difference']=abs(row['dir']-row['analytic_own_D_deg'])
        rows.append(row);detail.append(dict(case_id=case['case_id'],result=result))
        segment_rows.extend([dict(case_id=case['case_id'],**s) for s in segments])
    base=rows[0]
    for r in rows:
        if r.get('representation_reference_case'):
            r['Q_change_same_geometry']=r['Q_v11']-base['Q_v11']
            r['D_change_same_geometry']=r['dir']-base['dir']
            r['perimeter_change_same_geometry']=r['floor_perimeter_h']-base['floor_perimeter_h']
    physical=[r for r in rows if r['family']=='physical_correct_length_added']
    subdiv=[r for r in rows if r['family']=='same_geometry_subdivision']
    origin=[r for r in rows if r['family']=='same_geometry_sampling_origin']
    checks=dict(all_inputs_strictly_valid=all(r['status']=='available' for r in rows),
        analytic_D_formula_matches=max(r['analytic_D_abs_difference'] for r in physical)<1e-10,
        same_geometry_subdivision_D_unchanged=max(abs(r['D_change_same_geometry']) for r in subdiv)<1e-10,
        same_geometry_subdivision_Q_unchanged=max(abs(r['Q_change_same_geometry']) for r in subdiv)<1e-8,
        fixed_error_D_decreases_as_correct_physical_length_increases=all(physical[i]['dir']>physical[i+1]['dir'] for i in range(len(physical)-1)),
        local_bounded_loss_not_stronger_than_after_RMS=all(r['own_length_mean_local_bounded_loss']<=r['own_bounded_loss_after_rms']+1e-12 for r in rows))
    summary=dict(status='passed' if all(checks.values()) else 'failed',checks=checks,
        total_cases=len(cases), physical_anomaly_cases=len(physical),candidate_weights_run=False,
        maximum_ring_origin_or_direction_Q_change=max(abs(r['Q_change_same_geometry']) for r in origin),
        origin_change_interpretation='finite fixed quadrature phase; reported rather than declared exact invariance',
        engine_sha256=hashlib.sha256((args.engine/'core/quality_v11.py').read_bytes()).hexdigest(),
        real_independent_images_added=0)
    write_csv(args.out/'direction_dilution_controls.csv',rows)
    write_csv(args.out/'segment_residual_diagnostics.csv',segment_rows)
    write_json(args.out/'full_quality_results.json',detail)
    write_json(args.out/'validation.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__=='__main__':
    main()
