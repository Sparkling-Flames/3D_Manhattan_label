#!/usr/bin/env python3
"""Adaptive numerical follow-up for the previously observed narrow-pulse miss.

This retains the failed 32768-sample check. The 131072-sample probe diagnoses
convergence against the analytic answer; it is neither blind validation nor a
new production setting.
"""
import argparse
import json
import math
from pathlib import Path

from audit_official_controls import load_module, write_csv, write_json
from audit_height_pulse_sampling import flatness_edge_quadrature


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--engine', type=Path, required=True)
    p.add_argument('--input-results', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    args=p.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise SystemExit('Output must be a new empty directory.')
    args.out.mkdir(parents=True, exist_ok=True)
    load_module(args.engine/'core/quality_v11.py', '_q_height_numerical_followup')
    from height_revision import height_components, floor_samples_with_height
    from audit_geometry import flatness
    cases=json.loads((args.input_results/'preregistered_geometry_cases.json').read_text())
    cases=[c for c in cases if c['width_divisor']==8192]
    write_json(args.out/'adaptive_design.json',dict(
        purpose='Convergence diagnosis after the 32768-sample relative-error check failed; prior outputs preserved.',
        case_selection='All cyclic representations of fixed width P/8192 in the prior registered pulse matrix.',
        samples_per_direction=131072, physical_shapes=1, geometrical_representations=len(cases),
        no_quality_weight_selection=True, new_production_setting_adopted=False,
        independent_validation=False, numerical_tolerance_relative=.005))
    rows=[]
    for c in cases:
        a,g=c['annotation'],c['reference']
        hc=height_components(a,g,samples=131072)
        fn=flatness(a,n=131072)
        fe=flatness_edge_quadrature(a,nodes=128)
        he=c['pulse_amplitude_h']/c['reference_height_h']*math.sqrt(c['support_width_h']/(3*c['perimeter_h']))
        _,hs=floor_samples_with_height(a,n=131072)
        rows.append(dict(case_id=c['case_id'],samples_per_perimeter=131072,
            Hlocal=hc['Hlocal'],Hlocal_exact=he,Hlocal_relative_error=hc['Hlocal']/he-1,
            F_midpoint_deg=fn['flat'],F_edge_reference_deg=fe['flat_deg'],
            F_relative_error=fn['flat']/fe['flat_deg']-1,
            samples_with_positive_height_error=int((hs>2+1e-12).sum())))
    validation=dict(status='passed' if all(abs(r['Hlocal_relative_error'])<.005 for r in rows) else 'failed',
        relative_Hlocal_error_max=max(abs(r['Hlocal_relative_error']) for r in rows),
        numerical_comparison_rows=len(rows), new_real_images=0,
        prior_32768_two_percent_failure_retained=True,
        interpretation='Convergence against an exact special-case integral confirms a quadrature effect, without implying that finite uniform sampling is universally sufficient.')
    write_csv(args.out/'narrow_pulse_convergence.csv',rows)
    write_json(args.out/'validation.json',validation)
    print(json.dumps(validation,ensure_ascii=False,indent=2))
    if validation['status']!='passed': raise SystemExit(1)


if __name__=='__main__': main()
