#!/usr/bin/env python3
"""Height pulses: exact physical RMS versus finite perimeter quadrature.

Three fixed-amplitude triangular pulses, two cyclic representations, three
sample densities. This is a mechanism audit of frozen v1.1, not a new weight
choice or a requirement that any local peak imply a globally low quality.
"""
from __future__ import annotations

import argparse
import hashlib
import math
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import minimize_scalar

from audit_official_controls import geometry, load_module, write_csv, write_json


def rolled(record, start):
    return {k: np.roll(np.asarray(record[k]), -start, axis=0).tolist()
            for k in ['top3d', 'bottom3d']}


def build_cases(cyclic_starts=(0, 6)):
    cases = []
    for divisor in [32, 512, 8192]:
        width = 12. / divisor
        xz = [[-2., -1.], [-width/2, -1.], [0., -1.], [width/2, -1.],
              [2., -1.], [2., 1.], [-2., 1.]]
        a = geometry(xz, [2., 2., 3., 2., 2., 2., 2.])
        g = geometry(xz, 2.)
        for start in cyclic_starts:
            cases.append(dict(case_id=f'pulse_Pover{divisor}_cyclic{start}',
                width_divisor=divisor, support_width_h=width, perimeter_h=12.,
                pulse_amplitude_h=1., reference_height_h=2.,
                peak_relative_height_error=.5, cyclic_start=start,
                annotation=rolled(a, start), reference=rolled(g, start)))
    return cases


def flatness_edge_quadrature(record, nodes=64):
    """Legendre quadrature separately on each physical edge, including tiny ones.

    Reference integration, not an adopted replacement for the frozen F. The
    computation converges numerically and retains physical floor-length weights.
    """
    b = np.asarray(record['bottom3d'], float)
    t = np.asarray(record['top3d'], float)
    length = np.linalg.norm(np.roll(b, -1, axis=0)-b, axis=1)
    x, w = np.polynomial.legendre.leggauss(nodes)
    alpha = (x+1)/2
    pts = t[:, None, :] + alpha[None, :, None] * (np.roll(t, -1, axis=0)-t)[:, None, :]
    r = np.linalg.norm(pts[:, :, [0, 2]], axis=2)
    phi = np.arctan2(pts[:, :, 1], r)
    weights = length[:, None]*w[None, :]/(2*length.sum())
    obj = lambda ht: float(np.sum(weights * (phi-np.arctan2(ht, r))**2))
    lo = min(-.999, float(t[:, 1].min())-1)
    hi = max(1., float(t[:, 1].max())+1)
    opt = minimize_scalar(obj, bounds=(lo, hi), method='bounded', options={'xatol': 1e-13})
    return dict(flat_deg=float(np.rad2deg(np.sqrt(opt.fun))),
                fitted_wall_height_h=float(opt.x+1), nodes_per_edge=nodes)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--engine', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--cyclic-starts', default='0,6',
                   help='Comma-separated existing corner indices; 0,6 reproduce the first run.')
    p.add_argument('--design-note', default='initial fixed amplitude and density mechanism design')
    args = p.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise SystemExit('Use an empty new output directory; preserve earlier runs.')
    args.out.mkdir(parents=True, exist_ok=True)
    q = load_module(args.engine/'core/quality_v11.py', '_q_height_pulse_sampling')
    from height_revision import height_components, height_moments, rms_about_level, floor_samples_with_height
    from audit_geometry import flatness
    cyclic_starts = [int(s) for s in args.cyclic_starts.split(',')]
    if not cyclic_starts or any(i not in range(7) for i in cyclic_starts):
        raise ValueError('cyclic starts must be existing indices 0 through 6')
    cases = build_cases(cyclic_starts)
    sample_counts = [512, 4096, 32768]
    write_json(args.out/'preregistered_geometry_cases.json', cases)
    write_json(args.out/'experiment_design.json', dict(
        frozen_before_scores=True, case_count=len(cases), physical_pulse_shapes=3,
        width_divisors=[32, 512, 8192], amplitude_h=1., reference_height_h=2.,
        perimeter_h=12., sample_counts=sample_counts, cyclic_starts=cyclic_starts,
        design_note=args.design_note,
        default_F_samples=512, default_Hlocal_samples=4096, default_spherical_samples=2048,
        exact_Hlocal_formula='(amplitude/reference_height)*sqrt(width/(3*perimeter))',
        exact_Hmean_formula='amplitude*width/(2*perimeter*reference_height)',
        no_new_weights=True, no_validation_scores_read=True,
        interpretation='Physical support changes exact perimeter RMS; cyclic start preserves continuous geometry. Edge quadrature is a numerical diagnostic, not an adopted score. A high local peak is not an assumed whole-answer low-quality truth.'))
    rows = []; density_rows = []; details = []
    for case in cases:
        a, g = case['annotation'], case['reference']
        result = q.score_geometry(a, g)
        if result['status'] != 'available':
            raise RuntimeError((case['case_id'], result['reason_codes']))
        m = result['metrics']
        width, perimeter = case['support_width_h'], case['perimeter_h']
        amplitude, height = case['pulse_amplitude_h'], case['reference_height_h']
        exact_hmean = amplitude*width/(2*perimeter*height)
        exact_hlocal = amplitude/height * math.sqrt(width/(3*perimeter))
        edge64 = flatness_edge_quadrature(a, 64)
        edge128 = flatness_edge_quadrature(a, 128)
        moment = height_moments(a)
        row = {k: v for k, v in case.items() if k not in ['annotation', 'reference']}
        row.update(status=result['status'], Hmean_exact=exact_hmean, Hlocal_exact=exact_hlocal,
                   Hstar_exact=max(exact_hmean, exact_hlocal),
                   Hlocal_exact_edge_integral=rms_about_level(a, height)/height,
                   F_edge_quadrature_64_deg=edge64['flat_deg'],
                   F_edge_quadrature_128_deg=edge128['flat_deg'],
                   F_quadrature_abs_difference_deg=abs(edge128['flat_deg']-edge64['flat_deg']),
                   height_mean_exact_check=moment['height_mean_h'],
                   Q_v11_default=result['quality_score'])
        for key in ['iou', 'iou_3d_corner_mean', 'iou_3d_perimeter_mean', 'S_top_deg',
                    'S_bottom_deg', 'dir', 'flat', 'Hmean', 'Hlocal', 'Hstar',
                    'boundary_deduction_points', 'height_deduction_points',
                    'intrinsic_deduction_points']:
            row[key] = m.get(key)
        row['Q_Hexact_only_other_components_frozen'] = q.scalar_score(
            m['iou'], m['S_top_deg'], m['S_bottom_deg'], m['dir'], m['flat'],
            row['Hstar_exact'])['quality_score']
        row['Q_Hexact_Fedge_other_components_frozen'] = q.scalar_score(
            m['iou'], m['S_top_deg'], m['S_bottom_deg'], m['dir'], edge128['flat_deg'],
            row['Hstar_exact'])['quality_score']
        row['Q_default_minus_Hexact_Fedge'] = row['Q_v11_default']-row['Q_Hexact_Fedge_other_components_frozen']
        rows.append(row)
        for n in sample_counts:
            hc = height_components(a, g, samples=n)
            f = flatness(a, n=n)
            _, hs = floor_samples_with_height(a, n=n)
            density_rows.append(dict(case_id=case['case_id'], width_divisor=case['width_divisor'],
                cyclic_start=case['cyclic_start'], samples_per_perimeter=n,
                sample_spacing_h=perimeter/n, support_width_h=width,
                expected_continuous_samples_in_support=n*width/perimeter,
                samples_with_positive_height_residual=int(np.sum(hs > height+1e-12)),
                maximum_sampled_height_residual_h=float(max(hs)-height),
                physical_peak_height_residual_h=amplitude,
                Hmean=hc['Hmean'], Hlocal=hc['Hlocal'], Hstar=hc['Hstar'],
                Hlocal_exact=exact_hlocal,
                Hlocal_relative_numerical_error=(hc['Hlocal']-exact_hlocal)/exact_hlocal,
                F_midpoint_deg=f['flat'], F_edge_reference_deg=edge128['flat_deg'],
                F_absolute_numerical_error_deg=f['flat']-edge128['flat_deg'],
                Q_Hn_Fn_other_components_frozen=q.scalar_score(m['iou'], m['S_top_deg'],
                    m['S_bottom_deg'], m['dir'], f['flat'], hc['Hstar'])['quality_score']))
        details.append(dict(case_id=case['case_id'], default_result=result,
                            F_edge_quadrature_64=edge64, F_edge_quadrature_128=edge128))
    origin_changes = []
    for divisor in [32, 512, 8192]:
        pair = [r for r in rows if r['width_divisor'] == divisor]
        origin_changes.append(dict(width_divisor=divisor,
            Q_default_range=max(r['Q_v11_default'] for r in pair)-min(r['Q_v11_default'] for r in pair),
            Hlocal_default_range=max(r['Hlocal'] for r in pair)-min(r['Hlocal'] for r in pair),
            F_default_range_deg=max(r['flat'] for r in pair)-min(r['flat'] for r in pair),
            Hlocal_exact_range=max(r['Hlocal_exact'] for r in pair)-min(r['Hlocal_exact'] for r in pair),
            F_edge_range_deg=max(r['F_edge_quadrature_128_deg'] for r in pair)-min(r['F_edge_quadrature_128_deg'] for r in pair)))
    checks = dict(
        all_representations_strictly_valid=all(r['status'] == 'available' for r in rows),
        identical_floor_overlap=all(abs(r['iou']-1)<1e-12 for r in rows),
        exact_triangle_RMS_matches_edge_integral=all(abs(r['Hlocal_exact']-r['Hlocal_exact_edge_integral'])<1e-12 for r in rows),
        exact_Hmean_matches_frozen_moment=all(abs(r['Hmean']-r['Hmean_exact'])<1e-12 for r in rows),
        independent_F_quadratures_agree=all(r['F_quadrature_abs_difference_deg']<1e-8 for r in rows),
        cyclic_start_preserves_exact_Hlocal_and_edge_F=all(r['Hlocal_exact_range']<1e-12 and r['F_edge_range_deg']<1e-8 for r in origin_changes),
        high_density_Hlocal_is_within_two_percent=all(abs(r['Hlocal_relative_numerical_error'])<.02 for r in density_rows if r['samples_per_perimeter']==32768),
        constant_peak_height=all(r['peak_relative_height_error']==.5 for r in rows))
    default_dense = [r for r in density_rows if r['samples_per_perimeter']==4096]
    summary = dict(status='passed' if all(checks.values()) else 'failed', checks=checks,
        geometry_representations=len(cases), physical_height_pulses=3, density_rows=len(density_rows),
        default_Hlocal_zero_despite_nonzero_exact_count=sum(r['Hlocal']<1e-14 and r['Hlocal_exact']>0 for r in default_dense),
        maximum_default_Q_cyclic_start_range=max(r['Q_default_range'] for r in origin_changes),
        maximum_default_Q_minus_edge_reference=max(r['Q_default_minus_Hexact_Fedge'] for r in rows),
        root_weight_candidates_run=False, real_independent_images_added=0,
        engine_sha256=hashlib.sha256((args.engine/'core/quality_v11.py').read_bytes()).hexdigest(),
        warning='Exact H formula uses identical footprints and flat reference only. Edge-quadrature F is diagnostic. It is not a newly frozen algorithm or human quality calibration.')
    write_csv(args.out/'height_pulse_controls.csv', rows)
    write_csv(args.out/'height_pulse_density_controls.csv', density_rows)
    write_csv(args.out/'cyclic_representation_differences.csv', origin_changes)
    write_json(args.out/'default_quality_details.json', details)
    write_json(args.out/'validation.json', summary)
    print(__import__('json').dumps(summary, ensure_ascii=False, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
