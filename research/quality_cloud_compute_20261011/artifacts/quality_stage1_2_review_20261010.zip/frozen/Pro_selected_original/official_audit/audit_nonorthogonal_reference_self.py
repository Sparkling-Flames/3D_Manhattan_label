#!/usr/bin/env python3
"""Current accepted x8-09 reference self-match; diagnostic only, no weight change."""
import argparse,json,hashlib,sys
from pathlib import Path
from audit_official_controls import load_module,write_json
from audit_real_pixel_convention import project_current_object


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--current-input',type=Path,required=True)
    p.add_argument('--aliases',type=Path,required=True)
    p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.out.exists() and any(a.out.iterdir()):raise SystemExit('Use a new empty output directory.')
    a.out.mkdir(parents=True,exist_ok=True)
    data=json.loads(a.current_input.read_text());aliases=json.loads(a.aliases.read_text())['records']
    image=next(i for i in data['images'] if i['image_code']=='x8F5xyUWy9e-09')
    rid=image['references'].get('gt_manual_revision') or image['references']['gt_original']
    ref=next(o for o in data['objects'] if o['object_id']==rid)
    if aliases[rid]!='R02762' or ref['object_kind']!='gt_manual_revision':
        raise SystemExit('Expected reference version changed; do not silently substitute.')
    q=load_module(a.engine/'core/quality_v11.py','_q_real_reference_self')
    geometry=project_current_object(ref)
    before=q.geometry_digest(geometry)
    score=q.score_geometry(geometry,geometry)
    m=score['metrics']
    result=dict(image_code=image['image_code'],reference_object_id=rid,reference_id=aliases[rid],
        reference_version=ref['object_kind'],reference_geometry_sha256=before,
        reference_points_sha256=hashlib.sha256(json.dumps(ref['points_1024x512'],separators=(',',':')).encode()).hexdigest(),
        official_vertex_mean_iou=m.get('iou_3d_corner_mean'),Q_v11=score['quality_score'],
        D=m.get('dir'),F=m.get('flat'),S_top=m.get('S_top_deg'),S_bottom=m.get('S_bottom_deg'),
        Hstar=m.get('Hstar'),intrinsic_deduction_points=m.get('intrinsic_deduction_points'),
        evidence='User says nonorthogonal but annotatable; current selected manual revision. This is a GT self-match diagnostic, not an annotation added to a population.',
        geometry=geometry,full_score=score,
        original_reference_object_gate=ref['worker_quality_gate'],
        current_input_file_sha256=hashlib.sha256(a.current_input.read_bytes()).hexdigest(),
        source_geometry_unchanged=before==q.geometry_digest(geometry),weights_changed=False,eligibility_changed=False)
    write_json(a.out/'x8_09_current_reference_self.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['geometry','full_score']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
