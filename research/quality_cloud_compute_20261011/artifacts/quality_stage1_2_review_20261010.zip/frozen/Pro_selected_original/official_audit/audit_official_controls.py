#!/usr/bin/env python3
"""Run the pinned official HoHoNet IoU branch on unmodified synthetic rays.

The AST extraction retains every original statement before depth evaluation,
including both pair assertions, Shapely polygons, GT skip and try/except paths.
Only a return of locals is appended. This is an IoU-branch run, not a model,
Manhattan post-processing, depth evaluation, or complete official CLI run.
"""
from __future__ import annotations

import argparse
import ast
import contextlib
import csv
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path
import platform
import sys
from types import SimpleNamespace
import warnings

import numpy as np

HERE = Path(__file__).resolve().parent


def write_json(path, data):
    path.write_text(json.dumps(plain(data), ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def plain(x):
    if isinstance(x, dict):
        return {k: plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [plain(v) for v in x]
    if isinstance(x, np.ndarray):
        return plain(x.tolist())
    if isinstance(x, np.generic):
        return plain(x.item())
    if isinstance(x, float) and not math.isfinite(x):
        return None
    return x


def write_csv(path, rows):
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(plain(rows))


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_official_sources():
    manifest = json.loads((HERE / 'source_manifest.json').read_text())
    for item in manifest['files']:
        data = (HERE / 'official_source' / item['path']).read_bytes()
        assert hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
        blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        assert blob == item['git_blob_sha1'], item['path']
    return manifest


def load_official_iou_branch(Polygon):
    source = HERE / 'official_source'
    p_tree = ast.parse((source / 'lib/misc/post_proc.py').read_text())
    names = {'np_coorx2u', 'np_coory2v', 'np_coor2xy', 'get_z1'}
    defs = [n for n in p_tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in defs} == names
    p_ns = {'np': np, 'PI': float(np.pi)}
    exec(compile(ast.Module(body=defs, type_ignores=[]), str(source / 'lib/misc/post_proc.py'), 'exec'), p_ns)
    post = SimpleNamespace(**{n: p_ns[n] for n in names})

    e_tree = ast.parse((source / 'eval_layout.py').read_text())
    fn = next(n for n in e_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'test_general')
    cut = next(i for i, n in enumerate(fn.body) if isinstance(n, ast.Assign) and any(
        isinstance(t, ast.Name) and t.id == 'gt_layout_depth' for t in n.targets))
    kept = fn.body[:cut]
    assert sum(isinstance(n, ast.Try) for n in kept) == 2
    assert sum(isinstance(n, ast.Assert) for n in kept) == 2
    last_original_line = max(n.end_lineno for n in kept)
    fn.name = 'official_iou_branch'
    fn.body = kept + [ast.Return(value=ast.Call(func=ast.Name(id='locals', ctx=ast.Load()), args=[], keywords=[]))]
    ns = {'np': np, 'post_proc': post, 'Polygon': Polygon, 'gt_path': 'synthetic_reference'}
    module = ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[]))
    exec(compile(module, str(source / 'eval_layout.py'), 'exec'), ns)
    return ns['official_iou_branch'], post, {'first_line': fn.lineno, 'last_original_line': last_original_line}


def geometry(xz, heights=2.):
    xz = np.asarray(xz, dtype=float)
    h = np.broadcast_to(np.asarray(heights, dtype=float), (len(xz),))
    b = np.c_[xz[:, 0], np.full(len(xz), -1.), xz[:, 1]]
    t = b.copy()
    t[:, 1] = h - 1.
    return {'top3d': t.tolist(), 'bottom3d': b.tolist()}


def subdivide(record, edge, inserted):
    b, t = np.asarray(record['bottom3d']), np.asarray(record['top3d'])
    bb, tt = [], []
    for i in range(len(b)):
        bb.append(b[i]); tt.append(t[i])
        if i == edge:
            for alpha in np.arange(1, inserted + 1) / (inserted + 1):
                bb.append((1-alpha) * b[i] + alpha * b[(i+1) % len(b)])
                tt.append((1-alpha) * t[i] + alpha * t[(i+1) % len(t)])
    return {'top3d': np.asarray(tt).tolist(), 'bottom3d': np.asarray(bb).tolist()}


def make_cases():
    xz = np.array([[-2., -1.], [2., -1.], [2., 1.], [-2., 1.]])
    ref = geometry(xz)
    cancel = geometry(xz, [1.01, 1.01, 2.99, 2.99])
    rows = []
    def add(name, a, g=ref, kind='valid_geometry', **extra):
        rows.append(dict(case_id=name, kind=kind, annotation=a, reference=g, **extra))
    add('perfect_rectangle', ref)
    add('uniform_height_plus_1pct', geometry(xz, 2.02))
    add('uniform_height_plus_25pct', geometry(xz, 2.5))
    add('uniform_height_minus_25pct', geometry(xz, 1.5))
    add('position_shift_half_h', geometry(xz + [0.5, 0.]))
    add('mean_cancel_base4', cancel, representation_family='same_nonflat_ring')
    for edge, label in [(0, 'low'), (2, 'high')]:
        for n in [1, 4, 40]:
            add(f'mean_cancel_{label}_edge_add{n}', subdivide(cancel, edge, n),
                representation_family='same_nonflat_ring', inserted_collinear_points=n)
    far_ref = geometry(xz * 100.)
    add('mean_cancel_far_room', geometry(xz * 100., [1.01, 1.01, 2.99, 2.99]), far_ref)
    oblique = geometry([[-2., -1.], [2., -1.], [3., 1.], [-1., 1.]])
    add('acceptable_nonorthogonal_GT_self', oblique, oblique, purpose='model_applicability_control')
    add('acceptable_nonflat_GT_self', cancel, cancel, purpose='model_applicability_control')
    add('invalid_pred_self_intersection', geometry(xz[[0, 2, 1, 3]]), kind='invalid_geometry')
    add('invalid_ref_self_intersection', ref, geometry(xz[[0, 2, 1, 3]]), kind='invalid_reference')
    add('invalid_pred_negative_wall_height', geometry(xz, -2.), kind='invalid_geometry')
    add('pixels_pair_x_mismatch', ref, kind='official_pixel_contract', mutate_pixels='x_mismatch')
    add('pixels_nan_ceiling', ref, kind='official_pixel_contract', mutate_pixels='nan_ceiling')
    return rows


def run_compatibility(fn, pred, ref):
    buf = io.StringIO()
    out = {'official_branch_status': 'not_run', 'official_iou2d_raw': None,
           'official_iou3d_raw': None, 'official_exception': '', 'official_warnings': ''}
    try:
        with warnings.catch_warnings(record=True) as found, contextlib.redirect_stdout(buf):
            warnings.simplefilter('always')
            raw = fn(pred, ref, 1024, 512, {})
        out['official_warnings'] = ';'.join(str(w.message) for w in found)
        out['official_stdout'] = buf.getvalue().strip()
        if raw is None:
            out['official_branch_status'] = 'reference_skipped_invalid_polygon'
            return out
        for old, new in [('iou2d', 'official_iou2d_raw'), ('iou3d', 'official_iou3d_raw'),
                         ('h_dt', 'official_height_pred_m'), ('h_gt', 'official_height_ref_m'),
                         ('area_dt', 'official_area_pred_m2'), ('area_gt', 'official_area_ref_m2'),
                         ('area_inter', 'official_intersection_m2')]:
            if old in raw:
                value = float(raw[old])
                out[new] = value if math.isfinite(value) else None
                if not math.isfinite(value):
                    out[new + '_nonfinite_token'] = str(value)
        finite = out['official_iou2d_raw'] is not None and out['official_iou3d_raw'] is not None
        out['official_branch_status'] = 'returned_finite' if finite else 'returned_nonfinite'
    except Exception as exc:
        out['official_branch_status'] = 'raised_' + type(exc).__name__
        out['official_exception'] = str(exc)
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--engine', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--dependencies', type=Path, default=HERE / 'vendor_dependencies')
    args = p.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise SystemExit('Output directory is nonempty; do not overwrite an earlier run.')
    args.out.mkdir(parents=True, exist_ok=True)
    if args.dependencies.is_dir():
        sys.path.insert(0, str(args.dependencies.resolve()))
    import shapely
    from shapely.geometry import Polygon
    original_manifest = verify_official_sources()
    fn, post, ast_lines = load_official_iou_branch(Polygon)
    quality = load_module(args.engine / 'core/quality_v11.py', '_pinned_quality_for_official_audit')
    tr = load_module(args.engine / 'traditional/traditional_metrics.py', '_pinned_traditional_for_official_audit')
    engine_before = {str(f.relative_to(args.engine)): hashlib.sha256(f.read_bytes()).hexdigest()
                     for f in args.engine.rglob('*.py')}
    cases = make_cases()
    write_json(args.out / 'control_geometries.json', cases)
    rows, detail = [], []
    for case in cases:
        a, g = case['annotation'], case['reference']
        pa, pg = tr.frozen_to_hohonet_pixels(a), tr.frozen_to_hohonet_pixels(g)
        mutation = case.get('mutate_pixels')
        if mutation == 'x_mismatch':
            pa[0, 0] += 1.
        elif mutation == 'nan_ceiling':
            pa[0, 1] = np.nan
        off = run_compatibility(fn, pa, pg)
        row = {k: v for k, v in case.items() if k not in {'annotation', 'reference'}}
        row.update(vertex_count=len(a['bottom3d']), **off)
        # Pixel-contract probes do not reuse the unmutated research record as
        # if it were the same input; this prevents a misleading comparison.
        if mutation is None:
            q = quality.score_geometry(a, g)
            trad = tr.traditional_metrics_detailed(a, g,
                intersection_area_fn=lambda aa, gg: Polygon(aa).intersection(Polygon(gg)).area)
            row.update(research_status=q['status'], research_Q_v11=q['quality_score'],
                research_reason_codes=';'.join(q['reason_codes']),
                research_iou2d=trad['iou2d_bev'],
                research_corner_mean_iou3d=trad['hohonet_iou3d_vertex_mean'],
                research_perimeter_mean_iou3d=trad['conditional_iou3d_perimeter_mean'],
                corner_mean_height_h=trad['height_vertex_mean_h'],
                perimeter_mean_height_h=trad['height_perimeter_mean_h'])
            for key in ['dir', 'flat', 'S_top_deg', 'S_bottom_deg', 'Hmean', 'Hlocal', 'Hstar',
                        'score_v1_recomputed']:
                row[key] = q['metrics'].get(key)
            if trad['hohonet_iou3d_vertex_mean'] is not None and off['official_iou3d_raw'] is not None:
                row['official_vs_current_corner_abs_difference'] = abs(
                    off['official_iou3d_raw'] - trad['hohonet_iou3d_vertex_mean'])
            detail.append(dict(case_id=case['case_id'], quality=q, traditional=trad,
                               official=off, pixels_pred=pa.tolist(), pixels_ref=pg.tolist()))
        else:
            row.update(research_status='not_compared_pixels_only_probe', research_Q_v11=None)
        rows.append(row)
    write_csv(args.out / 'official_control_results.csv', rows)
    write_json(args.out / 'control_details.json', detail)
    same = [r for r in rows if r.get('representation_family') == 'same_nonflat_ring']
    score_range = max(r['research_Q_v11'] for r in same) - min(r['research_Q_v11'] for r in same)
    off_range = max(r['official_iou3d_raw'] for r in same) - min(r['official_iou3d_raw'] for r in same)
    byid = {r['case_id']: r for r in rows}
    max_diff = max(r.get('official_vs_current_corner_abs_difference', 0.) for r in rows)
    checks = {
        'perfect_official_iou_equals_one': abs(byid['perfect_rectangle']['official_iou3d_raw']-1) < 1e-12,
        'valid_geometry_official_and_current_height_convention_match': max_diff < 1e-10,
        'identical_nonflat_geometry_Q_subdivision_stable': score_range < 1e-8,
        'official_corner_weight_is_not_subdivision_invariant': off_range > .4,
        'mean_cancellation_is_invisible_to_official_iou': abs(byid['mean_cancel_base4']['official_iou3d_raw']-1) < 1e-12,
        'Hstar_existing_mechanism_detects_mean_cancellation': byid['mean_cancel_base4']['Hstar'] > .1,
        'nonpositive_wall_height_not_admitted_to_research': byid['invalid_pred_negative_wall_height']['research_Q_v11'] is None,
        'pair_x_mismatch_raises_official_assertion': byid['pixels_pair_x_mismatch']['official_branch_status']=='raised_AssertionError',
        'NaN_not_silently_counted_as_genuine_zero': byid['pixels_nan_ceiling']['official_branch_status']=='returned_nonfinite',
    }
    engine_after = {str(f.relative_to(args.engine)): hashlib.sha256(f.read_bytes()).hexdigest()
                    for f in args.engine.rglob('*.py')}
    checks['source_engine_unchanged'] = engine_before == engine_after
    checks['official_source_unchanged'] = original_manifest == verify_official_sources()
    summary = dict(status='passed' if all(checks.values()) else 'failed', checks=checks,
        total_control_cases=len(rows), shared_valid_official_corner_pairs=sum(
            'official_vs_current_corner_abs_difference' in r for r in rows),
        maximum_official_vs_current_corner_abs_difference=max_diff,
        same_geometry_collinear_subdivision_Q_range=score_range,
        same_geometry_official_iou3d_range=off_range,
        official_source_commit=original_manifest['commit'], ast_branch=ast_lines,
        official_full_CLI=False, official_depth_RMSE_delta1=False, Manhattan_postprocess_applied=False,
        current_engine_path=str(args.engine.resolve()), engine_sha256=engine_before,
        environment=dict(python=platform.python_version(), numpy=np.__version__, shapely=shapely.__version__),
        evidence_class='new_control_experiment_not_real_image_validation',
        source_and_GT_mutated=False, weights_tuned=False)
    write_json(args.out / 'validation.json', summary)
    print(json.dumps(plain(summary), ensure_ascii=False, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
