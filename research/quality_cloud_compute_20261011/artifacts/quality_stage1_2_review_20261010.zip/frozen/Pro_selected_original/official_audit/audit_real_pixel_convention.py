#!/usr/bin/env python3
"""Six prespecified-image coordinate convention probes from current loader data.

The selection is independent of quality and coordinate-convention differences.
No Q is calibrated and no eligibility is restored. Each output is diagnostic.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

from audit_official_controls import load_module, load_official_iou_branch, run_compatibility, write_csv, write_json, verify_official_sources

HERE=Path(__file__).resolve().parent
IMAGE_CODES=['e9zR4mvMWw7-17','x8F5xyUWy9e-09','UwV83HsGsw3-09',
             'rPc6DW4iMge-06','uNb9QFRL6hY-54','pRbA3pwrgk9-02']


def project_current_object(obj):
    """Current canvas convention, retaining the loader's paired ring order."""
    points=obj.get('points_1024x512')
    if points is None:
        raise ValueError('points_unavailable_from_current_loader')
    p=np.asarray(points,dtype=float)
    if p.ndim!=2 or p.shape[1]!=2 or len(p)%2:
        raise ValueError('paired_canvas_points_shape_invalid')
    u=(p[:,0]/1024.-.5)*2*np.pi
    v=(p[:,1]/512.-.5)*np.pi
    if np.any(np.abs(np.tan(v[1::2]))<1e-14):
        raise ValueError('floor_at_horizon')
    radius=1/np.tan(v[1::2])
    b=np.c_[radius*np.sin(u[1::2]),np.full(len(radius),-1.),-radius*np.cos(u[1::2])]
    t=np.c_[radius*np.sin(u[0::2]),-radius*np.tan(v[0::2]),-radius*np.cos(u[0::2])]
    return dict(top3d=t.tolist(),bottom3d=b.tolist(),points=p.tolist())


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--current-input',type=Path,required=True)
    p.add_argument('--aliases',type=Path,required=True)
    p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--dependencies',type=Path,default=HERE/'vendor_dependencies')
    args=p.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise SystemExit('Use a new empty output path.')
    args.out.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(args.dependencies))
    from shapely.geometry import Polygon
    verify_official_sources()
    fn,post,_=load_official_iou_branch(Polygon)
    tr=load_module(args.engine/'traditional/traditional_metrics.py','_trad_real_pixel_probe')
    data=json.loads(args.current_input.read_text())
    if 'data' in data and isinstance(data['data'],dict):
        data=data['data']
    assert data['schema']=='final_review_research_input_v1'
    assert len(data['objects'])==3441
    objects={o['object_id']:o for o in data['objects']}
    aliases=json.loads(args.aliases.read_text())['records']
    images={im['image_code']:im for im in data['images']}
    rows=[];saved=[];missing=[]
    write_json(args.out/'selection_rule.json',dict(prespecified_images=IMAGE_CODES,
        rule='first lexicographic object_id with available strictly valid paired geometry for each image',
        image_selection_reason='historical cases covering scope, nonorthogonal, corrected GT, glass and range; not selected by observed pixel effect',
        quality_or_parameter_selection=False))
    for code in IMAGE_CODES:
        im=images.get(code)
        if im is None:
            missing.append(dict(image_code=code,reason='image_not_in_loaded_inventory'));continue
        rid=im['references'].get('gt_manual_revision') or im['references'].get('gt_original')
        if not rid:
            missing.append(dict(image_code=code,reason='selected_reference_missing'));continue
        ref=objects[rid]
        try:g=project_current_object(ref)
        except ValueError as exc:
            missing.append(dict(image_code=code,reason='reference:'+str(exc)));continue
        if not tr.validate_record(g,role='reference')['available']:
            missing.append(dict(image_code=code,reason='selected_reference_geometry_unavailable'));continue
        chosen=None
        for o in sorted((o for o in objects.values() if o['image_id']==im['image_id'] and o['object_kind']=='annotation'),key=lambda o:o['object_id']):
            try:a=project_current_object(o)
            except ValueError:continue
            if tr.validate_record(a,role='annotation')['available']:
                chosen=(o,a);break
        if chosen is None:
            missing.append(dict(image_code=code,reason='no_strictly_valid_paired_annotation'));continue
        o,a=chosen
        correct_a,correct_g=tr.frozen_to_hohonet_pixels(a),tr.frozen_to_hohonet_pixels(g)
        raw_a,raw_g=np.asarray(a['points']),np.asarray(g['points'])
        corrected=run_compatibility(fn,correct_a,correct_g)
        naive=run_compatibility(fn,raw_a,raw_g)
        xonly_a,xonly_g=correct_a.copy(),correct_g.copy()
        xonly_a[:,0]+=.5;xonly_g[:,0]+=.5
        xonly=run_compatibility(fn,xonly_a,xonly_g)
        roundtrip=[]
        for raw,correct in [(raw_a,correct_a),(raw_g,correct_g)]:
            dx=(correct[:,0]-(raw[:,0]-.5)+512)%1024-512
            dy=correct[:,1]-(raw[:,1]-.5)
            roundtrip.append(float(max(abs(dx).max(),abs(dy).max())))
        row=dict(image_code=code,image_id=im['image_id'],object_id=o['object_id'],reference_object_id=rid,
            record_id=aliases[o['object_id']],reference_id=aliases[rid],
            reference_version=ref['object_kind'],annotation_worker_quality_gate=o.get('worker_quality_gate'),
            reference_object_gate=ref.get('worker_quality_gate'),diagnostic_only=True,
            source_point_count=len(raw_a),reference_point_count=len(raw_g),
            canvas_minus_half_pixel_max_roundtrip_difference=max(roundtrip),
            official_iou3d_same_geometry_vertex_mean=corrected['official_iou3d_raw'],
            official_iou2d_same_geometry=corrected['official_iou2d_raw'],
            official_iou3d_raw_canvas_probe=naive['official_iou3d_raw'],
            official_iou2d_raw_canvas_probe=naive['official_iou2d_raw'],
            official_iou3d_x_only_halfpixel_shift_probe=xonly['official_iou3d_raw'],
            official_status_same_geometry=corrected['official_branch_status'],
            official_status_raw_canvas=naive['official_branch_status'],
            raw_canvas_iou3d_difference=naive['official_iou3d_raw']-corrected['official_iou3d_raw'],
            raw_canvas_iou2d_difference=naive['official_iou2d_raw']-corrected['official_iou2d_raw'],
            only_x_iou3d_difference=xonly['official_iou3d_raw']-corrected['official_iou3d_raw'],
            frozen_geometry_points_sha256=hashlib.sha256(json.dumps(o['points_1024x512'],separators=(',',':')).encode()).hexdigest())
        rows.append(row)
        saved.append(dict(image_code=code,annotation_object_id=o['object_id'],reference_object_id=rid,
            annotation_geometry=a,reference_geometry=g,corrected_pixels_annotation=correct_a,
            corrected_pixels_reference=correct_g,corrected_official=corrected,raw_canvas_probe=naive,x_only_shift_probe=xonly))
    checks=dict(expected_six_prespecified_images_obtained=len(rows)==6,
        ray_preserving_conversion_matches_canvas_minus_half_pixel=max((r['canvas_minus_half_pixel_max_roundtrip_difference'] for r in rows),default=1)<1e-10,
        common_yaw_halfpixel_does_not_change_iou=max((abs(r['only_x_iou3d_difference']) for r in rows),default=1)<1e-10,
        all_official_same_geometry_and_probe_finite=all(r['official_status_same_geometry']=='returned_finite' and r['official_status_raw_canvas']=='returned_finite' for r in rows))
    summary=dict(status='passed' if all(checks.values()) else 'failed',checks=checks,
        case_count=len(rows),missing_or_unavailable=missing,
        current_input_file_sha256=hashlib.sha256(args.current_input.read_bytes()).hexdigest(),
        aliases_file_sha256=hashlib.sha256(args.aliases.read_bytes()).hexdigest(),
        input_revisions={k:v for k,v in data.items() if ('revision' in k or 'version' in k) and isinstance(v,(str,int,float,bool))},
        maximum_absolute_naive_iou3d_change=max((abs(r['raw_canvas_iou3d_difference']) for r in rows),default=None),
        maximum_absolute_naive_iou2d_change=max((abs(r['raw_canvas_iou2d_difference']) for r in rows),default=None),
        dtype='float64 for both paths to isolate convention from rounding',
        source_geometry_mutated=False,scope_reference_changed=False,eligibility_changed=False,
        score_calibration=False,official_full_CLI_run=False,
        inference='raw x halfpixel is a common yaw and cancels; raw y halfpixel changes elevation, depth and height estimates')
    write_csv(args.out/'real_pixel_convention_six.csv',rows)
    write_json(args.out/'raw_and_adapted_inputs.json',saved)
    write_json(args.out/'validation.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    if not all(checks.values()):raise SystemExit(1)


if __name__=='__main__':
    main()
