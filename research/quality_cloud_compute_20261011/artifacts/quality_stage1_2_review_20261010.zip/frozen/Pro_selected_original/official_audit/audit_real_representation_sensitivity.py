#!/usr/bin/env python3
"""Risk-selected real geometry audit of numerical representation sensitivity.

Risk selection uses no Q or human labels. It is not a blind holdout experiment:
the added three mechanism records were named after prior inspection, and this
audit follows a synthetic sampling failure. No weights or formal inputs change.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from audit_official_controls import load_module, subdivide, write_csv, write_json
from audit_height_pulse_sampling import rolled


META_FIELDS = ['record_id', 'object_id', 'image_code', 'image_id', 'selected_gt_object_id',
               'selected_gt_record_id', 'selected_gt_version', 'score_status',
               'conservative_fixed_gt_quality_candidate', 'target_aligned_quality_candidate',
               'main_quality_gate', 'worker_quality_gate', 'reference_research_status',
               'group_split', 'historical_exposure', 'room_id', 'building_id',
               'reference_policy_reasons', 'all_research_exclusion_reasons']


def ring_risks(a, g):
    out = {}
    for name, record in [('annotation', a), ('reference', g)]:
        for ring in ['bottom3d', 'top3d']:
            p = np.asarray(record[ring], float)
            ell = np.linalg.norm(np.roll(p, -1, axis=0)-p, axis=1)
            prefix = name+'_'+ring
            out[prefix+'_vertex_count'] = len(p)
            out[prefix+'_perimeter_h'] = float(ell.sum())
            out[prefix+'_min_edge_h'] = float(ell.min())
            out[prefix+'_min_edge_perimeter_ratio'] = float(ell.min()/ell.sum())
    keys = [k for k in out if k.endswith('_min_edge_perimeter_ratio')]
    out['selection_min_edge_perimeter_ratio'] = min(out[k] for k in keys)
    out['selection_risk_ring'] = min(keys, key=lambda k: out[k]).removesuffix('_min_edge_perimeter_ratio')
    return out


def representation_variants(a, g):
    variants = [dict(variant_id='original', family='original', annotation=a, reference=g)]
    for name, record, other in [('annotation', a, g), ('reference', g, a)]:
        n=len(record['bottom3d'])
        h=np.asarray(record['top3d'])[:,1]-np.asarray(record['bottom3d'])[:,1]
        offsets=sorted(set([1, n//2, int(np.argmax(h))])-{0})
        for start in offsets:
            changed=rolled(record,start)
            variants.append(dict(variant_id=f'{name}_cyclic{start}', family='cyclic_start',
                annotation=changed if name=='annotation' else other,
                reference=other if name=='annotation' else changed,
                changed_role=name, start_index=start))
    variants.append(dict(variant_id='both_cyclic1', family='cyclic_start',
                         annotation=rolled(a,1),reference=rolled(g,1), changed_role='both', start_index=1))
    for name, record, other in [('annotation',a,g),('reference',g,a)]:
        b=np.asarray(record['bottom3d'])
        ell=np.linalg.norm(np.roll(b,-1,axis=0)-b,axis=1)
        choices=[('shortest',int(np.argmin(ell)))]
        if name=='annotation': choices.append(('longest',int(np.argmax(ell))))
        for edge_name,edge in choices:
            changed=subdivide(record,edge,4)
            variants.append(dict(variant_id=f'{name}_add4_{edge_name}',family='exact_collinear_subdivision',
                annotation=changed if name=='annotation' else other,
                reference=other if name=='annotation' else changed,
                changed_role=name, subdivided_edge=edge, inserted_points=4))
    return variants


def coarse(q):
    return '95_plus' if q>=95 else '85_to_95' if q>=85 else '50_to_85' if q>=50 else 'below_50'


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--projected',type=Path,required=True)
    p.add_argument('--score-table',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    if args.out.exists() and any(args.out.iterdir()): raise SystemExit('Use a new empty output directory.')
    args.out.mkdir(parents=True,exist_ok=True)
    projected=json.loads(args.projected.read_text())
    # Deliberately discard all score and candidate columns for risk selection.
    with args.score_table.open(encoding='utf-8-sig') as f:
        meta=[{k:r[k] for k in META_FIELDS} for r in csv.DictReader(f)]
    by_rid={r['record_id']:r for r in meta}
    risks=[]
    for r in meta:
        if r['score_status']!='available' or r['conservative_fixed_gt_quality_candidate']!='True': continue
        a=projected[r['object_id']]['geometry'];g=projected[r['selected_gt_object_id']]['geometry']
        risks.append({**r,**ring_risks(a,g)})
    risks.sort(key=lambda r:(r['selection_min_edge_perimeter_ratio'],r['image_code'],r['record_id']))
    write_csv(args.out/'eligible_geometry_risk_inventory.csv',risks)
    selected=[];seen_images=set()
    for r in risks:
        if r['image_code'] in seen_images: continue
        selected.append({**r,'selection_role':'risk_selected_cross_image'})
        seen_images.add(r['image_code'])
        if len(selected)==10: break
    selected_ids={r['record_id'] for r in selected}
    for rid in ['R01920','R02075','R00064']:
        if rid in selected_ids:
            next(r for r in selected if r['record_id']==rid)['also_named_mechanism_example']=True
            continue
        r=by_rid[rid]
        if r['score_status']!='available': raise ValueError('Named mechanism geometry is not calculable: '+rid)
        a=projected[r['object_id']]['geometry'];g=projected[r['selected_gt_object_id']]['geometry']
        selected.append({**r,**ring_risks(a,g),'selection_role':'previously_inspected_named_mechanism'})
        selected_ids.add(rid)
    write_csv(args.out/'selection_frozen_before_Q.csv',selected)
    write_json(args.out/'experiment_design.json',dict(
        selected_before_Q_read=True, Q_or_labels_used_for_selection=False,
        eligibility='score_status available AND conservative_fixed_gt_quality_candidate True',
        candidate_count=len(risks), risk='minimum of min(edge_length)/perimeter across annotation and fixed-reference top/bottom 3D rings',
        top_ten_rule='ascending risk ratio, ties by image code then record ID, at most one per image',
        fixed_named_cases=['R01920','R02075','R00064'], selected_count=len(selected),
        numerical_variants='each ring cyclic start 1, halfway, maximum wall-height vertex (unique nonzero indices); both cyclic1; exact linear insertion of4 points on annotation shortest/longest and reference shortest floor edge',
        fixed_Q_version='geom_quality_research_v1.1.0', thresholds=[95,85,50],
        calibration_or_tuning=False, independent_blind_validation=False,
        warning='A short edge is a sampling-resolution risk, not evidence of an actual annotation defect. Named examples retain their qualification and reference gates.',
        projected_sha256=hashlib.sha256(args.projected.read_bytes()).hexdigest(),
        score_table_sha256=hashlib.sha256(args.score_table.read_bytes()).hexdigest(),
        engine_sha256=hashlib.sha256((args.engine/'core/quality_v11.py').read_bytes()).hexdigest()))
    # Only now read the frozen default Q for the selected IDs. Never use the
    # stronger/staged candidate columns in this numerical audit.
    with args.score_table.open(encoding='utf-8-sig') as f:
        existing_Q={r['record_id']:float(r['Q_v11']) for r in csv.DictReader(f) if r['record_id'] in selected_ids}
    q=load_module(args.engine/'core/quality_v11.py','_q_real_representation_sensitivity')
    geometries=[];results=[];case_rows=[]
    for i,s in enumerate(selected):
        rid=s['record_id'];a=projected[s['object_id']]['geometry'];g=projected[s['selected_gt_object_id']]['geometry']
        variants=representation_variants(a,g)
        geometries.append(dict(record_id=rid,selection=s,original_annotation=a,original_reference=g,
                               variants=variants))
        original_q=None
        for v in variants:
            full=q.score_geometry(v['annotation'],v['reference'])
            m=full['metrics'];score=full['quality_score']
            if v['variant_id']=='original': original_q=score
            row={**s,**{k:v[k] for k in v if k not in ['annotation','reference']},
                 'status':full['status'],'reason_codes':';'.join(full['reason_codes']),
                 'Q_v11_recomputed':score,'Q_original_recomputed':original_q,
                 'Q_frozen_main_run':existing_Q[rid]}
            if score is not None:
                row.update(Q_delta_from_original=score-original_q, Q_original_delta_from_main=original_q-existing_Q[rid],
                           coarse_class=coarse(score), original_coarse_class=coarse(original_q),
                           crossed_thresholds=';'.join(str(t) for t in [95,85,50] if (score>=t)!=(original_q>=t)))
            for key in ['iou','S_top_deg','S_bottom_deg','dir','flat','Hmean','Hlocal','Hstar']:
                row[key]=m.get(key)
            case_rows.append(row)
            results.append(dict(record_id=rid,variant_id=v['variant_id'],result=full))
        print(json.dumps({'completed_geometry_cases':i+1,'total_selected':len(selected),'record_id':rid}),flush=True)
    per_case=[]
    for s in selected:
        rr=[r for r in case_rows if r['record_id']==s['record_id']]
        valid=[r for r in rr if r['status']=='available']
        cyclic=[r for r in valid if r['family']=='cyclic_start']
        subdiv=[r for r in valid if r['family']=='exact_collinear_subdivision']
        per_case.append({**s,'variant_count':len(rr),'available_variant_count':len(valid),
            'Q_original':valid[0]['Q_v11_recomputed'],
            'max_abs_cyclic_Q_difference':max(abs(r['Q_delta_from_original']) for r in cyclic),
            'max_abs_subdivision_Q_difference':max(abs(r['Q_delta_from_original']) for r in subdiv),
            'all_variant_Q_range':max(r['Q_v11_recomputed'] for r in valid)-min(r['Q_v11_recomputed'] for r in valid),
            'coarse_boundary_crossing_variant_count':sum(bool(r['crossed_thresholds']) for r in valid)})
    available=[r for r in case_rows if r['status']=='available']
    summary=dict(
        selected_cases=len(selected),risk_selected_images=sum(s['selection_role']=='risk_selected_cross_image' for s in selected),
        added_named_mechanism_cases=sum(s['selection_role']=='previously_inspected_named_mechanism' for s in selected),
        different_images=len({s['image_code'] for s in selected}),
        total_variants=len(case_rows),available_variants=len(available),
        max_base_Q_difference_from_main=max(abs(r['Q_original_delta_from_main']) for r in available),
        max_abs_cyclic_Q_difference=max(r['max_abs_cyclic_Q_difference'] for r in per_case),
        max_abs_subdivision_Q_difference=max(r['max_abs_subdivision_Q_difference'] for r in per_case),
        maximum_same_geometry_Q_range=max(r['all_variant_Q_range'] for r in per_case),
        coarse_boundary_crossing_variants=sum(bool(r['crossed_thresholds']) for r in available),
        cases_with_boundary_crossing=sum(r['coarse_boundary_crossing_variant_count']>0 for r in per_case),
        thresholds=[95,85,50], weight_candidates_read=False, source_geometry_edited=False,
        interpretation='A finite risk-selected numerical audit; no claim that all real images, all cyclic phases, or all subdivisions are invariant. Any ineligible named case remains diagnostic only.')
    write_csv(args.out/'representation_sensitivity_rows.csv',case_rows)
    write_csv(args.out/'representation_sensitivity_per_case.csv',per_case)
    write_json(args.out/'input_and_variant_geometries.json',geometries)
    write_json(args.out/'full_default_quality_results.json',results)
    write_json(args.out/'summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
