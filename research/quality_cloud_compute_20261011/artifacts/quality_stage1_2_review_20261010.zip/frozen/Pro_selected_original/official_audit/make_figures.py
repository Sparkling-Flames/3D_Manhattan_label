#!/usr/bin/env python3
"""Render exact synthetic geometry/metric evidence from completed audit files."""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})

def read_csv(path):
    return list(csv.DictReader(path.open(encoding='utf-8-sig')))

def draw_shape(ax,record,color='#205b89'):
    b=np.asarray(record['bottom3d'])[:,[0,2,1]].copy()
    t=np.asarray(record['top3d'])[:,[0,2,1]].copy()
    b[:,2]+=1;t[:,2]+=1
    faces=[[b[i],b[(i+1)%len(b)],t[(i+1)%len(t)],t[i]] for i in range(len(b))]
    ax.add_collection3d(Poly3DCollection(faces,facecolor=color,edgecolor='none',alpha=.16))
    for ring in [b,t]:
        closed=np.vstack([ring,ring[0]])
        ax.plot(closed[:,0],closed[:,1],closed[:,2],c=color,lw=1.2)
        ax.scatter(ring[:,0],ring[:,1],ring[:,2],s=8,c=color)
    for i in range(len(b)):
        ax.plot([b[i,0],t[i,0]],[b[i,1],t[i,1]],[b[i,2],t[i,2]],c=color,lw=.35,alpha=.5)
    ax.set_xlim(-2.2,2.2);ax.set_ylim(-1.2,1.2);ax.set_zlim(0,3.2)
    ax.set_box_aspect((4.4,2.4,3.2));ax.view_init(elev=22,azim=-56)
    ax.set_xlabel('X / h');ax.set_ylabel('Z / h');ax.set_zlabel('Wall height / h')

cases={r['case_id']:r for r in json.loads((ROOT/'results/control_geometries.json').read_text())}
rows={r['case_id']:r for r in read_csv(ROOT/'results/official_control_results.csv')}
fig=plt.figure(figsize=(13,8.8))
fig.suptitle('Exact collinear subdivision changes corner-mean IoU, while geometry and Q stay fixed',fontsize=14,y=.98)
for i,(cid,title) in enumerate([('mean_cancel_base4','Original: 4 pairs'),('mean_cancel_low_edge_add40','40 pairs added on low wall'),('mean_cancel_high_edge_add40','40 pairs added on high wall')]):
    ax=fig.add_subplot(2,3,i+1,projection='3d');draw_shape(ax,cases[cid]['annotation'])
    ax.set_title(title+'\nOfficial 3D IoU = '+f"{float(rows[cid]['official_iou3d_raw']):.3f}",fontsize=11)
x=np.array([0,1,4,40]);xpos=np.arange(4)
for j,(col,title,ylabel) in enumerate([
    ('official_iou3d_raw','Official vertex-mean 3D IoU','IoU'),
    ('research_perimeter_mean_iou3d','Conditional perimeter-mean 3D IoU','IoU'),
    ('research_Q_v11','Frozen v1.1 Q','Quality points')]):
    ax=fig.add_subplot(2,3,j+4)
    for edge,color in [('low','#c05b31'),('high','#205b89')]:
        values=[float(rows['mean_cancel_base4' if n==0 else f'mean_cancel_{edge}_edge_add{n}'][col]) for n in x]
        ax.plot(xpos,values,marker='o',c=color,label=edge+' wall subdivision')
    ax.set_xticks(xpos,[str(n) for n in x]);ax.set_xlabel('Number of added collinear pairs')
    ax.set_ylabel(ylabel);ax.set_title(title,fontsize=11)
    ax.set_ylim((0,1.05) if j<2 else (0,10));ax.grid(axis='y',alpha=.2)
    if j==0:ax.legend(fontsize=8,loc='lower left')
fig.text(.5,.015,'All upper panels show the same piecewise linear surface. Reference: same footprint, flat wall height 2 h.\nThe two IoU variants summarize height; Q additionally evaluates boundaries, Hstar and intrinsic geometry.',ha='center',fontsize=10)
fig.subplots_adjust(left=.06,right=.97,bottom=.13,top=.91,wspace=.35,hspace=.40)
fig.savefig(OUT/'official_collinear_height_counterexample.png',dpi=190,bbox_inches='tight')
plt.close(fig)

physical=[r for r in read_csv(ROOT/'direction_results/direction_dilution_controls.csv') if r['family']=='physical_correct_length_added']
L=[float(r['half_length_h']) for r in physical]
D=[float(r['dir']) for r in physical]
F=[100*float(r['reference_fraction_above_20deg']) for r in physical]
Q=[float(r['Q_v11']) for r in physical]
fig,axes=plt.subplots(1,3,figsize=(13,4.7))
fig.suptitle('Fixed local 45-degree defect; increasing actual correct wall length dilutes its global RMS',fontsize=13,y=.98)
axes[0].plot(L,D,'o-',c='#205b89',label='Own-axis RMS D')
axes[0].plot(L,[45]*4,'--',c='#c05b31',label='Max residual to GT axis')
axes[0].set_ylabel('Angle / degrees');axes[0].set_ylim(0,49);axes[0].legend(fontsize=8,loc='center right')
axes[1].plot(L,F,'o-',c='#205b89');axes[1].set_ylabel('Actual anomalous wall length / perimeter (%)')
axes[1].set_ylim(0,6.5)
axes[2].plot(L,Q,'o-',c='#205b89');axes[2].set_ylabel('Frozen v1.1 Q');axes[2].set_ylim(90,100.1)
for ax in axes:
    ax.set_xscale('log',base=4);ax.set_xticks(L,[str(int(n)) for n in L]);ax.set_xlabel('Rectangle half-length L / h');ax.grid(alpha=.2)
for x,y in zip(L,D):axes[0].annotate(f'{y:.2f}',(x,y),xytext=(0,8),textcoords='offset points',ha='center',fontsize=9)
for x,y in zip(L,F):axes[1].annotate(f'{y:.3f}%',(x,y),xytext=(0,8),textcoords='offset points',ha='center',fontsize=9)
for x,y in zip(L,Q):axes[2].annotate(f'{y:.2f}',(x,y),xytext=(0,-16),textcoords='offset points',ha='center',fontsize=9)
fig.text(.5,.025,'The triangular protrusion always has half-width = height = 0.25 h. Longer walls change physical extent.\nAdding 40 exact collinear points to the same geometry changes Q by at most 4.3e-14; it does not cause this dilution.',ha='center',fontsize=10)
fig.subplots_adjust(left=.07,right=.98,bottom=.23,top=.84,wspace=.36)
fig.savefig(OUT/'direction_physical_length_dilution.png',dpi=190,bbox_inches='tight')
plt.close(fig)
print(str(OUT))
