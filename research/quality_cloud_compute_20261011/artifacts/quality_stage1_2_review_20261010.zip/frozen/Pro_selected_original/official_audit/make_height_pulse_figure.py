#!/usr/bin/env python3
"""Render the completed fixed-amplitude pulse audit; never generates scores."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
def read(path):
    with path.open(encoding='utf-8-sig') as f: return list(csv.DictReader(f))
rows=read(HERE/'height_pulse_results_with_apex/height_pulse_controls.csv')
dense=read(HERE/'height_pulse_results_with_apex/height_pulse_density_controls.csv')
follow=read(HERE/'height_pulse_convergence_followup/narrow_pulse_convergence.csv')
base=sorted([r for r in rows if r['cyclic_start']=='0'],key=lambda r:float(r['support_width_h']))
x=[1/float(r['width_divisor']) for r in base]
fig,axs=plt.subplots(2,2,figsize=(13,8.4),constrained_layout=True)
colors={0:'#2166ac',2:'#ae3376'}
labels={0:'Original corner start',2:'Same geometry, apex start'}
for start in [0,2]:
    rr=sorted([r for r in rows if r['cyclic_start']==str(start)],key=lambda r:float(r['support_width_h']))
    axs[0,0].plot(x,[float(r['Hlocal']) for r in rr],'o-',c=colors[start],label=labels[start])
    axs[0,1].plot(x,[float(r['flat']) for r in rr],'o-',c=colors[start],label=labels[start])
    axs[1,0].plot(x,[float(r['Q_v11_default']) for r in rr],'o-',c=colors[start],label=labels[start])
axs[0,0].plot(x,[float(r['Hlocal_exact']) for r in base],'k--',lw=1.6,label='Exact perimeter RMS')
axs[0,1].plot(x,[float(r['F_edge_quadrature_128_deg']) for r in base],'k--',lw=1.6,label='Separate integration on each edge')
axs[1,0].plot(x,[float(r['Q_Hexact_Fedge_other_components_frozen']) for r in base],'k--',lw=1.6,label='Exact H + edge F; other terms fixed')
axs[0,0].set(title='Hlocal: true RMS falls with support width',ylabel='Relative RMS height error')
axs[0,1].set(title='F512 can miss a pulse by sampling phase',ylabel='Flatness residual (degrees)')
axs[1,0].set(title='Default Q: up to 0.653-point cyclic difference',ylabel='Research quality Q',ylim=(93.5,100.1))
for ax in [axs[0,0],axs[0,1],axs[1,0]]:
    ax.set_xscale('log',base=2);ax.set_xticks(x,labels=['1/8192','1/512','1/32'])
    ax.set_xlabel('Pulse support / physical floor perimeter')
    ax.grid(alpha=.2);ax.legend(fontsize=8.6,loc='best')
for start in [0,2]:
    rr=sorted([r for r in dense if r['width_divisor']=='8192' and r['cyclic_start']==str(start)],key=lambda r:int(r['samples_per_perimeter']))
    nn=[int(r['samples_per_perimeter']) for r in rr]
    yy=[float(r['Hlocal']) for r in rr]
    fr=next(r for r in follow if r['case_id']==f'pulse_Pover8192_cyclic{start}')
    nn.append(131072);yy.append(float(fr['Hlocal']))
    axs[1,1].plot(nn,yy,'o-',c=colors[start],label=labels[start])
axs[1,1].axhline(float(base[0]['Hlocal_exact']),ls='--',c='k',label='Exact Hlocal = 0.00318944')
axs[1,1].set(xscale='log',title='Narrowest pulse: resolution convergence',xlabel='Samples per floor perimeter',ylabel='Relative RMS height error')
axs[1,1].set_xticks([512,4096,32768,131072],labels=['512','4096','32768','131072'])
axs[1,1].grid(alpha=.2);axs[1,1].legend(fontsize=8.6,loc='lower right')
fig.suptitle('Fixed local peak +1h; reference height 2h; identical floor footprint\nPhysical averaging is separate from numerical under-sampling',fontsize=14)
out=HERE/'figures/height_pulse_sampling_audit.png';out.parent.mkdir(exist_ok=True)
fig.savefig(out,dpi=180,bbox_inches='tight');plt.close(fig)
print(out)
