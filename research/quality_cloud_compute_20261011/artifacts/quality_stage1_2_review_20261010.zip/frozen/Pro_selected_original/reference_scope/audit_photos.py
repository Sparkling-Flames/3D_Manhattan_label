#!/usr/bin/env python3
"""Read-only inventory of actual photo renditions and reference-only identities."""
import argparse,csv,hashlib,json
from collections import Counter,defaultdict
from pathlib import Path
from PIL import Image


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write_csv(p,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fields);w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})

def main():
    p=argparse.ArgumentParser();p.add_argument('--current-data',type=Path,required=True);p.add_argument('--scope-bundle',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    data=read(a.current_data);scope=a.scope_bundle.resolve();dist=scope/'workbench_v3.4.2/dist'
    r=read(scope/'final_scope_reference_integration/results/reference_registry.json')['records']
    im={x['image_code']:x for x in data['images']};sr={x['image_code']:x for x in r}
    out=a.out.resolve()
    if out.exists() and any(out.iterdir()):raise FileExistsError('nonempty output')
    out.mkdir(parents=True,exist_ok=True)
    files=[]
    for folder,role in [('assets','photographic_rendition'),('evidence','derived_evidence_card')]:
        for f in sorted((dist/folder).rglob('*')):
            if not f.is_file() or f.suffix.lower() not in {'.jpg','.png','.jpeg'}:continue
            code=f.stem;size=f.stat().st_size;h=hashlib.sha256(f.read_bytes()).hexdigest()
            try:
                with Image.open(f) as image:
                    dimensions=image.size;mode=image.mode;image.load()
                status='readable';failure=None
            except Exception as e:dimensions=(None,None);mode=None;status='read_failure';failure=type(e).__name__+':'+str(e)
            context=im.get(code) or sr.get(code)
            image_id=context.get('image_id') if context else None
            is_research=bool(code in im and im[code]['population']=='research_annotation_image')
            files.append(dict(relative_path=f.relative_to(scope).as_posix(),file_name=f.name,image_code=code,image_id=image_id,
                role=role,width=dimensions[0],height=dimensions[1],mode=mode,bytes=size,sha256=h,read_status=status,read_failure=failure,
                in_formal_research_259=is_research,is_new_recovered_reference_only=bool(code in sr and not sr[code]['in_current_formal_corpus']),
                is_formal_existing_reference_only=bool(code in im and im[code]['population']!='research_annotation_image'),
                does_not_add_research_image=not is_research or role!='photographic_rendition'))
    photographic=[x for x in files if x['role']=='photographic_rendition'];photos_by_code=defaultdict(list)
    for x in photographic:photos_by_code[x['image_code']].append(x)
    mapping=[]
    for code in sorted(set(im)|set(sr)):
        image=im.get(code);s=sr.get(code);f=photos_by_code.get(code,[])
        mapping.append(dict(image_code=code,image_id=(image or s)['image_id'],
            in_formal_research_259=bool(image and image['population']=='research_annotation_image'),
            in_formal_existing_reference_only=bool(image and image['population']!='research_annotation_image'),
            new_recovered_reference_only=bool(s and not s['in_current_formal_corpus']),
            formal_annotation_count=image.get('annotations',0) if image else 0,
            formal_GT_objects=image.get('references',{}) if image else {},
            latest_confirmed_floor_reference_id=s.get('reference_id') if s else None,
            photo_file_count=len(f),readable_photo_count=sum(x['read_status']=='readable' for x in f),
            photo_rendition_paths=[x['relative_path'] for x in f],
            picture_status='present_readable' if f and all(x['read_status']=='readable' for x in f) else 'not_shipped_in_current_workbench_assets' if not f else 'read_failure'))
    byhash=defaultdict(list)
    for x in files:byhash[x['sha256']].append(x['relative_path'])
    summary=dict(new_run=True,actual_image_files=len(files),photographic_rendition_files=len(photographic),
        jpeg_photographic_files=sum(Path(x['file_name']).suffix.lower()=='.jpg' for x in photographic),
        png_extra_renditions=sum(Path(x['file_name']).suffix.lower()=='.png' for x in photographic),
        photographic_image_identities=len(photos_by_code),derived_evidence_cards=len(files)-len(photographic),
        exact_file_hash_duplicate_groups=[v for v in byhash.values() if len(v)>1],
        duplicate_photo_rendition_image_codes=[k for k,v in photos_by_code.items() if len(v)>1],
        image_read_failures=[x for x in files if x['read_status']!='readable'],
        file_dimensions=dict(Counter(str((x['width'],x['height'])) for x in files)),
        research_image_count=259,research_images_with_readable_photos=sum(x['in_formal_research_259'] and x['readable_photo_count']>0 for x in mapping),
        missing_research_photos=[x['image_code'] for x in mapping if x['in_formal_research_259'] and not x['readable_photo_count']],
        new_recovered_reference_only_codes=[x['image_code'] for x in mapping if x['new_recovered_reference_only']],
        formal_existing_reference_only_codes=[x['image_code'] for x in mapping if x['in_formal_existing_reference_only']],
        formal_existing_reference_only_missing_photos=[x['image_code'] for x in mapping if x['in_formal_existing_reference_only'] and not x['readable_photo_count']],
        union_formal_and_scope_image_identities=len(mapping),
        distinction='The 2 formal existing GT-only images (7y-16,wc2-23) differ from the 2 recovered scope-only views (q9-21,q9-25). Their union is 263 identities; research denominator remains 259.',
        scope='File availability, decoding, hashes and supplied ID mapping; not visual semantic validation of all photographs.')
    write_csv(out/'image_file_inventory_271.csv',files);write_csv(out/'image_GT_photo_mapping_263.csv',mapping)
    (out/'photo_inventory_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
