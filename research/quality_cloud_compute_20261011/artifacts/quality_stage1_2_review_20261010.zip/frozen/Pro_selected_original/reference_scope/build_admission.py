#!/usr/bin/env python3
"""Materialize read-only research admission from the current official loader.

Run with the source checkout and restored scope bundle. Output must be separate.
Q is deliberately not read during selection/group assignment. Join new method
results by object_id/record_id only after this table has been frozen.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import importlib.util
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path
from reference_policy import (ReferencePolicy, assess_annotation, canonical_hash,
    file_hash, POLICY_VERSION, selected_reference_id)

SEED='quality-next-stage-20261011'
FORMAL_COMMIT='24360ad8544d76d8aba18a8e641f784a76ca0d42'
HANDOFF_COMMIT='f485d49f0ccd57a7a7bf64931a81b770a37ff4df'
SCOPE_COMMIT='42f7ea569c591c0cb3472e1b8bb8c0d883bbd3cb'


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def digest_sorted(x):
    return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def save(p,x):
    Path(p).parent.mkdir(parents=True,exist_ok=True)
    Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def write_csv(p,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fields);w.writeheader()
        for r in rows:
            w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})


def metadata_groups(images):
    imgs=[i for i in images if i['population']=='research_annotation_image']
    fallback={i['building_id'] for i in imgs if not i.get('room_id')}
    rows=[]
    for im in sorted(imgs,key=lambda x:x['image_code']):
        b=im['building_id']; key='building:'+b if b in fallback else 'room:'+b+':'+im['room_id']
        h=hashlib.sha256((SEED+'|'+key).encode()).hexdigest()
        rows.append(dict(image_id=im['image_id'],image_code=im['image_code'],building_id=b,room_id=im.get('room_id'),
            group_key=key,group_mode='whole_building_due_to_missing_room_id' if b in fallback else 'room',
            group_split='validation' if int(h[:8],16)%3==0 else 'development',group_hash=h,
            historical_exposure='historical_research_inventory_not_independent_blind_data'))
    return rows


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--scope-bundle',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--registry',type=Path);args=ap.parse_args()
    repo=args.repo.resolve(); out=args.out.resolve(); scope=args.scope_bundle.resolve()
    if out==repo or out.is_relative_to(repo) or out==scope or out.is_relative_to(scope):
        raise ValueError('outputs_must_not_be_inside_source_data')
    if out.exists() and any(out.iterdir()): raise FileExistsError('nonempty_output')
    out.mkdir(parents=True,exist_ok=True)
    regpath=args.registry or repo/'research/quality_next_stage_handoff_20261010/reference_exclusion_registry_20261010.json'
    registry=read(regpath);policy=ReferencePolicy(registry)
    source_checks=policy.validate_sources(repo)
    sys.path.insert(0,str(repo))
    from tools.thesis_main.data_prep.consolidate_research_input import load_current_bundle
    from tools.thesis_main.data_prep.materialize_current_research_input import load_current_input
    from tools.thesis_main.data_prep.project_public_research_20260929 import project_bundle
    bundle=load_current_bundle(); data=bundle['data']
    if data!=load_current_input(): raise ValueError('current_loaders_disagree')
    object_checks=policy.validate_objects(data)
    _,aliases=project_bundle(bundle)
    objects={o['object_id']:o for o in data['objects']};images={i['image_id']:i for i in data['images']}
    baseline=read(repo/'analysis_results/research_input_20260929/preprocessed_source.json')
    original_objects={o['object_id']:o for o in baseline['objects']}
    annotations=[o for o in objects.values() if o['object_kind']=='annotation']
    research_ann={o['object_id']:o for o in bundle['research']['annotations']}
    research_img={o['image_id']:o for o in bundle['research']['images']}
    integration=scope/'final_scope_reference_integration'
    scope_registry=read(integration/'results/reference_registry.json')
    scope_by_image={r['image_id']:r for r in scope_registry['records']}
    if len(scope_registry['records'])!=35 or len(scope_by_image)!=35: raise ValueError('scope_cardinality_changed')
    if any(not r['is_primary'] or r['region_id']!='primary' or not r['top_boundary_pending'] or r['reference_ready'] for r in scope_registry['records']):
        raise ValueError('scope_current_readiness_or_target_set_drift')
    frozen_subset=read(integration/'inputs/current_formal_subset.json')
    actual_digests={oid:digest_sorted(o) for oid,o in objects.items()}
    if frozen_subset['all_formal_object_digests']!=actual_digests:
        raise ValueError('restored_scope_inputs_differ_current_loader')
    scope_metrics=read(integration/'results/record_metrics.json')
    if isinstance(scope_metrics,dict): scope_metrics=scope_metrics.get('records',scope_metrics)
    scope_metric_map={r['object_id']:r for r in scope_metrics}
    if len(scope_metric_map)!=429: raise ValueError('scope_record_count')
    # This fixed source selection was used by the current scope extraction.
    rel='analysis_results/objective_difficulty_20261009/structure_classification/images.csv'
    source_path=repo/rel
    if source_path.exists(): selection_bytes=source_path.read_bytes()
    else: selection_bytes=subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo)
    import io
    selections={r['image_id']:r['gt_object_id'] for r in csv.DictReader(io.StringIO(selection_bytes.decode('utf-8-sig')))}
    groups=metadata_groups(data['images']);group_map={g['image_id']:g for g in groups}
    # Compute scope BEV again is a separate successful process; this joins that
    # verified result without presenting it as complete quality or a GT approval.
    rows=[]; selection_checks=[]
    for o in sorted(annotations,key=lambda x:aliases['records'][x['object_id']]):
        oid=o['object_id'];im=images[o['image_id']];old=original_objects[oid];research=research_ann[oid]
        selected_id=selections.get(im['image_id'])
        if selected_id is None: raise ValueError('fixed_reference_selection_missing:'+im['image_code'])
        gt=objects.get(selected_id)
        if gt is None or gt['image_id']!=im['image_id']: raise ValueError('fixed_reference_binding_invalid:'+im['image_code'])
        if selected_id!=selected_reference_id(im):
            raise ValueError('fixed_reference_policy_differs_existing_selection:'+im['image_code'])
        s=scope_by_image.get(im['image_id']);smetric=scope_metric_map.get(oid)
        if s:
            if s['selected_gt_object_id']!=selected_id: raise ValueError('scope_selection_mismatch:'+im['image_code'])
            if smetric is None or smetric['record_id']!=aliases['records'][oid]: raise ValueError('scope_alias_binding_mismatch:'+oid)
        adjud=assess_annotation(o,im,gt,policy,s)
        row=dict(record_id=aliases['records'][oid],object_id=oid,image_code=im['image_code'],image_id=im['image_id'],
            worker_id=o['worker_id'],condition=o['condition'],source_main_commit=HANDOFF_COMMIT,
            formal_input_commit=FORMAL_COMMIT,scope_delivery_commit=SCOPE_COMMIT,
            input_revision=data.get('quality_update_revision'),order_update_revision=data.get('order_update_revision'),
            original_export_coordinates_sha256=canonical_hash(old.get('original_export_points')),
            baseline_coordinates_sha256=canonical_hash(old.get('points_1024x512')),
            current_coordinates_sha256=canonical_hash(o.get('points_1024x512')),
            current_formal_object_sha256=actual_digests[oid],current_points_available=o.get('points_1024x512') is not None,
            source_points_unchanged_from_frozen=old.get('points_1024x512')==o.get('points_1024x512'),
            preprocessing_status=o.get('preprocessing_status'),formal_geometry_status=o.get('geometry',{}).get('status'),
            formal_geometry_issues=o.get('geometry',{}).get('issues'),
            ring_confirmed=o.get('ring_confirmed'),order_status=o.get('order_status'),
            ordered_source_pair_indices=o.get('ordered_source_pair_indices'),order_record=o.get('order_record'),
            quality_review_provenance=o.get('quality_review_provenance'),
            cleaning_disposition=o.get('cleaning_disposition'),independent_vote_eligible=o.get('independent_vote_eligible'),
            independent_vote_reasons=o.get('independent_vote_reasons'),worker_quality_gate=o.get('worker_quality_gate'),
            main_quality_gate=o.get('main_quality_gate'),main_consensus_gate=o.get('main_consensus_gate'),
            consensus_group=o.get('consensus_group'),scene_category=research.get('scene_category'),
            scene_oos_status=research.get('scene_oos_status'),scene_doorway_status=research.get('scene_doorway_status'),
            gt_substantive_error_mark=research.get('gt_substantive_error_mark'),gt_uncertainty_explicit_tag=research.get('gt_uncertainty_explicit_tag'),
            selected_gt_object_id=selected_id,selected_gt_record_id=aliases['records'][selected_id],
            selected_gt_version=gt['object_kind'],selected_gt_coordinates_sha256=canonical_hash(gt.get('points_1024x512')),
            selected_gt_worker_quality_gate=gt.get('worker_quality_gate'),
            selected_gt_preprocessing_status=gt.get('preprocessing_status'),
            selected_gt_formal_geometry_status=gt.get('geometry',{}).get('status'),
            selected_reference_rule='existing_fixed_structure_classification_selection_checked_manual_else_original',
            scope_reference_id=s['reference_id'] if s else None,scope_floor_sha256=s['floor_polygon_sha256'] if s else None,
            scope_confirmation_origin=s['confirmation_origin'] if s else None,
            scope_confirmation_receipt_sha256=s['confirmation_provenance']['receipt_sha256'] if s else None,
            scope_top_boundary_status='top_pending' if s else 'not_a_new_confirmed_floor',
            scope_reference_ready=s['reference_ready'] if s else None,
            new_scope_complete_quality_permitted=False if s else None,
            scope_bev_calculable=(smetric['geometry_status']=='valid') if smetric else None,
            scope_bev_failure_reason=smetric.get('metrics_unavailable_reason') if smetric else None,
            method_quality_state='join_new_metric_results_before_reporting_effective_n',
            data_access_status='formal_current_loader_success')
        row.update(group_map[im['image_id']]);row.update(adjud);rows.append(row)
    write_csv(out/'admission_3152.csv',rows);save(out/'admission_3152.json',rows)
    write_csv(out/'image_group_split.csv',groups)
    save(out/'current_input/current_data.json',data)
    save(out/'current_input/aliases.json',aliases)
    save(out/'current_input/manifest_and_validation.json',dict(manifest=bundle['manifest'],validation=bundle['validation'],source_files=source_checks,source_main_commit=HANDOFF_COMMIT,formal_input_commit=FORMAL_COMMIT))
    purpose_flags=['formal_quality_gate_candidate','registry_minimum_quality_candidate','conservative_fixed_gt_quality_candidate','target_aligned_quality_candidate','formal_primary_gate_candidate','registry_minimum_primary_candidate','conservative_fixed_gt_primary_candidate','target_aligned_primary_candidate']
    counts={k:dict(records=sum(r[k] for r in rows),images=len({r['image_id'] for r in rows if r[k]}),
            buildings=len({r['building_id'] for r in rows if r[k]}),groups=len({r['group_key'] for r in rows if r[k]}),
            by_condition=dict(Counter(r['condition'] for r in rows if r[k])),
            by_split=dict(Counter(r['group_split'] for r in rows if r[k]))) for k in purpose_flags}
    scope_rows=[r for r in rows if r['scope_confirmed_floor_present']]
    summary=dict(policy_version=POLICY_VERSION,source_main_commit=HANDOFF_COMMIT,formal_input_commit=FORMAL_COMMIT,
        scope_delivery_commit=SCOPE_COMMIT,loader_validation=bundle['validation'],
        all_objects_identical_to_scope_formal_snapshot=True,objects_checked=len(actual_digests),
        registry_source_files_checked=len(source_checks),registry_reference_versions_checked=len(object_checks),
        records=len(rows),research_images=len(groups),buildings=len({r['building_id'] for r in rows}),
        source_input_revision=data.get('quality_update_revision'),order_update_revision=data.get('order_update_revision'),
        exact_source_hashes=source_checks,selection_source_sha256=hashlib.sha256(selection_bytes).hexdigest(),
        qualification_candidate_denominators_before_method_computability=counts,
        original_gate_counts=dict(Counter(r['worker_quality_gate'] for r in rows)),
        original_cleaning_counts=dict(Counter(r['cleaning_disposition'] for r in rows)),
        registry_binding_counts=dict(Counter(r['reference_registry_binding_status'] for r in rows)),
        registry_excluded_records=sum(r['registry_comparison_exclude'] for r in rows),
        extra_conservative_records=sum(r['reference_extra_conservative'] for r in rows),
        repeated_reasons_not_mutually_exclusive=dict(Counter(x for r in rows for x in r['all_research_exclusion_reasons'])),
        group_split_rule=SEED+'|group_key, sha256 first 8 hex modulo 3; zero is validation',
        group_rule='all building if any research image in it has missing room_id; otherwise room:building:room',
        buildings_with_room_fallback=sorted({r['building_id'] for r in groups if r['group_mode'].startswith('whole')}),
        group_counts=dict(Counter(next(r['group_split'] for r in groups if r['group_key']==g) for g in {r['group_key'] for r in groups})),
        scope_scope=dict(confirmed_floor_targets=35,research_images=33,records=len(scope_rows),
            valid_floor=sum(r['scope_bev_calculable'] for r in scope_rows),
            invalid_floor=sum(not r['scope_bev_calculable'] for r in scope_rows),
            no_full_scope_Q=True,primary=35,alternatives=0,
            candidate_denominators={k:sum(r[k] for r in scope_rows) for k in purpose_flags}),
        invariant_original_data_and_gates_unchanged=True,numerical_Q_read_for_admission=False,
        note='Candidate denominator only. Intersect flags with each newly run metric valid flag; never present missing as zero.')
    save(out/'admission_summary.json',summary);save(out/'reference_binding_checks.json',object_checks)
    image_rows=[]
    for im in groups:
        rr=[r for r in rows if r['image_id']==im['image_id']]
        image_rows.append(dict(im,n_records=len(rr),gate_counts=dict(Counter(r['worker_quality_gate'] for r in rr)),
            selected_gt_object_id=rr[0]['selected_gt_object_id'],selected_gt_version=rr[0]['selected_gt_version'],
            registry_classification=rr[0]['reference_registry_classification'],
            registry_policy_reasons=rr[0]['reference_policy_reasons'],
            scope_primary_floor_changed=rr[0]['scope_primary_floor_changed'],
            **{k:sum(r[k] for r in rr) for k in purpose_flags}))
    write_csv(out/'image_admission_259.csv',image_rows)
    save(out/'run_integrity.json',dict(source_files_after=policy.validate_sources(repo),
        registry_unchanged=file_hash(regpath),policy_code_sha256=file_hash(Path(__file__).with_name('reference_policy.py')),
        build_code_sha256=file_hash(__file__),admission_table_sha256=file_hash(out/'admission_3152.csv')))
    print(json.dumps({k:v for k,v in summary.items() if k not in ['exact_source_hashes','repeated_reasons_not_mutually_exclusive']},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
