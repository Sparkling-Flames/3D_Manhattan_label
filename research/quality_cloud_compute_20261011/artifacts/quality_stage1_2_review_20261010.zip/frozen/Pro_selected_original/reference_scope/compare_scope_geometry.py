#!/usr/bin/env python3
"""BEV-only fixed-reference diagnostics for the latest 35 primary floors.

No target is approved by this script. No full Q, GT edit, geometry repair or
formal assignment is produced. The original/selected references are candidate
sources; the confirmed primary is floor-only with its own frozen identity.
"""
from __future__ import annotations
import argparse,csv,hashlib,importlib.util,json,math,sys
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
import shapely
from shapely.geometry import Polygon

N_BOUNDARY=1024
TIE_TOL=1e-10  # Numerical equality only, not an accepted-quality threshold.


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csvwrite(p,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,keys);w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})

def samples(poly,n=N_BOUNDARY):
    """Length samples on the unchanged ring. Canonical start/direction only.

    Source coordinates remain untouched. Choosing leftmost/lowest start and
    positive signed orientation makes the numerical integration independent of
    ring start/direction and exact collinear resegmentation.
    """
    a=np.asarray(poly.exterior.coords[:-1],dtype=float)
    area2=np.sum(a[:,0]*np.roll(a[:,1],-1)-a[:,1]*np.roll(a[:,0],-1))
    if area2<0:a=a[::-1]
    k=min(range(len(a)),key=lambda i:(float(a[i,0]),float(a[i,1])))
    a=np.roll(a,-k,axis=0)
    delta=np.roll(a,-1,axis=0)-a;length=np.linalg.norm(delta,axis=1)
    if np.any(length<=0):raise ValueError('zero_edge_in_diagnostic_ring')
    cumulative=np.r_[0,np.cumsum(length)];position=(np.arange(n)+.5)/n*cumulative[-1]
    ix=np.searchsorted(cumulative,position,side='right')-1
    pts=a[ix]+((position-cumulative[ix])/length[ix])[:,None]*delta[ix]
    return shapely.points(pts)

def symmetric_boundary_rms(a,b,n=N_BOUNDARY):
    da=shapely.distance(samples(a,n),b.boundary)
    db=shapely.distance(samples(b,n),a.boundary)
    return float(np.sqrt(.5*(np.mean(da*da)+np.mean(db*db))))

def prefer(g,t,higher=True):
    if g is None or t is None:return 'unavailable'
    if abs(g-t)<=TIE_TOL:return 'numerical_tie'
    return ('confirmed_primary_floor' if t>g else 'selected_existing_GT') if higher else ('confirmed_primary_floor' if t<g else 'selected_existing_GT')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scope-integration',type=Path,required=True)
    ap.add_argument('--admission',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    src=args.scope_integration.resolve();out=args.out.resolve()
    if out.exists() and any(out.iterdir()):raise FileExistsError('nonempty output')
    out.mkdir(parents=True,exist_ok=True)
    spec=importlib.util.spec_from_file_location('frozen_scope_geometry',src/'recompute_bev.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    subset=read(src/'inputs/current_formal_subset.json');registry=read(src/'results/reference_registry.json')['records']
    refs={r['image_code']:r for r in registry};admission={r['object_id']:r for r in read(args.admission)}
    frozen={r['object_id']:r for r in read(src/'results/record_metrics.json')}
    long=[];wide=[];image_results=[];checks=[]
    for im in subset['images']:
        code=im['image_code'];r=refs[code]
        tp,tstatus=mod.floor_polygon(r['floor_xz_h']); assert tstatus=='valid'
        gt,gs=mod.project_floor(im['selected_gt']['points_1024x512']);og,os=mod.project_floor(im['original_gt']['points_1024x512'])
        # External two images have reference geometry but zero research answers.
        if not im['annotations']:
            image_results.append(dict(image_code=code,image_id=im['image_id'],reference_only=True,n_records=0,n_valid=0,new_floor=r['new_floor_geometry'],n_legal_alternatives=0,full_Q_ready=False))
            continue
        assert gs==os=='valid'
        common_scale=math.sqrt(gt.area)
        image_rows=[]
        for ann in im['annotations']:
            oid=ann['object_id'];a,astatus=mod.project_floor(ann['points_1024x512']);saved=frozen[oid];gate=admission[oid]
            assert astatus==saved['geometry_status']
            row=dict(record_id=ann['record_id'],object_id=oid,image_code=code,image_id=im['image_id'],worker_id=ann['worker_id'],condition=ann['condition'],
                geometry_status=astatus,geometry_failure_reason=None if a is not None else astatus,
                worker_quality_gate=ann['worker_quality_gate'],cleaning_disposition=ann['cleaning_disposition'],
                conservative_fixed_gt_quality_candidate=gate['conservative_fixed_gt_quality_candidate'],
                registry_comparison_exclude=gate['registry_comparison_exclude'],reference_policy_reasons=gate['reference_policy_reasons'],
                group_key=gate['group_key'],group_split=gate['group_split'],
                selected_reference_id=im['selected_gt']['object_id'],original_reference_id=im['original_gt']['object_id'],
                confirmed_floor_reference_id=r['reference_id'],confirmed_floor_sha256=r['floor_polygon_sha256'],
                confirmed_floor_new_geometry=r['new_floor_geometry'],new_reference_top_status='top_pending',new_reference_ready=False,
                full_target_quality=None,final_target_assignment=None,
                target_set_status='one_declared_primary_floor_zero_registered_alternatives',
                geometry_preference_is_historical_intent=False)
            for kind,p,refid in [('original',og,im['original_gt']['object_id']),('selected',gt,im['selected_gt']['object_id']),('confirmed',tp,r['reference_id'])]:
                m=mod.area_metrics(a,p) if a is not None else None
                distance=symmetric_boundary_rms(a,p) if a is not None else None
                expected=saved['original_gt_metrics'] if kind=='original' else saved['selected_gt_metrics'] if kind=='selected' else saved['confirmed_spaces'][0]['confirmed_floor_metrics']
                assert (m is None)==(expected is None)
                if m:
                    error=max(abs(m[k]-expected[k]) for k in m)
                    assert error<=1e-12
                    checks.append(error)
                row[kind+'_iou']=m['bev_iou'] if m else None
                row[kind+'_precision']=1-m['annotation_outside_fraction'] if m else None
                row[kind+'_recall_coverage']=m['reference_coverage_fraction'] if m else None
                row[kind+'_symmetric_boundary_rms_h']=distance
                row[kind+'_symmetric_boundary_rms_common_scale']=distance/common_scale if distance is not None else None
                row[kind+'_symmetric_difference_over_reference']=m['symmetric_difference_over_reference'] if m else None
                row[kind+'_reference_area_h2']=p.area
                long.append(dict(record_id=ann['record_id'],object_id=oid,image_code=code,image_id=im['image_id'],
                    worker_id=ann['worker_id'],condition=ann['condition'],reference_source=kind,reference_id=refid,
                    reference_kind='new_confirmed_primary_floor' if kind=='confirmed' else im['original_gt' if kind=='original' else 'selected_gt']['object_kind'],
                    metrics_kind='floor_only_diagnostic',target_set_membership='not_established_as_multiple_legal_full_targets',
                    primary_floor_approved=(kind=='confirmed'),top_pending=(kind=='confirmed'),
                    full_Q=None,final_target_assignment=None,geometry_status=astatus,
                    metric_failure_reason=None if a is not None else astatus,
                    precision=row[kind+'_precision'],recall_coverage=row[kind+'_recall_coverage'],
                    symmetric_boundary_rms_h=distance,symmetric_boundary_rms_common_scale=row[kind+'_symmetric_boundary_rms_common_scale'],
                    common_scale_sqrt_selected_GT_area_h=common_scale,**(m or {'bev_iou':None})))
            if a is not None:
                row['iou_confirmed_minus_selected']=row['confirmed_iou']-row['selected_iou']
                row['boundary_improvement_selected_minus_confirmed_h']=row['selected_symmetric_boundary_rms_h']-row['confirmed_symmetric_boundary_rms_h']
            else:
                row['iou_confirmed_minus_selected']=None;row['boundary_improvement_selected_minus_confirmed_h']=None
            row['preferred_by_iou']=prefer(row['selected_iou'],row['confirmed_iou'])
            row['preferred_by_boundary_rms']=prefer(row['selected_symmetric_boundary_rms_h'],row['confirmed_symmetric_boundary_rms_h'],False)
            row['metric_preferences_disagree']=(row['preferred_by_iou']!=row['preferred_by_boundary_rms']) if a is not None else None
            image_rows.append(row);wide.append(row)
        valid=[a for a in image_rows if a['geometry_status']=='valid']
        image_results.append(dict(image_code=code,image_id=im['image_id'],reference_only=False,n_records=len(image_rows),n_valid=len(valid),
            new_floor=r['new_floor_geometry'],confirmed_to_selected_area_ratio=tp.area/gt.area,
            mean_selected_iou=float(np.mean([v['selected_iou'] for v in valid])) if valid else None,
            mean_confirmed_iou=float(np.mean([v['confirmed_iou'] for v in valid])) if valid else None,
            iou_preference_counts=dict(Counter(v['preferred_by_iou'] for v in valid)),
            boundary_preference_counts=dict(Counter(v['preferred_by_boundary_rms'] for v in valid)),
            preference_disagreements=sum(v['metric_preferences_disagree'] for v in valid),n_legal_alternatives=0,full_Q_ready=False))
    csvwrite(out/'all_reference_source_metrics_1287.csv',long);save(out/'all_reference_source_metrics_1287.json',long)
    csvwrite(out/'geometric_preferences_429.csv',wide);save(out/'geometric_preferences_429.json',wide)
    csvwrite(out/'image_comparison_35.csv',image_results)
    valid=[r for r in wide if r['geometry_status']=='valid'];changed=[r for r in valid if r['confirmed_floor_new_geometry']]
    matrix=Counter((r['preferred_by_iou'],r['preferred_by_boundary_rms']) for r in valid)
    csvwrite(out/'preference_disagreements.csv',[r for r in wide if r['metric_preferences_disagree']])
    cases={'e9zR4mvMWw7-17','e9zR4mvMWw7-09','pRbA3pwrgk9-02','uNb9QFRL6hY-18','uNb9QFRL6hY-88','q9vSo1VnCiC-16'}
    csvwrite(out/'six_real_case_records_67.csv',[r for r in wide if r['image_code'] in cases])
    # Numerical integration stability: representation changes do not change the
    # polygon or ray geometry. This probe belongs only to this BEV descriptor.
    square=Polygon([[-2,-2],[2,-2],[2,2],[-2,2]]);q=Polygon([[-1.8,-2.1],[2.1,-1.9],[2,2.1],[-2.1,1.9]])
    variants={'start':Polygon([[2,-2],[2,2],[-2,2],[-2,-2]]),'reverse':Polygon(list(square.exterior.coords)[:-1][::-1]),
              'collinear':Polygon([[-2,-2],[0,-2],[2,-2],[2,2],[-2,2]])}
    base=symmetric_boundary_rms(square,q);test={k:abs(symmetric_boundary_rms(p,q)-base) for k,p in variants.items()};assert max(test.values())<1e-12
    summary=dict(new_run=True,source_formal_commit=subset['source_commit'],records=len(wide),reference_source_rows=len(long),research_images=33,
        confirmed_images=35,new_registered_alternatives=0,full_target_Q_computed=False,formal_target_assignment_computed=False,
        valid_records=len(valid),invalid_records=len(wide)-len(valid),all_original_bev_metrics_recomputed_match=True,
        n_valid_area_metric_comparisons=len(checks),maximum_saved_bev_error=max(checks),
        iou_preference_counts=dict(Counter(r['preferred_by_iou'] for r in valid)),
        boundary_preference_counts=dict(Counter(r['preferred_by_boundary_rms'] for r in valid)),
        changed_floor_valid_records=len(changed),changed_iou_preference_counts=dict(Counter(r['preferred_by_iou'] for r in changed)),
        n_preference_disagreements=sum(r['metric_preferences_disagree'] for r in valid),
        confusion=[dict(iou=i,boundary=b,n=n) for (i,b),n in sorted(matrix.items())],
        descriptor=dict(name='symmetric_arc_length_sampled_BEV_boundary_RMS',unit='camera_height_h',n_per_ring=N_BOUNDARY,
            normalization='divide by sqrt(selected fixed GT floor area), common to all candidate sources for an image',
            formula='sqrt((mean(d(sample(A), boundary(R))^2)+mean(d(sample(R), boundary(A))^2))/2)',
            interpretation='extra geometric matching descriptor; not a new complete quality score',
            canonical_sampling_start_and_direction_only=True,raw_geometry_unchanged=True,tie_tolerance=TIE_TOL,
            threshold_not_validated_for_automatic_historical_intent=True),
        representation_probe_absolute_deltas=test,
        scope_of_claim='Preferences among fixed reference SOURCES. No extra legal target created; agreement does not prove historical intent.',
        policy_excluded_diagnostic_rows=sum(r['registry_comparison_exclude'] for r in wide))
    save(out/'scope_comparison_summary.json',summary);print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
