"""Read-only, version-bound reference admission for this research stage.

This module never edits a loader gate, raw geometry, GT, or saved score.
An unmatched/hash-changed registered reference is quarantined, not repaired.
The returned fields describe research use, not annotation correctness.
"""
from __future__ import annotations
import hashlib
import json
from collections import Counter
from pathlib import Path

REGISTRY_FIELDS = (
    'confirmed_reference_exclusions', 'preserved_user_analysis_holds',
    'reference_evidence_conflicts_primary_research_quarantine',
    'nonautomatic_review_cases', 'version_resolved_not_global_exclusion')
PURPOSE_FIELDS = {
    'parameter_selection': 'exclude_this_reference_from_quality_parameter_selection',
    'primary_comparison': 'exclude_this_reference_from_primary_gt_quality_comparison',
    'annotator_calibration': 'exclude_this_reference_from_annotator_uncertainty_calibration'}
# Research-only extra caution explicitly requested by the handoff. These are
# unresolved historical reference comments, not newly confirmed GT errors.
ADDITIONAL_CONSERVATIVE_IMAGES = {'B6ByNegPMKs-37', 'q9vSo1VnCiC-34'}
POLICY_VERSION = 'quality_next_stage_reference_admission_20261011_v1'


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False,
                        separators=(',', ':')).encode('utf-8')).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def selected_reference_id(image):
    """Frozen policy: existing manual revision when present, else original.

    This is independent of score. It must be cross-checked against the current
    release's selected-reference object where a floor confirmation exists.
    """
    refs = image.get('references', {})
    return refs.get('gt_manual_revision') or refs.get('gt_original')


class ReferencePolicy:
    def __init__(self, registry):
        self.registry = registry
        self.index = {}
        self.by_image = {}
        for field in REGISTRY_FIELDS:
            for row in registry[field]:
                self.by_image.setdefault(row['image_id'], []).append(row)
                for version in row['gt_versions']:
                    key = (row['image_id'], version['gt_object_id'], version['version'])
                    if key in self.index:
                        raise ValueError('duplicate_registry_reference:' + repr(key))
                    self.index[key] = (row, version, field)

    def validate_sources(self, repo):
        records = []
        for source in self.registry['source_files']:
            p = Path(repo) / source['path']
            if not p.exists():
                raise FileNotFoundError('source_access_missing:' + str(p))
            actual = file_hash(p)
            if actual != source['sha256']:
                raise ValueError('registry_source_hash_mismatch:' + source['path'])
            records.append(dict(path=source['path'], sha256=actual, matches=True))
        return records

    def validate_objects(self, data):
        objects = {o['object_id']: o for o in data['objects']}
        images = {i['image_id']: i for i in data['images']}
        ann = [o for o in objects.values() if o['object_kind'] == 'annotation']
        checks = []
        for key, (row, version, field) in self.index.items():
            image_id, object_id, kind = key
            obj = objects[object_id]
            image = images[image_id]
            actual_hash = canonical_hash(obj.get('points_1024x512'))
            if (image['image_code'] != row['image_code']
                or image['references'].get(kind) != object_id
                or obj['image_id'] != image_id or obj['object_kind'] != kind
                or actual_hash != version['coordinates_sha256']):
                raise ValueError('registry_object_binding_mismatch:' + object_id)
            gates = dict(Counter(a['worker_quality_gate'] for a in ann
                                 if a['image_id'] == image_id))
            if gates != row['current_personnel_quality_gate_counts']:
                raise ValueError('registry_worker_gate_drift:' + image['image_code'])
            if obj['worker_quality_gate'] != version['observed_gt_object_worker_quality_gate']:
                raise ValueError('registry_gt_gate_drift:' + object_id)
            checks.append(dict(image_code=image['image_code'], image_id=image_id,
                gt_object_id=object_id, gt_version=kind, coordinates_sha256=actual_hash,
                registry_group=field, matches=True))
        return checks

    def assess_reference(self, image, obj):
        base = dict(reference_policy_version=POLICY_VERSION,
            reference_registry_binding_status='not_listed_no_additional_exclusion',
            reference_registry_classification=None, reference_registry_group=None,
            reference_decision_authority=None, reference_research_status=None,
            registry_parameter_exclude=False, registry_comparison_exclude=False,
            registry_annotator_exclude=False, reference_binding_error=None,
            reference_policy_reasons=[], reference_extra_conservative=False)
        if obj is None:
            base.update(reference_registry_binding_status='reference_data_missing',
                        reference_binding_error='selected_reference_missing')
            base['reference_policy_reasons'].append('selected_reference_missing')
            for p in ('parameter', 'comparison', 'annotator'):
                base['registry_' + p + '_exclude'] = True
            return base
        key = (image['image_id'], obj['object_id'], obj['object_kind'])
        if key in self.index:
            row, version, field = self.index[key]
            actual = canonical_hash(obj.get('points_1024x512'))
            if actual != version['coordinates_sha256']:
                base.update(reference_registry_binding_status='binding_hash_mismatch',
                            reference_binding_error='reference_geometry_requires_reaudit')
                base['reference_policy_reasons'].append('reference_geometry_requires_reaudit')
                for p in ('parameter', 'comparison', 'annotator'):
                    base['registry_' + p + '_exclude'] = True
                return base
            base.update(reference_registry_binding_status='exact_image_object_version_hash_match',
                reference_registry_classification=row['classification'], reference_registry_group=field,
                reference_decision_authority=row['decision_authority'],
                reference_research_status=row['research_status'])
            for purpose, short in [('parameter_selection','parameter'),
                                   ('primary_comparison','comparison'),
                                   ('annotator_calibration','annotator')]:
                base['registry_' + short + '_exclude'] = bool(row['new_research_use'][PURPOSE_FIELDS[purpose]])
            if any(base['registry_' + p + '_exclude'] for p in ('parameter','comparison','annotator')):
                base['reference_policy_reasons'].append(row['research_status'])
            if row['image_code'] in ADDITIONAL_CONSERVATIVE_IMAGES:
                base['reference_extra_conservative'] = True
                base['reference_policy_reasons'].append('unresolved_reference_comment_research_only_caution')
        elif image['image_id'] in self.by_image:
            base.update(reference_registry_binding_status='unregistered_version_for_reviewed_image',
                        reference_binding_error='unregistered_reference_version_requires_reaudit')
            base['reference_policy_reasons'].append('unregistered_reference_version_requires_reaudit')
            for p in ('parameter', 'comparison', 'annotator'):
                base['registry_' + p + '_exclude'] = True
        return base


def assess_annotation(annotation, image, reference, policy, scope_record=None):
    """Return policy candidates only; methods' computability is a later join.

    Three separate candidate sets: registry minimum, conservative fixed GT,
    and target-aligned (additionally no changed pending primary floor).
    None of these booleans sets method failures to zero or restores a gate.
    """
    r = policy.assess_reference(image, reference)
    gate = annotation.get('main_quality_gate', {}).get('status', annotation.get('worker_quality_gate'))
    eligibility_reasons = []
    if annotation.get('cleaning_disposition') != 'retained':
        eligibility_reasons.append('cleaning:' + str(annotation.get('cleaning_disposition')))
    if annotation.get('independent_vote_eligible') is not True:
        eligibility_reasons.append('not_independent_response:' + '|'.join(annotation.get('independent_vote_reasons', [])))
    if gate != 'candidate_pending_geometry':
        eligibility_reasons.append('worker_quality_gate:' + str(gate))
    gtgate = reference.get('worker_quality_gate') if reference else None
    if gtgate not in ('candidate_pending_geometry',):
        eligibility_reasons.append('selected_reference_gate:' + str(gtgate))
    r['formal_eligibility_reasons'] = eligibility_reasons
    # Independence is required for the personnel example, not for the mathematical
    # quality of one given geometry. Report both sets without changing the gate.
    quality_reasons = [x for x in eligibility_reasons if not x.startswith('not_independent_response:')]
    r['formal_quality_gate_candidate'] = not quality_reasons
    r['registry_minimum_quality_candidate'] = not quality_reasons and not r['registry_comparison_exclude']
    r['conservative_fixed_gt_quality_candidate'] = r['registry_minimum_quality_candidate'] and not r['reference_extra_conservative']
    r['formal_primary_gate_candidate'] = not eligibility_reasons
    r['registry_minimum_primary_candidate'] = (not eligibility_reasons
                                              and not r['registry_comparison_exclude'])
    r['conservative_fixed_gt_primary_candidate'] = (
        r['registry_minimum_primary_candidate'] and not r['reference_extra_conservative'])
    r['scope_confirmed_floor_present'] = scope_record is not None
    r['scope_primary_floor_changed'] = bool(scope_record and scope_record['new_floor_geometry'])
    r['scope_top_pending'] = bool(scope_record and scope_record['top_boundary_pending'])
    r['target_aligned_primary_candidate'] = (r['conservative_fixed_gt_primary_candidate']
        and not (r['scope_primary_floor_changed'] and r['scope_top_pending']))
    r['target_aligned_quality_candidate'] = (r['conservative_fixed_gt_quality_candidate']
        and not (r['scope_primary_floor_changed'] and r['scope_top_pending']))
    r['all_research_exclusion_reasons'] = eligibility_reasons + list(r['reference_policy_reasons'])
    if r['scope_primary_floor_changed'] and r['scope_top_pending']:
        r['target_aligned_exclusion_reason'] = 'changed_confirmed_primary_floor_top_pending'
    else:
        r['target_aligned_exclusion_reason'] = None
    return r
