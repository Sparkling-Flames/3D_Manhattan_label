"""Small contract checks; synthetic objects only, never changes user data."""
import copy
import json
from pathlib import Path
from reference_policy import ReferencePolicy, canonical_hash, assess_annotation, REGISTRY_FIELDS


def run():
    points=[[1.0,2.0],[3.0,4.0]]
    image={'image_id':'synthetic-image','image_code':'synthetic','references':{'gt_original':'synthetic-gt'}}
    gt={'object_id':'synthetic-gt','object_kind':'gt_original','image_id':image['image_id'],
        'points_1024x512':points,'worker_quality_gate':'candidate_pending_geometry'}
    ann={'cleaning_disposition':'retained','independent_vote_eligible':True,'independent_vote_reasons':[],
         'worker_quality_gate':'candidate_pending_geometry','main_quality_gate':{'status':'candidate_pending_geometry','reasons':[]}}
    row={'image_id':image['image_id'],'image_code':image['image_code'],
         'classification':'synthetic_confirmed_reference_error','decision_authority':'synthetic_test',
         'research_status':'exclude_confirmed_problem_reference_from_primary_quality_research',
         'gt_versions':[{'gt_object_id':gt['object_id'],'version':'gt_original','coordinates_sha256':canonical_hash(points)}],
         'new_research_use':{'exclude_this_reference_from_quality_parameter_selection':True,
                            'exclude_this_reference_from_primary_gt_quality_comparison':True,
                            'exclude_this_reference_from_annotator_uncertainty_calibration':True}}
    reg={k:[] for k in REGISTRY_FIELDS};reg['confirmed_reference_exclusions']=[row]
    policy=ReferencePolicy(reg); tests=[]
    def ck(name,value):
        if not value: raise AssertionError(name)
        tests.append({'test':name,'passed':True})
    before=copy.deepcopy((image,gt,ann,reg))
    r=assess_annotation(ann,image,gt,policy)
    ck('candidate_GT_row_cannot_bypass_reference_registry',r['registry_comparison_exclude'] and not r['conservative_fixed_gt_primary_candidate'])
    g2=copy.deepcopy(gt);g2['points_1024x512'][0][0]+=1
    r=assess_annotation(ann,image,g2,policy)
    ck('same_ID_changed_hash_is_quarantined',r['reference_registry_binding_status']=='binding_hash_mismatch' and r['registry_comparison_exclude'])
    g3=copy.deepcopy(gt);g3['object_id']='future_revision';g3['object_kind']='gt_manual_revision'
    r=assess_annotation(ann,image,g3,policy)
    ck('unreviewed_new_version_requires_reaudit_not_permanent_GT_error',r['reference_registry_binding_status']=='unregistered_version_for_reviewed_image' and r['reference_registry_classification'] is None)
    reg2={k:[] for k in REGISTRY_FIELDS};p2=ReferencePolicy(reg2)
    r=assess_annotation(ann,image,gt,p2)
    ck('unlisted_reference_gets_no_extra_error_label',r['registry_minimum_primary_candidate'] and r['reference_registry_classification'] is None)
    held=copy.deepcopy(ann);held['worker_quality_gate']='hold_scene_or_reference';held['main_quality_gate']['status']='hold_scene_or_reference'
    floor={'new_floor_geometry':True,'top_boundary_pending':True}
    r=assess_annotation(held,image,gt,p2,floor)
    ck('new_floor_cannot_lift_existing_hold',not r['conservative_fixed_gt_primary_candidate'] and not r['target_aligned_primary_candidate'])
    oos=copy.deepcopy(ann);oos['main_quality_gate']['status']='out_of_primary_scene'
    r=assess_annotation(oos,image,gt,p2)
    ck('OOS_not_reinstated_as_primary',not r['conservative_fixed_gt_primary_candidate'] and not r['registry_comparison_exclude'])
    borrowed=copy.deepcopy(ann);borrowed['independent_vote_eligible']=False;borrowed['independent_vote_reasons']=['borrowed_points_not_independent_complete_response']
    r=assess_annotation(borrowed,image,gt,p2)
    ck('borrowing_excluded_from_independent_personnel_sample_only',not r['conservative_fixed_gt_primary_candidate'] and not r['registry_comparison_exclude'])
    r=assess_annotation(ann,image,gt,p2,floor)
    ck('fixed_GT_diagnostic_does_not_become_new_scope_Q',r['conservative_fixed_gt_primary_candidate'] and not r['target_aligned_primary_candidate'])
    ck('source_objects_and_gates_unchanged',(image,gt,ann,reg)==before)
    r=assess_annotation(ann,image,None,p2)
    ck('missing_reference_is_data_state_not_zero_score',r['reference_registry_binding_status']=='reference_data_missing' and 'Q' not in r)
    # Different values of identity outside the explicit gates do not enter policy.
    ann2=copy.deepcopy(ann);ann2['worker_id']='other';ann2['difficulty_label']='hard'
    ck('worker_ID_and_difficulty_do_not_change_policy',assess_annotation(ann2,image,gt,p2)==assess_annotation(ann,image,gt,p2))
    return {'passed':True,'tests':tests,'n_tests':len(tests),'all_inputs_synthetic':True}

if __name__=='__main__':
    result=run(); print(json.dumps(result,ensure_ascii=False,indent=2))
