"""Select and type frozen result snapshots; no quality formula or ranking recomputation."""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sources = []

def read_csv(rel):
    p = ROOT / rel
    b = p.read_bytes()
    sources.append({'relative_path': rel, 'sha256': hashlib.sha256(b).hexdigest()})
    return list(csv.DictReader(b.decode('utf-8-sig').splitlines()))

def number(v):
    if v in ('', None, 'nan', 'NaN', 'NA', 'null'):
        return None
    f = float(v)
    assert f == f and abs(f) != float('inf'), v
    return int(f) if f.is_integer() else f

def boolean(v):
    if v in ('', None):
        return None
    assert v in ('True', 'False', True, False), v
    return v in ('True', True)

def text(v):
    return None if v in ('', None, '[]') else v

def choose(rows, fields):
    return [[fn(r.get(k)) for k, label, fn in fields] for r in rows]

def table(rows, fields, source, note):
    return {'headers': [x[1] for x in fields], 'rows': choose(rows, fields), 'keys': [x[0] for x in fields],
            'source': source, 'note': note,
            'numeric_columns': [i for i,x in enumerate(fields) if x[2] is number],
            'boolean_columns': [i for i,x in enumerate(fields) if x[2] is boolean]}

DISPLAY_MAP = {
    'manual':'人工', 'semi_auto':'半自动', 'semi':'半自动', 'development':'开发', 'validation':'留出', 'all':'全部',
    'available':'可计算', 'success':'读取成功',
    'pairing_preprocessing_unavailable':'点对预处理不可用',
    'invalid_canvas_coordinates':'坐标超出画布',
    'insufficient_or_invalid_paired_array':'点对数组不足/无效',
    'candidate_pending_geometry':'候选（需几何可算）', 'excluded':'正式排除',
    'hold_scene_or_reference':'场景/参考暂停', 'out_of_primary_scene':'主场景之外',
    'hold_reference_quality':'参考质量暂停', 'hold_individual_review':'单份复审暂停',
    'hold_all_analysis':'全部分析暂停', 'hold_main_analysis':'主分析暂停',
    'review_separately_no_additional_automatic_exclusion_preserve_formal_gates':'分项评论，沿用正式资格',
    'exclude_confirmed_problem_reference_from_primary_quality_research':'问题参考，排除主研究',
    'preserve_version_specific_acceptance_not_global_gt_exclusion':'按版本认可，沿用资格',
    'conservative_research_quarantine_pending_review':'历史证据冲突，保守暂停',
    'preserve_existing_user_all_analysis_hold':'保留全部分析暂停',
    'preserve_user_confirmed_main_analysis_hold':'保留用户主分析暂停',
}

def display(v):
    return DISPLAY_MAP.get(v, text(v))

score_path = 'deliverables/tables/逐份质量结果_3152.csv'
scores = read_csv(score_path)
assert len(scores) == 3152 and len({r['record_id'] for r in scores}) == 3152
fields = [
('record_id','记录编号',text), ('image_code','图片编号',text), ('worker_id','人员编号',text),
('condition','作答方式',display), ('Q_primary_v11','主比较 Q v1.1',number),
('iou_2d','2D IoU',number), ('official_iou3d_same_geometry_vertex_mean','3D IoU 角点均高',number),
('computation_status_category','计算状态',display), ('worker_quality_gate','正式质量资格',display),
('reference_policy_status','登记参考政策',display), ('source_access_status','访问状态',display),
('conservative_fixed_gt_quality_candidate','固定参考质量候选',boolean),
('conservative_fixed_gt_primary_candidate','固定参考独立人员候选',boolean),
('target_aligned_quality_candidate','目标一致质量候选',boolean),
('target_aligned_primary_candidate','目标一致独立人员候选',boolean),
('Q_v11','诊断 Q v1.1',number), ('S_deg','边界 S（°）',number), ('D_deg','方向 D（°）',number),
('F_deg','平面 F（°）',number), ('Hstar','局部高度 Hstar',number), ('C','质心距离 C',number),
('omission','参考覆盖遗漏率',number), ('extension','面积超出比',number),
('range_deduction','范围扣分',number), ('boundary_deduction','边界扣分',number),
('height_deduction','高度扣分',number), ('intrinsic_deduction','规整扣分',number),
('Q_alpha30','诊断 Q α0.30',number), ('Q_alpha45','诊断 Q α0.45',number),
('Q_stage13','诊断 Q 分阶段1–3',number), ('Q_stage24','诊断 Q 分阶段2–4',number),
('group_split','分组用途',display), ('selected_gt_version','固定 GT 版本',text),
('scope_primary_floor_changed','最新底面改变',boolean), ('scope_top_pending','最新顶界待定',boolean),
('computation_status_reason_zh','计算状态说明',text), ('all_research_exclusion_reasons','全部准入限制',text),
('selected_gt_object_id','固定 GT 对象',text), ('current_coordinates_sha256','当前坐标 SHA256',text),
('object_id','作答对象',text), ('band_v11_primary','主比较研究档位',text),
('band_v11_diagnostic','诊断研究档位',text)]
score_table = table(scores, fields, score_path,
    '主比较 Q 按保守固定 GT 准入政策输出。诊断 Q 保留未准入记录的数学结果，不能用于人员优劣判断。缺失数值留空。')
assert sum(isinstance(row[4], (int,float)) for row in score_table['rows']) == 2003
assert sum(isinstance(row[15], (int,float)) for row in score_table['rows']) == 3021

image_path = 'experiments/summaries/by_image_259.csv'
images = read_csv(image_path)
summary_fields = [
('records_supplied','收到作答数',number), ('math_available','完整 Q 可算数',number),
('primary_admitted','主比较候选数',number), ('primary_Q_n','主比较有效数',number),
('math_unavailable','不可算数',number), ('not_primary','未准入主比较数',number),
('Q_v11_mean','Q v1.1 均值',number), ('Q_v11_median','Q v1.1 中位数',number),
('iou_2d_mean','2D IoU 均值',number), ('iou_3d_corner_mean_mean','3D IoU 均值',number),
('D_deg_mean','D 均值（°）',number), ('F_deg_mean','F 均值（°）',number),
('S_deg_mean','S 均值（°）',number), ('Hstar_mean','Hstar 均值',number)]
image_table = table(images, [('image_code','图片编号',text),('building_id','建筑编号',text),
    ('room_id','房间编号',text),('group_split','分组用途',display)] + summary_fields, image_path,
    '均值、中位数仅基于主比较有效记录。记录为定向选例与抽样混合，不能据此估计图片总体质量或难度。')
assert len(images) == 259
building_path = 'experiments/summaries/by_building.csv'
buildings = read_csv(building_path)
building_table = table(buildings, [('building_id','建筑编号',text),('group_split','分组用途',display)] + summary_fields,
    building_path, '按建筑与开发/留出用途保留原汇总，27 行对应 22 个建筑。具有可靠房间 ID 的建筑可出现两个用途行。')

worker_path = 'worker_example/results/worker_common_image_summary.csv'
all_workers = read_csv(worker_path)
policy = 'target_aligned_primary_candidate'
workers_all = [r for r in all_workers if r['policy'] == policy and r['split'] == 'all']
assert len(workers_all) == 24
worker_index = {(r['worker_id'], r['split']): r for r in all_workers if r['policy'] == policy}
worker_rows = []
for r in workers_all:
    row = dict(r)
    for split in ['development','validation']:
        src = worker_index[(r['worker_id'], split)]
        for key in ['n_finite','mean_Q','across_image_SD','Q_lt50_historical_low_band_count']:
            row[split+'_'+key] = src[key]
    worker_rows.append(row)
worker_fields = [
('worker_id','人员编号',text), ('n_images','共同图片数',number), ('n_finite','有效作答数',number),
('n_noncalculable','不可算数',number), ('n_groups','房间/建筑组数',number), ('mean_Q','Q v1.1 均值',number),
('median_Q','Q v1.1 中位数',number), ('across_image_SD','跨图标准差',number),
('Q_lt50_historical_low_band_count','Q＜50 次数',number),
('Q_lt50_historical_low_band_rate','Q＜50 频率',number),
('BEV_IoU_lt0p5_count','2D IoU＜0.5 次数',number),('BEV_IoU_lt0p5_rate','2D IoU＜0.5 频率',number),
('S_gt8deg_count','S＞8° 次数',number),('Hstar_gt1_count','Hstar＞1 次数',number),
('development_n_finite','开发有效数',number),('development_mean_Q','开发均值',number),
('development_across_image_SD','开发跨图标准差',number),
('validation_n_finite','留出有效数',number),('validation_mean_Q','留出均值',number),
('validation_across_image_SD','留出跨图标准差',number),
('equal_group_mean_Q','组等权均值',number)]
worker_table = table(worker_rows, worker_fields, worker_path,
    '固定 24 人共同面板，目标一致政策下 9 图（8 开发图、1 留出图）。按人员编号保留顺序，无排名。留出只有 1 图，标准差留空。')
common_path = 'worker_example/results/common_image_summary.csv'
common_images = [r for r in read_csv(common_path) if r['policy'] == policy]
assert len(common_images) == 9
common_table = table(common_images, [('image_code','共同图片',text),('split','分组用途',display),
    ('n_people','人数',number),('mean_Q','Q v1.1 均值',number)], common_path,
    'Q＜50、IoU＜0.5、S＞8°、Hstar＞1 是描述性严重错误代理，未校准为人员类别。')

den_path = 'experiments/summaries/effective_denominators.csv'
denoms = read_csv(den_path)
den_fields = [('policy','准入政策',text),('admitted_rows','候选记录',number),('admitted_images','候选图片',number),
    ('complete_Q_rows','完整 Q 有效',number),('Q_images','有效图片',number),('Q_buildings','有效建筑',number),
    ('unavailable','候选中不可算',number),('development_rows','开发有效数',number),('validation_rows','留出有效数',number)]
denom_table = table(denoms, den_fields, den_path,
    '质量候选与独立人员候选分别计数。借点作答可做数学质量回放，但不自动恢复独立人员资格。')

ref_path = 'reference_scope/admission_run/reference_binding_checks.json'
ref_b = (ROOT/ref_path).read_bytes(); sources.append({'relative_path':ref_path,'sha256':hashlib.sha256(ref_b).hexdigest()})
refs = json.loads(ref_b)
ref_table = table(refs, [('image_code','登记图片',text),('gt_version','参考版本',text),('registry_group','登记组',text),
    ('matches','版本绑定匹配',boolean),('coordinates_sha256','坐标 SHA256',text),('gt_object_id','参考对象',text)],
    ref_path,'登记组含排除、暂停和保留既有资格的评论项，不等于全部是用户判错 GT。27 个对象版本绑定全部一致。')

var_path = 'experiments/summaries/variant_summaries.csv'
variants = read_csv(var_path)
delta_path = 'experiments/summaries/variant_deltas.csv'
deltas = {(r['split'],r['variant']):r for r in read_csv(delta_path)}
band_path = 'experiments/summaries/variant_bands.csv'
bands = {(r['split'],r['variant'],r['band']):r['n'] for r in read_csv(band_path)}
for r in variants:
    r.update({k:v for k,v in deltas[(r['split'],r['variant'])].items() if k not in r})
    for band in ['<50','50-85','85-95','95+']:
        source_band = 'below50' if band == '<50' else band
        r['band_'+band] = bands[(r['split'],r['variant'],source_band)]
variant_table = table(variants, [('split','分组用途',display),('variant','质量方案',text),('n','有效记录',number),
    ('mean','均值',number),('median','中位数',number),('p05','5% 分位',number),('p95','95% 分位',number),
    ('mean_delta','相对 v1.1 均值差',number),('changes_over_2','变化超过 2 分',number),
    ('changes_over_5','变化超过 5 分',number),('changes_over_10','变化超过 10 分',number),
    ('band_<50','Q＜50',number),('band_50-85','50≤Q＜85',number),('band_85-95','85≤Q＜95',number),('band_95+','Q≥95',number)],
    var_path+' + variant_deltas.csv + variant_bands.csv',
    '相同输入与保守固定参考有效样本，仅导入已运行对照。边界 50/85/95 为暂定研究分档，不是合格线。')
for r in variants:
    assert sum(number(r['band_'+b]) for b in ['<50','50-85','85-95','95+']) == number(r['n']), r

payload = {'tables': {'scores':score_table,'images':image_table,'buildings':building_table,'workers':worker_table,
    'common_images':common_table,'denominators':denom_table,'references':ref_table,'variants':variant_table},
    'source_manifest':sources,
    'version':{'main':'f485d49f0ccd57a7a7bf64931a81b770a37ff4df','formal_input':'24360ad8544d76d8aba18a8e641f784a76ca0d42',
               'scope':'42f7ea569c591c0cb3472e1b8bb8c0d883bbd3cb'},
    'policy': {'main_quality':'conservative_fixed_gt_quality_candidate AND score_status=available',
               'worker':'target_aligned_primary_candidate; common 24 workers, 9 images; Q_v11'},
    'counts':{'records':3152,'images':259,'buildings':22,'math_Q':3021,'unavailable':131,'main_Q':2003,
              'main_images':168,'target_aligned_Q':1725,'target_aligned_person':1724,'main_person_Q':2001}}
(OUT/'workbook_input.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False),encoding='utf-8')
(OUT/'source_manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'selected_table_rows':{k:len(t['rows']) for k,t in payload['tables'].items()},'output':str(OUT/'workbook_input.json')},ensure_ascii=False))
