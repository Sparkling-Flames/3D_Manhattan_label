"""Read-only XLSX package checks; this script does not author or modify workbooks."""
import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parents[2]
BUILD=Path(__file__).resolve().parent
FILE=ROOT/'deliverables/质量研究结果总表_20261011.xlsx'
data=json.loads((BUILD/'workbook_input.json').read_text())
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
def col(n):
    out=''
    while n:
        n,x=divmod(n-1,26);out=chr(65+x)+out
    return out

with ZipFile(FILE) as z:
    shared=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',NS):
            shared.append(''.join(t.text or '' for t in si.iter('{'+NS['s']+'}t')))
    rels={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    wb=ET.fromstring(z.read('xl/workbook.xml'))
    sheets={}
    for sh in wb.findall('s:sheets/s:sheet',NS):
        target=rels[sh.attrib['{'+NS['r']+'}id']]
        target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        tree=ET.fromstring(z.read(target))
        cells={}
        for c in tree.findall('.//s:sheetData/s:row/s:c',NS):
            t=c.attrib.get('t');v=c.find('s:v',NS)
            if t=='inlineStr': val=''.join(q.text or '' for q in c.findall('.//s:t',NS))
            elif v is None: val=None
            elif t=='s': val=shared[int(v.text)]
            elif t=='b': val=v.text=='1'
            elif t in ['str','e']: val=v.text
            else: val=float(v.text)
            cells[c.attrib['r']]=(val,t)
        sheets[sh.attrib['name']]={'cells':cells,'tree':tree}
    assert len(sheets)==7
    count=0
    for name,key,start in [('逐份分数','scores',7),('按图片','images',7),('按建筑','buildings',7),
        ('共同图片人员','workers',7),('方案对照','variants',7)]:
        tbl=data['tables'][key]
        cells=sheets[name]['cells']
        for i,row in enumerate(tbl['rows'],start):
            for j,want in enumerate(row,1):
                addr=f'{col(j)}{i}'
                got,t=cells.get(addr,(None,None))
                if want is None:
                    assert got is None,(name,addr,'expected missing',got)
                elif isinstance(want,bool):
                    assert isinstance(got,bool) and got==want,(name,addr,want,got,t)
                elif isinstance(want,(int,float)):
                    assert isinstance(got,(int,float)) and not isinstance(got,bool),(name,addr,want,got,t)
                    assert math.isclose(got,want,rel_tol=1e-12,abs_tol=1e-12),(name,addr,want,got)
                else:
                    assert got==want,(name,addr,want,got)
                count+=1
    score=sheets['逐份分数']['cells']
    nq=sum(score.get(f'E{i}',(None,None))[0] is not None for i in range(7,3159))
    nd=sum(score.get(f'P{i}',(None,None))[0] is not None for i in range(7,3159))
    assert nq==2003 and nd==3021
    errors=[]
    for sn,sh in sheets.items():
        for addr,(v,t) in sh['cells'].items():
            if t=='e': errors.append([sn,addr,v])
    assert not errors,errors
    panes={sn:sh['tree'].find('s:sheetViews/s:sheetView/s:pane',NS).attrib
        for sn,sh in sheets.items() if sh['tree'].find('s:sheetViews/s:sheetView/s:pane',NS) is not None}
    result={'file':str(FILE),'sheets':list(sheets),'checked_frozen_cells':count,
        'numeric_Q_main':nq,'numeric_Q_diagnostic':nd,'unavailable_Q_diagnostic':3152-nd,
        'typed_numeric_and_boolean_values_preserved':True,'missing_values_not_zero_filled':True,
        'xml_error_cells':errors,'panes':panes,'native_excel_application_opened':False}
(BUILD/'saved_workbook_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
