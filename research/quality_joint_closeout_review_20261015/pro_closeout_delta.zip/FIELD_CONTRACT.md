# 数值字段与用途字段

`ALL_3152_LEDGER.csv`每行是一份原始作答，`record_id`唯一；`ALL_REFERENCE_PAIRS.csv`每行是作答×固定参考×完整／底面口径，不能按其行数声称独立作答数增加。

`score_status`是当前数值／用途路由：`full`、`conditional_full`、`conditional_scope_diagnostic`、`historical_only`、`floor`、`target_version_unresolved`、`geometry_unavailable`、`route_unavailable`、`held`、`oos_not_applicable`。`status`若存在，只是一次公式运算的complete／floor_only，不替代`score_status`和原资格。

`WQ`、`current`、`IoU3D100`分别为冻结新组合、hill08旧组合和同参考顶点均高3D IoU百分比。`floor_WQ`在完整记录上也有值，表示去掉高度后的底面条件分；只有`score_status=floor`才是“只能计算底面”的作答。完整分缺失不得用`floor_WQ`替代后混排。

`boundary_loss`、`direction_loss`、`global_height_loss`、`local_height_loss`是分母损失；`height_drop_WQ`是实际完整分相对底面分的扣分。不能把损失大小当成实际分数扣除量。

`S_top_deg`、`flat`等可能由历史分项保留，不进入当前WQ公式。原始x诊断另见`RAW_X_DIAGNOSTICS.csv`，不加入主分。

`condition`／`source_cohort`／`role`／`stage`是不同分类，不能互相替代；`full`不自动意味着manual，不意味着人员合格。`original_holdout`、`personnel_barriers`、`context_barriers`和`formal_eligibility_newly_granted`保留来源限制。

`reference_id`是该行实际数值参考；`reference_binding`说明绑定依据。`reference_object_id`可能是历史准入表字段，不应绕过`reference_binding`重选新参考。`route_uncertainty`及`same_target_unconfirmed`保留自动路由的语义不确定性。

`latest_step_reference_pending`标识台阶未决图的3份历史数值；`same_target_quality_hold`标识台阶、Q01、Q02明确的同目标质量限制。962普通是完整数值描述集合；涉及同目标质量的保守分析另提供排除台阶整图的959集合。没有更改原人员／场景资格。

`calculation=stored_metrics_rescore`表示复用可靠分项，仅总分新算；`point_reconstruction`表示本次配对从点测量。一部分存储配对同时做了几何抽查，见独立parity清单，不把抽查次数与唯一配对数相加作为新作答数。

融合结果`formal_comparison_eligible=false`仍保留；`fusion_recomputed=false`表示只评价冻结终点。`TEAM_SELECTION_DIAGNOSTIC`评价选中个人均值，不是融合输出。`rank_third`是探索性等人数分组，不是正式人员质量等级，更不是建议将工人强分成三类。

后续补原图脚本只生成新展示材料，不重写原队列和绑定。新人工回执不自动变成训练标签、人员资格或评分阈值。
