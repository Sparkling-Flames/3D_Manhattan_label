# HOHONET质量模型收尾：实际数值对照与研究采用建议

使用的仓库main：`134e7c775b9ea25a076851c0605571ba0ea0ac31`。

先读[中文报告](REPORT_ZH.md)或[HTML报告](REPORT_ZH.html)，论文方法与结果草稿见[METHODS_AND_RESULTS_ZH.md](METHODS_AND_RESULTS_ZH.md)。外部文献与官方PDF在[文献核验](references/RELATED_WORK_ZH.md)。

建议保留HoHoNet兼容3D IoU为“参考重合”主终点，WQ-LS08与分项作为必须并列的几何质量描述；不将其中一项宣布为已经校准的人类质量真值。固定版本评分器会校验配置一致性，配置漂移时报错，不静默忽略更改。WQ参数未变，不改GT、正式人员资格、参考路由或融合。详细采用配置见`configs/ADOPTION_RECOMMENDATION.json`。

## 运行

```bash
python verify_delivery.py
python -m pip install -r requirements.txt
python reproduce.py --output ../quality_closeout_new_replay --figures
python score_one.py --record R03274 --rebuild
```

`--output`必须是新目录，脚本拒绝覆盖。首次执行先恢复3152用途投影，再重评分／重建配对，最后生成人员、组合、融合、机制和审核清单；没有联网依赖。`--figures`可省略，数值与测试仍全部运行。整个依赖链包含数据与冻结引擎，不需要忽略目录`source_package`。

无`--rebuild`的单例命令只读已计算分项重评分；`--rebuild`从固定点和同一参考重建。缺顶界对象不能用该命令制造完整分。`src/extract_sources.py`只记录本次容器历史归档提取过程，不是独立复现入口。

## 主要产物

- `results/ALL_3152_LEDGER.csv`：全作答ID、来源、资格、场景、留出、固定参考、分项、完整／底面分和限制。数值存在不取消用途限制。
- `results/ALL_REFERENCE_PAIRS.csv`：1610个逐参考组合，含1393完整和217仅底面；多参考不计为独立作答。
- `results/ORDINARY_962.csv`及`ORDINARY_GROUP_SUMMARY.csv`：普通条件完整结果与图片／建筑汇总。
- `results/WORKER_METRIC_SENSITIVITY.csv`及`TEAM_SELECTION_DIAGNOSTIC.json`：描述性人员和有限历史池组合敏感性，不是新的正式人员类别或融合结果。
- `results/FUSION_220_SCORES.csv`、`FUSION_220_RESULTS.json`：冻结融合终点144完整、1底面、75暂缓；未重新融合。
- `results/CONTROLS_REMEASURED_151.json`、`MECHANISM_CHECK_SUMMARY.json`：本次实测控制，不是人评。
- `review/CANDIDATE_QUEUE.json`、`CANDIDATE_BINDINGS.csv`：25卡、29作答、21图的固定后续核查队列；候选选择不以原图是否取得为条件。
- `review/REVIEW.html`：隐藏分数／算法／选例理由的几何页。只有5卡带原图，20卡必须补图后才能作视觉质量判断。参考未决卡不询问总质量排序。

本地已有原图文件夹或原图ZIP时，可运行以下辅助命令。它只生成另一个带图页面，保留原候选清单、数据、分数和参考绑定不变。

```bash
python hydrate_review_photos.py /path/to/original_photos_or_zip
```

## 证据边界

本次验证完整有效坐标快照及当前规则投影，不宣称运行仓库原生`load_current_bundle()`，也不宣称本次重新验证全部评论交叉表。完整坐标与READY共享907对象一致，3152用途规则结果与READY810条逐字段一致；详细来源见`SOURCE_PROVENANCE.md`。

外部PDF正文可读，部分PDF截图／下载失败；仅RoomFormer作者项目图完成图像查看。审核HTML通过JS语法检查，未进行浏览器实机交互验收。原始失败和修复保存在`EXECUTION_LIMITS.json`。所有已曝光人评仅是开发证据。

压缩包核验回执与ZIP自身SHA-256在同名外部`.verification.json`中，避免自引用哈希。包内MANIFEST核验全部载荷；字体文件和外部论文PDF不随包分发。
