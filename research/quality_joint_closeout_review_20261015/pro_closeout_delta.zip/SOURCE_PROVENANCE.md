# 输入、参考与版本来源

## 当前依据

main固定为`134e7c775b9ea25a076851c0605571ba0ea0ac31`。实际读取该版本的收尾README／PRO_TASK、独立审查、最新8卡回执、用途／参考选择和下游源码。未写入仓库。

完整坐标来自容器中已挂载历史包的`current_formal_loader_data.json`有效快照，保存为`source/historical_current_formal_loader_data.json`，3441对象、3152作答。SHA-256：`f5fa0082ee3400b2313bb70b284f525cb4591ca1effb359bf52b03a5990d209f`。这是应用过当时授权修订的有效坐标视图，不是拿旧原始导出覆盖当前处理结果。

本次独立核查全部配对、周期平均x及y不变、源点身份、环序和参考身份；3303份源状态可计算对象从点重建成功。READY中907个共同对象的共享字段一致。由于Git LFS／Library字节路径限制，未在容器运行最新仓库原生`load_current_bundle()`和全量评论跨表验证；不得把上述检查改写成其通过回执。

## 字节固定来源

`source/archive_sources.json`逐件保存66份历史载荷的原ZIP、成员路径、字节数、SHA-256。本包`source/ready/`保留READY119文件，包括冻结引擎、907对象投影、810条用途数据、旧回执与原图。优先级由当前任务与最新回执决定；旧README中的待审／参数安排不自动生效。

关键Git blob经本次连接器核对：

|载荷|Git blob|
|---|---|
|search_922|4d1f30cd4fa59e074702e4a7561ef09e1424fa54|
|routing_prepared|ca5396449d4d383da12c771d8c49104c95a608f9|
|routing_429|bed2a3ee1f36f67bf02766b3a19b70567a4a156e|
|reference_exclusions|efad94144d289ade77538e3dc9502cbf18ebcc41|
|severe_feedback|0ee0ef67065d60114955270a647b217175f53a25|
|fusion_220_old|31cafd536f6b3ac581b9686969aae8882406032e|

Git blob SHA-1与文件SHA-256是不同字段，不混同。全量用途账本是根据读取到的当前规则与固定证据恢复的投影，不是声称取得原始`FULL_ADMISSION.json`同字节副本。其计数与当前main一致，并对READY810条的14项资格字段核查为0差异。

## 明确标注的连接器字段投影

`source/fusion_gap_metric_projection.tsv`和`fusion_gap_projection.json`为本次从最新`research/quality_downstream_audit_20261013/REFERENCE_GAP_AUDIT.json`读取并转存的85份指标字段投影（84完整、1底面），不是该JSON的原始字节镜像。其原Git blob为`98fd3813e71d70c36e39673bc4ea68ef4c285101`。固定索引与图像／版本／参考由独立重建的139终点绑定账本对应；逐例成员、84／51／3／1参考处置、51限制成员和18留出成员计数均核对。一次分页遗漏已补回，最终85投影闭合。后续可以在有原文件字节的环境中进一步逐字段自动比较；本包不伪造原件哈希。

`source/latest_feedback_projection.json`同样是最新8卡原回执的实际最终回答与解释字段投影，来源Git blob`23b4febf00ae7e6ff5eccba546c838ee08f029cc`。L01与Q02首次展开快照到最终回答的修订保留，不把展开页面解释为导致修改的因果证据。全部人评已有分数曝光，不称盲测。

## 参考与用途

人工指定和既有路由保持；只有无路由且既有可信完整参考唯一时才条件绑定。原始／修订GT的版本敏感性单列，不等同多个合法空间，不选最高WQ／IoU。底面确认但顶界缺失时完整分为空。Q01合法小范围没有精确小参考，Q02两份带最新范围混杂标志；未通过大参考消除限制。

uNb-36台阶未决的三份有历史完整数值。新增加`latest_step_reference_pending`侧栏，且明确给出排除整图3份后的959敏感性；不追溯更改原始图级／人员资格。OOS406份始终不进入拟合或普通评分分析，282原留出身份不变。

全部输入和输出的最终SHA-256以MANIFEST为准。额外9张原图另有`source/additional_photo_provenance.json`，按照image_id匹配，不借用相邻视角。
