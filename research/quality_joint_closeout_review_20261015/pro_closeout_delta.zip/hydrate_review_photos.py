"""Attach original panoramas to the fixed audit queue; never change bindings/scores.
Usage: python hydrate_review_photos.py /path/to/photo_directory_or_zip [...]
"""
from pathlib import Path
import argparse, hashlib, json, zipfile
ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('sources',nargs='+',type=Path)
    args=ap.parse_args()
    data=json.loads((ROOT/'review/DISPLAY_DATA.json').read_text(encoding='utf-8'))
    rich=json.loads((ROOT/'review/CANDIDATE_QUEUE.json').read_text(encoding='utf-8'))
    ids={c['case_id']:c['bindings'][0]['image_id'] for c in rich['cases']}
    wanted=set(ids.values());found={};provenance=[]
    def consider(name,read,origin):
        stem=Path(name).stem
        if stem not in wanted or Path(name).suffix.lower() not in {'.png','.jpg','.jpeg'}:return
        blob=read();digest=hashlib.sha256(blob).hexdigest()
        if stem in found and found[stem][0]!=digest:raise ValueError('Conflicting photo bytes for '+stem)
        found[stem]=(digest,blob,Path(name).suffix.lower(),origin)
    for p in args.sources:
        if p.is_dir():
            for f in p.rglob('*'):
                if f.is_file() and f.stem in wanted:consider(f.name,f.read_bytes,str(f))
        elif zipfile.is_zipfile(p):
            with zipfile.ZipFile(p) as z:
                for name in z.namelist():
                    if Path(name).stem in wanted:consider(name,lambda n=name:z.read(n),str(p)+'!'+name)
        else:raise ValueError('Not a directory or ZIP: '+str(p))
    target=ROOT/'review/photos';target.mkdir(exist_ok=True)
    for c in data:
        im=ids[c['case_id']]
        if im not in found:continue
        digest,blob,suffix,origin=found[im];p=target/(im+suffix)
        if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise ValueError('Refusing different overwrite '+str(p))
        p.write_bytes(blob);c['photo']='photos/'+p.name
        provenance.append(dict(case_id=c['case_id'],image_id=im,path=p.name,sha256=digest,source=origin))
    (ROOT/'review/HYDRATED_DISPLAY_DATA.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    template=(ROOT/'src/review_template.html').read_text(encoding='utf-8')
    payload=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
    (ROOT/'review/REVIEW_WITH_PHOTOS.html').write_text(template.replace('__DATA__',payload),encoding='utf-8')
    (ROOT/'review/PHOTO_HYDRATION.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(cards=len(data),cards_with_photo=sum(bool(c['photo']) for c in data),bindings_changed=False),ensure_ascii=False))
if __name__=='__main__':main()
