# 相近研究、具体证据与迁移限制

本次文献核验与本项目计算分开。以下均为原作者论文或官方代码，未把外部案例当成本项目人评，未重新训练这些外部模型。没有找到直接验证WQ-LS08公式或其0.8／0.25高度尺度的人类质量实验；这仅限于本次检索和阅读范围，不等于证明此类文献不存在。

## 1. HoHoNet：3D IoU的实际实现，不只有一个IoU

**完整引用：** Cheng Sun, Min Sun, and Hwann-Tzong Chen. 2021. “HoHoNet: 360 Indoor Holistic Understanding With Latent Horizontal Features.” *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition*, 2573–2582.

[作者公开PDF](https://arxiv.org/pdf/2011.11498) · [官方论文页](https://openaccess.thecvf.com/content/CVPR2021/html/Sun_HoHoNet_360_Indoor_Holistic_Understanding_With_Latent_Horizontal_Features_CVPR_2021_paper.html) · [官方评价代码](https://github.com/sunset1995/HoHoNet/blob/master/eval_layout.py)

实际读取`eval_layout.py`，blob `2c764fe4b81382e6b4bce17f11d443a6120ce749`。`test_general()`用底面交面积乘两者顶点平均墙高的较小值作为交体积；并同时报告布局深度RMSE和δ1。不能说原作者只关心IoU，也不能把这里的均高棱柱当成任意局部非平顶布局的精确实体体积。官方脚本异常处理会赋零；本研究为保存不可算与资格分母，不照搬这一缺值策略。

可借鉴的是可核查的固定参考重合定义，以及并列评价多种误差。不可迁移的是把模型标准平顶输出的解释不加限制地赋予非平顶人工作答。本文的共线细分反例是本次自建并执行的诊断，不是HoHoNet论文提出的例子。

## 2. RoomFormer：较高IoU不保证角点／角度质量；角度改善也会与房间指标冲突

**完整引用：** Yuanwen Yue, Theodora Kontogianni, Konrad Schindler, and Francis Engelmann. 2023. “Connecting the Dots: Floorplan Reconstruction Using Two-Level Queries.” *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition*, 845–854.

[作者公开PDF及补充材料](https://arxiv.org/pdf/2211.15658) · [官方论文页](https://openaccess.thecvf.com/content/CVPR2023/html/Yue_Connecting_the_Dots_Floorplan_Reconstruction_Using_Two-Level_Queries_CVPR_2023_paper.html) · [作者项目页与真实数据示例](https://ywyue.github.io/RoomFormer/) · [官方评价代码](https://github.com/ywyue/RoomFormer/blob/main/s3d_floorplan_eval/Evaluator/Evaluator.py)

补充材料§D／Table12给出非学习流程的SceneCAD房间IoU为86.0，角点F1为72.7、角度F1为49.6。作者明确解释：粗轮廓重合尚可，而角度指标反映其几何仍不准确。这是与本项目最直接的相邻几何证据。作者项目页的SceneCAD与Structured3D结果图已实际查看；那些是扫描／模型重建示例，不是众包人评实验。

相反方向的证据在补充材料§B／Table10：tight-room训练版本相对原版本，角度F1从81.2升至84.2，而room F1从97.3降至96.7。作者说明这与近似训练GT、房间重叠和邻房约束有关。不能把“角度更好”直接扩写为总体质量更好。

官方评价器blob `8738d00cc6c732e2884aa5b5b60049b9ca839590`已读。它比较已匹配GT角点上的角度差，而不是对每个点统一罚偏离90°。其像素距离门和角度阈值属于256×256楼层轮廓评价；本项目含ERP接缝、冗余点、停止边和非唯一对应，不能直接复制10像素／5°，更不能由此认证WQ参数。

## 3. Bi-Layout：目标定义不同可能先于几何误差

**完整引用：** Yu-Ju Tsai, Jin-Cheng Jhang, Jingjing Zheng, Wei Wang, Albert Y. C. Chen, Min Sun, Cheng-Hao Kuo, and Ming-Hsuan Yang. 2024. “No More Ambiguity in 360° Room Layout via Bi-Layout Estimation.” *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition*, 28056–28065.

[作者公开PDF](https://arxiv.org/pdf/2404.09993) · [官方论文页](https://openaccess.thecvf.com/content/CVPR2024/html/Tsai_No_More_Ambiguity_in_360deg_Room_Layout_via_Bi-Layout_Estimation_CVPR_2024_paper.html) · [官方代码](https://github.com/LIAGM/Bi_Layout)

原文Figure1、§3和Figure2说明MatterportLayout在开口附近的enclosed与extended目标差异：模型输出与GT可能采用相反范围，即使不能简单解释为局部点击错误。该证据与本项目Q01合法小房间／大范围参考的分离直接相关。

其disambiguate评价从两个预测分支中取对给定GT更好的匹配，是多预测评价设计；不是许可本项目从多个GT中挑最高分当作真实目标。保留人工指定→局部结构→模糊底面兜底的既有参考绑定。论文证明目标歧义值得处理，不证明本项目每一种小范围都合理。

## 4. Boundary IoU：边界与面积的敏感度不同，但它不是三维布局评分

**完整引用：** Bowen Cheng, Ross Girshick, Piotr Dollár, Alexander C. Berg, and Alexander Kirillov. 2021. “Boundary IoU: Improving Object-Centric Image Segmentation Evaluation.” *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition*, 15334–15342.

[作者公开PDF](https://arxiv.org/pdf/2103.16562) · [官方论文页](https://openaccess.thecvf.com/content/CVPR2021/html/Cheng_Boundary_IoU_Improving_Object-Centric_Image_Segmentation_Evaluation_CVPR_2021_paper.html) · [作者项目页](https://bowenc0221.github.io/boundary-iou/)

Figure1的实例分割示例指出，较高Mask IoU仍可伴随粗糙边界；更精细的轮廓在Boundary IoU上得到更明显区分。可借鉴面积与边界分开测量的动机，不是把照片审美、清晰度或分割边界指标直接套到房间高度、墙族和拓扑。本文不新增Boundary IoU主项，也没有借外部例子确定本项目权重。

## 核验状态与可核查位置

四篇PDF的作者版本解析正文均可读；原始官方代码已通过GitHub连接器读取。CVF直接PDF下载返回403，arXiv截图服务多次返回Internal Error，所以不能声称已查看全部PDF表格／图片像素。上面的表格数值和图示论断限于可读正文、表格解析与图注；RoomFormer作者项目页的两张结果图例外，已通过图像工具实际查看。PDF未在本包重新分发，链接供直接核查。没有OCR，没有编造图片ID或人评结果。

相关文献支持“测量目标应拆开、几何需多项评价”的方向；不支持“本项目WQ已经胜过IoU”的结论，也不要求继续堆叠新指标。
