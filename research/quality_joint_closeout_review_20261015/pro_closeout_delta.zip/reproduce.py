from pathlib import Path
import argparse,shutil,subprocess,sys,json,os,time
ROOT=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);ap.add_argument('--figures',action='store_true');a=ap.parse_args();out=a.output.resolve()
 if out.exists():raise SystemExit('Refusing to overwrite an existing output directory')
 out.mkdir(parents=True)
 for name in ('src','source','engine','configs','tests'):
  shutil.copytree(ROOT/name,out/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for name in ('results','review','figures'): (out/name).mkdir()
 env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');receipts=[];t=time.perf_counter()
 scripts=['recover_ledger.py','compute_all.py','analyze_downstream.py','fusion_bindings.py','analyze_fusion.py','closeout_checks.py','additional_sensitivity.py','model_regression.py','build_review.py']
 if a.figures:scripts.append('render.py')
 for s in scripts:
  with (out/'results'/(s+'.log')).open('w',encoding='utf-8') as log:
   st=time.perf_counter();p=subprocess.run([sys.executable,'-B',str(out/'src'/s)],cwd=out,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=240)
  receipts.append(dict(script=s,exit_code=p.returncode,seconds=time.perf_counter()-st))
  print(s,p.returncode,flush=True)
  if p.returncode:raise SystemExit('Failed: '+s+'; inspect '+str(out/'results'/(s+'.log')))
 with (out/'results/pytest.log').open('w') as log:p=subprocess.run([sys.executable,'-m','pytest','-q','tests'],cwd=out,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=120)
 receipts.append(dict(script='pytest',exit_code=p.returncode))
 (out/'REPRODUCTION.json').write_text(json.dumps(dict(seconds=time.perf_counter()-t,steps=receipts,passed=p.returncode==0),indent=2))
 if p.returncode:raise SystemExit('Tests failed; see pytest.log')
if __name__=='__main__':main()
