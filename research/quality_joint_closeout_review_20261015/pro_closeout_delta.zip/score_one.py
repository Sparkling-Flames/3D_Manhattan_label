"""Score a fixed existing pair; numeric availability is not eligibility. Does not select a best reference or restore gates."""
from pathlib import Path
import sys,argparse,json
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from quality import read,score,measure,geometry
p=argparse.ArgumentParser();p.add_argument('--record',required=True);p.add_argument('--reference');p.add_argument('--rebuild',action='store_true');a=p.parse_args()
d=read(ROOT/'results/all_scores.json');can=d['canonical'].get(a.record)
if can is None:raise SystemExit('Unknown record')
key=can.get('pair_key')
if a.reference:rows=[r for r in d['records'] if r['record_id']==a.record and r['reference_id']==a.reference]
elif key:rows=[r for r in d['records'] if [r['record_id'],r['reference_id'],r['score_kind']]==key]
else:raise SystemExit('No single bound target. '+json.dumps(can,ensure_ascii=False))
if len(rows)!=1:raise SystemExit('Need an exact existing reference binding; no best-score reference is selected.')
r=rows[0];out=dict(canonical_disposition=can,reference_id=r['reference_id'],existing_use_layers=r['use_layers'],scores=score(r['metrics']),metrics=r['metrics'],calculation='stored_metrics_rescore')
if a.rebuild:
 objs={o['object_id']:o for o in read(ROOT/'source/historical_current_formal_loader_data.json')['objects']}
 if r['score_kind']=='floor':raise SystemExit('This is floor-only. Full geometry is not fabricated for reconstruction.')
 out.update(measure(geometry(objs[r['object_id']]['points_1024x512']),geometry(objs[r['reference_id']]['points_1024x512'])));out['calculation']='point_reconstruction'
import csv
with (ROOT/'results/ALL_3152_LEDGER.csv').open(encoding='utf-8-sig',newline='') as f:
 row=next(r for r in csv.DictReader(f) if r['record_id']==a.record)
out['current_use_restrictions']={k:row[k] for k in ('score_status','role','stage','personnel_barriers','context_barriers','original_holdout','latest_step_reference_pending','same_target_quality_hold')}
print(json.dumps(out,ensure_ascii=False,indent=2))
