"""Verify actual archive payload hashes. Does not certify statistical validity."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'MANIFEST.json').read_text());errors=[]
for f in m['files']:
 p=(ROOT/f['path']).resolve()
 if not p.is_relative_to(ROOT):raise SystemExit('Unsafe manifest path')
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:errors.append(f['path'])
print(json.dumps(dict(files=len(m['files']),errors=errors,passed=not errors),indent=2))
if errors:raise SystemExit(1)
