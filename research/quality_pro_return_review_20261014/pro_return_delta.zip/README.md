# WQ-LS08-20261014：质量校准研究工作版

先读 [中文报告](REPORT_ZH.md) 或 [HTML报告](REPORT_ZH.html)。完整数值、源数据和人评修订均随包，可离线复算。不改GT、输入、人员资格或融合算法。

## 工作公式

`Q = 100 I / [1 + I (Sb²/32 + 1.5 D²/(D²+37.5) + (Hm/.8)² + (Hc/.25)²)]`。

完整有效输入I=0取0；缺高度仅报告底面，完整Q为null；非法几何不补零。D仍是自身共同正交轴方向RMS，不是完整结构正确性。没有新增二维主罚项；原始上下x差只作诊断。此分数不是正确率、严重度等级或正式人员权重。

## 阶段与用途

574普通（207明确普通、367条件许可）先比较并冻结；9严重另作约束。之后重建门洞125条件完整分，保留92暂缓；Q01图8份只保留范围条件诊断，其余117条件回归。门洞后追加参数变化为零。Q02/Q03已审核并修订，无完整质量排序；不重复索要。Q01小房间没有精确小参考，不能用大参考低分评价它的真实质量。

## 运行

```bash
python verify_delivery.py
python -m pip install -r requirements.txt
python reproduce.py --output ../quality_reproduced
python src/score_cli.py --record R03274 --rebuild
python src/score_cli.py --record R03332
python -m pytest -q tests
```

`reproduce.py`默认全部数值重跑，拒绝覆盖已存在目录；加`--figures`重画图。源数据、引擎和回执在`frozen_input/`（119文件，原字节），不需要任何在线连接或隐藏目录。`requirements-lock.txt`是实测版本，不是所有平台的兼容保证。

## 文件入口

|文件或目录|用途|
|---|---|
|`configs/ordinary_frozen.json`|先于门洞新计算生成的普通工作冻结及依赖哈希|
|`configs/WORKING_FINAL.json`|门洞比较与回归后最终配置，参数相同|
|`results/FINAL_ordinary.csv`|574普通的原始诊断、指标、损失、当前/工作Q、同参考3D IoU|
|`results/FINAL_severe.csv`|9严重例外，资格不恢复|
|`results/FINAL_doorway.csv`|217门洞，92行NA及原因完整保留|
|`results/FINAL_historical_only.csv`|10来源受限旁证，不混普通池|
|`results/FINAL_by_image_building.csv`|按图片/建筑等权与行级汇总，层之间不混合|
|`results/*_scores_long.csv`|普通35候选、门洞10候选、控制的逐份分项|
|`results/height_attribution.csv`|高度损失、固定非高度背景的扣分、完整式实际扣分分别报告|
|`results/doorway_fine_normal_regression.csv`|门洞细调参数的普通/严重回归代价|
|`results/effective_use_ledger.json`|810记录用途、参考、原始限制与最终条件分数|
|`results/input_source_reference_manifest.csv`|907对象的源点、配对、环序、原始x诊断及来源|
|`results/real_bottom_trajectories.json`|3066真实输入派生诊断，不是新增真人样本|
|`results/mechanism_controls.json`|21独立机制控制和112密集底点状态|
|`results/axis_family_decomposition.json`|共同轴/方向族/长度权重分离|
|`evidence/Q01_reference_search.json`|实际读取三个历史登记文件的小参考检索边界|
|`logs/CLEAN_FULL_REPRODUCTION.json`|独立新目录整条数值链重跑回执|
|`tests/`|50项新增数值与来源合同测试|
|`figures/`|原图叠加、同尺度BEV/三维、控制曲线|
|`frozen_input/REVIEW.html`|继承的离线可旋转3D页面；本轮未测试浏览器交互|
|`MANIFEST.json`|交付文件字节数与SHA-256；自身哈希由ZIP外回执保护|

既有人评、控制和当前选择均是开发证据；原留出未重切。目录成功、测试成功、偏好一致、量表有效是不同结论。当前/旧尾项不能混名：输入现工作版是hill_global08，旧普通行components仍是历史尾项；报告及新表统一重算对照。
