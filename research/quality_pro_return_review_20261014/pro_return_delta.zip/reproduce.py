#!/usr/bin/env python3
"""Offline full numerical reproduction in a NEW directory. No downloads.
Default recomputes all 718 permitted real pairs,151 source controls, independent
controls,3066 diagnostic trajectory states,35 ordinary and10 doorway candidates.
Use --figures to regenerate views as well. Human judgements are not recollected.
The investigator's fixed working choice is re-recorded, not learned or certified.
"""
import argparse,json,os,shutil,subprocess,sys,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--figures',action='store_true');a=p.parse_args()
    here=Path(__file__).resolve().parent;out=Path(a.output).resolve()
    if out.exists():raise SystemExit('Refusing to overwrite existing output directory: '+str(out))
    if out.is_relative_to(here):raise SystemExit('Use a sibling/outside directory, not inside the delivered evidence bundle.')
    out.mkdir(parents=True)
    for folder in ['frozen_input','src','tests','evidence']:
        shutil.copytree(here/folder,out/folder,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
    for folder in ['results','configs','figures','logs']: (out/folder).mkdir()
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    runs=[];start=time.time()
    def run(args,label,cwd=out):
        print(label,flush=True);t=time.time()
        with (out/'logs'/f'{label}.log').open('w',encoding='utf-8') as log:
            r=subprocess.run([sys.executable,*args],cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env=env)
        runs.append(dict(stage=label,exit_code=r.returncode,seconds=time.time()-t))
        if r.returncode:raise RuntimeError(label+' failed: see '+str(out/'logs'/f'{label}.log'))
    # The provided startup writes its own result; preserve that result in logs
    # and restore the uploaded byte-identical historical startup snapshot.
    path=out/'frozen_input/startup_result.json';saved=path.read_bytes()
    try:
        run(['run.py'],'startup',out/'frozen_input')
        shutil.copy2(path,out/'logs/startup_this_run.json')
    finally:path.write_bytes(saved)
    run(['src/measure.py','--phase','ordinary'],'ordinary_measurement')
    run(['src/compare.py','--phase','ordinary'],'ordinary_comparison')
    run(['src/mechanisms.py'],'mechanisms')
    run(['src/freeze_ordinary.py'],'ordinary_freeze')
    run(['src/measure.py','--phase','doorway'],'doorway_measurement')
    run(['src/compare.py','--phase','doorway'],'doorway_comparison')
    run(['src/finalize.py'],'finalize')
    run(['src/summarize_mechanisms.py'],'mechanism_summary')
    run(['src/provenance.py'],'provenance')
    run(['-m','pytest','-q','tests'],'pytest')
    if a.figures:run(['src/render.py'],'render')
    # Compare actual rebuilt final scores against delivered results, not only tests.
    expected=json.loads((here/'results/effective_use_ledger.json').read_text())['records']
    actual=json.loads((out/'results/effective_use_ledger.json').read_text())['records']
    assert len(actual)==len(expected)==810
    lookup={r['record_id']:r for r in expected};maxerr=0
    for r in actual:
        e=lookup[r['record_id']]
        assert (r['status'],r['reference_object_id'],r['effective_use'])==(e['status'],e['reference_object_id'],e['effective_use'])
        if r['working_Q'] is None:assert e['working_Q'] is None
        else:maxerr=max(maxerr,abs(r['working_Q']-e['working_Q']))
    assert maxerr<1e-8,maxerr
    info=dict(passed=True,runs=runs,seconds=time.time()-start,final_rows=len(actual),max_final_Q_error=maxerr,
              numerical_reproduction_not_blind_validation=True)
    (out/'REPRODUCTION.json').write_text(json.dumps(info,indent=2)+'\n')
    print(json.dumps(info,indent=2))
if __name__=='__main__':main()
