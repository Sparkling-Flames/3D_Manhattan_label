#!/usr/bin/env python3
"""Verify all distributed payload files against MANIFEST.json, without executing them."""
from pathlib import Path
import hashlib
import json

def main():
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    checked=[]
    for row in manifest['files']:
        p=(root/row['path']).resolve()
        if not p.is_relative_to(root):raise ValueError('Unsafe manifest path: '+row['path'])
        if not p.is_file():raise FileNotFoundError(row['path'])
        raw=p.read_bytes()
        if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
            raise ValueError('Payload checksum mismatch: '+row['path'])
        checked.append(row['path'])
    assert len(checked)==len(set(checked))==manifest['file_count_excluding_manifest']
    print(json.dumps({'passed':True,'payload_files':len(checked),'note':'Manifest excludes itself; verify the complete ZIP against its external SHA-256 receipt.'}))

if __name__=='__main__':main()
