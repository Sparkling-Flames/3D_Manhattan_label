最小多空间协议：显式任务模式优先，几何偏好不等于历史意图
版本：explicit_frozen_target_protocol_20261011_v1

一、当前可执行结论

本目录实现的是冻结 v1.1 评分器外的一层目标使用协议，没有新建真实图片 GT，没有改变正式资格、任何既有质量分或全库主评分表。数值调用仍是本轮固定的 frozen_engine/core/quality_v11.py 及 ../preregistered_candidates.json 的参数。它适用于研究者已经在评分前确定、审核并冻结的候选目标；哈希只能证明内容一致，不能证明这个审核是正确的，也不能证明审核独立于待评作答。

建议按任务协议分三种明确状态，不依靠一个新的 IoU 阈值强行选空间：

1. fixed_declared_target：已有固定任务目标，或有可信的目标声明记录。只以明确指定的目标形成正式 Q。保留其他候选的计算结果作为诊断；它们不能覆盖指定目标。指定目标缺失、不合法、不完整或几何无效就不能形成正式 Q，不回退到另一个分高的目标。

2. any_preapproved_target：任务在作答前明确允许任一已审核目标，且整个固定集合内每个目标都具有完整可算的顶底几何，才计算全部 Q 并取最大值。这衡量“满足允许目标集合的最佳程度”。它没有恢复作答者真实意图；返回的是 selected_quality_reference_ids，若并列则保留全部。任何集合成员 top_pending、绑定错误或不符合合法授权，都会阻止这种模式的完整评分。是否允许这个模式必须先由研究规则明确，不能在看到得分后选择。

3. unresolved_legacy：历史作答缺乏可信的目标/任务模式记录时，计算可用的候选几何信息与候选 Q，只给 BEV 和 Q 的偏好及差距，正式 Q 和正式归属保持空值。无需发明“差距足够大便当作真实意图”的阈值。这不撤销主表已存在的固定 GT 分；诊断结果另存，不与固定参考主分混为同一种量。

每次输出保留所有候选目标的原几何、ID、哈希、合法性/完整性、冻结评分完整结果、覆盖信息、选择依据及最终状态。coverage_relative_to_fixed_overall_scope 始终是同一个预先固定总范围中的覆盖比例，不能因选了小空间就把总覆盖改成 100%。每个候选另有 target_vs_fixed_overall_scope，能够区分目标本身只覆盖总范围一部分，还是作答在该目标内还存在遗漏。

本协议不从图像、人员身份、难度或 Q 推导合法目标集；不删除顶点、规整、补顶、补闭环或修复输入。输入非法时保留冻结验证器的 unavailable 和具体理由。不可评价不是低分。

二、本次实际运行：5类控制，9次协议运行，17项检查通过

完整合成目标是以相机高度 h 为单位的两个同高方形：大空间边长 8h、小空间边长 4h，地面 -h、顶面 +h，墙高 2h。所有合成坐标、目标集合、任务模式先写入 fixtures/ 并记录哈希，再调用评分。它们不对应任何真实图片的新 GT。

同一个精确小空间作答：
  固定要求大空间：Q = 2.7501511379；
  固定要求小空间：Q = 100（浮点结果 99.99999999999999）；
  事前明确允许两者，集合中完整目标均通过：Q = 100，选小空间作质量参考；
  三种情况的固定大范围覆盖均为 0.25。

这不是模型有歧义造成的例子。作答和两个候选目标完全相同，BEV 最优候选明确为小空间，第一/第二候选 IoU 差为 0.75。它可以是小目标任务下完全正确的答案，也可以是大目标任务下遗漏 75% 底面积的答案。几何本身无法区分两种任务事实。因此，“只要几何匹配清楚就不用人工确认历史目标”不能从几何推出。只对模糊情况人工复核，至少还需要一个可信的、先于得分的任务授权或目标声明；若历史记录没有它，明确的几何偏好也只是偏好。

对同一个固定小目标把作答横向平移 0.5h，Q 从 100 降至 52.6717502890；合法小空间不是定位误差的豁免。这项控制只确认保持任务目标后位置偏差仍被当前公式惩罚，不用该数值另行制定合格线。

其余守卫实际通过：未授权 any 模式不调用完整评分；单个 primary 只有底面时返回 top_pending；包含 pending 候选的 any 模式不调用任何完整 Q；有重叠回退边、非相邻顶点触边的原环返回 unavailable_annotation，记录两类几何证据，不修形；改变冻结目标内容会被集合哈希阻止，集合哈希更新但目标自身几何哈希不一致仍不能产生指定目标正式分；所有输入前后内容哈希一致。

三、最新35条范围登记实际做了什么

输入为 ../../reference_scope/bev_replay/reference_registry.json 的本次恢复/复算登记，35条均为 primary，顶界均 top_pending，reference_ready 均为 false。包括33张研究图和2张仅供参考图片；后两张未加入259张研究图分母。

run_protocol_controls.py 将每条已确认底面原坐标原序列复制为 floor_y=-1 的计算表达，top3d 明确为 null，保留完整源登记及其确认来源。授权范围标记为 confirmed_floor_only。为了测试“是否会错误补顶并生成 Q”，使用同一个明确标记为 synthetic_annotation_only 的有效合成作答调用完整性守卫：35/35 返回 top_pending，完整评分调用 0 次，实际研究作答新增目标 Q 为 0 条。每条结果均有源 floor_polygon_sha256 和新的包含空顶面几何哈希。

这不是35张图或429份作答的新目标完整质量回放；没有将选定旧 GT 顶面拼接到新范围。最新登记没有建立 any-target 任务协议，不能因为 floor 确认就变成两个完整合法 GT。源记录中的暂停或排除状态也没有解除。latest35_readiness_guards.csv 的作答数量列是源元数据，不能当本目录评分分母。

四、复现

需要已有正式冻结引擎、当前候选配置和最新登记。依赖与冻结引擎相同；本协议没有添加学习模型或额外权重。以下从 work/quality_next_stage_20261011 目录运行，--out 必须是尚不存在的新目录，以保留历史产物：

python experiments/target_protocol/run_protocol_controls.py \
  --engine repo/research/quality_scope_comparison_20261010/frozen_engine \
  --config experiments/preregistered_candidates.json \
  --registry reference_scope/bev_replay/reference_registry.json \
  --out experiments/target_protocol/reproduced_results

单包命令行也已实际运行并核验：

python experiments/target_protocol/target_protocol.py \
  --engine repo/research/quality_scope_comparison_20261010/frozen_engine \
  --config experiments/preregistered_candidates.json \
  --input experiments/target_protocol/results/fixtures/04_same_small_legacy.json \
  --out experiments/target_protocol/reproduced_legacy.json

返回 unresolved_legacy_no_formal_assignment，formal_Q=null，formal_target_id=null，historical_intent_inferred=false。JSON 单包入口须包含 annotation、targets、overall_scope、mode、target_set_sha256；固定模式另有 declared_target_id，any 模式须 any_target_mode_authorized=true。任何真实应用仍须先执行本研究的图片/GT对象/GT版本排除政策。本层不会替代那个准入过滤器。

五、产物与解释边界

target_protocol.py：最小可运行协议；
run_protocol_controls.py：生成控制与35条完整性守卫；
results/registration.json：评分前控制哈希、配置/代码/登记哈希；
results/fixtures/：全部原始控制单包；
results/control_summary.csv、complete_control_results.json：所有候选的分数、覆盖和协议结果；
results/binding_conflict_result.json：明确绑定冲突失败；
results/checks.json：17项实际检查及计数；
results/latest35_readiness_guards.csv、latest35_readiness_full.json：35条逐条守卫与完整出处；
results/standalone_cli_legacy.json：独立命令行结果。

“按BEV选择再算Q”和“直接取最大Q”并不等价，BEV与Q对高度/边界权衡不同。前者减少直接按Q择优，但没有消除“用作答形状解释作答是否遗漏”的语义循环，也没有恢复历史意图。可以把几何匹配用于缩小复核候选、展示每个目标的兼容程度；不能把其输出直接称为标注者真实目标。对今后的采集，最小新增记录是作答前固定任务模式，或让作答者从事先审核集合中声明 target_id；仍需保留覆盖，而不是先要求全库逐点重审。

用户审核事实、冻结公式结果与本协议建议互不替代：35个已确认底面和顶界待审来自登记；上述Q数值与守卫计数来自本次运行；三模式用途和默认 legacy 不正式归属是研究建议。没有给本轮35张新完整GT认证，没有宣称几何能自动裁定所有合理小目标，也没有为完成研究而强行确定双参考。
