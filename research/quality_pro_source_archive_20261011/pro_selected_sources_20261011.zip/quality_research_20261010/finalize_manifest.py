#!/usr/bin/env python3
"""Update the full delivery manifest after adding the final report/PDF/XLSX.

Original copied research files remain protected by the separate source hashes.
This writes only provenance/MANIFEST_SHA256.json, never research results.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    copied = json.loads((ROOT / "provenance/source_copy_manifest.json").read_text())
    for row in copied["files"]:
        p = ROOT / row["bundle_path"]
        assert hashlib.sha256(p.read_bytes()).hexdigest() == row["copied_sha256"], row["bundle_path"]
    destination = ROOT / "provenance/MANIFEST_SHA256.json"
    files = []
    for p in sorted(ROOT.rglob("*")):
        assert not p.is_symlink(), p
        if not p.is_file() or p == destination or "__pycache__" in p.parts:
            continue
        files.append({"path": str(p.relative_to(ROOT)), "size_bytes": p.stat().st_size,
                      "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
    result = {"files": files, "files_count": len(files), "bytes": sum(x["size_bytes"] for x in files),
              "source_copies_unchanged": True, "symlinks": 0,
              "excluded_self": "provenance/MANIFEST_SHA256.json"}
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ["files_count", "bytes", "source_copies_unchanged", "symlinks"]}))


if __name__ == "__main__":
    main()
