官方指标与几何反例独立核验
研究日期：2026-10-11（Australia/Sydney）

一、可直接采用的结论

1. 当前角点均高3D IoU与冻结HoHoNet的IoU分支，在相同未修改几何和有效输入条件下吻合。本轮实际运行20个控制，15个有效同几何对照的最大绝对差为6.7724e-15；不仅沿用旧面积，还执行了官方Shapely求交分支。
2. 此IoU不是任意非平顶多面体的真实体积交并，而是底面多边形与角点均高形成的共同地面柱体。它可以完全看不见正负抵消的局部高度误差，且会被非均匀共线加点改变。本轮控制确认这两点；现有v1.1 Hstar已经应对平均抵消，不作为新发明。
3. 官方异常处理不等同于统一零分：预测自交可能进except得0；非法GT直接skip；上下x不一致在try外触发断言；NaN可能传播而不触发except。研究用有效样本比较仍须保留NA和原因，兼容异常值另列。
4. 局部严重方向误差可以被真实长墙的边长权重稀释。它与精确共线分段完全不同：前者改变真实几何总长度，后者不应改变Q。新增13个方向控制已实际运行；未比较或选择候选权重。
5. 固定高度峰值的窄脉冲暴露了数值积分相位问题：同一连续几何仅换环起点，默认Q可差0.65281分。13份真实风险/机制例的133个表示未复现如此大的影响：同几何最大极差0.00191分、共线加点最大差6.39e-14，均未跨95/85/50边界。两项证据并存，不能静默修补默认实现或声称全库表示完全不变。

二、准确的官方定义与坐标适配

固定官方代码commit为2bbc0866789cf7ad728064bc52aaf1d11b67c885。eval_layout.py的test_general在本commit的72—111行执行IoU；文件SHA256为6d7175ab5968668bb09ca2d741c752014e3c5a7c2e815c447a947d8d99cff290。post_proc.py SHA256为7520dce03c93be1758c8ac28351987283fb420b2641dc6933d7c8df615f706d9。五个官方文件的Git blob SHA及SHA256均逐一验证，未改源码。

设地面高度ch=-1.6，官方逐对像素先求rho=ch/tan(v_floor)，再求z_ceiling=rho*tan(v_ceiling)。每个布局的柱体高为abs(mean(z_ceiling)-ch)，均值按角点计数。令A_P、A_G为底面积，A_I为底面交集，官方3D IoU为：

  A_I*min(h_P,h_G) / (A_P*h_P + A_G*h_G - A_I*min(h_P,h_G))。

它使用固定1024×512的几何投影。1.6是共同相机高度假设，不能当作每张图的实测相机高度。对当前y=-1、正墙高、竖直点对，投影后各长度统一放大1.6，体积共同缩放，IoU不变；角点均高正好对应current traditional_metrics中的mean(top_y+1)。周长均高指标另行报告，不能更名为官方口径。

项目当前连续画布角度使用x/1024、y/512；官方像素中心换角度先加0.5。因此本次调用current traditional_metrics.frozen_to_hohonet_pixels(record)，从相同3D射线反投：
  x_pixel=(atan2(x,-z)/(2*pi)+0.5)*1024-0.5；
  y_pixel=(-atan2(y,sqrt(x*x+z*z))/pi+0.5)*512-0.5。

这是坐标基转换，不改变角点、环序、形状或顶高。直接把原points的同一数值喂给官方加0.5投影会改变射线，应只作为“raw canvas probe”诊断，不能与同几何v1.1公平混比。

本次从未改动官方文件中抽取原test_general至深度计算之前的全部AST语句，保留两条x断言、Shapely Polygon、GT skip及两个try/except，只在末尾返回局部量。可称“相同几何上的官方IoU分支核验”。没有运行HoHoNet模型、曼哈顿后处理、RMSE/delta1或完整官方CLI。post_proc中的轴向墙面构造可插入/强制改墙段，不能先应用于人工作答再声称原始人工指标。

三、20个官方控制的关键对照

底面矩形顶点[-2,-1],[2,-1],[2,1],[-2,1]，参考墙高2h。预测墙高[1.01,1.01,2.99,2.99]h：
  原4角：官方3D IoU=1；周长均高IoU=1；v1.1 Q=6.0237695302。
  低墙精确共线插40点：官方IoU=0.55；周长均高IoU=1；Q不变。
  高墙精确共线插40点：官方IoU=0.6896551724；周长均高IoU=1；Q不变。
这三者及1点、4点插入表示同一条底面和顶面折线，不是新增真实缺陷。7个表示的Q范围仅8.88e-16，而官方IoU范围0.45。该缺陷来自角点计数均值；把预测强制平顶会掩盖问题而非解决评价。

将同一矩形XZ放大100倍后，Hmean仍为0，Hstar=0.4365489440，官方IoU约1；仅均高版本Q=99.3652430561，现有v1.1=56.4829760840。这是Hstar既有改进的回放，不是新校准。

另有正常尺度轻微高度+1%：官方IoU=0.990099，Q=99.267982；固定均高+25%：官方IoU=0.8，Q=23.083455；-25%：官方IoU=0.75，Q=12.874162。它们说明球面边界与相对高度会给出比柱体体积更强、且受相机几何关系影响的响应。该数值本身不证明23分或13分的人类标定正确，未据此改参数。

条件适用性反例：可接受非正交GT自比，IoU=1而原Q=93.501016；可接受非平顶GT自比，IoU=1而原Q=92.554154。两个都是明示的合成条件，不是新用户GT批准；说明自身规整项必须有适用前提。

非法负墙高反例：顶点位于底面以下，官方abs均高仍给约1，研究严格验证返回NA(top_at_or_below_floor)。不能把官方兼容返回值直接作为有效质量样本。

四、13个方向控制：RMS稀释与表示稳定性

固定局部错误为两个45°边构成的三角凸出，半宽和高均0.25h。参考是各自的完美矩形，半长L=2/8/32/128h；扩大L只增加真实正确墙长，局部错误的宽、高、角度保持固定。

  L=2：D=10.5121°，相对GT轴局部峰值45°，严重边长占比5.7926%，Q=92.9152。
  L=8：D=6.2269°，峰值45°，占比1.9530%，Q=95.0518。
  L=32：D=3.2822°，峰值45°，占比0.5348%，Q=97.4964。
  L=128：D=1.6644°，峰值45°，占比0.1370%，Q=99.0418。

严重边长占比这里使用>20°仅作诊断，不是质量合格阈值。长到L=128的矩形是数学压力测试，不代表真实房间分布。若p为两条斜边的总边长占比，本构造精确有D=45*sqrt(p*(1-p))，因为最佳自身轴还会旋转；实算与该式一致。

对L=2同一几何分别在正确长墙或错误斜边插40个精确共线点，D不变、Q最大变化4.3e-14。变更环起点或方向的Q最大变化1.4e-7，是固定数值积分相位，不伪称数学上逐位完全一致。

这证明RMS不能保证惩罚每个局部峰值，也证明现有实现没有按点数稀释。边长占比本身变小是否应仍让整份低分，是评价用途的取舍，不能从45°这个局部角度直接推出。建议保留最大局部方向残差及超额残差的真实边长作为解释，不用更多点数代替物理量。

五、对根线程有限加重方案的审查

只改0.15/0.30/0.45，以及对u=D/5、F/2设连续强度alpha(u)=0.15+0.30*clip((u-a)/(b-a),0,1)，再乘原有u²/(1+u²)，作为机制对照没有明显代数漏洞。a/b=1/3或2/4是研究设定，非已审核合格线；单调且连续，但它仍只看汇总RMS，不恢复局部分布。本目录没有运行或选取这些候选权重，由主实验保持统一登记。

尤其不能宣称“把有界损失移至局部再平均”必然更强。f(s)=s/(s+25)对s为凹函数，Jensen给E[f(d²)]<=f(E[d²])；它对本组异质残差反而更轻。L=2时汇总后有界损失0.8155，逐段后平均0.2585；L=128时分别0.09975和0.00150。若需要局部重大缺陷保护，不能仅改计算顺序后沿用旧尺度并宣称修复。

六、复算入口与边界

依赖见requirements.txt；Shapely本轮安装于本目录vendor_dependencies作为独立环境目录，不属于源输入。可在正常Python环境安装同版本后运行，无需带走该二进制目录。

  python audit_official_controls.py --engine /path/to/frozen_engine --out /new/path/official_results
  python audit_direction_dilution.py --engine /path/to/frozen_engine --out /new/path/direction_results

输出目录必须为空。默认球面2048、高度4096、F512；所有坐标与参考另存，不修形、不改GT或资格、不拟合人工分。两个脚本分别产生结果CSV、完整几何、详细分项与validation.json。控制仅为机制诊断，本目录新增独立真实图片0张。

七、补充的当前真实坐标探针与非正交参考自比

读取reference_scope/admission_run/current_input/current_data.json。该文件来自正式load_current_bundle()，3441对象；文件SHA256为027819d79d91f8de61277aa769a40216358a35d4e93235d5ad97af1f6ed811ed，order_update_revision=difficulty_orders_20261010_v1，quality_update_revision=quality_review_20261010_v1。没有直接把历史preprocessed_source当当前数据。

预先固定六张历史案例图，每图按object_id字典序取首份严格有效配对几何，未按质量或像素影响大小筛选。保留各自固定选定GT与原gate，仅作坐标诊断：
  e9z-17/R00240：直接喂原画布的3D IoU比同射线适配高0.00405438。
  x8-09/R00050：差0.00033813。
  UwV-09/R00064：差0.00037868。
  rPc-06/R00020：差0.00118824。
  uNb-54/R00102：差0.00073242。
  pRb-02/R00186：差0.00031728。

这里是IoU原始[0,1]单位，最大值相当于0.4054个百分点，不是0.4054的IoU。六例均正向不能推出所有样本都正向。相同射线转换与points−0.5的最大像素差1.14e-13；只改变x的半像素是共同yaw，IoU不变至浮点量；原始y数值直接调用则改变仰角、深度与高度。完整逐条表以real_pixel_results_with_ids/real_pixel_convention_six.csv为准。较早real_pixel_results是同6例未附R编号的保存稿，不增加样本计数。

另将当前固定x8-09人工修订GT R02762与自身比较：传统角点均高IoU=1，S与Hstar约0，而D=11.549362°、F=0.008526°，v1.1 Q=93.683667，差6.316333分全部来自自身规整项。D是本图汇总残差，不是某面墙的实测角度，不能据此写成“135°墙”。该自比是既有参考的诊断，不新增人员作答，也不恢复24份out_of_primary_scene和2份excluded资格。结果见reference_self_results/x8_09_current_reference_self.json。

补充命令：
  python audit_real_pixel_convention.py --current-input /path/current_data.json --aliases /path/aliases.json --engine /path/frozen_engine --out /new/path/pixel_probe
  python audit_nonorthogonal_reference_self.py --current-input /path/current_data.json --aliases /path/aliases.json --engine /path/frozen_engine --out /new/path/reference_self
  python make_figures.py

以上前两组共33个合成/契约控制、6份当前真实坐标诊断、1份当前GT自比；主数据分母不因此增加。这里没有读取主实验候选权重在留出组上的对照。下述追加的数值审计按几何风险预选，在登记选例后读取选中记录的默认Q；其中Uw-09来自validation，不能称为此前未看或独立盲测。

八、固定高度峰值、三种支撑宽度与采样密度

新增控制的固定底面为4h×2h矩形，周长P=12h；参考墙高2h。在底面一条直墙上增加一个三角形高度脉冲，峰值始终比参考高1h，支撑宽度分别为P/32、P/512和P/8192。底面完全相同；顶界折线包含真实局部错误，仍严格有效，不因不平顶排除。

在这一特殊同底面、平顶参考条件下，可以独立精确计算：

  Hmean = A*w/(2*P*h_GT)；
  Hlocal = (A/h_GT)*sqrt(w/(3P))。

这里A=1h、h_GT=2h；三个精确Hlocal为0.0510310363、0.0127577591、0.0031894398。峰值不变但物理支撑缩小，周长RMS本来就会下降；不能把所有高分解释成数值漏采，也不能直接把局部峰值转成整份必须低分的真值。

先运行两个既有角点作为循环起点、512/4096/32768三档采样，保存height_pulse_results。两个角点恰有对称采样相位。随后明确登记机制跟进：加入已有脉冲尖端作为第三个纯循环起点，没有新增几何或改参数。主对照以height_pulse_results_with_apex为准，共3种物理脉冲、9种输入表示、27个密度对照；较早6个表示是重复保存，不另加样本。

F的数值参照采用每条真实边单独64和128点Gauss积分，再拟合同一个水平顶高。它保留真实边长权重，64/128结果差均小于1e-8°。这只是机制诊断，并未替换正式F512。

  支撑P/32：F数值参照2.061950°，默认Q随起点约94.0122—94.0174。
  支撑P/512：F数值参照0.523336°，普通角点起点F512=0.619532°；尖端起点F512约0。
             同一连续几何Q从98.556542到99.209353，极差0.652811分。
  支撑P/8192：F数值参照0.130959°，F512在这几个相位都漏掉脉冲。
              尖端起点Hlocal4096=0，而精确值0.00318944；Hmean仍非零。
              默认Q约99.275—99.278。仅替换数值积分为精确H、逐边F，约99.2417。

固定峰值下，角点均高3D IoU在三种宽度均为0.933333，反映同样7个角点的计数均高；它没有使用真实脉冲占周长比例。这是既有角点计数缺陷的另一种呈现，不是v1.1新组成。

保留的失败：对于P/8192的尖端起点，32768样本仅覆盖脉冲4个样点，Hlocal相对误差3.1754%，未通过预先登记的2%数值误差检查；height_pulse_results_with_apex/validation.json因此明确为failed，8项检查中7项通过。不能删除该失败或把运行退出码1说成材料不可读。后续只对同3个最窄表示提高到131072，最大相对误差0.1955%，确认数值收敛，保存height_pulse_convergence_followup。该后续是针对已发现失败的数值诊断，不是盲测，也没有采用131072作为新正式参数。

当前默认Q没有静默修补。更强的固定规整系数会放大F数值波动；改变权重不能解决积分漏采。在现有粗分档用途下是否需要先替换积分器，应结合实际表示敏感性判断；以下小样本真实审计未发现重大影响，但不能保证所有潜在尖脉冲。

  python audit_height_pulse_sampling.py --engine /path/frozen_engine --out /new/path/pulse --cyclic-starts 0,2,6
  python audit_height_pulse_convergence.py --engine /path/frozen_engine --input-results /new/path/pulse --out /new/path/convergence
  python make_height_pulse_figure.py

第一个命令有意保留上述已知数值检查失败并以退出码1结束；CSV和详细结果仍完整生成。复现最早6表示保存稿则使用--cyclic-starts 0,6。

九、13图真实表示敏感性审计：有限负结果

这是发现合成相位问题后追加的针对性数值审计，不是新的参数选择。本次直接读取主运行投影对象projected_objects_3441.json和score_rows_3152.csv；选择阶段只保留身份、参考、准入和划分元数据，丢弃Q/人工分/其他候选分数。筛选score_status=available且conservative_fixed_gt_quality_candidate=True，共2003个候选。对标注与固定参考各自top3d/bottom3d四个环计算min_edge/perimeter，取四者最小值作为几何分辨率风险，升序、按图片去重取10图。该风险不意味着实际有误差。

预选的10份：
  R00732 / B6ByNegPMKs-47
  R00543 / q9vSo1VnCiC-30
  R01760 / 7y3sRwLe3Va-13
  R00299 / e9zR4mvMWw7-39
  R00550 / VFuaQ6m2Qom-04
  R00004 / VFuaQ6m2Qom-07
  R00219 / uNb9QFRL6hY-88
  R00153 / VFuaQ6m2Qom-10
  R00417 / q9vSo1VnCiC-11
  R00804 / 7y3sRwLe3Va-21

再加已被主线程点名的3个机制例：R01920/yqstnuAEVhm-32、R02075/x8F5xyUWy9e-09、R00064/UwV83HsGsw3-09。R02075保留out_of_primary_scene，仅诊断，不恢复正式资格。13图中12图development、1图validation（Uw-09）；前10图自然全部在development，不为获得好看结果人为平衡。

先落盘selection_frozen_before_Q.csv和experiment_design.json，之后才读取这13条默认Q以复核基线，始终不读取alpha30/alpha45/stage等候选列。对两条输入环分别试起点1、半周顶点、最大墙高顶点（去重），再同时旋转起点；在标注最短/最长底边及参考最短底边各精确线性插4点。环序仅循环，真实折线不改；原输入和所有表示另存。

实际结果133个表示均可算，原始Q复算与主运行最大差2.84e-14；纯循环起点相对原Q最大差0.00134511分，全表示极差最大0.00190983分；精确共线加点相对原Q最大差6.39e-14；跨95/85/50边界的表示0个。最大相位差来自R00543/q9vSo1VnCiC-30，原Q=53.78553。

因此，合成控制中的约0.65分相位影响没有在这批真实高分辨率风险例中出现；这是有用的负结果。但并未遍历全库每一种环起点、任意精细边段或接近分档边界的所有输入，不能宣称已经证明全库数值表示不变。主候选的最小min_edge/perimeter为0.00265573，最窄合成脉冲的物理边远短于此；两者的证据范围不同。

Uw-09/R00064当前固定修订GT为R02557，预测4对点、GT8对点；同几何2D IoU=0.1673724070、官方3D IoU=0.1654729209、默认Q=1.34348359。直接错误使用原像素的3D IoU只改变0.00037868，循环起点的Q最大差仅2.32e-6。因此其低分不是这两种数值约定造成，必须回到固定目标范围、位置及边界来解释。该计算不单独证明修订GT语义正确，也不据此修改GT。

完整材料在real_representation_results/，包含2003条无Q风险清单、预选表、133条分项、13条汇总、全部受控表示与原几何。复算：

  python audit_real_representation_sensitivity.py --engine /path/frozen_engine --projected /path/projected_objects_3441.json --score-table /path/score_rows_3152.csv --out /new/path/real_sensitivity

所有追加实验都不改变默认算法或正式输入。合成控制按不重复表示计20+13+9=42个；另有27个脉冲密度对照、3个高密度跟进，以及13份真实作答的133种表示。它们是机制/数值验证，不增加259张研究图的分母，也不替代本轮主质量或人员实验。

文献与代码来源

Cheng Sun, Min Sun, Hwann-Tzong Chen (2021). HoHoNet: 360 Indoor Holistic Understanding With Latent Horizontal Features. Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), pp.2573–2582.
出版方PDF：https://openaccess.thecvf.com/content/CVPR2021/papers/Sun_HoHoNet_360_Indoor_Holistic_Understanding_With_Latent_Horizontal_Features_CVPR_2021_paper.pdf
作者版HTML（本轮已读）：https://arxiv.org/html/2011.11498v3
作者版PDF：https://arxiv.org/pdf/2011.11498v3
官方代码：https://github.com/sunset1995/HoHoNet/tree/2bbc0866789cf7ad728064bc52aaf1d11b67c885

访问状态：CVF元数据及布局段落通过搜索缓存取得；直接打开CVF HTML/PDF返回403，作者PDF也未成功打开。作者版HTML正文与有关章节读取成功。未声称PDF已下载或完成PDF图像核验。精确引用与读取状态见citations.json，源码版本见source_manifest.json。
