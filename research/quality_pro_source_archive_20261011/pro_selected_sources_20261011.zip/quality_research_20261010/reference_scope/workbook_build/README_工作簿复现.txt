质量研究结果工作簿复现说明

本工作簿为已经运行结果的中文查阅快照，不在 Excel 内重新实现质量公式、不重新选择参数、不按人员得分排序。完整机器字段仍保留在配套 CSV/JSON。

来源
1. deliverables/tables/逐份质量结果_3152.csv
2. experiments/summaries/effective_denominators.csv、by_image_259.csv、by_building.csv
3. experiments/summaries/variant_summaries.csv、variant_deltas.csv、variant_bands.csv
4. worker_example/results/worker_common_image_summary.csv、common_image_summary.csv
5. reference_scope/admission_run/reference_binding_checks.json

source_manifest.json 记录上述实际字节的 SHA256。prepare_workbook_input.py 只做列选择、明确数值类型和少量中文显示名映射。工作簿人员页通过人员编号连接已经计算的全部/开发/留出结果；不重新选人或补图。

输出
deliverables/质量研究结果总表_20261011.xlsx
7 张工作表：概览、逐份分数、按图片、按建筑、共同图片人员、方案对照、参考与分母。
逐份表 3152 行、42 个关键字段；按图片 259 行；按建筑按原来源保留 27 个建筑×用途行，对应 22 个建筑；共同图片人员 24 行。
逐份表末尾 AO/AP 分别为主比较研究档位、诊断研究档位，直接采用根逐份 CSV 中冻结的 95/85/50 档位，不在工作簿重新计算。不可评价与不纳入主比较分别保留，档位不是合格线。

数值规则
所有质量、IoU、角度、计数、频率均为数值单元格。TRUE/FALSE 是布尔值。缺失值保留为空。主比较 Q 有效 2003，数学诊断 Q 有效 3021，131 份完整 Q 不可算。主比较与目标一致的质量候选/独立人员候选分列，未以坐标修复或数学可算覆盖原资格。

构建工具
使用 @oai/artifact-tool JS 与 CODEX_PRIMARY_RUNTIME_NODE。未使用 openpyxl、xlsxwriter 或 pandas.ExcelWriter。
先用 CODEX_PRIMARY_RUNTIME_PYTHON 运行 prepare_workbook_input.py。
在一个可写的 OS 临时目录内，将 node_modules 链接到 CODEX_PRIMARY_RUNTIME_NODE_MODULES，将 build_quality_workbook.mjs 放在该临时目录运行。通过 QUALITY_RESEARCH_ROOT 指定当前研究输出根目录，即包含 deliverables、experiments、worker_example 的目录。源脚本中默认路径为此次运行目录，异机复现时应设置该变量。
中文字体使用现有 report_assets/fonts/NotoSansSC.ttf，字体族名 Noto Sans SC。将该字体注册到生成环境的 fontconfig 可解决中文渲染环境缺少字形的问题。未修改任何原始研究图、GT、作答、资格或历史结果。

验证
1. artifact-tool recalculate 后 inspect 关键范围，扫描 Excel 错误标记。
2. 逐张渲染全部 7 张工作表；大表取首屏关键区域，人员页另看共同图片组成，参考页另看绑定清单。
3. verify_saved_workbook.py 只用 zipfile 与 XML 标准库读取导出文件，将 138207 个冻结数据单元格与选定来源逐格比较，并核验布尔/数值类型、空值、错误单元格和冻结窗格。
4. build_verification.json、artifact_inspection.json、saved_workbook_validation.json、visual_review.json 为验证记录。

此工作簿未在桌面 Excel 应用中打开运行；它是静态结果查阅快照，核心评分的可复算代码与控制实验在主研究交付中。

追加档位的窄修改使用同一构建脚本的 --append-bands 模式：导入已有工作簿，先核对既有 40 列数据未变，仅扩展 Scores3152 表的 AO/AP 两列与概览/逐份表说明，不重建其它工作表。完整新建时不传该参数即可。
