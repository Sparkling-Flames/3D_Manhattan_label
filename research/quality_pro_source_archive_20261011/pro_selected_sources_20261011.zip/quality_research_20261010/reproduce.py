#!/usr/bin/env python3
"""Portable entry points. Recomputed files always go to a new output folder."""
from __future__ import annotations
import argparse
import csv
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / "repo/research/quality_scope_comparison_20261010/frozen_engine"
CONFIG = ROOT / "experiments/preregistered_candidates.json"
CURRENT = ROOT / "reference_scope/admission_run/current_input/current_data.json"
ADMISSION = ROOT / "reference_scope/admission_run/admission_3152.csv"
SAVED_SCORES = ROOT / "experiments/fixed_run/score_rows_3152.csv"


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def run(script, *args, allowed=(0,)):
    command = [sys.executable, str(ROOT / script), *map(str, args)]
    p = subprocess.run(command, cwd=ROOT)
    if p.returncode not in allowed:
        raise SystemExit(p.returncode)
    return {"script": script, "returncode": p.returncode, "allowed_returncodes": list(allowed)}


def verify_copies():
    manifest = json.loads((ROOT / "provenance/source_copy_manifest.json").read_text())
    for row in manifest["files"]:
        p = ROOT / row["bundle_path"]
        assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == row["copied_sha256"], row["bundle_path"]
    assert not any(p.is_symlink() for p in ROOT.rglob("*"))
    return {"byte_identical_source_copies_checked": len(manifest["files"]), "symbolic_links": 0}


def smoke(out):
    from verify_effective_input import verify
    integrity = verify_copies()
    effective = verify()
    sys.path.insert(0, str(ROOT / "experiments"))
    sys.path.insert(0, str(ROOT / "official_audit"))
    import run_quality as quality
    from audit_official_controls import verify_official_sources
    official_manifest = verify_official_sources()
    config = json.loads(CONFIG.read_text())
    data = json.loads(CURRENT.read_text())
    objects = {o["object_id"]: o for o in data["objects"]}
    with ADMISSION.open(encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    with SAVED_SCORES.open(encoding="utf-8-sig") as f:
        saved = {r["record_id"]: r for r in csv.DictReader(f)}
    # Fixed identifiers test current projection, valid scoring, an unavailable
    # canvas record, and too few pairs; no quality-based sample selection.
    smoke_ids = {"R00064", "R01424", "R01879", "R02075"}
    chosen = [r for r in rows if r["record_id"] in smoke_ids]
    assert len(chosen) == 4
    quality.init_worker(str(ENGINE), str(ROOT / "official_audit"), None, config)
    comparisons = []
    score_columns = ["Q_v11", "Q_alpha30", "Q_alpha45", "Q_stage13", "Q_stage24", "iou_2d", "iou_3d_corner_mean"]
    for row in chosen:
        a, am = quality.project_object(objects[row["object_id"]])
        g, gm = quality.project_object(objects[row["selected_gt_object_id"]])
        new, _ = quality.job((row, a, g, am, gm))
        old = saved[row["record_id"]]
        assert new["score_status"] == old["score_status"]
        differences = {}
        for key in score_columns:
            ov = None if old[key] == "" else float(old[key])
            nv = new[key]
            assert (ov is None) == (nv is None), (row["record_id"], key)
            if nv is not None:
                differences[key] = abs(nv - ov)
                assert differences[key] < 1e-8, (row["record_id"], key, nv, ov)
        comparisons.append({"record_id": row["record_id"], "status": new["score_status"],
                            "maximum_score_component_delta": max(differences.values(), default=0),
                            "projection_reasons": new["annotation_projection_reasons"]})
    save(out / "effective_input_recheck.json", effective)
    save(out / "four_record_scoring_smoke.json", comparisons)
    run("experiments/target_protocol/target_protocol.py", "--engine", ENGINE, "--config", CONFIG,
        "--input", ROOT / "experiments/target_protocol/results/fixtures/04_same_small_legacy.json", "--out", out / "legacy_protocol.json")
    workers(out / "workers", SAVED_SCORES)
    versions = {name: importlib.metadata.version(name) for name in ["numpy", "scipy", "shapely", "pandas"]}
    result = {"status": "passed", "scope": "portable paths, input/gate/group checks, four scores, legacy target, worker replay",
              "quality_full_3152_rerun": False, "source_loader_rerun": False, "integrity": integrity,
              "official_source_commit": official_manifest["commit"], "runtime_packages": versions,
              "known_numerical_failure_preserved": "official_audit/height_pulse_results_with_apex/validation.json",
              "nonorthogonal_reference_self_penalty_preserved": "official_audit/reference_self_results/x8_09_current_reference_self.json",
              "all_quality_assumptions_validated": False}
    save(out / "smoke_summary.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def workers(out, scores):
    return run("worker_example/analyze_workers.py", "--admission", ADMISSION, "--scores", scores,
               "--panel-dir", ROOT / "worker_example/preregistered", "--config", ROOT / "worker_example/worker_analysis_config_units_corrected.json",
               "--out", out)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("task", choices=["verify", "smoke", "quality", "controls", "workers", "summaries", "scope", "official", "numerical"])
    ap.add_argument("--out", type=Path, required=True, help="new folder; existing outputs are never overwritten")
    ap.add_argument("--processes", type=int, default=4)
    ap.add_argument("--scores", type=Path, default=SAVED_SCORES)
    a = ap.parse_args()
    a.scores = a.scores.resolve()
    out = a.out.resolve()
    if out.exists():
        raise FileExistsError("Choose a new --out directory")
    out.mkdir(parents=True)
    if a.task == "verify":
        from verify_effective_input import verify
        result = {**verify(), **verify_copies()}
        save(out / "verification.json", result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif a.task == "smoke":
        smoke(out)
    elif a.task == "quality":
        from verify_effective_input import verify
        save(out / "effective_input_recheck.json", verify())
        run("experiments/run_quality.py", "--current-data", CURRENT, "--admission", ADMISSION,
            "--engine", ENGINE, "--official-dir", ROOT / "official_audit", "--config", CONFIG,
            "--out", out / "fixed_run", "--processes", a.processes)
    elif a.task == "workers":
        workers(out / "worker_results", a.scores)
    elif a.task == "summaries":
        run("experiments/summarize_quality.py", "--scores", a.scores, "--out", out / "summaries")
        run("experiments/summarize_policies_and_metrics.py", "--scores", a.scores, "--out", out / "summaries")
        run("experiments/reporting_status.py", "--scores", a.scores, "--out", out / "tables")
    elif a.task == "controls":
        run("experiments/controlled_variants.py", "--engine", ENGINE, "--config", CONFIG, "--out", out / "objective")
        run("experiments/multitarget_controls.py", "--engine", ENGINE, "--config", CONFIG, "--out", out / "multitarget")
        run("experiments/target_protocol/run_protocol_controls.py", "--engine", ENGINE, "--config", CONFIG,
            "--registry", ROOT / "reference_scope/bev_replay/reference_registry.json", "--out", out / "target_protocol")
    elif a.task == "scope":
        run("scope_integration/recompute_bev.py", "--inputs", ROOT / "scope_integration/inputs", "--out", out / "bev")
        run("reference_scope/compare_scope_geometry.py", "--scope-integration", ROOT / "scope_integration",
            "--admission", ROOT / "reference_scope/admission_run/admission_3152.json", "--out", out / "boundary_comparison")
    elif a.task == "official":
        run("official_audit/audit_official_controls.py", "--engine", ENGINE, "--out", out / "official_controls")
        run("official_audit/audit_direction_dilution.py", "--engine", ENGINE, "--out", out / "direction")
    elif a.task == "numerical":
        # The known 2% tolerance failure must remain visible, even when its
        # process returns 1. A successfully detected counterexample is not a
        # claim that the original numerical method passed the quality test.
        call = run("official_audit/audit_height_pulse_sampling.py", "--engine", ENGINE,
                   "--out", out / "pulse", "--cyclic-starts", "0,2,6", allowed=(0, 1))
        validation = json.loads((out / "pulse/validation.json").read_text())
        save(out / "preserved_pulse_exit_status.json", {**call, "numerical_validation_status": validation["status"],
                                                       "not_an_all_tests_passed_claim": True})
        run("official_audit/audit_height_pulse_convergence.py", "--engine", ENGINE,
            "--input-results", out / "pulse", "--out", out / "convergence")


if __name__ == "__main__":
    main()
