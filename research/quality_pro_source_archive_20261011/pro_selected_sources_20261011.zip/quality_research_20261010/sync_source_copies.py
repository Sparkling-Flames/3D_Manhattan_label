#!/usr/bin/env python3
"""Packaging-only: explicitly refresh named copies after an artifact correction.

Never edits sources. Old and new hashes are retained in delivery_update_log.
The effective input, frozen engine and primary score table are protected.
"""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-root", type=Path, required=True)
    ap.add_argument("--paths", nargs="+", required=True, help="exact bundle paths or directory prefixes")
    ap.add_argument("--reason", required=True)
    a = ap.parse_args()
    manifest_path = ROOT / "provenance/source_copy_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    updates = []
    protected = ["reference_scope/admission_run/current_input/", "repo/research/quality_scope_comparison_20261010/frozen_engine/",
                 "experiments/fixed_run/", "reference_scope/admission_run/admission_3152."]
    for row in manifest["files"]:
        rel = row["bundle_path"]
        if not any(rel == p or rel.startswith(p.rstrip("/") + "/") for p in a.paths):
            continue
        if any(rel.startswith(p) for p in protected):
            raise ValueError("Protected research input or results cannot be refreshed: " + rel)
        source = a.source_root / row["source_relative_path"]
        dest = ROOT / rel
        raw = source.read_bytes()
        new_hash = hashlib.sha256(raw).hexdigest()
        if new_hash == row["copied_sha256"]:
            continue
        old_hash = hashlib.sha256(dest.read_bytes()).hexdigest()
        assert old_hash == row["copied_sha256"], rel
        shutil.copy2(source, dest)
        assert hashlib.sha256(dest.read_bytes()).hexdigest() == new_hash, rel
        updates.append({"bundle_path": rel, "old_copy_sha256": old_hash, "new_source_and_copy_sha256": new_hash,
                        "source_relative_path": row["source_relative_path"], "reason": a.reason})
        row.update(source_sha256=new_hash, copied_sha256=new_hash, copy_is_byte_identical=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    logpath = ROOT / "provenance/delivery_update_log.json"
    log = json.loads(logpath.read_text()) if logpath.exists() else {"events": []}
    log["events"].append({"utc": dt.datetime.now(dt.timezone.utc).isoformat(), "updates": updates,
                          "source_data_modified": False})
    logpath.write_text(json.dumps(log, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"updated": len(updates), "paths": [x["bundle_path"] for x in updates]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
