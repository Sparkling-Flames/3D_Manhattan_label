#!/usr/bin/env python3
"""Recheck the delivered effective snapshot, not the upstream loader pipeline."""
from __future__ import annotations
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "reference_scope"))
from reference_policy import ReferencePolicy, assess_annotation, selected_reference_id
from build_admission import metadata_groups, digest_sorted


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def verify(root=ROOT):
    current = root / "reference_scope/admission_run/current_input"
    data = read(current / "current_data.json")
    aliases = read(current / "aliases.json")["records"]
    rows = read(root / "reference_scope/admission_run/admission_3152.json")
    objects = {o["object_id"]: o for o in data["objects"]}
    images = {im["image_id"]: im for im in data["images"]}
    registry = read(root / "repo/research/quality_next_stage_handoff_20261010/reference_exclusion_registry_20261010.json")
    scope = read(root / "scope_integration/results/reference_registry.json")["records"]
    scopes = {s["image_id"]: s for s in scope}
    subset = read(root / "scope_integration/inputs/current_formal_subset.json")
    assert len(objects) == 3441 and len(rows) == 3152 and len(scope) == 35
    assert {oid: digest_sorted(obj) for oid, obj in objects.items()} == subset["all_formal_object_digests"]
    assert all(s["is_primary"] and s["top_boundary_pending"] and not s["reference_ready"] for s in scope)
    with (root / "repo/analysis_results/objective_difficulty_20261009/structure_classification/images.csv").open(encoding="utf-8-sig") as f:
        selected = {r["image_id"]: r["gt_object_id"] for r in csv.DictReader(f)}
    policy = ReferencePolicy(registry)
    bound = policy.validate_objects(data)
    groups = {r["image_id"]: r for r in metadata_groups(data["images"])}
    assert len(groups) == 259
    group_splits = {}
    for g in groups.values():
        group_splits.setdefault(g["group_key"], set()).add(g["group_split"])
    assert all(len(v) == 1 for v in group_splits.values())
    compared = 0
    for r in rows:
        obj = objects[r["object_id"]]
        im = images[obj["image_id"]]
        rid = selected[im["image_id"]]
        assert rid == r["selected_gt_object_id"] == selected_reference_id(im)
        assert aliases[obj["object_id"]] == r["record_id"]
        assert digest_sorted(obj) == r["current_formal_object_sha256"]
        actual = assess_annotation(obj, im, objects[rid], policy, scopes.get(im["image_id"]))
        for key, value in actual.items():
            assert value == r[key], (r["record_id"], key, value, r[key])
            compared += 1
        for key, value in groups[im["image_id"]].items():
            assert value == r[key], (r["record_id"], key, value, r[key])
    flags = ["registry_minimum_quality_candidate", "conservative_fixed_gt_quality_candidate",
             "target_aligned_quality_candidate", "conservative_fixed_gt_primary_candidate",
             "target_aligned_primary_candidate"]
    return {"status": "passed", "verification_type": "effective_snapshot_policy_and_group_recheck",
            "upstream_loader_executed_in_this_check": False, "raw_source_files_reloaded": False,
            "objects": len(objects), "annotations": len(rows), "research_images": len(groups),
            "reference_registry_bindings_checked": len(bound), "annotation_policy_fields_compared": compared,
            "frozen_object_digests_all_match": True, "fixed_reference_choices_all_match": True,
            "no_group_crosses_split": True, "groups": len(group_splits),
            "images_by_split": dict(Counter(g["group_split"] for g in groups.values())),
            "candidate_denominators_before_method_availability": {k: sum(r[k] for r in rows) for k in flags},
            "floor_only_records": len(scope), "full_new_target_references": 0,
            "inputs_mutated": False}


if __name__ == "__main__":
    print(json.dumps(verify(), ensure_ascii=False, indent=2))
