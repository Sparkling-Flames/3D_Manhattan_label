人员质量最小分析示例

目的
在相同manual任务、同一组参与者和共同图片上描述质量水平、跨图波动及留出表现。Q仍由固定几何/参考/规则生成，人员身份仅用于汇总。这里不拟合Q、不固定人员类别、不开发融合、不恢复原资格。

文件
- PRE_OUTCOME_PROTOCOL.md：读分数前的设计约束。
- register_panel.py 与 preregistered/：只读元数据选择26人×29图原始共同任务池，以及24人×11图有资格完整面板；同时保存房间/建筑划分。
- worker_analysis_config_units_corrected.json：候选列名、事件阈值、唯一划分seed与统计规则；初始worker_analysis_config.json保留，单位文字修正见VERSION_NOTES.txt。
- analyze_workers.py：读取当前loader/reference policy准入表和本轮评分表，生成逐人统计与留出结果。
- check_transfer_invariants.py 与 transfer_invariance_checks.json：小型机制检查，防止held结果进入训练预测以及缺失值偷偷重选。
- render_worker_summary.py：依据实际输出生成中文报告和可导出科学图，不重新选择面板或公式。

准入
conservative_fixed_gt_primary_candidate用于人员主面板，明确要求独立性；不能换成quality-only候选，因为后者可能包含借点等非独立作答。另检查registry_annotator_exclude。target_aligned_primary_candidate只从同一固定名单去除已改primary地面但top_pending的两张rPc图，作为参考政策敏感性。

计数与限制
预登记初始11图264条；当前loader逐条核对后保持不变，target-aligned为9图216条。实际Q可算分母以results中的运行表为准。旧原始26人×29图754条任务池另外保留资格/hold/排除计数，防止将完整有效面板均值误称为所有作答可靠率。没有可据以确认的独立同图重测对；12个原始重复组是历史版本，最多一个当前有资格记录。

留出
以注册room_id为组；一个建筑有任何研究视角room缺失时，整个建筑合为一组。sha256('quality-next-stage-20261011|'+group_key)前8hex整数mod3为0时validation，其余development。整259图和人员预登记的分组分别执行并核对一致。11图固定面板恰只有UwV83HsGsw3-09一张validation图；它是历史开发图，因此不能叫新独立盲测。逐组留出只用于同一批历史数据的补充描述，不改Q、不把重叠折当独立新增样本。

阈值
Q<50是历史低分研究线；Q<40/60只是频率敏感性。IoU<0.5、S>8°、Hstar>1是明确的人为大偏差口径，分别报告。它们不是经过人工认证的严重错误/合格标签。不可算和不纳入都不填0、不合并到低分率。

复算（路径按完整交付包实际根目录调整）
python analyze_workers.py --admission ../reference_scope/admission_run/admission_3152.csv --scores ../experiments/fixed_run/score_rows_3152.csv --panel-dir preregistered --config worker_analysis_config_units_corrected.json --out ../worker_replay
python render_worker_summary.py --results ../worker_replay --out ../worker_replay_report
python check_transfer_invariants.py --out ../worker_transfer_checks.json

依赖
Python 3、NumPy、pandas、SciPy；报告图片另需matplotlib。与主任务同环境即可，不安装复杂人员模型。输出目录必须为新目录；输入与分数文件hash在运行开始和结束核验。

实际运行边界
首轮results与最终results_final均保留。11图主面板263/264可算，R01424/W002/rPc-22坐标超出画布，因此11图的平衡留出预测按预设保护停止。9图target_aligned面板216/216可算，运行了固定留出和8组逐一留出；没有用缺失来重选图或人。最终报告与图在report_final。
