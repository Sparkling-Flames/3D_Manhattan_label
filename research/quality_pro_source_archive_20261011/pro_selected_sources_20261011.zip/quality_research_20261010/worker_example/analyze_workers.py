#!/usr/bin/env python3
"""A small, outcome-blind-selected common-image personnel analysis.

This script consumes current run scores. It does not fit a quality formula,
change eligibility, infer intent, or produce fixed worker classes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr


POLICIES = ["conservative_fixed_gt_primary_candidate", "target_aligned_primary_candidate"]
EVENTS = {
    "Q_lt40_sensitivity": ("baseline", "lt", 40.0),
    "Q_lt50_historical_low_band": ("baseline", "lt", 50.0),
    "Q_lt60_sensitivity": ("baseline", "lt", 60.0),
    "BEV_IoU_lt0p5": ("IoU", "lt", 0.5),
    "S_gt8deg": ("S", "gt", 8.0),
    "Hstar_gt1": ("Hstar", "gt", 1.0),
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def boolean(series: pd.Series) -> pd.Series:
    values = series.astype(str).str.lower()
    if not values.isin(["true", "false", "1", "0"]).all():
        raise ValueError("Non-boolean policy field: " + str(series.name))
    return values.isin(["true", "1"])


def finite(series: pd.Series) -> pd.Series:
    return np.isfinite(pd.to_numeric(series, errors="coerce"))


def jsonsafe(x):
    if isinstance(x, dict):
        return {str(k): jsonsafe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [jsonsafe(v) for v in x]
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating, float)):
        return float(x) if math.isfinite(x) else None
    if isinstance(x, np.bool_):
        return bool(x)
    return x


def corr(a, b, kind="spearman") -> float:
    a, b = np.asarray(a, float), np.asarray(b, float)
    valid = np.isfinite(a) & np.isfinite(b)
    if valid.sum() < 3 or np.ptp(a[valid]) == 0 or np.ptp(b[valid]) == 0:
        return math.nan
    fn = spearmanr if kind == "spearman" else pearsonr
    return float(fn(a[valid], b[valid]).statistic)


def events(rows: pd.DataFrame, fields: dict) -> dict:
    out = {}
    for event, (source, op, cutoff) in EVENTS.items():
        arr = pd.to_numeric(rows[fields[source]], errors="coerce")
        good = np.isfinite(arr)
        hits = (arr < cutoff) if op == "lt" else (arr > cutoff)
        n, k = int(good.sum()), int((hits & good).sum())
        out[event + "_n"] = n
        out[event + "_count"] = k
        out[event + "_rate"] = k / n if n else math.nan
    return out


def summary_row(rows: pd.DataFrame, q: str) -> dict:
    vals = pd.to_numeric(rows[q], errors="coerce")
    ok = np.isfinite(vals)
    good = rows[ok].copy()
    good[q] = vals[ok]
    by_group = good.groupby("group_key")[q].mean()
    return dict(n_records=len(rows), n_finite=int(ok.sum()), n_noncalculable=int((~ok).sum()),
                n_images=rows.image_id.nunique(), n_groups=rows.group_key.nunique(),
                n_buildings=rows.building_id.nunique(),
                mean_Q=vals[ok].mean(), median_Q=vals[ok].median(),
                across_image_SD=vals[ok].std(ddof=1),
                min_Q=vals[ok].min(), max_Q=vals[ok].max(),
                Q25=vals[ok].quantile(.25), Q75=vals[ok].quantile(.75),
                equal_group_mean_Q=by_group.mean(),
                across_group_SD=by_group.std(ddof=1))


def transfer(rows: pd.DataFrame, q: str, policy: str, fold_type: str):
    """Equal-group means: an elementary personnel prediction, never a Q fit."""
    if not finite(rows[q]).all():
        return [], [], "missing_Q_kept_no_complete_case_panel_reselection"
    mat = rows.pivot_table(index="worker_id", columns="group_key", values=q, aggfunc="mean")
    if mat.isna().any().any():
        return [], [], "incomplete_person_by_group_panel"
    split_by_group = rows.groupby("group_key").split.first().to_dict()
    if fold_type == "fixed_split":
        folds = [("fixed_validation", [g for g in mat if split_by_group[g] == "validation"])]
    else:
        folds = [(g, [g]) for g in sorted(mat)]
    fold_rows, detail_rows = [], []
    for fold, held in folds:
        train = [g for g in mat if g not in held]
        if not held or not train:
            continue
        pred = mat[train].mean(axis=1)
        actual = mat[held].mean(axis=1)
        constant = float(mat[train].mean(axis=0).mean())
        n = len(mat)
        # Each worker's offset is relative to the other workers, not to itself.
        pred_rel = pred - (pred.sum() - pred) / (n - 1)
        actual_rel = actual - (actual.sum() - actual) / (n - 1)
        person_err = pred - actual
        constant_err = constant - actual
        rel_err = pred_rel - actual_rel
        held_images = sorted(rows.loc[rows.group_key.isin(held), "image_code"].unique())
        fold_rows.append(dict(policy=policy, method=q, fold_type=fold_type, fold_id=fold,
            n_workers=n, training_groups=len(train), held_groups=len(held),
            training_images=rows.loc[rows.group_key.isin(train), "image_id"].nunique(),
            held_images=len(held_images), held_image_codes=json.dumps(held_images),
            pearson=corr(pred, actual, "pearson"), spearman=corr(pred, actual),
            person_mean_MAE=float(abs(person_err).mean()),
            constant_mean_MAE=float(abs(constant_err).mean()),
            person_mean_RMSE=float(np.sqrt((person_err ** 2).mean())),
            constant_mean_RMSE=float(np.sqrt((constant_err ** 2).mean())),
            person_gain_MAE=float(abs(constant_err).mean() - abs(person_err).mean()),
            relative_offset_MAE=float(abs(rel_err).mean()),
            relative_zero_baseline_MAE=float(abs(actual_rel).mean()),
            relative_gain_MAE=float(abs(actual_rel).mean() - abs(rel_err).mean()),
            held_grand_mean=float(actual.mean()), training_grand_mean=constant,
            interpretation=("historical_data_personnel_transfer_not_new_blind_validation" if fold_type == "fixed_split"
                            else "overlapping_folds_descriptive_not_independent_new_samples")))
        for w in mat.index:
            detail_rows.append(dict(policy=policy, method=q, fold_type=fold_type, fold_id=fold,
                                    worker_id=w, predicted_Q=pred[w], observed_Q=actual[w],
                                    constant_Q=constant, predicted_relative=pred_rel[w],
                                    observed_relative=actual_rel[w],
                                    absolute_error=abs(person_err[w]), constant_absolute_error=abs(constant_err[w]),
                                    relative_absolute_error=abs(rel_err[w]),
                                    relative_zero_absolute_error=abs(actual_rel[w])))
    return fold_rows, detail_rows, "computed"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--admission", required=True, type=Path)
    ap.add_argument("--scores", required=True, type=Path)
    ap.add_argument("--panel-dir", required=True, type=Path)
    ap.add_argument("--config", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise FileExistsError("Use a new output directory")
    args.out.mkdir(parents=True, exist_ok=True)
    config = json.loads(args.config.read_text())
    fields = config["score_fields"]
    qcols = config["q_methods"]
    assert fields["baseline"] in qcols
    files = [args.admission, args.scores, args.config,
             args.panel_dir / "initial_panel_records_264.csv",
             args.panel_dir / "image_split_259.csv", args.panel_dir / "panel_preregistration.json"]
    start_hashes = {str(p.resolve()): sha(p) for p in files}
    adm = pd.read_csv(args.admission, dtype=str, keep_default_na=False)
    score = pd.read_csv(args.scores, dtype=str, keep_default_na=False)
    key = config.get("join_key", "object_id")
    assert len(adm) == 3152 and adm[key].is_unique
    assert len(score) == 3152 and score[key].is_unique
    assert set(adm[key]) == set(score[key])
    diagnostic_cols = [c for c in ["score_status", "annotation_projection_status", "reference_projection_status",
        "annotation_projection_reasons", "reference_projection_reasons", "annotation_valid_2d", "annotation_valid_3d",
        "reference_valid_2d", "reference_valid_3d", "failure_classes", "reason_codes", "annotation_reason_codes",
        "reference_reason_codes", "traditional_reason_codes"] if c in score and c not in adm]
    score_cols = list(dict.fromkeys([key] + list(fields.values()) + qcols + diagnostic_cols))
    for c in score_cols:
        if c not in score:
            raise ValueError("Missing score column: " + c)
    if set(score_cols[1:]) & set(adm.columns):
        raise ValueError("Ambiguous pre-existing score columns in admission")
    data = adm.merge(score[score_cols], on=key, how="left", validate="one_to_one")
    split = pd.read_csv(args.panel_dir / "image_split_259.csv", dtype=str, keep_default_na=False)
    for col in ["group_key", "split"]:
        if col in data:
            check = data.merge(split[["image_id", col]], on="image_id", suffixes=("", "_registered"), validate="many_to_one")
            assert (check[col] == check[col + "_registered"]).all(), col + " drift"
        else:
            data = data.merge(split[["image_id", col]], on="image_id", validate="many_to_one")
    for c in list(dict.fromkeys(list(fields.values()) + qcols)):
        data[c] = pd.to_numeric(data[c], errors="coerce")
    for policy in POLICIES:
        data[policy] = boolean(data[policy])
    if "registry_annotator_exclude" not in data:
        raise ValueError("Explicit annotator-reference exclusion is required")
    data["registry_annotator_exclude"] = boolean(data["registry_annotator_exclude"])
    for policy in POLICIES:
        if (data[policy] & data.registry_annotator_exclude).any():
            raise ValueError("Comparison policy conflicts with annotator exclusion")
    initial = pd.read_csv(args.panel_dir / "initial_panel_records_264.csv", dtype=str, keep_default_na=False)
    pre = json.loads((args.panel_dir / "panel_preregistration.json").read_text())
    assert len(initial) == 264 and initial.object_id.is_unique
    panel = initial[["object_id", "worker_id", "image_id", "condition"]].merge(
        data, on="object_id", how="left", suffixes=("_preregistered", ""), validate="one_to_one")
    for c in ["worker_id", "image_id", "condition"]:
        assert (panel[c] == panel[c + "_preregistered"]).all(), c + " drift"
    assert set(panel.worker_id) == set(pre["selected_worker_ids"])
    assert panel.groupby(["worker_id", "image_id", "condition"]).size().max() == 1
    roster = sorted(panel.worker_id.unique())
    status_cols = [c for c in ["object_id", "record_id", "worker_id", "image_id", "image_code", "condition",
                               "building_id", "room_id", "group_key", "split", "cleaning_disposition",
                               "worker_quality_gate", "registry_annotator_exclude", "scope_primary_floor_changed",
                               "scope_top_pending", "reference_policy_reasons", "formal_eligibility_reasons",
                               "source_main_commit", "formal_input_commit", "input_revision", "current_coordinates_sha256",
                               "selected_gt_object_id", "selected_gt_version", "selected_gt_coordinates_sha256",
                               "scope_reference_id", "scope_floor_sha256", "scope_top_boundary_status",
                               "all_research_exclusion_reasons", "target_aligned_exclusion_reason"] if c in panel] + diagnostic_cols
    panel[status_cols + POLICIES + list(dict.fromkeys(qcols + list(fields.values())))].to_csv(
        args.out / "fixed_panel_264_all_statuses_and_scores.csv", index=False, encoding="utf-8-sig")
    panel.loc[~finite(panel[fields["baseline"]]), status_cols + POLICIES + qcols].to_csv(
        args.out / "panel_noncalculable_records.csv", index=False, encoding="utf-8-sig")

    # Preserve the equal-assignment denominator before the complete eligible
    # panel was selected. Exclusions/holds are not quality failures or zero Q.
    raw_pool_ids = set(split.loc[boolean(split.in_maximum_coverage_pool), "image_id"])
    raw_common = data[(data.condition == "manual") & data.image_id.isin(raw_pool_ids)].copy()
    assert len(raw_common) == 29 * 26 and raw_common.worker_id.nunique() == 26
    assert (raw_common.groupby("worker_id").image_id.nunique() == 29).all()
    raw_common[status_cols + POLICIES + list(dict.fromkeys(qcols + list(fields.values())))].to_csv(
        args.out / "raw_common_task_pool_754_records.csv", index=False, encoding="utf-8-sig")
    raw_common_denominators = []
    for policy in POLICIES:
        for w, wrs in raw_common.groupby("worker_id"):
            ok = wrs[wrs[policy]]
            raw_common_denominators.append(dict(policy=policy, worker_id=w,
                common_assigned_images=wrs.image_id.nunique(), raw_records=len(wrs),
                policy_candidate_records=len(ok), finite_Q_on_policy_candidates=int(finite(ok[fields["baseline"]]).sum()),
                noncalculable_on_policy_candidates=int((~finite(ok[fields["baseline"]])).sum()),
                cleaning_retained_count=int((wrs.cleaning_disposition == "retained").sum()),
                historical_not_accepted_count=int((wrs.cleaning_disposition == "historical_not_accepted").sum()),
                excluded_by_review_count=int((wrs.cleaning_disposition == "excluded_by_review").sum()),
                quality_gate_counts=json.dumps(wrs.worker_quality_gate.value_counts().to_dict(),ensure_ascii=False),
                cleaning_counts=json.dumps(wrs.cleaning_disposition.value_counts().to_dict(),ensure_ascii=False),
                interpretation="equal_assignment_pool; exclusions_and_holds_are_not_scored_zero; no_unmatched_ranking"))
    pd.DataFrame(raw_common_denominators).to_csv(args.out/"raw_common_task_pool_worker_denominators_26.csv",index=False,encoding="utf-8-sig")

    inventory_rows, person_rows, image_rows, method_rows, fold_rows, pred_rows = [], [], [], [], [], []
    panel_counts, transfer_status = {}, []
    for policy in POLICIES:
        # Raw condition-specific summaries are explicitly not matched comparisons.
        for (w, condition), wrs in data.groupby(["worker_id", "condition"], sort=True):
            accepted = wrs[wrs[policy]]
            inventory_rows.append(dict(policy=policy, worker_id=w, condition=condition,
                raw_records=len(wrs), raw_images=wrs.image_id.nunique(),
                policy_candidate_records=len(accepted), policy_excluded_records=len(wrs)-len(accepted),
                raw_gate_counts=json.dumps(wrs.worker_quality_gate.value_counts().to_dict(), ensure_ascii=False),
                comparison_status="unmatched_task_mix_descriptive_only",
                **summary_row(accepted, fields["baseline"]), **events(accepted, fields)))
        ps = panel[panel[policy]].copy()
        by_image = ps.groupby("image_id").worker_id.nunique()
        if len(by_image) and not (by_image == len(roster)).all():
            raise ValueError("Current qualification broke a preregistered common-image panel; do not silently reselect")
        if ps.groupby(["worker_id", "image_id", "condition"]).size().max() != 1:
            raise ValueError("Current repeated records are not independent units")
        panel_counts[policy] = dict(n_people=len(roster), n_records=len(ps), n_images=ps.image_id.nunique(),
            n_groups=ps.group_key.nunique(), n_buildings=ps.building_id.nunique(),
            n_finite_v11=int(finite(ps[fields["baseline"]]).sum()),
            splits=ps.groupby("split").agg(records=("object_id", "size"), images=("image_id", "nunique"), groups=("group_key", "nunique")).to_dict("index"),
            image_codes=sorted(ps.image_code.unique()),
            excluded_initial_image_codes=sorted(set(panel.image_code)-set(ps.image_code)),
            partial_image_qualification=False)
        for w in roster:
            wrs = ps[ps.worker_id == w]
            person_rows.append(dict(policy=policy, worker_id=w, split="all", **summary_row(wrs, fields["baseline"]), **events(wrs, fields)))
            for s in ["development", "validation"]:
                rs = wrs[wrs.split == s]
                person_rows.append(dict(policy=policy, worker_id=w, split=s, **summary_row(rs, fields["baseline"]), **events(rs, fields)))
        for image_id, irs in ps.groupby("image_id"):
            image_rows.append(dict(policy=policy, image_id=image_id, image_code=irs.iloc[0].image_code,
                group_key=irs.iloc[0].group_key, split=irs.iloc[0].split, n_people=irs.worker_id.nunique(),
                mean_Q=irs[fields["baseline"]].mean(), SD_between_people=irs[fields["baseline"]].std(ddof=1),
                **events(irs, fields)))
        common = ps[np.isfinite(ps[qcols]).all(axis=1)]
        for q in qcols:
            for w, wrs in common.groupby("worker_id"):
                method_rows.append(dict(policy=policy, method=q, worker_id=w,
                    matched_across_methods=True, baseline=fields["baseline"],
                    **summary_row(wrs, q), mean_change_from_v11=float((wrs[q] - wrs[fields["baseline"]]).mean()),
                    low50_count=int((wrs[q] < 50).sum()), low50_n=len(wrs),
                    low50_rate=float((wrs[q] < 50).mean()) if len(wrs) else math.nan))
            for mode in ["fixed_split", "leave_group_out"]:
                fs, ds, st = transfer(ps, q, policy, mode)
                fold_rows.extend(fs)
                pred_rows.extend(ds)
                transfer_status.append(dict(policy=policy, method=q, fold_type=mode, status=st, folds=len(fs)))
    for filename, rows in [
        ("worker_condition_inventory_unmatched.csv", inventory_rows),
        ("worker_common_image_summary.csv", person_rows),
        ("common_image_summary.csv", image_rows),
        ("worker_formula_comparison_common_rows.csv", method_rows),
        ("held_group_prediction_summary.csv", fold_rows),
        ("held_group_predictions_per_worker.csv", pred_rows),
    ]:
        pd.DataFrame(rows).to_csv(args.out / filename, index=False, encoding="utf-8-sig")
    summary = dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),
        source_sha256=start_hashes, config=config, preregistration=pre,
        no_quality_parameter_fitting=True, no_personnel_classification=True,
        no_heldout_quality_selection=True, no_reference_or_gate_changes=True,
        no_geometry_changes=True, no_missing_filled_with_zero=True,
        main_panel_condition="manual", other_conditions_separate=True,
        panel_counts=panel_counts, transfer_status=transfer_status,
        raw_common_assignment_pool=dict(people=26,images=29,records=754),
        interpretation_limits=[
            "Across-image variability is not isolated worker noise.",
            "Historical duplicate versions do not establish independent same-image retesting.",
            "The fixed holdout contains one historical development image UwV83HsGsw3-09.",
            "Leave-group-out folds overlap and are not independent new observations.",
            "Held-image peer means are used only for relative-performance diagnosis, not pre-annotation prediction.",
            "Q<50 is a historical research band; event cutoffs are research scales, not human-confirmed severe-error labels.",
            "Panel is conditional on pre-existing qualifications and complete common-task coverage; excluded answers remain in the inventory.",
        ])
    summary["input_files_unchanged"] = all(sha(Path(p)) == h for p, h in start_hashes.items())
    assert summary["input_files_unchanged"]
    (args.out / "worker_analysis_run_summary.json").write_text(json.dumps(jsonsafe(summary), ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(jsonsafe(dict(panel_counts=panel_counts, transfer_status=transfer_status,
                                  input_files_unchanged=summary["input_files_unchanged"])), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
