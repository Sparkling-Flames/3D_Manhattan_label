#!/usr/bin/env python3
"""Small mechanism checks: held outcomes must not enter personnel predictions."""
from pathlib import Path
import argparse
import json

import numpy as np
import pandas as pd

from analyze_workers import transfer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    if args.out.exists():
        raise FileExistsError(args.out)
    rows = []
    for w, ability in zip(["A", "B", "C", "D"], [-9, -3, 4, 8]):
        for g, image_shift in zip(["G1", "G2", "G3", "G4"], [0, 7, -6, 14]):
            rows.append(dict(worker_id=w, group_key=g, image_id=g, image_code=g,
                             split="validation" if g == "G4" else "development",
                             Q=70 + ability + image_shift))
    data = pd.DataFrame(rows)
    f1, p1, st = transfer(data, "Q", "synthetic", "fixed_split")
    changed = data.copy()
    changed.loc[changed.group_key == "G4", "Q"] += 3
    f2, p2, st2 = transfer(changed, "Q", "synthetic", "fixed_split")
    a, b = pd.DataFrame(p1), pd.DataFrame(p2)
    perturbed = data.copy()
    perturbed.loc[(perturbed.group_key == "G4") & (perturbed.worker_id == "A"), "Q"] -= 12
    _, p3, _ = transfer(perturbed, "Q", "synthetic", "fixed_split")
    missing = data.copy()
    missing.loc[0, "Q"] = np.nan
    fm, pm, sm = transfer(missing, "Q", "synthetic", "fixed_split")
    checks = {
        "fixed_split_computed": st == st2 == "computed",
        "held_common_shift_cannot_change_training_prediction": np.array_equal(a.predicted_Q.to_numpy(), b.predicted_Q.to_numpy()),
        "held_individual_change_cannot_change_training_prediction": np.array_equal(a.predicted_Q.to_numpy(), pd.DataFrame(p3).predicted_Q.to_numpy()),
        "common_image_shift_cancels_only_in_relative_diagnostic": np.allclose(a.observed_relative, b.observed_relative, atol=1e-12),
        "additive_person_plus_image_fixture_has_zero_relative_error": f1[0]["relative_offset_MAE"] < 1e-12,
        "missing_Q_does_not_trigger_silent_complete_case_reselection": (not fm and not pm and sm == "missing_Q_kept_no_complete_case_panel_reselection"),
    }
    if not all(checks.values()):
        raise AssertionError(checks)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    result = dict(checks=checks, all_pass=True,
                  meaning="Statistical mechanism checks only; not an empirical personnel result or validation of the Q formula")
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
