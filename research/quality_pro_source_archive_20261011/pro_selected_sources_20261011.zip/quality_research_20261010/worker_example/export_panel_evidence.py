#!/usr/bin/env python3
"""Transparent component and failure evidence for the fixed 264-record panel."""
from pathlib import Path
import argparse
import hashlib
import json

import numpy as np
import pandas as pd


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--scores",required=True,type=Path)
    ap.add_argument("--panel-dir",required=True,type=Path)
    ap.add_argument("--out",required=True,type=Path)
    args=ap.parse_args()
    if args.out.exists() and any(args.out.iterdir()):raise FileExistsError(args.out)
    args.out.mkdir(parents=True,exist_ok=True)
    h=hashlib.sha256(args.scores.read_bytes()).hexdigest()
    source=pd.read_csv(args.scores,keep_default_na=False)
    ids=pd.read_csv(args.panel_dir/'initial_panel_records_264.csv').object_id
    a=source[source.object_id.isin(ids)].copy()
    assert len(a)==264 and a.object_id.is_unique
    metrics=['Q_v11','iou_2d','S_deg','Hstar','D_deg','F_deg','omission','extension']
    for k in metrics:a[k]=pd.to_numeric(a[k],errors='coerce')
    columns=[k for k in ['record_id','object_id','worker_id','image_code','image_id','condition',
              'selected_gt_object_id','selected_gt_version','selected_gt_coordinates_sha256',
              'current_coordinates_sha256','conservative_fixed_gt_primary_candidate',
              'target_aligned_primary_candidate','scope_primary_floor_changed','scope_top_pending',
              'score_status','annotation_projection_status','annotation_projection_reasons',
              'failure_classes','reason_codes'] if k in a]+metrics
    a[columns].to_csv(args.out/'panel_component_rows_264.csv',index=False,encoding='utf-8-sig')
    a[a.image_code=='UwV83HsGsw3-09'][columns].to_csv(args.out/'Uw09_component_rows_24.csv',index=False,encoding='utf-8-sig')
    a[a.Q_v11.isna()][columns].to_csv(args.out/'panel_failure_rows_1.csv',index=False,encoding='utf-8-sig')
    rows=[]
    for im,rs in a.groupby('image_code'):
        row={'image_code':im,'n_records':len(rs),'n_Q_finite':int(np.isfinite(rs.Q_v11).sum()),'Q_mean':rs.Q_v11.mean()}
        for k in metrics:
            good=rs.loc[np.isfinite(rs[k]),k]
            row[k+'_n']=len(good);row[k+'_median']=good.median()
        rows.append(row)
    pd.DataFrame(rows).to_csv(args.out/'panel_image_component_summary_11.csv',index=False,encoding='utf-8-sig')
    assert hashlib.sha256(args.scores.read_bytes()).hexdigest()==h
    result={'source_score_sha256':h,'panel_records':264,'component_summary_images':11,
            'Q_finite':int(np.isfinite(a.Q_v11).sum()),'source_unchanged':True,
            'failure_interpretation':'R01424 has available source coordinates outside the 512-pixel image; upstream projection failure is not file access failure. Legacy downstream missing rings remain in their original fields.',
            'median_interpretation':'Each component median has its own finite n; Q evaluated at medians was not computed; these are descriptive empirical summaries.'}
    (args.out/'evidence_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
