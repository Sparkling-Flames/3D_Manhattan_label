#!/usr/bin/env python3
"""Copy the minimal research deliverable without modifying any source artifact.

This packaging helper needs the completed research working tree. Recomputing
the delivered study uses the independent reproduce.py, not this helper.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    src, out = args.source_root.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    records, omitted = [], []
    excluded_names = {".git", "__pycache__", "vendor_dependencies", "comments.json"}
    mappings = [
        ("experiments", "experiments"),
        ("official_audit", "official_audit"),
        ("reference_scope", "reference_scope"),
        ("worker_example", "worker_example"),
        ("repo/research/quality_scope_comparison_20261010/frozen_engine", "repo/research/quality_scope_comparison_20261010/frozen_engine"),
        ("repo/research/quality_next_stage_handoff_20261010", "repo/research/quality_next_stage_handoff_20261010"),
        ("restored/quality_scope_review_complete_20261010/final_scope_reference_integration", "scope_integration"),
        ("deliverables/tables", "tables"),
    ]
    for source_name, dest_name in mappings:
        base = src / source_name
        for path in sorted(base.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(base)
            if any(p in excluded_names for p in rel.parts) or path.suffix in {".pyc", ".so"}:
                omitted.append({"source": str(path.relative_to(src)), "reason": "binary dependency, cache, or excluded source"})
                continue
            if source_name == "reference_scope" and rel.parts[0] == "workbook_build":
                omitted.append({"source": str(path.relative_to(src)), "reason": "workbook production handled separately"})
                continue
            dest = out / dest_name / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
            records.append({"bundle_path": str(dest.relative_to(out)), "source_relative_path": str(path.relative_to(src)),
                            "source_sha256": sha(path), "copied_sha256": sha(dest), "copy_is_byte_identical": True})
    # Preserve the fixed reference-selection CSV even though this sparse source
    # checkout has no materialized working-tree file at that path.
    rel = "analysis_results/objective_difficulty_20261009/structure_classification/images.csv"
    commit = "f485d49f0ccd57a7a7bf64931a81b770a37ff4df"
    raw = subprocess.check_output(["git", "show", commit + ":" + rel], cwd=src / "repo")
    dest = out / "repo" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    records.append({"bundle_path": str(dest.relative_to(out)), "source_git_commit": commit,
                    "source_git_path": rel, "source_sha256": hashlib.sha256(raw).hexdigest(),
                    "copied_sha256": sha(dest), "copy_is_byte_identical": True})
    # Small restore instructions and checksums, without the 17 archive parts.
    release = src / "repo/research/quality_scope_review_complete_20261010"
    for name in ["README.md", "ARCHIVE_PARTS.json", "BUNDLE_FILE_MANIFEST.json", "CHECKSUMS_SHA256.txt",
                 "CORE_FILE_INDEX.json", "PACKAGING_VALIDATION.json", "SUMMARY_FINAL.json", "restore_bundle.py", "verify_release.py"]:
        path = release / name
        dest = out / "upstream_release_manifest" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
        records.append({"bundle_path": str(dest.relative_to(out)), "source_relative_path": str(path.relative_to(src)),
                        "source_sha256": sha(path), "copied_sha256": sha(dest), "copy_is_byte_identical": True})
    (out / "provenance").mkdir()
    (out / "provenance/source_copy_manifest.json").write_text(json.dumps({"files": records,
        "source_file_edits": [], "source_scores_changed": False, "binary_dependencies_copied": False,
        "archive_parts_copied": False, "original_photo_library_copied": False,
        "omitted": omitted}, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"copied_files": len(records), "copied_bytes": sum(p.stat().st_size for p in out.rglob("*") if p.is_file()),
                      "actual_symlinks": sum(p.is_symlink() for p in out.rglob("*")), "out": str(out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
