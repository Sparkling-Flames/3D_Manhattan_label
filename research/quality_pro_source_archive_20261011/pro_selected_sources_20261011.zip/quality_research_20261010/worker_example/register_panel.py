#!/usr/bin/env python3
"""Select a common-image personnel panel without reading quality scores.

The input is the repository interpretation metadata, not a score table. The
current-loader reference policy is applied subsequently without replenishing
the panel. No record, GT, or qualification is modified.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


SEED = "quality-next-stage-20261011|"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("Refuse silent empty output: " + str(path))
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def eligible(row: dict) -> bool:
    return (
        row["worker_quality_gate"] == "candidate_pending_geometry"
        and row["cleaning_disposition"] == "retained"
        and row["independent_vote_eligible"] is True
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--metadata", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise FileExistsError("Use a new output directory")
    args.out.mkdir(parents=True, exist_ok=True)
    src_sha = digest(args.metadata)
    raw = json.loads(args.metadata.read_text(encoding="utf-8-sig"))
    annotations = raw["annotations"]
    images = raw["images"]
    assert len(annotations) == 3152 and len(images) == 259
    if any(any(k in r for k in ["Q", "Q_v11", "Q_v1_1", "quality_score"])
           for r in annotations):
        raise ValueError("This registrar must not ingest a score table")
    manual = [r for r in annotations if r["condition"] == "manual"]
    grouped = defaultdict(list)
    units = defaultdict(list)
    for row in annotations:
        units[(row["worker_id"], row["image_id"], row["condition"])].append(row)
    for row in manual:
        grouped[row["image_id"]].append(row)
    max_roster = max(len({r["worker_id"] for r in rs}) for rs in grouped.values())
    raw_pool = {im: rs for im, rs in grouped.items()
                if len({r["worker_id"] for r in rs}) == max_roster}
    rosters = {tuple(sorted({r["worker_id"] for r in rs})) for rs in raw_pool.values()}
    if len(rosters) != 1:
        raise ValueError("Maximum-coverage images do not share one roster")
    observed_roster = set(next(iter(rosters)))
    core_roster = {r["worker_id"] for rs in raw_pool.values() for r in rs if eligible(r)}
    selected = {im: rs for im, rs in raw_pool.items()
                if {r["worker_id"] for r in rs if eligible(r)} == core_roster}
    selected_records = []
    imap = {r["image_id"]: r for r in images}
    building_fallback = {r["building_id"] for r in images if not r.get("room_id")}
    image_rows = []
    for row in images:
        b, room = row["building_id"], row.get("room_id") or ""
        fallback = b in building_fallback
        key = f"building:{b}" if fallback else f"room:{b}:{room}"
        split_hash = hashlib.sha256((SEED + key).encode("utf-8")).hexdigest()
        split = "validation" if int(split_hash[:8], 16) % 3 == 0 else "development"
        image_rows.append(dict(image_id=row["image_id"], image_code=row["image_code"],
                               building_id=b, room_id=room, group_key=key,
                               group_basis="whole_building_due_to_missing_room" if fallback else "registered_room",
                               split=split, split_hash=split_hash,
                               in_maximum_coverage_pool=row["image_id"] in raw_pool,
                               in_initial_panel=row["image_id"] in selected))
    split_map = {r["image_id"]: r for r in image_rows}
    for image_id, rs in sorted(selected.items()):
        use = [r for r in rs if r["worker_id"] in core_roster and eligible(r)]
        if len(use) != len(core_roster) or len({r["worker_id"] for r in use}) != len(use):
            raise ValueError("Ambiguous accepted repeat in selected panel")
        for r in sorted(use, key=lambda r: r["worker_id"]):
            selected_records.append({**{k: r[k] for k in ["object_id", "worker_id", "image_id", "image_code", "condition", "building_id", "room_id", "cleaning_disposition", "worker_quality_gate", "independent_vote_eligible"]},
                                     "source_project": r["source"].get("project"),
                                     "group_key": split_map[image_id]["group_key"],
                                     "split": split_map[image_id]["split"]})
    availability = []
    for w in sorted(observed_roster):
        wrs = [r for rs in raw_pool.values() for r in rs if r["worker_id"] == w]
        availability.append(dict(worker_id=w, raw_pool_records=len(wrs),
                                 eligible_pool_records=sum(eligible(r) for r in wrs),
                                 selected_initial_roster=w in core_roster,
                                 initial_panel_records=sum(r["worker_id"] == w for r in selected_records),
                                 quality_gate_counts=json.dumps(Counter(r["worker_quality_gate"] for r in wrs), ensure_ascii=False)))
    duplicates = []
    for (w, im, c), rs in units.items():
        if len(rs) > 1:
            duplicates.append(dict(worker_id=w, image_id=im, image_code=rs[0]["image_code"],
                                   condition=c, raw_records=len(rs),
                                   eligible_current_records=sum(eligible(r) for r in rs),
                                   object_ids=json.dumps([r["object_id"] for r in rs]),
                                   cleaning_dispositions=json.dumps([r["cleaning_disposition"] for r in rs]),
                                   interpretation="historical_versions_not_verified_independent_retest"))
    within = defaultdict(set)
    for r in image_rows:
        within[r["group_key"]].add(r["split"])
    assert all(len(v) == 1 for v in within.values())
    for building in building_fallback:
        assert len({r["group_key"] for r in image_rows if r["building_id"] == building}) == 1
    assert digest(args.metadata) == src_sha
    write_csv(args.out / "initial_panel_records_264.csv", selected_records)
    write_csv(args.out / "initial_panel_images_11.csv", [r for r in image_rows if r["in_initial_panel"]])
    write_csv(args.out / "image_split_259.csv", image_rows)
    write_csv(args.out / "raw_roster_availability_26.csv", availability)
    write_csv(args.out / "duplicate_versions_12_groups.csv", duplicates)
    summary = dict(
        phase="outcome_blind_metadata_preregistration",
        timestamp_utc=datetime.now(timezone.utc).isoformat(),
        source=str(args.metadata.resolve()), source_sha256=src_sha,
        geometry_not_loaded=True, score_fields_read=[],
        metadata_must_be_reconciled_with_current_loader=True,
        final_reference_qualification_pending=True,
        split_seed=SEED, split_hash_rule="first_8_hex_sha256_integer_mod_3_eq_0_validation",
        raw_annotations=len(annotations), manual_annotations=len(manual),
        raw_workers=len({r["worker_id"] for r in annotations}),
        raw_manual_workers=len({r["worker_id"] for r in manual}),
        common_raw_images=len(raw_pool), common_raw_roster=len(observed_roster),
        eligible_roster=len(core_roster), initial_panel_images=len(selected),
        initial_panel_records=len(selected_records),
        initial_panel_image_codes=sorted(imap[i]["image_code"] for i in selected),
        selected_worker_ids=sorted(core_roster),
        initial_panel_image_split=dict(Counter(split_map[i]["split"] for i in selected)),
        initial_panel_group_split={s:len({split_map[i]["group_key"] for i in selected if split_map[i]["split"] == s}) for s in ["development","validation"]},
        building_fallback_count=len(building_fallback), building_fallback_ids=sorted(building_fallback),
        duplicate_version_groups=len(duplicates),
        eligible_duplicate_groups=sum(r["eligible_current_records"] > 1 for r in duplicates),
        verified_repeat_test_pairs=0,
        holdout_interpretation="not_used_for_this_round_personnel_fit; historical_images_not_blind_new_data",
        checks=dict(no_score_fields=True, no_group_crosses_split=True,
                    missing_room_buildings_not_split=True, metadata_unchanged=True),
        next_step="apply exact current-loader reference and formal gates; never replenish using Q values or calculability",
    )
    (args.out / "panel_preregistration.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
