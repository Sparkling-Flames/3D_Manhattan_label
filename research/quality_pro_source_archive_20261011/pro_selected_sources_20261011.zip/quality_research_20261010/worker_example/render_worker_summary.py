#!/usr/bin/env python3
"""Render descriptive personnel results; no scoring, fitting, or selection."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def f(x, n=2):
    return "不可算" if pd.isna(x) else f"{x:.{n}f}"


def rate(k, n):
    return f"{int(k)}/{int(n)}" if n else "无有效分母"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        raise FileExistsError("Use a new output directory")
    args.out.mkdir(parents=True, exist_ok=True)
    summary = json.loads((args.results / "worker_analysis_run_summary.json").read_text())
    q = summary["config"]["score_fields"]["baseline"]
    ps = pd.read_csv(args.results / "worker_common_image_summary.csv")
    pred = pd.read_csv(args.results / "held_group_prediction_summary.csv")
    full = pd.read_csv(args.results / "fixed_panel_264_all_statuses_and_scores.csv")
    perpred = pd.read_csv(args.results / "held_group_predictions_per_worker.csv")
    base_policy = "conservative_fixed_gt_primary_candidate"
    target_policy = "target_aligned_primary_candidate"
    allbase = ps[(ps.policy == base_policy) & (ps.split == "all")].sort_values("worker_id")
    target = ps[(ps.policy == target_policy) & (ps.split == "all")].sort_values("worker_id")
    counts = summary["panel_counts"]
    text = [
        "人员质量最小示例：共同图片、固定评分与分组留出",
        "",
        "核心结论",
        "",
        "已完成一个按人员/任务覆盖选定、在读取质量分前固定的共同图片分析。最可信的完整比较是24人×9张共同图片、216条有效结果。固定GT的11图主面板保留263个有效分及1条不可算；没有删掉不可算记录来凑完整面板。结果显示存在人员间差异，但平均分对这些留出房间组的绝对分预测较弱，跨图片的共同变化和人员×图片差异仍很大。不能把跨图片标准差当作纯人员噪声，也不能据此划定长期固定的人员类别。",
        "",
        "1. 样本与资格",
        "",
        "原始 manual 池有 2,344 条、27 人、232 图。最高覆盖的29图对应同一26人原始名单；沿既有 retained、independent 与主质量 gate，24人至少有一条合格记录，其共同资格完整的图为11张、264条。W019/W026在该池没有当前有效资格；W022不属于这个26人的共同任务池。这里不据他们的分数判断优劣。",
        "面板在读取Q前固化，之后仅叠加当前loader和参考版本登记；未因分数、缺失或人物表现补选图片/人员。完整3152条的条件分列清单保留在 worker_condition_inventory_unmatched.csv。manual、semi、oos没有混成一种人员均分；该全库描述表任务构成不齐，不能用于直接排名。",
        "另保留26人×29图、754条原始共同分配任务的资格、历史不接受、场景hold与计算失败计数。完整11图面板本身经过既有资格和完整覆盖筛选，不能把这个有效面板的均分或低分率称为所有原始作答的总体可靠率。",
    ]
    for pol, title in [(base_policy, "固定有效GT主面板"), (target_policy, "去除最新primary地面已变但top_pending图的敏感性")]:
        c = counts[pol]
        text.append(f"{title}：{c['n_people']}人 × {c['n_images']}图，{c['n_records']}条，{c['n_groups']}组、{c['n_buildings']}建筑；完整v1.1可算{c['n_finite_v11']}条。")
        text.append("图片：" + "、".join(c["image_codes"]) + "。")
    text += [
        "两套政策始终采用同一份几何与固定GT。rPc-06/-22最新确认了不同primary地面，但顶界未完成；9图敏感性不再用这两图评价人员。删除它们导致均值变化属于评价任务集合变化，不是Q公式改进，也不是新的顶界质量结果。",
        "11图的唯一不可算是rPc-22的W002/R01424：当前坐标含y=3897.2824，超出512像素画布，投影不可用。这是已读取输入的坐标域问题，不是文件访问失败；没有自动改回历史坐标。预先设置的完整面板保护停止了11图的平衡人员留出预测。9图的216条全部可算；这9图来自读Q前约定的范围政策敏感性，不是看到缺失后临时另选的图。",
        "",
        "2. 重复的含义与分组",
        "",
        "历史台账有12个 worker×image×condition 多版本组，但每组至多一条当前有资格记录；没有可据此确认的独立同图重测对。现有材料可以研究同一人员跨图片的表现，不能直接估计同图重测噪声。",
        "按既有room_id分组；一个建筑只要存在研究视角的room_id缺失，整栋建筑归入同一保守组，避免它与已知房间落到两侧。固定sha256种子在读Q前确定；11图面板为10图/8组 development、1图/1组 validation，9图敏感性为8图/7组与1图/1组。唯一固定留出图UwV83HsGsw3-09是历史六图/旧36份的开发图：它只是未用于本轮人员均值估计，绝不是此前从未看过的新盲测。",
        "",
        "3. 每人质量与波动（9张共同图片，v1.1）",
        "",
        "均值采用同一9图等权；SD为跨图样本标准差。另有按房间/保守建筑组等权均值，防止同组多视角被当成独立任务数。Q<50仅是历史研究低分线；几何大偏差率分列，不把它们冒充经过人工校准的严重错误标签。11图描述与其中W002只有10个有效分的分母差异完整保留在CSV，不能与9图完整匹配结果混用。",
        "人员   有效图  组  均值    中位    跨图SD   Q<50    IoU<0.5  S>8°  Hstar>1",
    ]
    for _, r in target.iterrows():
        text.append(f"{r.worker_id:5s}  {int(r.n_finite):2d}  {int(r.n_groups):2d}  {f(r.mean_Q):>6s}  {f(r.median_Q):>6s}  {f(r.across_image_SD):>7s}  "
                    + "  ".join([rate(r.Q_lt50_historical_low_band_count,r.Q_lt50_historical_low_band_n),
                                   rate(r.BEV_IoU_lt0p5_count,r.BEV_IoU_lt0p5_n),
                                   rate(r.S_gt8deg_count,r.S_gt8deg_n),
                                   rate(r.Hstar_gt1_count,r.Hstar_gt1_n)]))
    text += [
        "",
        "上述S>8°与Hstar>1对应明显偏离的研究尺度，并非已验证合格线；Hstar以GT周长加权平均墙高为分母，是无量纲相对误差。D/F的5°/2°没有当作严重错误界线。每人9个图片事件的计数分辨率为1/9；同房/同建筑相关性进一步限制有效独立证据，故未用独立伯努利假设给虚假的精密置信区间。Q<40、Q<60的频率敏感性见逐人CSV，不用它们选人或调Q。",
        "",
        "4. 固定留出和逐组留出的实际结果",
        "",
        "只用其他组上的每人平均Q预测被留出组的平均Q；比较不分人的全体训练均值常数预测。训练先在每组内平均，再各组等权。此处只估计最简单的人员均值，不拟合质量公式。",
    ]
    for pol, title in [(base_policy,"11图"),(target_policy,"9图敏感性")]:
        r = pred[(pred.policy==pol) & (pred.method==q) & (pred.fold_type=="fixed_split")]
        if len(r):
            r=r.iloc[0]
            text.append(f"{title}固定留出：24人预测均值与Uw-09实际Q的Spearman={f(r.spearman,3)}、Pearson={f(r.pearson,3)}；个人均值预测MAE={f(r.person_mean_MAE)}，统一常数MAE={f(r.constant_mean_MAE)}，差值改善={f(r.person_gain_MAE)}分（正值为改善）。只有1张留出图，不能据此认定普遍稳定。")
        folds = pred[(pred.policy==pol) & (pred.method==q) & (pred.fold_type=="leave_group_out")]
        if len(folds):
            text.append(f"{title}逐组留出：{len(folds)}个描述性折，Spearman范围 {f(folds.spearman.min(),3)} 至 {f(folds.spearman.max(),3)}；个人均值的绝对Q预测在{int((folds.person_gain_MAE>1e-8).sum())}/{len(folds)}组优于统一常数，逐组等权平均MAE改善={f(folds.person_gain_MAE.mean())}。浮点1e-8以内的差值记为数值相同。")
            text.append(f"去除留出图其他参与者共同均值后的相对偏差诊断：在{int((folds.relative_gain_MAE>1e-8).sum())}/{len(folds)}组优于零偏差基线，逐组等权平均MAE改善={f(folds.relative_gain_MAE.mean())}。留出图其他人的答案仅用于事后相对表现对照，这不是标注前质量预测。")
    text += [
        "逐组留出的训练集合相互重叠，各折也复用了相同24人；不能把24人×各折数视为独立新增样本。绝对Q预测会受到被留出图整体难度/目标差异影响；相对诊断减去同图共同变化，但仍保留人员×图片交互，也不能完成因果不确定性分解。",
        "",
        "5. 公式对照与适用边界",
        "",
        "worker_formula_comparison_common_rows.csv逐人比较同一资格、同一图集、各方法共同可算行上的候选均值和历史低分率；没有根据人员相关性选择Q。held_group_prediction_summary.csv保留各候选的固定与逐组留出结果。相关变大或人员间距变大不等于公式更准确，尤其不能以这24人的稳定排序优化规则。",
        "共同图片设计减少了人员任务构成不同这一层混淆，但结果仍条件于既有资格、选取的图片集合、固定GT、单目条件3D假设及当前采集阶段。11图并不是所有房型的代表抽样；9图敏感性仍不保证每个允许目标已经完全认证。原规则排除过的作答未算入人员低分分母，必须结合资格计数解释，不能把仅剩有效记录的均值称为完整作答可靠率。",
        "",
        "最小建议：保留人员逐次作答Q、同图/同条件匹配统计、有效分母与失败/排除理由；暂不固定人员类别。现有数据最欠缺的是在少量已完成参考认证、覆盖不同空间条件的新房间上，让同一批人各自独立重复作答至少两次。即使只增加少量共同任务，也比继续调整历史面板权重更能区分同图重测波动与跨图条件差异。",
        "",
        "6. 复算",
        "",
        "先由当前loader、参考policy与本轮冻结候选生成3152表；再运行 analyze_workers.py --admission <admission_3152.csv> --scores <本轮3152分数表> --panel-dir <preregistered> --config <worker_analysis_config_units_corrected.json> --out <新目录>。输入hash与候选列名完整记录在worker_analysis_run_summary.json。register_panel.py可从原metadata重建不看Q的初始面板；check_transfer_invariants.py检查留出信息未进入训练预测、共同图片偏移仅在相对诊断抵消、缺失不会触发偷偷重选。",
    ]
    (args.out / "人员质量最小示例_中文报告.txt").write_text("\n".join(text)+"\n",encoding="utf-8")
    # Exportable scientific figures; all values are literal current-run scores.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size":9, "figure.dpi":150, "savefig.dpi":180})
    order = list(allbase.worker_id)
    mat = full.pivot(index="worker_id",columns="image_code",values=q).reindex(order)
    fig, ax = plt.subplots(figsize=(12.6,8.2))
    h=ax.imshow(mat.to_numpy(),vmin=0,vmax=100,cmap="viridis",aspect="auto")
    labels=[c+" *" if c in ["rPc6DW4iMge-06","rPc6DW4iMge-22"] else c for c in mat.columns]
    ax.set_xticks(range(len(mat.columns)),labels,rotation=50,ha="right")
    ax.set_yticks(range(len(mat.index)),mat.index)
    ax.set_title("Fixed common-image panel: v1.1 Q (24 workers × 11 images)")
    ax.set_xlabel("* Changed primary floor; ceiling pending. Both rPc views are excluded by the 9-image policy.",fontsize=8)
    for i in range(len(mat)):
        for j in range(len(mat.columns)):
            v=mat.iloc[i,j]
            ax.text(j,i,"NA" if pd.isna(v) else f"{v:.0f}",ha="center",va="center",fontsize=6.5,color="white" if v<52 else "black")
    fig.colorbar(h,ax=ax,label="Q (fixed reference, 0–100)")
    fig.tight_layout()
    fig.savefig(args.out/"worker_common_panel_heatmap.png")
    plt.close(fig)
    df=perpred[(perpred.policy==target_policy)&(perpred.method==q)&(perpred.fold_type=="fixed_split")]
    fig,ax=plt.subplots(figsize=(7.7,6.1))
    ax.scatter(df.predicted_Q,df.observed_Q,s=30,color="#235c83")
    for _,r in df[df.worker_id.isin(["W001","W002","W012","W027"])].iterrows():
        ax.annotate(r.worker_id,(r.predicted_Q,r.observed_Q),xytext=(3,2),textcoords="offset points",fontsize=8)
    lo=min(df.predicted_Q.min(),df.observed_Q.min())-3; hi=max(df.predicted_Q.max(),df.observed_Q.max())+3
    ax.plot([lo,hi],[lo,hi],"--",color="gray",lw=1)
    ax.set(xlim=(lo,hi),ylim=(lo,hi),xlabel="Mean Q on 7 other groups (8 images; equal group weights)",ylabel="Held image Uw-09 Q",title="Nine-image policy: one historical-image holdout")
    ax.text(.02,.97,"One held image; not independent blind validation",transform=ax.transAxes,va="top",fontsize=8)
    ax.text(.02,.93,"All 24 workers shown; four examples labelled",transform=ax.transAxes,va="top",fontsize=8)
    fig.tight_layout();fig.savefig(args.out/"worker_fixed_holdout.png");plt.close(fig)
    print(json.dumps({"report":str(args.out/"人员质量最小示例_中文报告.txt"),"figures":2},ensure_ascii=False))


if __name__=="__main__":main()
